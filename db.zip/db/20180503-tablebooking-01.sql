

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";



CREATE TABLE `tbl_admin` (
  `Id` int(11) NOT NULL,
  `UserName` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `status` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `tbl_admin` (`Id`, `UserName`, `Email`, `Password`, `status`) VALUES
(1, 'Admin', 'admin@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 1);



CREATE TABLE `tbl_clubgallery` (
  `Id` int(11) NOT NULL,
  `VendorId` int(11) DEFAULT NULL,
  `Image` varchar(255) DEFAULT NULL,
  `Created` date DEFAULT NULL,
  `Status` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



CREATE TABLE `tbl_clublayout` (
  `Id` int(11) NOT NULL,
  `VendorId` int(11) DEFAULT NULL,
  `nooftables` varchar(255) DEFAULT NULL,
  `noofpax` varchar(255) DEFAULT NULL,
  `mainimage` varchar(255) DEFAULT NULL,
  `Created` date DEFAULT NULL,
  `Description` text,
  `AvailableParking` varchar(255) DEFAULT NULL,
  `PriceParkingPerhrs` varchar(255) DEFAULT NULL,
  `SundayFrom` varchar(255) DEFAULT NULL,
  `SundayTo` varchar(255) DEFAULT NULL,
  `SundayFromClose` varchar(255) DEFAULT NULL,
  `SundayToClose` varchar(255) DEFAULT NULL,
  `MondayFrom` varchar(255) DEFAULT NULL,
  `MondayTo` varchar(255) DEFAULT NULL,
  `MondayFromClose` varchar(255) DEFAULT NULL,
  `MondayToClose` varchar(255) DEFAULT NULL,
  `TuesdayFrom` varchar(255) DEFAULT NULL,
  `TuesdayTo` varchar(255) DEFAULT NULL,
  `TuesdayFromClose` varchar(255) DEFAULT NULL,
  `TuesdayToClose` varchar(255) DEFAULT NULL,
  `WednesdayFrom` varchar(255) DEFAULT NULL,
  `WednesdayTo` varchar(255) DEFAULT NULL,
  `WednesdayFromClose` varchar(255) DEFAULT NULL,
  `WednesdayToClose` varchar(255) DEFAULT NULL,
  `ThursdayFrom` varchar(255) DEFAULT NULL,
  `ThursdayTo` varchar(255) DEFAULT NULL,
  `ThursdayFromClose` varchar(255) DEFAULT NULL,
  `ThursdayToClose` varchar(255) DEFAULT NULL,
  `FridayFrom` varchar(255) DEFAULT NULL,
  `FridayTo` varchar(255) DEFAULT NULL,
  `FridayFromClose` varchar(255) DEFAULT NULL,
  `FridayToClose` varchar(255) DEFAULT NULL,
  `SaturdayFrom` varchar(255) DEFAULT NULL,
  `SaturdayTo` varchar(255) DEFAULT NULL,
  `SaturdayFromClose` varchar(255) DEFAULT NULL,
  `SaturdayToClose` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `tbl_customer` (
  `Id` int(11) NOT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Phone` varchar(50) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Fbloginkey` varchar(255) DEFAULT NULL,
  `Gploginkey` varchar(255) DEFAULT NULL,
  `Status` int(5) DEFAULT NULL,
  `Created` date DEFAULT NULL,
  `FirstName` varchar(255) DEFAULT NULL,
  `LastName` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `tbl_vendor` (
  `Id` int(11) NOT NULL,
  `FirstName` varchar(255) DEFAULT NULL,
  `LastName` varchar(255) DEFAULT NULL,
  `ClubName` varchar(255) DEFAULT NULL,
  `City` varchar(255) DEFAULT NULL,
  `State` varchar(255) DEFAULT NULL,
  `Country` varchar(255) DEFAULT NULL,
  `Phone` varchar(40) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Created` date DEFAULT NULL,
  `Status` int(5) DEFAULT NULL,
  `PaymentStatus` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `AlternativePhone` varchar(50) DEFAULT NULL,
  `PostCode` varchar(50) DEFAULT NULL,
  `AddressIfram` text,
  `ContactName` varchar(255) DEFAULT NULL,
  `Address` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`Id`);

ALTER TABLE `tbl_clubgallery`
  ADD PRIMARY KEY (`Id`);


ALTER TABLE `tbl_clublayout`
  ADD PRIMARY KEY (`Id`);

ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`Id`);


ALTER TABLE `tbl_vendor`
  ADD PRIMARY KEY (`Id`);


ALTER TABLE `tbl_admin`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;


ALTER TABLE `tbl_clubgallery`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;


ALTER TABLE `tbl_clublayout`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

ALTER TABLE `tbl_customer`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;


ALTER TABLE `tbl_vendor`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
  
  ALTER TABLE `tbl_vendor` ADD `Slug` VARCHAR(255) NULL AFTER `Address`;

ALTER TABLE `tbl_admin` CHANGE `status` `Status` INT(5) NULL DEFAULT NULL;
ALTER TABLE `tbl_clublayout` CHANGE `nooftables` `NoofTables` VARCHAR(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL, CHANGE `noofpax` `NoofPax` VARCHAR(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL, CHANGE `mainimage` `MainImage` VARCHAR(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL;
  
  ALTER TABLE `tbl_clublayout` ADD `PerAdultPrice` VARCHAR(255) NULL AFTER `SaturdayToClose`, ADD `PerChildPrice` VARCHAR(255) NULL AFTER `PerAdultPrice`;
ALTER TABLE `tbl_clublayout` ADD `Cuisines` TEXT NULL AFTER `PerChildPrice`;
  
COMMIT;

