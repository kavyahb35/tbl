
CREATE TABLE `tbl_events` (
  `Id` int(11) NOT NULL,
  `ClubId` int(11) DEFAULT NULL,
  `Title` varbinary(255) DEFAULT NULL,
  `Description` text,
  `FromDate` date DEFAULT NULL,
  `ToDate` date DEFAULT NULL,
  `NoofDays` varchar(255) DEFAULT NULL,
  `OneDate` date DEFAULT NULL,
  `TimeFrom` varchar(255) DEFAULT NULL,
  `TimeTo` varchar(255) DEFAULT NULL,
  `Image` varchar(255) DEFAULT NULL,
  `Status` int(5) DEFAULT NULL,
  `Created` date DEFAULT NULL,
  `Price` varchar(255) DEFAULT NULL,
  `Slug` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


ALTER TABLE `tbl_events`
  ADD PRIMARY KEY (`Id`);

ALTER TABLE `tbl_events` ADD `eventtype` VARCHAR(255) NULL AFTER `Slug`;

ALTER TABLE `tbl_events`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
  ALTER TABLE `tbl_events` CHANGE `Title` `Title` VARCHAR(255) NULL DEFAULT NULL;
COMMIT;

