

CREATE TABLE `tbl_reviews` (
  `Id` int(11) NOT NULL,
  `ClubId` int(11) DEFAULT NULL,
  `BookingId` int(11) DEFAULT NULL,
  `Review` varchar(50) DEFAULT NULL,
  `Reviewscomment` text,
  `PublishStatus` int(5) DEFAULT NULL,
  `Created` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


ALTER TABLE `tbl_reviews`
  ADD PRIMARY KEY (`Id`);

ALTER TABLE `tbl_reviews`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

