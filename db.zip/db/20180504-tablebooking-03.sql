
CREATE TABLE `tbl_fooditem` (
  `Id` int(11) NOT NULL,
  `ClubId` int(11) DEFAULT NULL,
  `CategoryId` int(11) DEFAULT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Slug` varchar(255) DEFAULT NULL,
  `Price` varchar(255) DEFAULT NULL,
  `Image` varchar(255) DEFAULT NULL,
  `Status` int(5) DEFAULT NULL,
  `Created` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `tbl_fooditem`
  ADD PRIMARY KEY (`Id`);


ALTER TABLE `tbl_fooditem`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

