

CREATE TABLE `tbl_booking` (
  `Id` int(11) NOT NULL,
  `ClubId` int(11) DEFAULT NULL,
  `FirstName` varchar(255) DEFAULT NULL,
  `LastName` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Phone` varchar(50) DEFAULT NULL,
  `BookingDate` varchar(255) DEFAULT NULL,
  `BookingTime` varchar(255) DEFAULT NULL,
  `NoofPax` varchar(50) DEFAULT NULL,
  `DiningPreferences` varchar(255) DEFAULT NULL,
  `Created` datetime DEFAULT NULL,
  `Status` int(5) DEFAULT NULL,
  `BookingStatus` int(5) DEFAULT NULL,
  `BillAmount` varchar(255) DEFAULT NULL,
  `Noofitems` varchar(255) DEFAULT NULL,
  `OTP` varchar(50) DEFAULT NULL,
  `CancelReason` text,
  `CancelDate` varchar(255) DEFAULT NULL,
  `ModifyDate` varchar(255) DEFAULT NULL,
  `CustomerId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


ALTER TABLE `tbl_booking`
  ADD PRIMARY KEY (`Id`);


ALTER TABLE `tbl_booking`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
  
  ALTER TABLE `tbl_customer` ADD `OTP` VARCHAR(255) NULL AFTER `LastName`;
  
  ALTER TABLE `tbl_customer` ADD `Slug` VARCHAR(255) NULL AFTER `OTP`;

  ALTER TABLE `tbl_customer` ADD `ProfileImage` VARCHAR(255) NULL AFTER `Slug`;

  ALTER TABLE `tbl_customer` ADD `Address` TEXT NULL AFTER `ProfileImage`, ADD `Yourself` TEXT NULL AFTER `Address`;
COMMIT;
