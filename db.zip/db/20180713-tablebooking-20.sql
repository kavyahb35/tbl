-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 13, 2018 at 03:43 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tablefastbooking9`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ticket_purches`
--

CREATE TABLE `tbl_ticket_purches` (
  `Id` int(11) NOT NULL,
  `CustomerId` int(11) DEFAULT NULL,
  `ClubId` int(11) DEFAULT NULL,
  `EventId` int(11) DEFAULT NULL,
  `EventType` int(11) DEFAULT NULL,
  `Amount` varchar(255) DEFAULT NULL,
  `Comment` text,
  `Created` varchar(255) DEFAULT NULL,
  `Status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_ticket_purches`
--
ALTER TABLE `tbl_ticket_purches`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_ticket_purches`
--
ALTER TABLE `tbl_ticket_purches`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;


ALTER TABLE `tbl_clublayout` ADD `facebook` TEXT NULL AFTER `BookingNoTable`, ADD `googleplus` TEXT NULL AFTER `facebook`, ADD `twitter` TEXT NULL AFTER `googleplus`, ADD `linked` TEXT NULL AFTER `twitter`, ADD `youtube` TEXT NULL AFTER `linked`, ADD `vimeo` TEXT NULL AFTER `youtube`, ADD `instagram` TEXT NULL AFTER `vimeo`;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
