
CREATE TABLE `tbl_reviewsimages` (
  `Id` int(11) NOT NULL,
  `ReviewId` int(11) DEFAULT NULL,
  `Image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `tbl_reviewsimages`
  ADD PRIMARY KEY (`Id`);


ALTER TABLE `tbl_reviewsimages`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
  
  ALTER TABLE `tbl_booking` ADD `BookingNo` VARCHAR(255) NULL AFTER `ClubId`;
  
  ALTER TABLE  `tbl_booking` ADD  `CompletedDate` DATETIME NOT NULL ;
  
  
  ALTER TABLE `tbl_vendor` ADD `txnid` VARCHAR(255) NULL AFTER `Slug`, ADD `payment_amount` VARCHAR(255) NULL AFTER `txnid`, ADD `payment_status` VARCHAR(255) NULL AFTER `payment_amount`, ADD `itemidv` VARCHAR(255) NULL AFTER `payment_status`;
COMMIT;

