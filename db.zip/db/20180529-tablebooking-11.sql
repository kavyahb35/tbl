
CREATE TABLE `tbl_banner` (
  `Id` int(11) NOT NULL,
  `BannerImage` varchar(255) DEFAULT NULL,
  `Status` int(5) DEFAULT NULL,
  `Created` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `tbl_banner`
  ADD PRIMARY KEY (`Id`);

ALTER TABLE `tbl_banner`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

