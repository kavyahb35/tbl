

CREATE TABLE `tbl_facility` (
  `Id` int(11) NOT NULL,
  `ClubId` int(11) DEFAULT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Description` text,
  `Status` int(5) DEFAULT NULL,
  `Created` date DEFAULT NULL,
  `Slug` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


ALTER TABLE `tbl_facility`
  ADD PRIMARY KEY (`Id`);


ALTER TABLE `tbl_facility`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

