-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 03, 2018 at 04:58 AM
-- Server version: 5.6.39-cll-lve
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tablefastdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `Id` int(11) NOT NULL,
  `UserName` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Status` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`Id`, `UserName`, `Email`, `Password`, `Status`) VALUES
(1, 'Admin', 'admin@gmail.com', '0192023a7bbd73250516f069df18b500', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_banner`
--

CREATE TABLE `tbl_banner` (
  `Id` int(11) NOT NULL,
  `BannerImage` varchar(255) DEFAULT NULL,
  `Status` int(5) DEFAULT NULL,
  `Created` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_banner`
--

INSERT INTO `tbl_banner` (`Id`, `BannerImage`, `Status`, `Created`) VALUES
(1, 'banner_1.jpg', 1, NULL),
(2, 'banner_2.jpg', 1, NULL),
(3, 'banner_3.jpg', 1, NULL),
(4, 'Banner_4.jpg', 1, NULL),
(5, 'banner_5.jpg', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_booking`
--

CREATE TABLE `tbl_booking` (
  `Id` int(11) NOT NULL,
  `ClubId` int(11) DEFAULT NULL,
  `BookingNo` varchar(255) DEFAULT NULL,
  `FirstName` varchar(255) DEFAULT NULL,
  `LastName` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Phone` varchar(50) DEFAULT NULL,
  `BookingDate` varchar(255) DEFAULT NULL,
  `BookingTime` varchar(255) DEFAULT NULL,
  `NoofPax` varchar(50) DEFAULT NULL,
  `DiningPreferences` varchar(255) DEFAULT NULL,
  `Created` datetime DEFAULT NULL,
  `Status` int(5) DEFAULT NULL,
  `BookingStatus` int(5) DEFAULT NULL,
  `BillAmount` varchar(255) DEFAULT NULL,
  `Noofitems` varchar(255) DEFAULT NULL,
  `OTP` varchar(50) DEFAULT NULL,
  `CancelReason` text,
  `CancelDate` varchar(255) DEFAULT NULL,
  `ModifyDate` varchar(255) DEFAULT NULL,
  `CustomerId` int(11) DEFAULT NULL,
  `CompletedDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_booking`
--

INSERT INTO `tbl_booking` (`Id`, `ClubId`, `BookingNo`, `FirstName`, `LastName`, `Email`, `Phone`, `BookingDate`, `BookingTime`, `NoofPax`, `DiningPreferences`, `Created`, `Status`, `BookingStatus`, `BillAmount`, `Noofitems`, `OTP`, `CancelReason`, `CancelDate`, `ModifyDate`, `CustomerId`, `CompletedDate`) VALUES
(1, 9, '1', 'Bhavna', 'Baria', 'rahulcueserve6@gmail.com', '7600988598', '2018-05-18', '08:00 PM', '4', 'outdoor', '2018-05-16 06:22:00', 1, 5, NULL, NULL, '2442', NULL, NULL, NULL, 2, '2018-05-21 00:00:00'),
(2, 3, '1', 'Bhavna', 'Baria', 'rahulcueserve6@gmail.com', '7600988598', '2018-05-24', '06:00 PM', '2', NULL, '2018-05-16 07:06:00', 1, 0, NULL, NULL, '2722', NULL, NULL, '2018-05-16 07:17', 2, '0000-00-00 00:00:00'),
(3, 9, '2', 'Bhavna', 'Baria', 'rahulcueserve6@gmail.com', '7600988598', '2018-05-28', '07:30 PM', '2', 'indoor', '2018-05-16 12:01:00', 1, 3, NULL, NULL, '3708', 'Not provide good facility.', '2018-05-16 13:20', NULL, 2, '0000-00-00 00:00:00'),
(4, 9, '3', 'Test@123 Test@123 Test@123 Test@123', 'Test@123Test@123Test@123Test@123Test@123', 'rahulcueserve6@gmail.com', '1234567890', '2018-05-31', '05:40 PM', '19', 'outdoor', '2018-05-16 12:11:00', 0, 0, NULL, NULL, '4372', NULL, NULL, NULL, 2, '0000-00-00 00:00:00'),
(5, 9, '4', 'Test@123 Test@123 Test@123 Test@123', 'Test@123Test@123Test@123Test@123Test@123', 'rahulcueserve6@gmail.com', '1234567890', '2018-05-31', '05:40 PM', '19', 'outdoor', '2018-05-16 12:22:00', 0, 0, NULL, NULL, '3211', NULL, NULL, NULL, 2, '0000-00-00 00:00:00'),
(6, 9, '5', 'Test@123 Test@123 Test@123 Test@123', 'Test@123Test@123Test@123Test@123Test@123', 'rahulcueserve6@gmail.com', '7600988598', '2018-06-15', '06:00 PM', '19', 'outdoor', '2018-05-16 12:32:00', 0, 0, NULL, NULL, '4493', NULL, NULL, NULL, 2, '0000-00-00 00:00:00'),
(8, 9, '6', 'Bhavna', 'Baria', 'rahulcueserve6@gmail.com', '7600988598', '2018-05-28', '07:22 AM', '10', 'indoor', '2018-05-16 13:52:00', 1, 3, NULL, NULL, '2751', 'rtewrwr', '2018-05-31 13:17', NULL, 2, '0000-00-00 00:00:00'),
(9, 9, '7', 'Bhavna', 'Baria', 'rahulcueserve6@gmail.com', '7600988598', '2018-06-1', '07:30 PM', '15', 'outdoor', '2018-05-16 13:56:00', 1, 2, NULL, NULL, '3711', NULL, NULL, NULL, 2, '0000-00-00 00:00:00'),
(10, 9, '10', 'Sumit', 'Patel', 'cue.sumit.patel@gmail.com', '7600988598', '2018-05-23', '04:30 PM', '2', 'outdoor', '2018-05-21 11:17:00', 0, 0, NULL, NULL, '2543', NULL, NULL, NULL, 3, '0000-00-00 00:00:00'),
(11, 9, '11', 'Sumit', 'Patel', 'cue.sumit.patel@gmail.com', '7600988598', '2018-05-23', '04:30 PM', '2', 'outdoor', '2018-05-21 11:17:00', 0, 0, NULL, NULL, '2340', NULL, NULL, NULL, 3, '0000-00-00 00:00:00'),
(12, 9, '12', 'Sumit', 'Patel', 'cue.sumit.patel@gmail.com', '7600988598', '2018-05-23', '04:30 PM', '2', 'outdoor', '2018-05-21 11:17:00', 0, 0, NULL, NULL, '4385', NULL, NULL, NULL, 3, '0000-00-00 00:00:00'),
(13, 9, '13', 'Unnati', 'Rana', 'ranaunnati04@gmail.com', '7600988598', '2018-05-25', '04:30 PM', '4', 'outdoor', '2018-05-21 11:18:00', 1, 1, NULL, NULL, '2784', NULL, NULL, NULL, 3, '0000-00-00 00:00:00'),
(14, 9, '14', 'Unnati', 'Rana', 'ranaunnati04@gmail.com', '7600988598', '2018-05-24', '06:30 PM', '5', 'indoor', '2018-05-21 11:27:00', 1, 0, NULL, NULL, '2648', NULL, NULL, NULL, 3, '0000-00-00 00:00:00'),
(15, 9, '15', 'qwerty', 'qwerty', 'qwert@qwrty.com', '1234567890', '2018-06-13', '02:56 PM', '2', 'indoor', '2018-05-29 17:49:00', 0, 0, NULL, NULL, '2789', NULL, NULL, NULL, 4, '0000-00-00 00:00:00'),
(16, 12, '1', 'rahul', 'baria', 'kamg@gmail.com', '9033155801', '2018-05-31', '11:24 AM', '2', 'outdoor', '2018-05-31 05:54:00', 0, 0, NULL, NULL, '3252', NULL, NULL, NULL, 5, '0000-00-00 00:00:00'),
(17, 19, '1', 'Bhavna', 'Baria', 'rahulcueserve6@gmail.com', '6351346285', '2018-05-31', '04:37 PM', '2', NULL, '2018-05-31 13:06:00', 1, 5, NULL, NULL, '4227', NULL, NULL, '2018-05-31 13:13', 2, '2018-05-31 13:18:14'),
(18, 2, '1', 'bhavna', 'baria', 'kam@gmail.com', '9033155801', '2018-06-01', '11:13 AM', '2', 'outdoor', '2018-06-01 10:13:00', 0, 0, NULL, NULL, '3204', NULL, NULL, NULL, 5, '0000-00-00 00:00:00'),
(19, 2, '19', 'test', 'test', 'test@g.c', '5675675656', '2018-06-01', '01:14 PM', '2', 'outdoor', '2018-06-01 11:13:00', 0, 0, NULL, NULL, '2771', NULL, NULL, NULL, 6, '0000-00-00 00:00:00'),
(20, 2, '20', 'kavya', 'hb', 'kavyahb@gmail.com', '87735353535', '2018-06-27', '09:50 AM', '2', 'outdoor', '2018-06-07 09:50:00', 0, 0, NULL, NULL, '3274', NULL, NULL, NULL, 7, '0000-00-00 00:00:00'),
(21, 2, '21', 'Joy', 'Vidal', 'vidal.joy14@gmail.com', '+97477484850', '2018-07-07', '03:00 PM', '2', 'outdoor', '2018-07-07 15:29:00', 0, 0, NULL, NULL, '2809', NULL, NULL, NULL, 15, '0000-00-00 00:00:00'),
(22, 32, '1', 'Joy', 'Vidal', 'joy.vidal16@gmail.com', '97477484850', '2018-07-09', '12:30 PM', '2', NULL, '2018-07-08 17:01:00', 1, 0, NULL, NULL, '2827', 'gsagdasjhdsa', '2018-07-08 13:56', '2018-07-09 18:39', 14, '0000-00-00 00:00:00'),
(23, 23, '1', 'Joy', 'Vidal', 'joy.vidal16@gmail.com', '97477484850', '2018-07-08', '02:49 PM', '2', NULL, '2018-07-08 17:19:00', 0, 0, NULL, NULL, '3392', NULL, NULL, NULL, 14, '0000-00-00 00:00:00'),
(24, 23, '24', 'Joy', 'Vidal', 'joy.vidal16@gmail.com', '97477484850', '2018-07-08', '02:49 PM', '2', NULL, '2018-07-08 17:19:00', 0, 0, NULL, NULL, '3601', NULL, NULL, NULL, 14, '0000-00-00 00:00:00'),
(25, 2, '22', 'Joy', 'Vidal', 'joy.vidal16@gmail.com', '97477484850', '2018-07-08', '04:30 PM', '2', 'outdoor', '2018-07-08 19:28:00', 0, 0, NULL, NULL, '2952', NULL, NULL, NULL, 14, '0000-00-00 00:00:00'),
(26, 2, '26', 'Joy', 'Vidal', 'joy.vidal16@gmail.com', '97477484850', '2018-07-14', '01:45 PM', '2', 'outdoor', '2018-07-09 16:29:00', 1, 1, NULL, NULL, '2459', NULL, NULL, NULL, 14, '0000-00-00 00:00:00'),
(27, 2, '27', 'kavya', 'baria', 'bhavna@cueserve.com', '9033155801', '2018-07-18', '04:33 PM', '2', 'outdoor', '2018-07-09 16:33:00', 1, 0, NULL, NULL, '2390', NULL, NULL, NULL, 5, '0000-00-00 00:00:00'),
(28, 2, '28', 'Joy', 'Vidal', 'joy.vidal16@gmail.com', '+97477484850', '2018-07-09', '04:11 PM', '2', 'outdoor', '2018-07-09 18:41:00', 0, 0, NULL, NULL, '4015', NULL, NULL, NULL, 15, '0000-00-00 00:00:00'),
(29, 2, '29', 'Joy', 'Vidal', 'joy.vidal16@gmail.com', '97477484850', '2018-07-09', '05:31 PM', '2', 'outdoor', '2018-07-09 20:02:00', 1, 1, NULL, NULL, '3509', NULL, NULL, NULL, 14, '0000-00-00 00:00:00'),
(30, 32, '23', 'Joy', 'Vidal', 'joy.vidal16@gmail.co', '+97477484850', '2018-07-10', '12:12 PM', '2', NULL, '2018-07-10 13:43:00', 0, 0, NULL, NULL, '2880', NULL, NULL, NULL, 15, '0000-00-00 00:00:00'),
(31, 2, '30', 'bhavna', 'baria', 'bhavna1@cueserve.com', '9033155801', '2018-07-18', '10:13 AM', '1', 'outdoor', '2018-07-11 10:13:00', 1, 0, NULL, NULL, '3524', NULL, NULL, NULL, 5, '0000-00-00 00:00:00'),
(32, 2, '32', 'bhavna', 'baria', 'bhavna1@cueserve.com', '9033155801', '2018-07-19', '10:13 AM', '2', 'outdoor', '2018-07-11 10:14:00', 1, 0, NULL, NULL, '2974', NULL, NULL, NULL, 5, '0000-00-00 00:00:00'),
(33, 2, '33', 'neha', 'baria', 'neha@gmail.com', '4334535801', '2018-07-18', '10:14 AM', '2', 'outdoor', '2018-07-11 10:15:00', 1, 0, NULL, NULL, '2492', NULL, NULL, NULL, 16, '0000-00-00 00:00:00'),
(34, 2, '34', 'Joy', 'Vidal', 'joy.vidal16@gmail.co', '+97477484850', '2018-07-12', '07:30 PM', '--Select No. of Pax--', 'outdoor', '2018-07-12 17:15:00', 0, 0, NULL, NULL, '2967', NULL, NULL, NULL, 15, '0000-00-00 00:00:00'),
(35, 2, '35', 'Joahn Marie', 'Senerpida', 'joahnsenerpida@gmail.com', '97430131368', '2018-08-16', '07:00 PM', '2', 'outdoor', '2018-07-17 16:36:00', 1, 0, NULL, NULL, '3698', NULL, NULL, NULL, 17, '0000-00-00 00:00:00'),
(36, 45, '1', 'Bhavna', 'Baria', 'sumit@cueserve.com', '1122334455', '2018-08-03', '04:18 PM', '1', 'outdoor', '2018-08-03 16:18:00', 1, 0, NULL, NULL, '4106', NULL, NULL, NULL, 2, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_booking_calender`
--

CREATE TABLE `tbl_booking_calender` (
  `Id` int(11) NOT NULL,
  `VendorId` int(11) DEFAULT NULL,
  `BookingDate` varchar(255) DEFAULT NULL,
  `NobTable` int(6) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_booking_calender`
--

INSERT INTO `tbl_booking_calender` (`Id`, `VendorId`, `BookingDate`, `NobTable`) VALUES
(1, 2, '2018-07-18', 4),
(2, 2, '2018-07-19', 1),
(3, 2, '2018-08-16', 1),
(4, 45, '2018-08-03', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_clubgallery`
--

CREATE TABLE `tbl_clubgallery` (
  `Id` int(11) NOT NULL,
  `VendorId` int(11) DEFAULT NULL,
  `Image` varchar(255) DEFAULT NULL,
  `Created` date DEFAULT NULL,
  `Status` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_clubgallery`
--

INSERT INTO `tbl_clubgallery` (`Id`, `VendorId`, `Image`, `Created`, `Status`) VALUES
(14, 2, 'cS-50.jpg', '2018-05-02', 1),
(17, 3, 'cS-241.jpg', '2018-05-03', 1),
(19, 3, 'cS-261.jpg', '2018-05-03', 1),
(21, 3, 'cS-281.jpg', '2018-05-03', 1),
(22, 3, 'cS-291.jpg', '2018-05-03', 1),
(28, 4, 'cS-44.jpg', '2018-05-03', 1),
(33, 5, 'cS-31.jpg', '2018-05-03', 1),
(34, 5, 'cS-321.jpg', '2018-05-03', 1),
(36, 5, 'cS-34.jpg', '2018-05-03', 1),
(46, 1, '7a75dcab80175660d6a974c2a08a8978_featured_v2.jpg', '2018-05-04', 1),
(47, 1, '18-59edfa78c9f56b4ad6f726c6.jpg', '2018-05-04', 1),
(48, 1, '1950-american-diner-forte-dei-marmi-a-01f72.jpg', '2018-05-04', 1),
(49, 1, '1950-american-diner-pontedera-d-4295e.jpg', '2018-05-04', 1),
(50, 1, 'america-graffiti-bologna.jpg', '2018-05-04', 1),
(51, 1, 'Classic-Elegant-Restaurant-Iterior-Design-with-Romantic-Fine-Dining-Experience-of-Roxys-Diner-Las-Vegas-Dining-Area_(1).jpg', '2018-05-04', 1),
(52, 1, 'restaurants-bars-stratosphere-hotel-casino-v539793-720.jpg', '2018-05-04', 1),
(53, 1, 'restaurants-bars-stratosphere-hotel-casino-v539800-720.jpg', '2018-05-04', 1),
(54, 2, 'cS-281.jpeg', '2018-05-04', 1),
(55, 2, 'cS-322.jpg', '2018-05-04', 1),
(56, 2, 'cS-2811.jpg', '2018-05-04', 1),
(57, 2, 'cS-2911.jpg', '2018-05-04', 1),
(58, 2, 'cS-3111.jpg', '2018-05-04', 1),
(59, 2, 'n010064_2017dec15_new-york-hotel-parkside-diner_16-9.jpg', '2018-05-04', 1),
(60, 3, 'cS-252.jpg', '2018-05-04', 1),
(61, 3, 'cS-282.jpeg', '2018-05-04', 1),
(62, 3, 'moab-s-diner.jpg', '2018-05-04', 1),
(63, 3, 'Moderne_Burger_Diner_Vancouver.jpg', '2018-05-04', 1),
(64, 3, 'n010064_2017dec15_new-york-hotel-parkside-diner_16-91.jpg', '2018-05-04', 1),
(65, 3, 'new-britain-diner-restaurant.jpg', '2018-05-04', 1),
(66, 4, '08.jpg', '2018-05-04', 1),
(67, 4, 'cS-201.jpg', '2018-05-04', 1),
(68, 4, 'cS-242.jpg', '2018-05-04', 1),
(69, 4, 'cS-253.jpg', '2018-05-04', 1),
(70, 4, 'cS-283.jpeg', '2018-05-04', 1),
(71, 4, 'electric-diner.jpg', '2018-05-04', 1),
(72, 4, 'moab-diner.jpg', '2018-05-04', 1),
(73, 5, '7.jpg', '2018-05-04', 1),
(74, 5, '081.jpg', '2018-05-04', 1),
(75, 5, '8.jpg', '2018-05-04', 1),
(76, 5, '10.jpg', '2018-05-04', 1),
(77, 5, '11.jpg', '2018-05-04', 1),
(78, 6, '1.jpg', '2018-05-04', 1),
(79, 6, '2.jpg', '2018-05-04', 1),
(80, 6, '3.jpg', '2018-05-04', 1),
(81, 6, '4.jpg', '2018-05-04', 1),
(82, 6, '5.jpg', '2018-05-04', 1),
(83, 6, '71.jpg', '2018-05-04', 1),
(84, 6, '082.jpg', '2018-05-04', 1),
(85, 6, '81.jpg', '2018-05-04', 1),
(86, 6, '111.jpg', '2018-05-04', 1),
(90, 9, '31.jpg', '2018-05-15', 1),
(91, 9, '6.jpg', '2018-05-15', 1),
(92, 9, '21.jpg', '2018-05-15', 1),
(93, 9, 'cS-441.jpg', '2018-05-15', 1),
(94, 9, 'cS-472.jpg', '2018-05-15', 1),
(109, 21, '61.jpg', '2018-05-30', 1),
(110, 21, '101.jpg', '2018-05-30', 1),
(111, 21, '112.jpg', '2018-05-30', 1),
(112, 21, '311.jpg', '2018-05-30', 1),
(113, 22, '12.jpg', '2018-05-30', 1),
(114, 22, '22.jpg', '2018-05-30', 1),
(115, 22, '32.jpg', '2018-05-30', 1),
(116, 22, '41.jpg', '2018-05-30', 1),
(117, 22, '51.jpg', '2018-05-30', 1),
(118, 22, '62.jpg', '2018-05-30', 1),
(119, 23, '63.jpg', '2018-05-30', 1),
(120, 23, '72.jpg', '2018-05-30', 1),
(121, 23, '7a75dcab80175660d6a974c2a08a8978_featured_v21.jpg', '2018-05-30', 1),
(122, 23, '18-59edfa78c9f56b4ad6f726c61.jpg', '2018-05-30', 1),
(126, 27, 'b13.jpg', '2018-05-30', 1),
(127, 27, 'b23.jpg', '2018-05-30', 1),
(128, 27, 'b33.jpg', '2018-05-30', 1),
(129, 19, 'b24.jpg', '2018-05-31', 1),
(130, 19, 'b34.jpg', '2018-05-31', 1),
(131, 19, 'b52.jpg', '2018-05-31', 1),
(141, 32, 'b16.jpg', '2018-06-11', 1),
(142, 32, 'b27.jpg', '2018-06-11', 1),
(143, 32, 'b36.jpg', '2018-06-11', 1),
(144, 35, '083.jpg', '2018-07-02', 1),
(145, 35, '82.jpg', '2018-07-02', 1),
(146, 35, '18-59edfa78c9f56b4ad6f726c62.jpg', '2018-07-02', 1),
(147, 35, '211.jpg', '2018-07-02', 1),
(148, 35, '1527920762.png', '2018-07-02', 1),
(149, 35, '1527921250.png', '2018-07-02', 1),
(150, 36, '084.jpg', '2018-07-02', 1),
(151, 36, '83.jpg', '2018-07-02', 1),
(152, 37, 'Fullscreen_capture_5312018_30521_AM.bmp.jpg', '2018-07-02', 1),
(168, 44, '24.jpg', '2018-07-29', 1),
(169, 46, '14.jpg', '2018-07-31', 1),
(170, 46, '25.jpg', '2018-07-31', 1),
(171, 46, '1035fba3c8d85ef59438cedd9dd00974.jpg', '2018-07-31', 1),
(177, 45, '16.jpg', '2018-07-31', 1),
(179, 45, '35.jpg', '2018-07-31', 1),
(180, 45, '64.jpg', '2018-07-31', 1),
(182, 47, '60313288.jpg', '2018-07-31', 1),
(183, 47, 'download_(1).jpg', '2018-07-31', 1),
(184, 47, 'download.jpg', '2018-07-31', 1),
(185, 47, 'Shangri-La_Hotel,_Doha_-_Main_Pool_-_1082928_(2).jpg', '2018-07-31', 1),
(186, 47, 'Shangri-La_Hotel,_Doha_-_Main_Pool_-_1082928.jpg', '2018-07-31', 1),
(187, 47, 'shangri-la-hotel-doha---childrens-pool---1.jpg', '2018-07-31', 1),
(188, 47, 'SLM-PooL-Bar.jpg', '2018-07-31', 1),
(189, 47, 'wp-1456578806320.jpg', '2018-07-31', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_clublayout`
--

CREATE TABLE `tbl_clublayout` (
  `Id` int(11) NOT NULL,
  `VendorId` int(11) DEFAULT NULL,
  `NoofTables` varchar(255) DEFAULT NULL,
  `NoofPax` varchar(255) DEFAULT NULL,
  `MainImage` varchar(255) DEFAULT NULL,
  `Created` date DEFAULT NULL,
  `Description` text,
  `AvailableParking` varchar(255) DEFAULT NULL,
  `PriceParkingPerhrs` varchar(255) DEFAULT NULL,
  `SundayFrom` varchar(255) DEFAULT NULL,
  `SundayTo` varchar(255) DEFAULT NULL,
  `SundayFromClose` varchar(255) DEFAULT NULL,
  `SundayToClose` varchar(255) DEFAULT NULL,
  `MondayFrom` varchar(255) DEFAULT NULL,
  `MondayTo` varchar(255) DEFAULT NULL,
  `MondayFromClose` varchar(255) DEFAULT NULL,
  `MondayToClose` varchar(255) DEFAULT NULL,
  `TuesdayFrom` varchar(255) DEFAULT NULL,
  `TuesdayTo` varchar(255) DEFAULT NULL,
  `TuesdayFromClose` varchar(255) DEFAULT NULL,
  `TuesdayToClose` varchar(255) DEFAULT NULL,
  `WednesdayFrom` varchar(255) DEFAULT NULL,
  `WednesdayTo` varchar(255) DEFAULT NULL,
  `WednesdayFromClose` varchar(255) DEFAULT NULL,
  `WednesdayToClose` varchar(255) DEFAULT NULL,
  `ThursdayFrom` varchar(255) DEFAULT NULL,
  `ThursdayTo` varchar(255) DEFAULT NULL,
  `ThursdayFromClose` varchar(255) DEFAULT NULL,
  `ThursdayToClose` varchar(255) DEFAULT NULL,
  `FridayFrom` varchar(255) DEFAULT NULL,
  `FridayTo` varchar(255) DEFAULT NULL,
  `FridayFromClose` varchar(255) DEFAULT NULL,
  `FridayToClose` varchar(255) DEFAULT NULL,
  `SaturdayFrom` varchar(255) DEFAULT NULL,
  `SaturdayTo` varchar(255) DEFAULT NULL,
  `SaturdayFromClose` varchar(255) DEFAULT NULL,
  `SaturdayToClose` varchar(255) DEFAULT NULL,
  `PerAdultPrice` varchar(255) DEFAULT NULL,
  `PerChildPrice` varchar(255) DEFAULT NULL,
  `Cuisines` text,
  `NumTable` int(5) DEFAULT '0',
  `BookingNoTable` int(5) DEFAULT '0',
  `facebook` text,
  `googleplus` text,
  `twitter` text,
  `linked` text,
  `youtube` text,
  `vimeo` text,
  `instagram` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_clublayout`
--

INSERT INTO `tbl_clublayout` (`Id`, `VendorId`, `NoofTables`, `NoofPax`, `MainImage`, `Created`, `Description`, `AvailableParking`, `PriceParkingPerhrs`, `SundayFrom`, `SundayTo`, `SundayFromClose`, `SundayToClose`, `MondayFrom`, `MondayTo`, `MondayFromClose`, `MondayToClose`, `TuesdayFrom`, `TuesdayTo`, `TuesdayFromClose`, `TuesdayToClose`, `WednesdayFrom`, `WednesdayTo`, `WednesdayFromClose`, `WednesdayToClose`, `ThursdayFrom`, `ThursdayTo`, `ThursdayFromClose`, `ThursdayToClose`, `FridayFrom`, `FridayTo`, `FridayFromClose`, `FridayToClose`, `SaturdayFrom`, `SaturdayTo`, `SaturdayFromClose`, `SaturdayToClose`, `PerAdultPrice`, `PerChildPrice`, `Cuisines`, `NumTable`, `BookingNoTable`, `facebook`, `googleplus`, `twitter`, `linked`, `youtube`, `vimeo`, `instagram`) VALUES
(1, 1, '6', NULL, '1527932153.jpg', '2018-07-15', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil atque modi velit molestiae, repellendus iure sint possimus cumque, provident, dolorum unde laboriosam ut eius ex maiores quod repudiandae aut asperiores?Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil atque modi velit molestiae, repellendus iure sint possimus cumque, provident, dolorum unde laboriosam ut eius ex maiores quod repudiandae aut asperiores?Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil atque modi velit molestiae, repellendus iure sint possimus cumque, provident, dolorum unde laboriosam ut eius ex maiores quod repudiandae aut asperiores?Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil atque modi velit molestiae, repellendus iure sint possimus cumque, provident, dolorum unde laboriosam ut eius ex maiores quod repudiandae aut asperiores?Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil atque modi velit molestiae, repellendus iure sint possimus cumque, provident, dolorum unde laboriosam ut eius ex maiores quod repudiandae aut asperiores?</p>\r\n', 'no', '', '10:32 AM', '07:32 PM', '07:32 AM', '10:33 PM', '07:32 AM', '07:32 PM', '07:33 AM', '10:33 PM', '07:32 AM', '07:32 PM', '07:33 AM', '10:33 PM', '07:32 AM', '07:32 PM', '07:33 AM', '07:33 PM', '07:32 AM', '07:32 PM', '08:33 AM', '07:33 PM', '07:32 AM', '07:32 PM', '07:33 AM', '07:33 PM', '07:32 AM', '07:32 PM', '07:33 AM', '07:33 PM', '1200', '1', 'Continental, North Indian, Italian, Chinese', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 2, 'indoor', '1', '1530958065.png', '2018-07-19', '                                                                                                                                                                        <p>This information is especially important for those travelling to your accommodation by car.This information is especially important for those travelling to your accommodation by car.This information is especially important for those travelling to your accommodation by car.This information is especially important for those travelling to your accommodation by car.This information is especially important for those travelling to your accommodation by car.</p>\r\n                                                                                                                                                            ', 'no', '', '07:36 AM', '07:36 PM', '07:37 AM', '07:37 PM', '07:36 AM', '07:36 PM', '07:37 AM', '07:37 PM', '07:36 AM', '07:36 PM', '07:37 AM', '07:37 PM', '07:36 AM', '07:36 PM', '07:37 AM', '07:37 PM', '07:36 AM', '07:36 PM', '07:37 AM', '07:37 PM', '07:37 AM', '07:37 PM', '07:37 AM', '07:37 AM', '07:37 AM', '07:37 PM', '07:37 AM', '07:37 PM', '1400', '1', 'North Indian, Continental, Mughlai', 60, 0, 'https://www.facebook.com', '', '', '', '', '', ''),
(3, 3, '9', NULL, '1527932408.jpg', '2018-06-02', '<p>This information is especially important for those travelling to your accommodation by car.This information is especially important for those travelling to your accommodation by car.This information is especially important for those travelling to your accommodation by car.This information is especially important for those travelling to your accommodation by car.This information is especially important for those travelling to your accommodation by car.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>This information is especially important for those travelling to your accommodation by car.</p>\r\n', 'no', '', '11:25 AM', '06:25 PM', '04:26 AM', '07:26 PM', '04:26 AM', '06:26 PM', '06:27 AM', '08:27 PM', '04:26 AM', '06:26 PM', '04:27 AM', '08:27 PM', '09:26 AM', '06:26 PM', '04:27 AM', '07:27 PM', '04:26 AM', '09:26 PM', '05:27 AM', '08:27 PM', '06:26 AM', '09:26 PM', '06:27 AM', '09:27 PM', '08:26 AM', '11:26 PM', '04:27 AM', '11:27 PM', '1590', '1', 'North Indian, Italian, Chinese', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 4, '9', NULL, '1527932482.jpg', '2018-06-02', '<p>This information is especially important for those travelling to your accommodation by car.This information is especially important for those travelling to your accommodation by car.This information is especially important for those travelling to your accommodation by car.This information is especially important for those travelling to your accommodation by car.This information is especially important for those travelling to your accommodation by car.This information is especially important for those travelling to your accommodation by car.</p>\r\n', 'free', '', '04:30 PM', '04:30 PM', '04:30 PM', '04:30 PM', '04:30 PM', '04:30 PM', '04:30 PM', '04:30 PM', '04:30 PM', '04:30 PM', '04:30 PM', '04:30 PM', '04:30 PM', '04:30 PM', '04:30 PM', '04:30 PM', '04:30 PM', '04:30 PM', '04:30 PM', '04:30 PM', '04:30 PM', '04:30 PM', '04:30 PM', '04:30 AM', '04:30 PM', '04:30 PM', '04:31 PM', '04:31 PM', '1700', '1', 'Italian, Asian, Grill', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 5, '90', NULL, '1527932572.jpg', '2018-06-02', '<p>Located in the heart of the famous caldera of Imerovigli, Annabel&#39;s Luxury Suites feature modern accommodation with Cycladic elements and full views of the Aegean Sea and the volcano.</p>\r\n\r\n<p>Located in the heart of the famous caldera of Imerovigli, Annabel&#39;s Luxury Suites feature modern accommodation with Cycladic elements and full views of the Aegean Sea and the volcano.</p>\r\n\r\n<p>Located in the heart of the famous caldera of Imerovigli, Annabel&#39;s Luxury Suites feature modern accommodation with Cycladic elements and full views of the Aegean Sea and the volcano.</p>\r\n\r\n<p>Located in the heart of the famous caldera of Imerovigli, Annabel&#39;s Luxury Suites feature modern accommodation with Cycladic elements and full views of the Aegean Sea and the volcano.</p>\r\n', 'free', '', '04:53 PM', '04:53 PM', '04:53 PM', '04:53 PM', '04:53 PM', '04:53 PM', '04:53 PM', '04:53 PM', '04:53 PM', '04:53 PM', '04:53 PM', '04:53 PM', '04:53 PM', '04:53 PM', '04:53 PM', '04:53 PM', '04:53 PM', '04:53 PM', '04:53 PM', '04:53 PM', '04:53 PM', '04:53 PM', '04:53 PM', '04:53 AM', '04:53 PM', '04:53 PM', '04:53 PM', '04:53 PM', '1000', '1', 'Continental, North Indian, Chinese', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 6, '89', NULL, '1527932628.jpg', '2018-06-02', '<p>Located in the heart of the famous caldera of Imerovigli, Annabel&#39;s Luxury Suites feature modern accommodation with Cycladic elements and full views of the Aegean Sea and the volcano.</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil atque modi velit molestiae, repellendus iure sint possimus cumque, provident, dolorum unde laboriosam ut eius ex maiores quod repudiandae aut asperiores?</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil atque modi velit molestiae, repellendus iure sint possimus cumque, provident, dolorum unde laboriosam ut eius ex maiores quod repudiandae aut asperiores?</p>\r\n\r\n<p>Located in the heart of the famous caldera of Imerovigli, Annabel&#39;s Luxury Suites feature modern accommodation with Cycladic elements and full views of the Aegean Sea and the volcano.</p>\r\n', 'no', '', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '04:56 PM', '1500', '1', 'Italian, Asian, Grill, Chinese', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 9, NULL, '1', '1527932716.jpg', '2018-06-02', '<p>This is for testing purpose. Please ignore it.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<div id=\"selenium-highlight\">&nbsp;</div>\r\n', 'paid', '20', '04:03 AM', '09:03 PM', '04:03 AM', '09:03 PM', '04:03 AM', '09:03 PM', '04:03 AM', '09:03 PM', '04:03 AM', '09:03 PM', '04:03 AM', '09:03 PM', '04:03 AM', '09:03 PM', '04:03 AM', '09:03 PM', '04:03 AM', '09:03 PM', '04:03 AM', '09:03 PM', '04:03 AM', '09:03 PM', '04:03 AM', '09:03 PM', '04:03 AM', '09:03 PM', '04:03 AM', '09:03 PM', '390', '1', 'Italian, Asian, Grill, Chinese', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 10, NULL, '1', '1527932759.jpg', '2018-06-02', '<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n', 'paid', '10', '10:00 AM', '10:00 PM', '10:00 AM', '10:00 PM', '10:00 AM', '10:00 PM', '10:00 AM', '10:00 PM', '10:00 AM', '10:00 PM', '10:00 AM', '10:00 PM', '10:00 AM', '10:00 PM', '10:00 AM', '10:00 PM', '10:00 AM', '10:00 PM', '10:00 AM', '10:00 PM', '10:00 AM', '10:00 PM', '10:00 AM', '10:00 PM', '10:00 AM', '10:00 PM', '10:00 AM', '10:00 PM', '1500', '1', 'Italian, Asian, Grill, Chinese', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(11, 12, NULL, '1', '1527932801.jpg', '2018-06-02', '<p>This is for testing purpose. Please ignore it.</p>\r\n\r\n<div id=\"selenium-highlight\">&nbsp;</div>\r\n', 'no', '', '09:00 AM', '10:00 PM', '09:00 AM', '10:00 PM', '09:00 AM', '10:00 PM', '09:00 AM', '10:00 PM', '09:00 AM', '10:00 PM', '09:00 AM', '10:00 PM', '09:00 AM', '10:00 PM', '09:00 AM', '10:00 PM', '09:00 AM', '10:00 PM', '09:00 AM', '10:00 PM', '09:00 AM', '10:00 PM', '09:00 AM', '10:00 PM', '09:00 AM', '10:00 PM', '09:00 AM', '10:00 PM', '500', '1', 'Italian, maxican and chinese', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(14, 17, NULL, NULL, 'IMG_2841.JPG', '2018-05-28', '<p>good place</p>\r\n', 'no', '', '03:23 PM', '03:23 AM', '03:24 PM', '03:24 PM', '03:23 AM', '03:23 PM', '03:24 PM', '03:24 PM', '03:24 AM', '03:24 PM', '03:24 PM', '03:24 PM', '03:23 PM', '03:23 PM', '03:24 PM', '03:24 PM', '03:24 PM', '03:24 PM', '03:24 PM', '03:24 PM', '03:24 PM', '03:24 PM', '03:24 PM', '03:24 PM', '03:24 PM', '03:24 PM', '03:24 PM', '03:24 PM', '1000', '1', 'italian', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(16, 20, NULL, NULL, '11.jpg', '2018-05-29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '54', '1', 'Italian, Asian, Grill, Chinese', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(17, 21, NULL, NULL, '1527932993.jpg', '2018-06-02', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil atque modi velit molestiae, repellendus iure sint possimus cumque, provident, dolorum unde laboriosam ut eius ex maiores quod repudiandae aut asperiores?</p>\r\n', 'no', '', '03:25 PM', '03:25 PM', '03:25 PM', '03:25 PM', '03:25 PM', '03:25 PM', '03:25 PM', '03:25 PM', '03:25 PM', '03:25 PM', '03:25 PM', '03:25 PM', '03:25 PM', '03:25 PM', '03:25 PM', '03:25 PM', '03:25 PM', '03:25 PM', '03:25 PM', '03:25 PM', '03:25 PM', '03:25 PM', '03:25 PM', '03:25 AM', '03:25 PM', '03:25 PM', '03:25 PM', '03:25 AM', '1500', '1', 'Italian, Asian, Grill, Chinese', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(18, 22, NULL, '1', '1527933073.jpg', '2018-06-02', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil atque modi velit molestiae, repellendus iure sint possimus cumque, provident, dolorum unde laboriosam ut eius ex maiores quod repudiandae aut asperiores.</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil atque modi velit molestiae, repellendus iure sint possimus cumque, provident, dolorum unde laboriosam ut eius ex maiores quod repudiandae aut asperiores</p>\r\n', 'no', '', '09:40 AM', '11:40 PM', '03:40 PM', '03:40 PM', '09:40 AM', '11:40 PM', '03:40 PM', '03:40 PM', '09:40 AM', '11:40 PM', '03:40 PM', '03:40 PM', '09:40 AM', '11:40 PM', '03:40 PM', '03:40 PM', '09:40 AM', '11:40 PM', '03:40 PM', '03:40 PM', '09:40 AM', '11:40 PM', '03:40 PM', '03:40 PM', '09:40 AM', '11:40 PM', '03:40 PM', '03:40 PM', '1500', '1', 'North Indian, Continental, Mughlai', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(19, 23, NULL, NULL, '1527933143.jpg', '2018-06-02', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil atque modi velit molestiae, repellendus iure sint possimus cumque, provident, dolorum unde laboriosam ut eius ex maiores quod repudiandae aut asperiores</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil atque modi velit molestiae, repellendus iure sint possimus cumque, provident, dolorum unde laboriosam ut eius ex maiores quod repudiandae aut asperiores</p>\r\n', 'no', '', '03:50 AM', '10:50 PM', '03:50 PM', '03:50 PM', '03:50 AM', '10:50 PM', '03:50 PM', '03:50 PM', '03:50 AM', '10:50 PM', '03:50 PM', '03:50 PM', '03:50 AM', '10:50 PM', '03:50 PM', '03:50 PM', '03:50 AM', '10:50 PM', '03:50 PM', '03:50 PM', '03:50 AM', '10:50 PM', '03:50 PM', '03:50 PM', '03:50 AM', '10:50 PM', '03:50 PM', '03:50 PM', '1000', '1', 'North Indian, Continental, Mughlai', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21, 27, NULL, '1', 'banner1.jpg', '2018-06-07', '<p>This is for test. Please ignore it.</p>\r\n', 'no', '', '10:00 AM', '09:00 PM', '10:00 AM', '09:00 PM', '10:00 AM', '09:00 PM', '10:00 AM', '09:00 PM', '10:00 AM', '09:00 PM', '10:00 AM', '09:00 PM', '10:00 AM', '09:00 PM', '10:00 AM', '09:00 PM', '10:00 AM', '09:00 PM', '10:00 AM', '09:00 PM', '10:00 AM', '09:00 PM', '10:00 AM', '09:00 PM', '10:00 AM', '09:00 PM', '10:00 AM', '09:00 PM', '1000', '2', 'Mexican, Italian and Chinese', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(22, 19, NULL, NULL, '1527932845.jpg', '2018-06-02', ' Friendly Staff, Prompt Service', 'no', '', '06:04 AM', '09:04 PM', '06:05 PM', '06:05 PM', '07:04 AM', '10:04 PM', '06:05 PM', '06:05 PM', '06:00 AM', '10:04 PM', '06:05 PM', '06:05 PM', '06:00 AM', '10:04 PM', '06:05 PM', '06:05 PM', '06:00 AM', '10:04 PM', '06:05 PM', '06:05 PM', '06:00 AM', '10:04 PM', '06:05 PM', '06:05 PM', '06:00 AM', '10:04 PM', '06:05 PM', '06:05 PM', '900', '1', 'Continental, Mexican, North Indian', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(23, 28, NULL, NULL, '1530527063.jpg', '2018-06-06', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil atque modi velit molestiae, repellendus iure sint possimus cumque, provide                           ', 'no', '', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '01:52 PM', '1200', '1', 'North Indian, Continental, Mughlai', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(27, 32, NULL, NULL, '1528701440.jpg', '2018-06-11', 'This is for club descriptions                                          ', 'no', '', '07:49 AM', '12:49 PM', '12:50 PM', '12:50 PM', '07:49 AM', '12:50 PM', '12:50 PM', '12:50 PM', '07:49 AM', '12:50 PM', '12:50 PM', '12:50 PM', '07:49 AM', '12:50 PM', '12:50 PM', '12:50 PM', '07:49 AM', '12:50 PM', '12:50 PM', '12:50 PM', '07:49 AM', '12:50 PM', '12:50 PM', '12:50 PM', '07:49 AM', '12:50 PM', '12:50 PM', '12:50 PM', '1000', '1', 'mughli, chinies, sea food', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(28, 34, NULL, '1', '1530527063.jpg', '2018-06-30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '350', '1', 'Test', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(29, 35, NULL, NULL, '1530518919.jpg', '2018-07-02', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil atque modi velit molestiae, repellendus iure sint possimus cumque, provident, dolorum unde laboriosam ut eius ex maiores quod repudiandae aut asperiores', 'no', '', '01:39 PM', '09:39 PM', '01:40 PM', '01:40 PM', '01:39 PM', '09:39 PM', '01:40 PM', '01:40 PM', '01:40 PM', '09:39 PM', '01:40 PM', '01:40 PM', '01:40 PM', '09:39 PM', '01:40 PM', '01:40 PM', '01:40 PM', '09:39 PM', '01:40 PM', '01:40 PM', '01:40 PM', '09:39 PM', '01:40 PM', '01:40 PM', '01:40 PM', '09:39 PM', '01:40 PM', '01:40 PM', '1500', '1', 'Italian, Asian, Grill, Chinese', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(30, 36, NULL, NULL, '1530527063.jpg', '2018-07-02', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil atque modi velit molestiae, repellendus iure sint possimus cumque, provident, dolorum unde laboriosam ut eius ex                                              ', 'no', '', '01:46 PM', '09:46 PM', '01:47 PM', '01:47 PM', '01:46 PM', '09:46 PM', '01:47 PM', '01:47 PM', '01:46 PM', '09:46 PM', '01:47 PM', '01:47 PM', '01:46 PM', '09:46 PM', '01:47 PM', '01:47 PM', '01:46 PM', '09:46 PM', '01:47 PM', '01:47 PM', '01:46 PM', '09:46 PM', '01:47 PM', '01:47 PM', '01:47 PM', '09:46 PM', '01:47 PM', '01:47 PM', '1400', '1', 'North Indian, Continental, Mughlai', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(31, 37, NULL, '1', '1530527063.jpg', '2018-07-02', '                                                      Filipino cuisine', 'no', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '500', '10', 'Filipino', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(32, 44, NULL, '1', '1533030279.jpg', '2018-07-31', '<p>With a sleek and stylish interior, amazing Cantonese cuisine, creative fusion bar food, great drinks and popular DJs, Shanghai Club always draws a hip crowd, and Chinese food lovers. It&rsquo;s a perfect venue for an authentic dim sum lunch, after-work drinks, a sumptuous dinner or classy private parties.</p>\r\n', 'free', '', '07:00 AM', '12:30 AM', '12:30 AM', '07:00 AM', '07:00 AM', '12:30 AM', '12:30 AM', '07:00 AM', '07:00 AM', '12:30 AM', '12:30 AM', '07:00 AM', '07:00 AM', '12:30 AM', '12:30 AM', '07:00 AM', '07:00 AM', '12:30 AM', '12:30 AM', '07:00 AM', '07:00 AM', '12:30 AM', '12:30 AM', '07:00 AM', '07:00 AM', '12:30 AM', '12:30 AM', '07:00 AM', 'Starts at QAR 500', '9', 'Chinese Cuisines', 25, 0, 'https://www.facebook.com/shangrilahoteldoha/', '', '', '', '', '', ''),
(33, 45, NULL, '1', '1533030235.jpg', '2018-07-31', '<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries</p>\r\n', 'no', '', '06:57 AM', '06:58 PM', '06:58 PM', '06:58 PM', '06:58 AM', '06:58 PM', '06:58 PM', '06:58 PM', '06:58 AM', '06:58 PM', '06:58 PM', '06:58 PM', '06:58 AM', '06:58 PM', '06:58 PM', '06:58 PM', '06:58 AM', '06:58 PM', '06:58 PM', '06:58 PM', '06:58 AM', '06:58 PM', '06:58 PM', '06:58 PM', '06:58 AM', '06:58 PM', '06:58 PM', '06:58 PM', '1500', '1', 'North Indian, Continental, Mughlai', 100, 0, 'https://www.facebook.com', '', '', '', '', '', ''),
(34, 46, NULL, '1', '1533030326.jpg', '2018-07-31', '<p>Begin the day with a lovely breakfast, or while away an hour or two in the afternoon with a selection of fine teas, coffees and cold beverages, as well as a choice of delicious cakes and pastries, at the splendid Lobby Lounge.&nbsp;</p>\r\n', 'no', '', '07:30 AM', '12:30 AM', '12:31 AM', '07:29 AM', '07:30 AM', '12:30 AM', '12:31 AM', '07:29 AM', '07:30 AM', '12:30 AM', '12:31 AM', '07:29 AM', '07:30 AM', '12:30 AM', '12:31 AM', '07:29 AM', '07:30 AM', '12:30 AM', '12:31 AM', '07:29 AM', '07:30 AM', '12:30 AM', '12:31 AM', '07:29 AM', '07:30 AM', '12:30 AM', '12:31 AM', '07:29 AM', 'Starts at QAR 500', '7', 'Chinese Cuisine', 25, 0, 'https://www.facebook.com/shangrilahoteldoha/', '', '', '', '', '', ''),
(35, 47, NULL, '1', '1533049352.jpg', '2018-07-31', '<p>Relax at the breezy outdoor poolside lounge, which serves light snacks and beverages throughout the day.</p>\r\n', 'free', '', '07:30 AM', '12:30 AM', '12:31 AM', '07:29 AM', '07:30 AM', '12:30 AM', '12:31 AM', '07:29 AM', '07:30 AM', '12:30 AM', '12:31 AM', '07:29 AM', '07:30 AM', '12:30 AM', '12:31 AM', '07:29 AM', '07:30 AM', '12:30 AM', '12:31 AM', '07:29 AM', '07:30 AM', '12:30 AM', '12:31 AM', '07:29 AM', '07:30 AM', '12:30 AM', '12:31 AM', '07:29 AM', 'Starts at 500', '8', 'Chinese Cuisines', 25, 0, 'https://www.facebook.com/shangrilahoteldoha/', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE `tbl_contact` (
  `Id` int(11) NOT NULL,
  `FirstName` varchar(255) DEFAULT NULL,
  `LastName` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Phone` varchar(50) DEFAULT NULL,
  `Subject` varchar(255) DEFAULT NULL,
  `Message` text,
  `Created` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`Id`, `FirstName`, `LastName`, `Email`, `Phone`, `Subject`, `Message`, `Created`) VALUES
(1, 'Bhavna', 'baria', 'bhavna@gmail.com', '9982388234', 'test subject', 'demo dets                ', '2018-05-09'),
(2, 'unnati', 'rana', 'unnati@cueserve.com', '7600988598', 'Test Email', ' Test                 ', '2018-05-24'),
(3, 'unnati', 'rana', 'unnati@cueserve.com', '7600988598', 'Test Email', 'Test                  ', '2018-05-24'),
(4, 'bhavana', 'baria', 'bhavna@cueserve.com', '8834535344', 'test mail', 'testing mail please ignore this mail', '2018-06-06'),
(5, 'bhavana', 'baria', 'rahulcueserve6@gmail.com', '3535345345', 'test mail', 'ignore msg.', '2018-06-06'),
(6, 'bhavana', 'baria', 'kam@gmail.com', '9033155801', 'test mail', 'test', '2018-06-06'),
(7, 'bhavana', 'baria', 'rahulcueserve6@gmail.com', '3423155801', 'test mail', 'test', '2018-06-06'),
(8, 'bhavana', 'baria', 'rahulcueserve6@gmail.com', '9033155801', 'test mail', 'test nail 2', '2018-06-06'),
(9, 'bhavana', 'baria', 'kam@gmail.com', '9033155801', 'test mail', 'test', '2018-06-06'),
(10, 'rahul', 'varma', 'rahulcueserve6@gmail.com', '6453534534', 'news Test mail', 'St Amsterdam finland, United Stats of AKY16 8PNSt Amsterdam finland, United Stats of AKY16 8PNSt Amsterdam finland, United Stats of AKY16 8PN', '2018-06-06'),
(11, 'bhavana', 'baria', 'rahulcueserve6@gmail.com', '9033155801', 'test mail', 'test mail ignor', '2018-06-06'),
(12, 'contactwlexuz', 'contactwlexuz', 'terrie_hulburt82@rambler.ru', '123456789', 'Sending newsletters of Your messages via contact forms to the sites of companies via all countries and domain zones of the world. ', 'I\'m happy to welcome you! \r\n \r\nWe offer sending newsletters of Your messages via follow-up forms to the sites offirms via all domain zones of the world in any languages.  \r\nhttp://xn----7sbb1bbndheurc1a.xn--p1ai \r\n \r\nThe commercial offer is sent to email address of business organization 100 percent will get to inbox folder! \r\n \r\nTest: \r\nten thousand messages on foreign zones to your email - 20 dollars. \r\nWe need from You only email address, title and text of the letter. \r\n \r\nIn our price there are more 800 databases for all domains of the world. \r\nCommon databases: \r\nAll Europe 44 countries 60726150 of domain names - 1100$ \r\nAll European Union 28 countries 56752547 of sites- 1000$ \r\nAll Asia 48 countries 14662004 of domains - 300$ \r\nAll Africa 50 countries 1594390 of domain names - 200$ \r\nAll North and Central America in 35 countries 7441637 of domain names - 300$ \r\nAll South America 14 countries 5826884 of domains - 200$ \r\nBusinesses of Russia - 300$ \r\nUkraine 605745 of sites - 5000 rubles. \r\nAll Russian-speaking countries minus Russia are 15 countries and there are 1526797 of domain names - 200$ \r\n \r\nOur databases: \r\nWhois-service databases of sites for all countries of the world. \r\nYou can purchase our databases separately from newsletter\'s service at the request. \r\n \r\nP.S. \r\nPlease, do not respond to this letter from your electronic box, as it has been generated in automatic mode and will not reach us! \r\nUse the contact form from the site http://xn----7sbb1bbndheurc1a.xn--p1ai', '2018-07-18'),
(13, 'Joy', 'Vidal', 'joy.vidal16@gmail.com', '+974774848', 'Inquiries', 'Hi', '2018-08-02'),
(14, 'cueserve', 'test', 'bhavna@cueserve.com', '9944221133', 'test mail', 'Ignore this test mail', '2018-08-03');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `Id` int(11) NOT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Phone` varchar(50) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Fbloginkey` varchar(255) DEFAULT NULL,
  `Gploginkey` varchar(255) DEFAULT NULL,
  `Status` int(5) DEFAULT NULL,
  `Created` date DEFAULT NULL,
  `FirstName` varchar(255) DEFAULT NULL,
  `LastName` varchar(255) DEFAULT NULL,
  `OTP` varchar(255) DEFAULT NULL,
  `Slug` varchar(255) DEFAULT NULL,
  `ProfileImage` varchar(255) DEFAULT NULL,
  `Address` text,
  `Yourself` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`Id`, `Email`, `Phone`, `Password`, `Fbloginkey`, `Gploginkey`, `Status`, `Created`, `FirstName`, `LastName`, `OTP`, `Slug`, `ProfileImage`, `Address`, `Yourself`) VALUES
(2, 'sumit@cueserve.com', '1122334455', '25d55ad283aa400af464c76d713c07ad', NULL, '104306020810461970513', 1, '2018-05-15', 'Bhavna', 'Baria', '', 'bhavna-baria', NULL, NULL, NULL),
(3, 'ranaunnati04@gmail.com', '7600988598', 'f925916e2754e5e03f75dd58a5733251', NULL, NULL, 1, '2018-05-17', 'Unnati', 'Rana', '4116', 'unnati-rana', NULL, NULL, NULL),
(4, 'qwert@qwrty.com', '1234567890', NULL, NULL, NULL, 0, '2018-05-29', 'qwerty', 'qwerty', NULL, NULL, NULL, NULL, NULL),
(5, 'kamg@gmail.com', '1234567890', NULL, NULL, NULL, 1, '2018-05-31', 'rahul', 'baria', NULL, NULL, NULL, NULL, NULL),
(6, 'test@g.c', '5675675656', NULL, NULL, NULL, 0, '2018-06-01', 'test', 'test', NULL, NULL, NULL, NULL, NULL),
(7, 'kavyahb@gmail.com', '87735353535', NULL, NULL, NULL, 0, '2018-06-07', 'kavya', 'hb', NULL, NULL, NULL, NULL, NULL),
(8, 'bhavanabaria13@gmail.com', '65567567155801', '2c9341ca4cf3d87b9e4eb905d6a3ec45', '1432771056869321', NULL, 1, '2018-06-07', 'Bhavana ', 'baria', NULL, 'bhavana-baria', '', 'baroda', NULL),
(9, 'nirmalchauhan125@gmail.com', NULL, NULL, NULL, '100698026312356289417', 0, '2018-06-26', 'Nirmal', 'Chauhan', '4767', 'nirmal-chauhan', NULL, NULL, NULL),
(10, NULL, NULL, NULL, '222845554999023', NULL, 0, '2018-06-26', 'Safqaat Mohammed', NULL, NULL, 'safqaat-mohammed', NULL, NULL, NULL),
(11, 'laurencegarcia304@gmail.com', NULL, '25d55ad283aa400af464c76d713c07ad', NULL, '103895770927017057618', 1, '2018-06-26', 'Laurence', 'Garcia', '4866', 'laurence-garcia', NULL, NULL, NULL),
(12, NULL, NULL, NULL, '1876548072404834', NULL, 0, '2018-06-26', 'Nirmal Chauhan', NULL, NULL, 'nirmal-chauhan3', NULL, NULL, NULL),
(13, 'jamarie_31@yahoo.com', '55698832', '894cb58406c0951994300c800275445a', NULL, NULL, 0, '2018-06-30', 'Jamarie', 'Escobar', '4240', 'jamarie-escobar', NULL, NULL, NULL),
(14, 'joy.vidal16@gmail.com', '97477484850', 'd69a924bd6dc612150afba9749c6cb0e', NULL, '101016840047506338020', 1, '2018-07-06', 'Joy', 'Vidal', '', 'joy-vidal', '', 'Doha', 'sasadasdas'),
(15, 'vidal.joy14@gmail.com', '+97477484850', NULL, NULL, NULL, 0, '2018-07-07', 'Joy', 'Vidal', NULL, NULL, NULL, NULL, NULL),
(16, 'neha@gmail.com', '4334535801', NULL, NULL, NULL, 1, '2018-07-11', 'neha', 'baria', NULL, NULL, NULL, NULL, NULL),
(17, 'joahnsenerpida@gmail.com', '97430131368', NULL, NULL, NULL, 1, '2018-07-17', 'Joahn Marie', 'Senerpida', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_events`
--

CREATE TABLE `tbl_events` (
  `Id` int(11) NOT NULL,
  `ClubId` int(11) DEFAULT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Description` text,
  `FromDate` date DEFAULT NULL,
  `ToDate` date DEFAULT NULL,
  `NoofDays` varchar(255) DEFAULT NULL,
  `OneDate` date DEFAULT NULL,
  `TimeFrom` varchar(255) DEFAULT NULL,
  `TimeTo` varchar(255) DEFAULT NULL,
  `Image` varchar(255) DEFAULT NULL,
  `Status` int(5) DEFAULT NULL,
  `Created` date DEFAULT NULL,
  `Price` varchar(255) DEFAULT NULL,
  `Slug` varchar(255) DEFAULT NULL,
  `eventtype` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_events`
--

INSERT INTO `tbl_events` (`Id`, `ClubId`, `Title`, `Description`, `FromDate`, `ToDate`, `NoofDays`, `OneDate`, `TimeFrom`, `TimeTo`, `Image`, `Status`, `Created`, `Price`, `Slug`, `eventtype`) VALUES
(6, 10, 'Test Even 05', 'Test Even 05', '2018-08-31', '2018-09-08', '3', '2018-05-24', '19:00', '00:00', NULL, 1, '2018-08-01', NULL, 'test-even-05', NULL),
(7, 10, 'Test Even 06', 'Test Even 06', '2018-05-24', '2018-05-24', '1', '2018-08-15', '10:00', '17:00', 'Table3.jpg', 1, '2018-07-31', NULL, 'test-even-06', NULL),
(8, 12, 'Test Even 01', 'Test Even 01', '2018-05-24', '2018-05-24', '1', '2018-08-10', '09:00', '17:00', 'Table1.jpg', 1, '2018-07-31', NULL, 'test-even-01', NULL),
(9, 2, 'Happy Wednesday', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book', '1970-01-01', '1970-01-01', '1', '2018-08-16', '03:00', '06:00', 'club5.jpg', 1, '2018-07-31', NULL, 'happy-wednesday', '2,1'),
(10, 45, 'Happy Sunday', 'Their original product was the Letraset Type Lettering System.[2] By 1961, Letraset\'s dry rub-down Instant Lettering[3] was perfected. This was to be its core product for many years to come.\r\n\r\nStarting in 1964, Letraset also applied the dry rub-down transfer technique to create a children\'s game called Action Transfers, which would later develop into Kalkitos (marketed by Gillette) and many other series of transferable figures that were very popular up to the 1980s.', '2018-08-01', '2018-08-08', '6', '1970-01-01', '01:07', '03:05', 'b34.jpg', 1, '2018-08-01', NULL, 'happy-sunday', '4,3'),
(11, 45, 'Happy Saturday', 'Their original product was the Letraset Type LetteringTheir original product was the Letraset Type LetteringTheir original product was the Letraset Type LetteringTheir original product was the Letraset Type Lettering', '2018-08-01', '2018-08-03', '3', '2018-08-02', '05:59', '07:08', 'b5.jpg', 1, '2018-08-01', NULL, 'happy-saturday', '4,3'),
(12, 45, 'Cheer with Unlimited food ', 'dfdgdfgdfg', '1970-01-01', '1970-01-01', '1', '2018-08-14', '03:05', '03:44', '311.jpg', 1, '2018-08-01', NULL, 'cheer-with-unlimited-beer1', '3,4'),
(14, 20, 'Happy Hour', 'Unlimited Drinks\r\nUnlimited Foods', '1970-01-01', '1970-01-01', '1', '2018-08-01', '20:00', '00:00', NULL, 1, '2018-08-01', NULL, 'happy-hour', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_event_ticket_update`
--

CREATE TABLE `tbl_event_ticket_update` (
  `Id` int(11) NOT NULL,
  `ClubId` int(11) DEFAULT NULL,
  `EventId` int(11) DEFAULT NULL,
  `EventTypeId` int(11) DEFAULT NULL,
  `NoofTicket` int(11) DEFAULT NULL,
  `UsedTicket` int(11) DEFAULT NULL,
  `Created` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_event_ticket_update`
--

INSERT INTO `tbl_event_ticket_update` (`Id`, `ClubId`, `EventId`, `EventTypeId`, `NoofTicket`, `UsedTicket`, `Created`) VALUES
(1, 2, 9, 2, 50, 0, '2018-07-19'),
(2, 2, 9, 1, 30, 0, '2018-07-19'),
(3, 2, 1, 2, 50, 0, '2018-07-19'),
(4, 2, 1, 1, 30, 5, '2018-07-19'),
(5, 45, 10, 2, 50, 0, '2018-08-01'),
(6, 45, 10, 1, 30, 0, '2018-08-01'),
(7, 45, 11, 4, 30, 0, '2018-08-01'),
(8, 45, 11, 3, 50, 0, '2018-08-01'),
(9, 45, 10, 4, 30, 0, '2018-08-01'),
(10, 45, 10, 3, 50, 0, '2018-08-01'),
(11, 45, 12, 4, 30, 0, '2018-08-01'),
(12, 2, 13, 2, 50, 0, '2018-08-01'),
(13, 45, 12, 3, 50, 0, '2018-08-01');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_event_type`
--

CREATE TABLE `tbl_event_type` (
  `Id` int(11) NOT NULL,
  `ClubId` int(11) DEFAULT NULL,
  `NoofTickets` int(11) DEFAULT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `ShortDescription` text,
  `Amount` varchar(255) DEFAULT NULL,
  `Status` int(5) DEFAULT NULL,
  `Created` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_event_type`
--

INSERT INTO `tbl_event_type` (`Id`, `ClubId`, `NoofTickets`, `Title`, `ShortDescription`, `Amount`, `Status`, `Created`) VALUES
(1, 2, 30, 'Basic Level', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s', '5', 1, '2018-07-31'),
(2, 2, 50, 'Standard Level', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s', '7', 1, '2018-07-31'),
(3, 45, 50, 'Standard event', 'Their original product was the Letraset Type Lettering System.[2] By 1961, Letraset\'s dry rub-down Instant Lettering[3] was perfected. This was to be its core product for many years to come.', '5', 1, '2018-08-01'),
(4, 45, 30, 'Basic Event', 'Their original product was the Letraset Type Lettering System.[2] By 1961, Letraset\'s dry rub-down Instant Lettering[3] was perfected. This was to be its core product for many years to come.', '7', 1, '2018-08-01'),
(5, 20, 10, 'Happy Hour', 'Unlimited foods and drinks.', '150', 1, '2018-08-01');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_facility`
--

CREATE TABLE `tbl_facility` (
  `Id` int(11) NOT NULL,
  `ClubId` int(11) DEFAULT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Description` text,
  `Status` int(5) DEFAULT NULL,
  `Created` date DEFAULT NULL,
  `Slug` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_foodcategory`
--

CREATE TABLE `tbl_foodcategory` (
  `Id` int(11) NOT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Slug` varchar(255) DEFAULT NULL,
  `ClubId` int(11) DEFAULT NULL,
  `Image` varchar(255) DEFAULT NULL,
  `Status` int(5) DEFAULT NULL,
  `Created` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_foodcategory`
--

INSERT INTO `tbl_foodcategory` (`Id`, `Title`, `Slug`, `ClubId`, `Image`, `Status`, `Created`) VALUES
(36, 'Desset', 'desset', 45, NULL, 1, '2018-07-26'),
(37, 'Soft Drink', 'soft-drink', 45, NULL, 1, '2018-07-26'),
(41, 'Appetizers', 'appetizers', 44, NULL, 1, '2018-07-26'),
(43, 'Desserts', 'desserts', 44, NULL, 1, '2018-07-29'),
(45, 'Main Courses', 'main-courses', 44, NULL, 1, '2018-07-29'),
(46, 'Drinks', 'drinks', 44, NULL, 1, '2018-07-29'),
(47, 'Bar Snacks', 'bar-snacks', 44, NULL, 1, '2018-07-29'),
(48, 'Salads', 'salads', 46, NULL, 1, '2018-07-31'),
(49, 'Soups', 'soups', 46, NULL, 1, '2018-07-31'),
(50, 'For Sharing', 'for-sharing', 46, NULL, 1, '2018-07-31'),
(51, 'Sandwhiches', 'sandwhiches', 46, NULL, 1, '2018-07-31'),
(52, 'Desserts', 'desserts4', 46, NULL, 1, '2018-07-31'),
(53, 'Non-Alcoholic Cocktails', 'non-alcoholic-cocktails', 46, NULL, 1, '2018-07-31'),
(54, 'Non-Alcoholic Take On the Classics', 'non-alcoholic-take-on-the-classics', 46, NULL, 1, '2018-07-31'),
(55, 'Non-Alcoholic Beer', 'non-alcoholic-beer', 46, NULL, 1, '2018-07-31'),
(56, 'Freshly Squeezed Juices', 'freshly-squeezed-juices', 46, NULL, 1, '2018-07-31'),
(57, 'Juices', 'juices', 46, NULL, 1, '2018-07-31'),
(58, 'Water', 'water', 46, NULL, 1, '2018-07-31'),
(59, 'Soft Drinks', 'soft-drinks', 46, NULL, 1, '2018-07-31'),
(60, 'Iced Tea', 'iced-tea', 46, NULL, 1, '2018-07-31'),
(61, 'Iced Coffee and Chocolate', 'iced-coffee-and-chocolate', 46, NULL, 1, '2018-07-31'),
(62, 'Hot Drinks', 'hot-drinks', 46, NULL, 1, '2018-07-31'),
(63, 'Chinese Loose Leaves Tea', 'chinese-loose-leaves-tea', 46, NULL, 1, '2018-07-31');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_fooditem`
--

CREATE TABLE `tbl_fooditem` (
  `Id` int(11) NOT NULL,
  `ClubId` int(11) DEFAULT NULL,
  `CategoryId` int(11) DEFAULT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Slug` varchar(255) DEFAULT NULL,
  `Price` varchar(255) DEFAULT NULL,
  `Image` varchar(255) DEFAULT NULL,
  `Status` int(5) DEFAULT NULL,
  `Created` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_fooditem`
--

INSERT INTO `tbl_fooditem` (`Id`, `ClubId`, `CategoryId`, `Title`, `Slug`, `Price`, `Image`, `Status`, `Created`) VALUES
(58, 45, 36, 'Ice-cream', 'ice-cream', '60', NULL, 1, '2018-07-26'),
(59, 45, 37, 'Orange Juice', 'orange-juice', '60', NULL, 1, '2018-07-26'),
(60, 45, 37, 'Coca Cola', 'coca-cola', '60', NULL, 1, '2018-07-26'),
(61, 45, 36, 'Rasbari', 'rasbari', '100', NULL, 1, '2018-07-26'),
(63, 44, 45, 'Peking Duck', 'peking-duck4', 'QAR 388', NULL, 1, '2018-07-29'),
(64, 44, 45, 'Small Plates Cold Yusheng', 'small-plates-cold-yusheng', 'QAR 78', NULL, 1, '2018-07-29'),
(65, 44, 45, 'Small Plates Hot Shanghai Club sauna Prawns', 'small-plates-hot-shanghai-club-sauna-prawns', 'QAR 68', NULL, 1, '2018-07-29'),
(66, 44, 45, 'Xiao Long Bao', 'xiao-long-bao', 'QAR 68', NULL, 1, '2018-07-29'),
(67, 44, 45, 'Dim Sum \"In the Box\"', 'dim-sum-\"in-the-box\"', 'QAR 98', NULL, 1, '2018-07-29'),
(68, 44, 41, 'Soups - Stuffed', 'soups---stuffed', 'QAR 38', NULL, 1, '2018-07-29'),
(69, 44, 41, 'Soup Hot and Sour King Crab and Tofu', 'soup-hot-and-sour-king-crab-and-tofu', 'QAR 48', NULL, 1, '2018-07-29'),
(70, 44, 41, 'Soup Dan Dan Noodles', 'soup-dan-dan-noodles', 'QAR 88', NULL, 1, '2018-07-29'),
(71, 44, 43, 'Black Sesame Panna Cotta with Pumpkin', 'black-sesame-panna-cotta-with-pumpkin', 'QAR 38', NULL, 1, '2018-07-29'),
(72, 44, 43, 'Chilled Mango Sago Cream with Pomelo', 'chilled-mango-sago-cream-with-pomelo', 'QAR 38', NULL, 1, '2018-07-29'),
(73, 44, 43, 'Deep-Fried Lychee Ice Cream', 'deep-fried-lychee-ice-cream', 'QAR 48', NULL, 1, '2018-07-29'),
(74, 44, 43, 'Melting Mandarin Orange', 'melting-mandarin-orange', 'QAR 58', NULL, 1, '2018-07-29'),
(75, 44, 43, 'Saffron Brownie', 'saffron-brownie', 'QAR 38', NULL, 1, '2018-07-29'),
(76, 44, 47, 'Shanghai Club Duck Bao Sliders', 'shanghai-club-duck-bao-sliders', 'QAR 78', NULL, 1, '2018-07-29'),
(77, 44, 47, 'Salt and Pepper Squid Bao Sliders', 'salt-and-pepper-squid-bao-sliders', 'QAR 68', NULL, 1, '2018-07-29'),
(78, 44, 47, 'Fried Pepper Chicken Wings', 'fried-pepper-chicken-wings', 'QAR 58', NULL, 1, '2018-07-29'),
(79, 44, 47, 'Sichuan Popcorn Chicken', 'sichuan-popcorn-chicken', 'QAR 48', NULL, 1, '2018-07-29'),
(80, 44, 47, 'Spring Rolls with Duck Crackling', 'spring-rolls-with-duck-crackling', 'QAR 58', NULL, 1, '2018-07-29'),
(81, 44, 47, 'Crispy Shrimp and Mushroom Wontons', 'crispy-shrimp-and-mushroom-wontons', 'QAR 48', NULL, 1, '2018-07-29'),
(82, 44, 47, 'Spicy Beef Kebabs', 'spicy-beef-kebabs', 'QAR 68', NULL, 1, '2018-07-29'),
(83, 44, 47, 'Shanghai Club Spicy Fries', 'shanghai-club-spicy-fries', 'QAR 38', NULL, 1, '2018-07-29'),
(84, 44, 46, 'Champagne (By Glass)', 'champagne-(by-glass)', 'QAR 70', NULL, 1, '2018-07-29'),
(85, 44, 46, 'Champagne (By Bottle)', 'champagne-(by-bottle)', 'QAR 350', NULL, 1, '2018-07-29'),
(86, 44, 46, 'Cava (By Glass)', 'cava-(by-glass)1', 'QAR 35', NULL, 1, '2018-07-29'),
(87, 44, 46, 'Cava (By Bottle)', 'cava-(by-bottle)', 'QAR 175', NULL, 1, '2018-07-29'),
(88, 44, 46, 'Sparkling Rose (By Glass)', 'sparkling-rose-(by-glass)', 'QAR 35', NULL, 1, '2018-07-29'),
(89, 44, 46, 'Sparkling Rose (By Bottle)', 'sparkling-rose-(by-bottle)', 'QAR 175', NULL, 1, '2018-07-29'),
(90, 44, 46, 'White OR Red Wine (By Glass)', 'white-or-red-wine-(by-glass)', 'QAR 35', NULL, 1, '2018-07-29'),
(91, 44, 46, 'White OR Red Wine  (By Bottle)', 'white-or-red-wine--(by-bottle)', 'QAR 175', NULL, 1, '2018-07-29'),
(92, 44, 46, 'Beers On Tap', 'beers-on-tap', 'QAR 35', NULL, 1, '2018-07-29'),
(94, 44, 46, 'House Spirits', 'house-spirits', 'QAR 35', NULL, 1, '2018-07-29'),
(97, 46, 48, 'Tropical Prawn Salad', 'tropical-prawn-salad3', '90', NULL, 1, '2018-07-31'),
(98, 46, 48, 'Selection of Cold Arabic Mezze', 'selection-of-cold-arabic-mezze', '50', NULL, 1, '2018-07-31'),
(100, 46, 49, 'Shorbat Adas', 'shorbat-adas', '35', NULL, 1, '2018-07-31'),
(101, 46, 49, 'Smoked Tomato and Goat Cheese Soup', 'smoked-tomato-and-goat-cheese-soup', '45', NULL, 1, '2018-07-31'),
(102, 46, 50, 'Dim Sum', 'dim-sum', '100', NULL, 1, '2018-07-31'),
(103, 46, 50, 'Selection of Cold and Hot Arabic Mezze', 'selection-of-cold-and-hot-arabic-mezze', '115', NULL, 1, '2018-07-31'),
(104, 46, 50, 'Arabian Delights', 'arabian-delights', '100', NULL, 1, '2018-07-31'),
(105, 46, 51, 'Chicken Caesar Wrap', 'chicken-caesar-wrap', '70', NULL, 1, '2018-07-31'),
(107, 46, 51, 'Vegetable Panini', 'vegetable-panini', '65', NULL, 1, '2018-07-31'),
(108, 46, 51, 'The Lobby Club Sandwich', 'the-lobby-club-sandwich', '75', NULL, 1, '2018-07-31'),
(110, 46, 52, 'Ice Cream Bouquet', 'ice-cream-bouquet', '40', NULL, 1, '2018-07-31');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_information`
--

CREATE TABLE `tbl_information` (
  `Id` int(11) NOT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Subtitle` varchar(255) DEFAULT NULL,
  `Description` text,
  `Status` int(5) DEFAULT NULL,
  `Created` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_information`
--

INSERT INTO `tbl_information` (`Id`, `Title`, `Subtitle`, `Description`, `Status`, `Created`) VALUES
(1, 'About us', 'About us', '<p><strong>Welcome to Tablefast.com </strong>where you can reserve tables from exclusive and alluring&nbsp;clubs and restaurants here in Doha, Qatar.</p>\r\n\r\n<p>We intend to give accessible table reservation with pleasant surroundings, superb food and admirable services to make your stay definitely repayable and satisfaction guarantee.</p>\r\n\r\n<p>Please explore our website where you can find all the informations you need from these clubs and restaurants&nbsp;like their location, menu, facilities provided to their customers and etc.</p>\r\n\r\n<p>We are glad to serve you.</p>\r\n', 1, '2018-07-29'),
(2, 'Terms & Conditions', 'Terms & Conditions', '<p><strong>Welcome to Tablefast</strong></p>\r\n\r\n<p>These terms and conditions outline the rules and regulations for the use of Tablefast&#39;s Website.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Tablefast is located at:</p>\r\n\r\n<p>12 Simpson Loan Edinburgh, UK - EH3 9GD, United Kingdom</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>By accessing this website we assume you accept these terms and conditions in full. Do not continue to use Tablefast&#39;s website</p>\r\n\r\n<p>if you do not accept all of the terms and conditions stated on this page.</p>\r\n\r\n<p>The following terminology applies to these Terms and Conditions, Privacy Statement and Disclaimer Notice and any or all Agreements: &ldquo;Client&rdquo;, &ldquo;You&rdquo; and &ldquo;Your&rdquo; refers to you, the person accessing this website and accepting the Company&rsquo;s terms and conditions. &ldquo;The Company&rdquo;, &ldquo;Ourselves&rdquo;, &ldquo;We&rdquo;, &ldquo;Our&rdquo; and &ldquo;Us&rdquo;, refers to our company. &ldquo;Party&rdquo;, &ldquo;Parties&rdquo;, or &ldquo;Us&rdquo;, refers to both the Client and ourselves, or either the Client or ourselves. All terms refer to the offer, acceptance and consideration of payment necessary to undertake the process of our assistance to the Client in the most appropriate manner, whether by formal meetings of a fixed duration, or any other means, for the express purpose of meeting the Client&rsquo;s needs in respect of provision of the Company&rsquo;s stated services/products, in accordance with and subject to, prevailing law of United Kingdom. Any use of the above terminology or other words in the singular, plural, capitalisation and/or he/she or they, are taken as interchangeable and therefore as referring to same.</p>\r\n\r\n<p><strong>Cookies </strong></p>\r\n\r\n<p>We employ the use of cookies. By using Tablefast&#39;s website you consent to the use of cookies in accordance with Tablefast&rsquo;s privacy policy.Most of the modern day interactive websites use cookies to enable us to retrieve user details for each visit. Cookies are used in some areas of our site to enable the functionality of this area and ease of use for those people visiting. Some of our affiliate / advertising partners may also use cookies.</p>\r\n\r\n<p><strong>License&nbsp;</strong></p>\r\n\r\n<p>Unless otherwise stated, Tablefast and/or it&rsquo;s licensors own the intellectual property rights for all material on Tablefast. All intellectual property rights are reserved. You may view and/or print pages from https://www.tablefast.com for your own personal use subject to restrictions set in these terms and conditions.</p>\r\n\r\n<p>You must not:</p>\r\n\r\n<p>Republish material from https://www.tablefast.com</p>\r\n\r\n<p>Sell, rent or sub-license material from https://www.tablefast.com</p>\r\n\r\n<p>Reproduce, duplicate or copy material from https://www.tablefast.com</p>\r\n\r\n<p>Redistribute content from Tablefast (unless content is specifically made for redistribution).</p>\r\n\r\n<p><strong>User Comments</strong></p>\r\n\r\n<p>This Agreement shall begin on the date hereof. Certain parts of this website offer the opportunity for users to post and exchange opinions, information, material and data (&#39;Comments&#39;) in areas of the website. Tablefast does not screen, edit, publish or review Comments prior to their appearance on the website and Comments do not reflect the views or opinions of Tablefast, its agents or affiliates. Comments reflect the view and opinion of the person who posts such view or opinion. To the extent permitted by applicable&nbsp;laws Tablefast shall not be responsible or liable for the Comments or for any loss cost, liability, damages or expenses caused and or suffered as a result of any use of and/or posting of and/or appearance of the Comments on this website. Tablefast reserves the right to monitor all Comments and to remove any Comments which it considers&nbsp;in its absolute discretion to be inappropriate, offensive or otherwise in breach of these Terms and Conditions.</p>\r\n\r\n<p><strong>You warrant and represent that:</strong></p>\r\n\r\n<p>You are entitled to post the Comments on our website and have all necessary licenses and consents to do so;</p>\r\n\r\n<p>The Comments do not infringe any intellectual property right, including without limitation copyright, patent or trademark, or other proprietary right of any third party;</p>\r\n\r\n<p>The Comments do not contain any defamatory, libelous, offensive, indecent or otherwise unlawful material or material which is an invasion of privacy</p>\r\n\r\n<p>The Comments will not be used to solicit or promote business or custom or present commercial activities or unlawful activity.</p>\r\n\r\n<p>You hereby grant to Tablefast a non-exclusive royalty-free license to use, reproduce,&nbsp;edit and authorize others to use, reproduce and edit any of your Comments in any and all forms, formats&nbsp;or media.</p>\r\n\r\n<p><strong>Hyperlinking to our Content</strong></p>\r\n\r\n<p>The following organizations may link to our Website without prior written approval:</p>\r\n\r\n<p>Government agencies;</p>\r\n\r\n<p>Search engines;</p>\r\n\r\n<p>News organizations;</p>\r\n\r\n<p>Online directory distributors when they list us in the directory may link to our Website in the samemanner as they hyperlink to the Websites of other listed businesses; and</p>\r\n\r\n<p>Systemwide Accredited Businesses except soliciting non-profit organizations, charity shopping malls, and charity fundraising groups which may not hyperlink to our Website.</p>\r\n\r\n<p>These organizations may link to our home page, to publications or to other Website information so long as the link:</p>\r\n\r\n<p>(a) is not in any way misleading;</p>\r\n\r\n<p>(b) does not falsely imply sponsorship, endorsement or&nbsp;approval of the linking party and its products or services; and</p>\r\n\r\n<p>(c) fits within the context of the linking party&#39;s site.</p>\r\n\r\n<p>We may consider and approve in our sole discretion other link requests from the following types of organizations:</p>\r\n\r\n<p>commonly-known consumer and/or business information sources such as Chambers of Commerce, American&nbsp;Automobile Association, AARP and Consumers Union;</p>\r\n\r\n<p>dot.com community sites;</p>\r\n\r\n<p>associations or other groups representing charities, including charity giving sites, online directory distributors;</p>\r\n\r\n<p>internet portals;</p>\r\n\r\n<p>accounting, law and consulting firms whose primary clients are businesses; and</p>\r\n\r\n<p>educational institutions and trade associations.</p>\r\n\r\n<p>We will approve link requests from these organizations if we determine that:</p>\r\n\r\n<p>(a) the link would not reflect unfavorably on us or our accredited businesses (for example, trade associations or other organizations representing inherently suspect types of business, such as work-at-home opportunities, shall not be allowed to link);</p>\r\n\r\n<p>(b) the organization does not have an unsatisfactory record with us;</p>\r\n\r\n<p>(c) the benefit to us from the visibility associated with the hyperlink outweighs the absence of ; and</p>\r\n\r\n<p>(d) where the link is in the context of general resource information or is otherwise consistent with editorial content in a newsletter or similar product furthering the mission of the organization.</p>\r\n\r\n<p>These organizations may link to our home page, to publications or to other Website information so long as the link:</p>\r\n\r\n<p>(a) is not in any way misleading;</p>\r\n\r\n<p>(b) does not falsely imply sponsorship, endorsement or approval of the linking party and it products or services; and</p>\r\n\r\n<p>(c) fits within the context of the linking party&#39;s site.</p>\r\n\r\n<p>If you are among the organizations listed in paragraph 2 above and are interested in linking to our website, you must notify us by sending an e-mail to info@tablefast.com.</p>\r\n\r\n<p>Please include your name, your organization name, contact information (such as a phone number and/or e-mail address) as well as the URL of your site, a list of any URLs from which you intend to link to our Website, and a list of the URL(s) on our site to which you would like to link. Allow 2-3 weeks for a response.</p>\r\n\r\n<p>Approved organizations may hyperlink to our Website as follows:</p>\r\n\r\n<p>&nbsp;By use of our corporate name; or</p>\r\n\r\n<p>&nbsp;By use of the uniform resource locator (Web address) being linked to; or</p>\r\n\r\n<p>&nbsp;By use of any other description of our Website or material being linked to that makes sense within the&nbsp;context and format of content on the linking party&#39;s site.</p>\r\n\r\n<p>No use of Tablefast&rsquo;s logo or other artwork will be allowed for linking absent a trademark license agreement.</p>\r\n\r\n<p><strong>Iframes</strong></p>\r\n\r\n<p>Without prior approval and express written permission, you may not create frames around our Web pages or use other techniques that alter in any way the visual presentation or appearance of our Website.</p>\r\n\r\n<p><strong>Reservation of Rights</strong></p>\r\n\r\n<p>We reserve the right at any time and in its sole discretion to request that you remove all links or any particular link to our Website. You agree to immediately remove all links to our Website upon such request. We also reserve the right to amend these terms and conditions and its linking policy at any time. By continuing to link to our Website, you agree to be bound to and abide by these linking terms and conditions.</p>\r\n\r\n<p><strong>Removal of links from our website</strong></p>\r\n\r\n<p>If you find any link on our Website or any linked website objectionable for any reason, you may contact us about this. We will consider requests to remove links but will have no obligation to do so or to respond directly to you. Whilst we endeavour to ensure that the information on this website is correct, we do not warrant its completeness or accuracy; nor do we commit to ensuring that the website remains available or that the material on the website is kept up to date.</p>\r\n\r\n<p><strong>Content Liability</strong></p>\r\n\r\n<p>We shall have no responsibility or liability for any content appearing on your Website. You agree to indemnify and defend us against all claims arising out of or based upon your Website. No link(s) may appear on any page on your Website or within any context containing content or materials that may be interpreted as libelous, obscene or criminal, or which infringes, otherwise violates, or advocates the infringement or other violation of, any third party rights.</p>\r\n\r\n<p><strong>Disclaimer</strong></p>\r\n\r\n<p>To the maximum extent permitted by applicable law, we exclude all representations, warranties and conditions relating to our website and the use of this website (including, without limitation, any warranties implied by law in respect of satisfactory quality, fitness for purpose and/or the use of reasonable care and skill). Nothing in this disclaimer will:</p>\r\n\r\n<p>limit or exclude our or your liability for death or personal injury resulting from negligence;</p>\r\n\r\n<p>limit or exclude our or your liability for fraud or fraudulent misrepresentation;</p>\r\n\r\n<p>limit any of our or your liabilities in any way that is not permitted under applicable law; or</p>\r\n\r\n<p>exclude any of our or your liabilities that may not be excluded under applicable law.</p>\r\n\r\n<p>The limitations and exclusions of liability set out in this Section and elsewhere in this disclaimer:</p>\r\n\r\n<p>(a) are subject to the preceding paragraph; and</p>\r\n\r\n<p>(b) govern all liabilities arising under the disclaimer or</p>\r\n\r\n<p>(c) in relation to the subject matter of this disclaimer, including liabilities arising in contract, in tort (including negligence) and for breach of statutory duty.</p>\r\n\r\n<p>To the extent that the website and the information and services on the website are provided free of charge, we will not be liable for any loss or damage of any nature.</p>\r\n', 1, '2018-07-29'),
(3, 'Privacy Policy', 'Privacy Policy', '<p>Your privacy is critically important to us.</p>\r\n\r\n<p>Tablefast is located at:</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Tablefast</p>\r\n\r\n<p>12 Simpson Loan Edinburgh</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>It is Tablefast&rsquo;s policy to respect your privacy regarding any information we may collect while operating our website. This Privacy Policy applies to https://www.tablefast.com (hereinafter, &quot;us&quot;, &quot;we&quot;, or &quot;https://www.tablefast.com&quot;). We respect your privacy and are committed to protecting personally identifiable information you may provide us through the Website. We have adopted this privacy policy (&quot;Privacy Policy&quot;) to explain what information may be collected on our Website, how we use this information, and under what circumstances we may disclose the information to third parties. This Privacy Policy applies only to information we collect through the Website and does not apply to our collection of information from other sources.</p>\r\n\r\n<p>This Privacy Policy, together with the Terms and conditions posted on our Website, set forth the general rules and policies governing your use of our Website. Depending on your activities when visiting our Website, you may be required to agree to additional terms and conditions.</p>\r\n\r\n<p><strong>- Website Visitors</strong></p>\r\n\r\n<p>Like most website operators, Tablefast collects non-personally-identifying information of the sort that web browsers and servers typically make available, such as the browser type, language preference, referring site, and the date and time of each visitor request. Tablefast&rsquo;s purpose in collecting non-personally identifying information is to better understand how Tablefast&rsquo;s visitors use its website. From time to time, Tablefast may release non-personally-identifying information in the aggregate, e.g., by publishing a report on trends in the usage of its website.</p>\r\n\r\n<p>Tablefast also collects potentially personally-identifying information like Internet Protocol (IP) addresses for logged in users and for users leaving comments on https://www.tablefast.com blog posts. Tablefast only discloses logged in user and commenter IP addresses under the same circumstances that it uses and discloses personally-identifying information as described below.</p>\r\n\r\n<p><strong>- Gathering of Personally-Identifying Information</strong></p>\r\n\r\n<p>Certain visitors to Tablefast&rsquo;s websites choose to interact with Tablefast in ways that require Tablefast to gather personally-identifying information. The amount and type of information that Tablefast gathers depends on the nature of the interaction. For example, we ask visitors who sign up for a blog at https://www.tablefast.com to provide a username and email address.</p>\r\n\r\n<p><strong>- Security</strong></p>\r\n\r\n<p>The security of your Personal Information is important to us, but remember that no method of transmission over the Internet, or method of electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your Personal Information, we cannot guarantee its absolute security.</p>\r\n\r\n<p><strong>- Advertisements</strong></p>\r\n\r\n<p>Ads appearing on our website may be delivered to users by advertising partners, who may set cookies. These cookies allow the ad server to recognize your computer each time they send you an online advertisement to compile information about you or others who use your computer. This information allows ad networks to, among other things, deliver targeted advertisements that they believe will be of most interest to you. This Privacy Policy covers the use of cookies by Tablefast and does not cover the use of cookies by any advertisers.</p>\r\n\r\n<p><strong>- Links To External Sites</strong></p>\r\n\r\n<p>Our Service may contain links to external sites that are not operated by us. If you click on a third party link, you will be directed to that third party&#39;s site. We strongly advise you to review the Privacy Policy and terms and conditions of every site you visit.</p>\r\n\r\n<p>We have no control over, and assume no responsibility for the content, privacy policies or practices of any third party sites, products or services.</p>\r\n\r\n<p><strong>Https://www.tablefast.com uses Google AdWords for remarketing</strong></p>\r\n\r\n<p>Https://www.tablefast.com uses the remarketing services to advertise on third party websites (including Google) to previous visitors to our site. It could mean that we advertise to previous visitors who haven&rsquo;t completed a task on our site, for example using the contact form to make an enquiry. This could be in the form of an advertisement on the Google search results page, or a site in the Google Display Network. Third-party vendors, including Google, use cookies to serve ads based on someone&rsquo;s past visits. Of course, any data collected will be used in accordance with our own privacy policy and Google&rsquo;s privacy policy.</p>\r\n\r\n<p>You can set preferences for how Google advertises to you using the Google Ad Preferences page, and if you want to you can opt out of interest-based advertising entirely by cookie settings or permanently using a browser plugin.</p>\r\n\r\n<p><strong>Protection of Certain Personally-Identifying Information</strong></p>\r\n\r\n<p>Tablefast discloses potentially personally-identifying and personally-identifying information only to those of its employees, contractors and affiliated organizations that (i) need to know that information in order to process it on Tablefast&rsquo;s behalf or to provide services available at Tablefast&rsquo;s website, and (ii) that have agreed not to disclose it to others. Some of those employees, contractors and affiliated organizations may be located outside of your home country; by using Tablefast&rsquo;s website, you consent to the transfer of such information to them. Tablefast will not rent or sell potentially personally-identifying and personally-identifying information to anyone. Other than to its employees, contractors and affiliated organizations, as described above, Tablefast discloses potentially personally-identifying and personally-identifying information only in response to a subpoena, court order or other governmental request, or when Tablefast believes in good faith that disclosure is reasonably necessary to protect the property or rights of Tablefast, third parties or the public at large.</p>\r\n\r\n<p>If you are a registered user of https://www.tablefast.com and have supplied your email address, Tablefast may occasionally send you an email to tell you about new features, solicit your feedback, or just keep you up to date with what&rsquo;s going on with Tablefast and our products. We primarily use our blog to communicate this type of information, so we expect to keep this type of email to a minimum. If you send us a request (for example via a support email or via one of our feedback mechanisms), we reserve the right to publish it in order to help us clarify or respond to your request or to help us support other users. Tablefast takes all measures reasonably necessary to protect against the unauthorized access, use, alteration or destruction of potentially personally-identifying and personally-identifying information.</p>\r\n\r\n<p><strong>Aggregated Statistics</strong></p>\r\n\r\n<p>Tablefast may collect statistics about the behavior of visitors to its website. Tablefast may display this information publicly or provide it to others. However, Tablefast does not disclose your personally-identifying information.</p>\r\n\r\n<p><strong>Affiliate Disclosure</strong></p>\r\n\r\n<p>This site uses affiliate links and does earn a commission from certain links. This does not affect your purchases or the price you may pay.</p>\r\n\r\n<p><strong>Cookies</strong></p>\r\n\r\n<p>To enrich and perfect your online experience, Tablefast uses &quot;Cookies&quot;, similar technologies and services provided by others to display personalized content, appropriate advertising and store your preferences on your computer.</p>\r\n\r\n<p>A cookie is a string of information that a website stores on a visitor&rsquo;s computer, and that the visitor&rsquo;s browser provides to the website each time the visitor returns. Tablefast uses cookies to help Tablefast identify and track visitors, their usage of https://www.tablefast.com, and their website access preferences. Tablefast visitors who do not wish to have cookies placed on their computers should set their browsers to refuse cookies before using Tablefast&rsquo;s websites, with the drawback that certain features of Tablefast&rsquo;s websites may not function properly without the aid of cookies.</p>\r\n\r\n<p>By continuing to navigate our website without changing your cookie settings, you hereby acknowledge and agree to Tablefast&#39;s use of cookies.</p>\r\n\r\n<p><strong>E-commerce</strong></p>\r\n\r\n<p>Those who engage in transactions with Tablefast &ndash; by purchasing Tablefast&#39;s services or products, are asked to provide additional information, including as necessary the personal and financial information required to process those transactions. In each case, Tablefast collects such information only insofar as is necessary or appropriate to fulfill the purpose of the visitor&rsquo;s interaction with Tablefast. Tablefast does not disclose personally-identifying information other than as described below. And visitors can always refuse to supply personally-identifying information, with the caveat that it may prevent them from engaging in certain website-related activities.</p>\r\n\r\n<p><strong>Business Transfers</strong></p>\r\n\r\n<p>If Tablefast, or substantially all of its assets, were acquired, or in the unlikely event that Tablefast goes out of business or enters bankruptcy, user information would be one of the assets that is transferred or acquired by a third party. You acknowledge that such transfers may occur, and that any acquirer of Tablefast may continue to use your personal information as set forth in this policy.</p>\r\n\r\n<p><strong>Privacy Policy Changes</strong></p>\r\n\r\n<p>Although most changes are likely to be minor, Tablefast may change its Privacy Policy from time to time, and in Tablefast&rsquo;s sole discretion. Tablefast encourages visitors to frequently check this page for any changes to its Privacy Policy. Your continued use of this site after any change in this Privacy Policy will constitute your acceptance of such change.</p>\r\n', 1, '2018-07-29');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_meta`
--

CREATE TABLE `tbl_meta` (
  `Id` int(11) NOT NULL,
  `PageId` int(11) DEFAULT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Description` text,
  `MetaKeyword` varchar(255) DEFAULT NULL,
  `Status` int(5) DEFAULT NULL,
  `Created` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_meta`
--

INSERT INTO `tbl_meta` (`Id`, `PageId`, `Title`, `Description`, `MetaKeyword`, `Status`, `Created`) VALUES
(1, 1, 'Tablefast.com', 'Tablefast.com', '', 1, '2018-05-31');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_newsletter`
--

CREATE TABLE `tbl_newsletter` (
  `Id` int(11) NOT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Created` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_newsletter`
--

INSERT INTO `tbl_newsletter` (`Id`, `Email`, `Created`) VALUES
(4, 'unnati@cueserve.com', '2018-05-24'),
(5, 'sumit@cueserve.com', '2018-05-24'),
(6, 'himansi@cueserve.com', '2018-05-24'),
(7, 'rahulcueserve6@gmail.com', '2018-06-06'),
(8, 'joy.vidal16@gmail.com', '2018-07-19');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_packageitem`
--

CREATE TABLE `tbl_packageitem` (
  `Id` int(11) NOT NULL,
  `PackageId` int(11) DEFAULT NULL,
  `CategoryId` int(11) DEFAULT NULL,
  `ItemId` int(11) DEFAULT NULL,
  `Price` varchar(255) DEFAULT NULL,
  `Status` int(5) DEFAULT NULL,
  `Created` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_packageitem`
--

INSERT INTO `tbl_packageitem` (`Id`, `PackageId`, `CategoryId`, `ItemId`, `Price`, `Status`, `Created`) VALUES
(4, 2, 3, 6, '60', 1, '2018-06-01'),
(5, 2, 3, 40, '20', 1, '2018-06-01'),
(6, 1, 3, 5, '60', 1, '2018-06-01'),
(7, 1, 3, 6, '60', 1, '2018-06-01'),
(8, 1, 4, 7, '120', 1, '2018-06-01'),
(9, 3, 36, 58, '60', 1, '2018-07-26'),
(10, 3, 36, 61, '100', 1, '2018-07-26'),
(11, 3, 37, 59, '60', 1, '2018-07-26'),
(12, 3, 37, 60, '60', 1, '2018-07-26'),
(13, 4, 41, 68, 'QAR 38', 1, '2018-07-29'),
(14, 4, 43, 71, 'QAR 38', 1, '2018-07-29'),
(15, 4, 45, 63, 'QAR 388', 1, '2018-07-29'),
(16, 4, 46, 84, 'QAR 70', 1, '2018-07-29'),
(17, 4, 47, 76, 'QAR 78', 1, '2018-07-29');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_packages`
--

CREATE TABLE `tbl_packages` (
  `Id` int(11) NOT NULL,
  `ClubId` int(11) DEFAULT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `ShortDetails` text,
  `ActPrice` varchar(255) DEFAULT NULL,
  `Price` varchar(255) DEFAULT NULL,
  `Image` varchar(255) DEFAULT NULL,
  `Status` int(5) DEFAULT NULL,
  `Created` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_packages`
--

INSERT INTO `tbl_packages` (`Id`, `ClubId`, `Title`, `ShortDetails`, `ActPrice`, `Price`, `Image`, `Status`, `Created`) VALUES
(1, 2, 'Tea food Combo Pack', 'test Pack', NULL, '240', 'b3.jpg', 1, '2018-06-01'),
(2, 2, 'Cheer with Unlimited Beer ', 'fdgdfgdfg', NULL, '80', NULL, 1, '2018-06-01'),
(3, 45, 'Happy Thursday', 'free wifi', '280', '280', 'b31.jpg', 1, '2018-07-26'),
(4, 44, 'Combo 1', 'Free WIFI\r\nFree Parking Space', 'QAR 612', '0', 'menu.jpg', 1, '2018-07-29');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment_history`
--

CREATE TABLE `tbl_payment_history` (
  `order_history_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `order_status_id` int(11) NOT NULL,
  `notify` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_payment_history`
--

INSERT INTO `tbl_payment_history` (`order_history_id`, `order_id`, `order_status_id`, `notify`, `comment`, `date_added`) VALUES
(43, 2, 3, 0, 'AVSCODE: Y\r\nCVV2MATCH: M\r\nTRANSACTIONID: 8SN456044K4398948\r\n', '2017-09-03 06:48:33'),
(42, 2, 2, 0, 'AVSCODE: Y\r\nCVV2MATCH: M\r\nTRANSACTIONID: 8SN456044K4398948\r\n', '2017-07-03 06:48:33'),
(41, 3, 3, 0, 'AVSCODE: Y\nCVV2MATCH: M\nTRANSACTIONID: 62M12969JA587612T\n', '2018-06-19 01:03:30'),
(40, 3, 2, 0, 'AVSCODE: Y\nCVV2MATCH: M\nTRANSACTIONID: 8C562728EG209333N\n', '2018-06-19 01:02:10'),
(39, 3, 1, 0, 'PAYID: NV4LWMNPRS3Q4\nTRANSACTION-ID:EC-3H230694SY0031508TRANSACTIONID: I-K5YH24N52LYV\n', '2018-06-19 01:01:15'),
(38, 2, 1, 0, 'AVSCODE: Y\nCVV2MATCH: M\nTRANSACTIONID: 8SN456044K4398948\n', '2017-08-03 06:48:33'),
(37, 1, 5, 0, 'AVSCODE: Y\nCVV2MATCH: M\nTRANSACTIONID: 6S526373C17190049\n', '2018-06-16 05:17:42'),
(36, 1, 4, 0, 'AVSCODE: Y\nCVV2MATCH: M\nTRANSACTIONID: 5J309398KB178673X\n', '2018-06-16 04:38:12'),
(35, 1, 3, 0, 'AVSCODE: Y\nCVV2MATCH: M\nTRANSACTIONID: 30317780LM141261R\n', '2018-06-16 03:49:50'),
(34, 1, 2, 0, 'AVSCODE: Y\nCVV2MATCH: M\nTRANSACTIONID: 9AU83077TM1164715\n', '2018-06-16 03:24:06'),
(33, 1, 1, 0, 'AVSCODE: Y\nCVV2MATCH: M\nTRANSACTIONID: 3M962199671859408\n', '2018-06-16 00:46:10');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paypal_setting`
--

CREATE TABLE `tbl_paypal_setting` (
  `Id` int(11) NOT NULL,
  `UserName` text CHARACTER SET utf8,
  `Password` text CHARACTER SET utf8,
  `Signature` text CHARACTER SET utf8 COLLATE utf8_danish_ci,
  `Paymentisocode2` varchar(50) DEFAULT NULL,
  `Paymentisocode3` varchar(50) DEFAULT NULL,
  `Paymentzonecode` varchar(50) DEFAULT NULL,
  `Shippingisocode2` varchar(50) DEFAULT NULL,
  `Shippingisocode3` varchar(50) DEFAULT NULL,
  `Shippingzonecode` varchar(50) DEFAULT NULL,
  `Languagecode` varchar(50) DEFAULT NULL,
  `CurrencyCode` varchar(50) DEFAULT NULL,
  `PaymentZoneId` varchar(50) DEFAULT NULL,
  `PaymentZone` int(50) DEFAULT NULL,
  `BillingPeriod` varchar(50) DEFAULT NULL,
  `BillingFrequency` varchar(50) DEFAULT NULL,
  `TotalBillingCycle` varchar(50) DEFAULT NULL,
  `Amt` varchar(50) DEFAULT NULL,
  `Status` int(5) DEFAULT NULL,
  `Created` date DEFAULT NULL,
  `ExpressPeriod` varchar(50) DEFAULT NULL,
  `ExpressFrequency` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_paypal_setting`
--

INSERT INTO `tbl_paypal_setting` (`Id`, `UserName`, `Password`, `Signature`, `Paymentisocode2`, `Paymentisocode3`, `Paymentzonecode`, `Shippingisocode2`, `Shippingisocode3`, `Shippingzonecode`, `Languagecode`, `CurrencyCode`, `PaymentZoneId`, `PaymentZone`, `BillingPeriod`, `BillingFrequency`, `TotalBillingCycle`, `Amt`, `Status`, `Created`, `ExpressPeriod`, `ExpressFrequency`) VALUES
(1, 'bo5alefa_api1.hotmail.com', '6VDFMRM8MKZRPRV3', 'AJeQr6fIi1DEokPcWnYjJHOU7e8MAFKDYQsYNVg5MXdTz-nIdVQw7Cja', 'IE', 'IRL', 'CO', 'IE', 'IRL', 'CO', 'en-gb', 'USD', '1589', 0, '2', '5', '1', '0.5', 1, '2018-07-19', 'Year', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_reviews`
--

CREATE TABLE `tbl_reviews` (
  `Id` int(11) NOT NULL,
  `ClubId` int(11) DEFAULT NULL,
  `BookingId` int(11) DEFAULT NULL,
  `Review` varchar(50) DEFAULT NULL,
  `Reviewscomment` text,
  `PublishStatus` int(5) DEFAULT NULL,
  `Created` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_reviews`
--

INSERT INTO `tbl_reviews` (`Id`, `ClubId`, `BookingId`, `Review`, `Reviewscomment`, `PublishStatus`, `Created`) VALUES
(1, 9, 1, '4', 'This is for test. Please ignore it...', 1, '2018-06-07'),
(2, 19, 17, '5', 'Good Service given to all customer.', 1, '2018-05-31'),
(3, 19, 17, '4', 'best Service', 1, '2018-05-31');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_reviewsimages`
--

CREATE TABLE `tbl_reviewsimages` (
  `Id` int(11) NOT NULL,
  `ReviewId` int(11) DEFAULT NULL,
  `Image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_reviewsimages`
--

INSERT INTO `tbl_reviewsimages` (`Id`, `ReviewId`, `Image`) VALUES
(1, 17, 'b2.jpg'),
(2, 17, 'b3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_setting`
--

CREATE TABLE `tbl_setting` (
  `Id` int(11) NOT NULL,
  `ContactNumber` varchar(255) DEFAULT NULL,
  `Address` text,
  `Email` varchar(255) DEFAULT NULL,
  `Facebook` text,
  `Google` text,
  `Linked` text,
  `Twitter` text,
  `HeaderLogo` varchar(255) DEFAULT NULL,
  `FooterLogo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_setting`
--

INSERT INTO `tbl_setting` (`Id`, `ContactNumber`, `Address`, `Email`, `Facebook`, `Google`, `Linked`, `Twitter`, `HeaderLogo`, `FooterLogo`) VALUES
(1, NULL, 'Edinburgh, UK <br>\r\n12 Simpson Loan', 'info@tablefast.com', NULL, '', '', NULL, 'site-logo1.png', 'footer-logo-one1.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ticket_purches`
--

CREATE TABLE `tbl_ticket_purches` (
  `Id` int(11) NOT NULL,
  `CustomerId` int(11) DEFAULT NULL,
  `ClubId` int(11) DEFAULT NULL,
  `EventId` int(11) DEFAULT NULL,
  `EventType` int(11) DEFAULT NULL,
  `Amount` varchar(255) DEFAULT NULL,
  `Comment` text,
  `Created` varchar(255) DEFAULT NULL,
  `Status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_ticket_purches`
--

INSERT INTO `tbl_ticket_purches` (`Id`, `CustomerId`, `ClubId`, `EventId`, `EventType`, `Amount`, `Comment`, `Created`, `Status`) VALUES
(1, 2, 2, 1, 2, '21', '', '2018-07-19', '0'),
(2, 2, 2, 9, 2, '21', '', '2018-07-19', '0'),
(4, 2, 2, 1, 1, '25', 'AVSCODE: Y\nCVV2MATCH: M\nTRANSACTIONID: 4F854330KL114581H\n', '2018-07-19 08:02 AM', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_vendor`
--

CREATE TABLE `tbl_vendor` (
  `Id` int(11) NOT NULL,
  `FirstName` varchar(255) DEFAULT NULL,
  `LastName` varchar(255) DEFAULT NULL,
  `ClubName` varchar(255) DEFAULT NULL,
  `City` varchar(255) DEFAULT NULL,
  `State` varchar(255) DEFAULT NULL,
  `Country` varchar(255) DEFAULT NULL,
  `Phone` varchar(40) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Created` date DEFAULT NULL,
  `Status` int(5) DEFAULT NULL,
  `PaymentStatus` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `AlternativePhone` varchar(50) DEFAULT NULL,
  `PostCode` varchar(50) DEFAULT NULL,
  `AddressIfram` text,
  `ContactName` varchar(255) DEFAULT NULL,
  `Address` text,
  `Slug` varchar(255) DEFAULT NULL,
  `txnid` varchar(255) DEFAULT NULL,
  `payment_amount` varchar(255) DEFAULT NULL,
  `payment_status` varchar(255) DEFAULT NULL,
  `itemidv` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_vendor`
--

INSERT INTO `tbl_vendor` (`Id`, `FirstName`, `LastName`, `ClubName`, `City`, `State`, `Country`, `Phone`, `Password`, `Created`, `Status`, `PaymentStatus`, `Email`, `AlternativePhone`, `PostCode`, `AddressIfram`, `ContactName`, `Address`, `Slug`, `txnid`, `payment_amount`, `payment_status`, `itemidv`) VALUES
(1, 'Rahul', 'Varma', 'Fastclub', 'Baroda', '4725', 'Gujarat', '9345438534', '25d55ad283aa400af464c76d713c07ad', '2018-05-02', 4, NULL, 'rahulcueserve16@gmail.com', '0265884564', NULL, 'Ajwa+road,+super+bakery+baroda+', 'Rahul Varma', 'Ajwa road, super bakery baroda ', 'fastclub', NULL, NULL, NULL, NULL),
(2, 'Bhavna', 'Bariya', 'Light Club', 'Baroda', '4683', 'Gujarat', '9845453734', '25d55ad283aa400af464c76d713c07ad', '2018-05-02', 4, NULL, 'bhavna1@cueserve.com', '6546456456', NULL, 'swami+Vivekananda+school+vadhodiya+road+', 'Bhavna Baria', 'swami Vivekananda school vadhodiya road ', 'light-club', NULL, NULL, NULL, NULL),
(3, 'Hardik', 'Baria', 'Rangoli', 'baroda', NULL, 'Gujarat', '1321312312', '25d55ad283aa400af464c76d713c07ad', '2018-05-03', 4, NULL, 'baria.hardik@gmail.com', '4533454354', '390019', 'baroda', 'Hardik Baria', 'baroda', 'rangoli', NULL, NULL, NULL, NULL),
(4, 'Hardy', 'Bariya', 'Sun Bar', 'baroda', NULL, 'Gujarat', '5675675676', '25d55ad283aa400af464c76d713c07ad', '2018-05-03', 4, NULL, 'bariya.hardik@gmail.com', '5675675675', '390019', 'singapur', 'Hardy Baria', 'singapur', 'sun-bar', NULL, NULL, NULL, NULL),
(5, 'Sumit', 'Patel', 'Royal Club', 'baroda', NULL, 'Gujarat', '9546856884', '25d55ad283aa400af464c76d713c07ad', '2018-05-03', 4, NULL, 'sumitpatel@gmail.com', '9834584534', '390019', 'alkapuri+siya+riya+baroda', 'Sumit Patel', 'alkapuri siya riya ,baroda', 'royal-club', NULL, NULL, NULL, NULL),
(6, 'Jaya', 'Patel', 'Capital Club', 'Amdabad', NULL, 'Gujarat', '9835345345', '25d55ad283aa400af464c76d713c07ad', '2018-05-03', 4, NULL, 'jaya@cueserve.com', '9975656756', '390019', 'amdabad', 'Jaya Patel', 'amdabad', 'capital-club', NULL, NULL, NULL, NULL),
(9, 'Himansi', 'Shah', 'Star Dot Club', 'baroda', '', 'Gujarat', '6351346285', 'da2f73a3a352e479f387fe35a3c417ea', '2018-05-15', 4, NULL, 'rahulcueserve65@gmail.com', '5444444444', '390019', 'Bldg+No+14,+Jay+Prakash+Rd,+Andheri', 'Himansi Shah', 'Bldg No 14, Jay Prakash Rd, Andheri', 'star-dot-club', NULL, NULL, NULL, NULL),
(10, 'Unnati', 'Rana', 'Sky Club', 'Baroda', '', 'India', '9157329875', 'f925916e2754e5e03f75dd58a5733251', '2018-05-17', 4, NULL, 'ranaunnati4@gmail.com', '5050505050', '390006', 'Raopura,+baroda+-+390006', 'Unnati', 'Raopura, baroda - 390006', 'sky-club', NULL, NULL, NULL, NULL),
(12, 'Sumit', 'Patel', 'Snake and Jake’s Christmas Club Lounge', ' Mumbai', '', 'India', '9157329800', 'f925916e2754e5e03f75dd58a5733251', '2018-05-24', 4, NULL, 'cue.sumit.patel@gmail.com', '760098800', '400058', 'Bldg+No+14,+Jay+Prakash+Rd,+Opp+Ram+Mandir,+Andheri+Market,+Andheri+(west)', 'Sumit', 'Bldg No 14, Jay Prakash Rd, Opp Ram Mandir, Andheri Market, Andheri (west)', 'snake-and-jakes-christmas-club-lounge', NULL, NULL, NULL, NULL),
(17, 'ahmad', 'ahmad', 'z club', 'doha', NULL, 'qatar', '0000000000', NULL, '2018-05-28', 0, NULL, 'ha340609@ohio.edu', '0000000000', '00794', 'doha,qatar', 'ahmad', 'doha,qatar', 'z-club', NULL, NULL, NULL, NULL),
(18, 'Ali', 'Alsayegh', 'Club 7 ', NULL, NULL, NULL, NULL, NULL, '2018-05-28', 0, NULL, 'ali88qa@gmail.com', NULL, NULL, NULL, NULL, NULL, 'club-7', NULL, NULL, NULL, NULL),
(19, 'Bhavna', 'Baria', 'Duty Free', 'baroda', '', 'Gujarat', '9985468948568', '2c9341ca4cf3d87b9e4eb905d6a3ec45', '2018-05-31', 4, NULL, 'rahulcueserve63@gmail.com', '5647437668595678', NULL, 'baroda', 'Bhavna cueserve', 'baroda', 'duty-free', NULL, NULL, NULL, NULL),
(20, 'bhavna', 'cueserve', 'Cueserve club', 'baroda', NULL, 'Gujarat', '0000005801', NULL, '2018-05-29', 0, NULL, 'cue@g.c', '0000000000', '390019', 'baroda', 'bhavna cueserve', 'baroda', 'cueserve-club', NULL, NULL, NULL, NULL),
(21, 'sumit', 'Patel', 'chilli bar (below average class)', 'baroda', NULL, 'Gujarat', '978345353445', 'f925916e2754e5e03f75dd58a5733251', '2018-05-30', 4, NULL, 'sumit@gmail.com', '567657565653', '390019', 'baroda', 'Sumit Patel', 'baroda', 'chilli-bar-below-average-class', NULL, NULL, NULL, NULL),
(22, 'W', 'lounge', 'W lounge (high-end) ', 'baroda', '4728', 'Gujarat', '009988776655', '2c9341ca4cf3d87b9e4eb905d6a3ec45', '2018-05-30', 4, NULL, 'w@gmail.com', '0987654321', '390019', 'baroda', 'W lounge', 'baroda', 'w-lounge', NULL, NULL, NULL, NULL),
(23, 'Paradise ', 'beach ', 'Paradise beach (medium class)', 'baroda', '5162', 'Gujarat', '990088345345', 'f925916e2754e5e03f75dd58a5733251', '2018-05-30', 4, NULL, 'paradise@gmail.com', '5466664444444', '390019', 'Paradise+beach', 'Paradise beach', 'Paradise beach', 'paradise-beach', NULL, NULL, NULL, NULL),
(27, 'Laurence', 'Garcia', 'India\'s big club', 'baroda', '4669', 'Gujarat', '1234567890', NULL, '2018-05-30', 4, NULL, 'laurencegarciassss304@gmail.com', '1100000444134534', NULL, 'Near+manjalpur,+sindhvai+mata+road,+baroda+-+390004', 'Laurence', 'baroda', 'big-club', NULL, NULL, NULL, NULL),
(32, 'Rahul', 'Varma', 'Habib Club', 'Baroda', '4640', 'India', '97457564644565', '2c9341ca4cf3d87b9e4eb905d6a3ec45', '2018-06-11', 4, NULL, 'rahulcueserve6@gmail.com', '64445433333', NULL, 'baroda', 'Rahul Varma', 'baroda', 'habib-club2', NULL, NULL, NULL, NULL),
(33, 'Rahul', 'Verma', 'sitaraom', NULL, '', NULL, NULL, 'aff8c7c4f8d9fab3bb7322ea79cc5170', '2018-06-11', 0, NULL, 'rahul@cueserve.com', NULL, NULL, NULL, NULL, NULL, 'sitaraom', NULL, NULL, NULL, NULL),
(34, 'Jamarie', 'Escobar', 'Jam\'s Club', 'Doha', NULL, 'Qatar', '55698832', NULL, '2018-06-30', 0, NULL, 'jamarie_31@yahoo.com', '55698832', NULL, 'Hatem+St.+Al+Hilal', 'Jamarie', 'Hatem St. Al Hilal', 'jams-club', NULL, NULL, NULL, NULL),
(37, 'Czarina', 'Parada', 'Czarina\'s Club', NULL, NULL, NULL, NULL, NULL, '2018-07-02', 0, NULL, 'ynahxd@yahoo.com', NULL, NULL, NULL, NULL, NULL, 'czarina-club', NULL, NULL, NULL, NULL),
(38, 'Nirmal ', 'Chauhan', 'Test 12345 Club ', NULL, NULL, NULL, NULL, NULL, '2018-07-03', 0, NULL, 'nirmal12@cueserve.com', NULL, NULL, NULL, NULL, NULL, 'test-12345-club', NULL, NULL, NULL, NULL),
(41, 'joy', 'staff', '3july', NULL, '4543', NULL, NULL, 'f925916e2754e5e03f75dd58a5733251', '2018-07-03', 0, NULL, 'laurencegarcia304@gmail.com', NULL, NULL, NULL, NULL, NULL, '3july', '', NULL, NULL, NULL),
(42, 'Mark Ron', 'Ancheta', 'Jam\'s Club', NULL, NULL, NULL, NULL, NULL, '2018-07-07', 0, NULL, 'markron.ancheta02@gmail.com', NULL, NULL, NULL, NULL, NULL, 'jam-club', '4778', NULL, NULL, NULL),
(43, 'Joy', 'Vidal', 'Mansoura', NULL, NULL, NULL, NULL, NULL, '2018-07-07', 0, NULL, 'vidal.joy14@gmail.com', NULL, NULL, NULL, NULL, NULL, 'mansoura', '7267', NULL, NULL, NULL),
(44, 'Joy', 'Vidal', 'Shanghai Club', 'Doha', '', 'Qatar', '(974) 4429 5295', 'e7bd25a61916afbdfcedef3c2d456b41', NULL, 2, NULL, 'joy.vidal16@gmail.com', '00000000', NULL, 'Conference+Centre+Street,+West+Bay,+P.O.Box+9282,+Doha,+Qatar', 'Shanghai Club', 'Conference Centre Street, West Bay, P.O.Box 9282, Doha, Qatar', 'shanghai-club', NULL, NULL, NULL, NULL),
(45, 'Bhavna', 'Baria', 'Cueserve Test', 'baroda', '5070', 'Gujarat', '9988776655', '25d55ad283aa400af464c76d713c07ad', NULL, 2, NULL, 'bhavna@cueserve.com', '8877665544', NULL, 'baroda', 'Bhavna Baria', 'baroda', 'cueserve-test', NULL, NULL, NULL, NULL),
(46, 'Shangri-La', 'Hotel', 'Lobby Lounge', 'Doha', '', 'Qatar', '(974) 4429 5001', '2fda63cc20ebd7c145c2700343074e5d', NULL, 2, NULL, 'jazzjavier07@gmail.com', '00000000', NULL, 'Conference+Centre+Street,+West+Bay,+P.O.Box+9282,+Doha,+Qatar+Doha-+Qatar', 'Shangri-La Hotel', 'Conference Centre Street, West Bay, P.O.Box 9282, Doha, Qatar  Doha- ,Qatar', 'lobby-lounge', NULL, NULL, NULL, NULL),
(47, 'Shangri-La', 'Hotel', 'Pool Bar', 'Doha', '4757', 'Qatar', '111111111', NULL, NULL, 2, NULL, 'info@xcardq.com', '00000000', NULL, 'Conference+Centre+Street,+West+Bay,+P.O.Box+9282,+Doha,+Qatar', 'Shangri-La Hotel', 'Level 7, Conference Centre Street, West Bay, P.O.Box 9282, Doha, Qatar', 'pool-bar', NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_banner`
--
ALTER TABLE `tbl_banner`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_booking`
--
ALTER TABLE `tbl_booking`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_booking_calender`
--
ALTER TABLE `tbl_booking_calender`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_clubgallery`
--
ALTER TABLE `tbl_clubgallery`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_clublayout`
--
ALTER TABLE `tbl_clublayout`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_events`
--
ALTER TABLE `tbl_events`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_event_ticket_update`
--
ALTER TABLE `tbl_event_ticket_update`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_event_type`
--
ALTER TABLE `tbl_event_type`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_facility`
--
ALTER TABLE `tbl_facility`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_foodcategory`
--
ALTER TABLE `tbl_foodcategory`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_fooditem`
--
ALTER TABLE `tbl_fooditem`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_information`
--
ALTER TABLE `tbl_information`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_meta`
--
ALTER TABLE `tbl_meta`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_newsletter`
--
ALTER TABLE `tbl_newsletter`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_packageitem`
--
ALTER TABLE `tbl_packageitem`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_packages`
--
ALTER TABLE `tbl_packages`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_payment_history`
--
ALTER TABLE `tbl_payment_history`
  ADD PRIMARY KEY (`order_history_id`);

--
-- Indexes for table `tbl_paypal_setting`
--
ALTER TABLE `tbl_paypal_setting`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_reviews`
--
ALTER TABLE `tbl_reviews`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_reviewsimages`
--
ALTER TABLE `tbl_reviewsimages`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_setting`
--
ALTER TABLE `tbl_setting`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_ticket_purches`
--
ALTER TABLE `tbl_ticket_purches`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_vendor`
--
ALTER TABLE `tbl_vendor`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_banner`
--
ALTER TABLE `tbl_banner`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_booking`
--
ALTER TABLE `tbl_booking`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `tbl_booking_calender`
--
ALTER TABLE `tbl_booking_calender`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_clubgallery`
--
ALTER TABLE `tbl_clubgallery`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=190;

--
-- AUTO_INCREMENT for table `tbl_clublayout`
--
ALTER TABLE `tbl_clublayout`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_events`
--
ALTER TABLE `tbl_events`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_event_ticket_update`
--
ALTER TABLE `tbl_event_ticket_update`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_event_type`
--
ALTER TABLE `tbl_event_type`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_facility`
--
ALTER TABLE `tbl_facility`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_foodcategory`
--
ALTER TABLE `tbl_foodcategory`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `tbl_fooditem`
--
ALTER TABLE `tbl_fooditem`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT for table `tbl_meta`
--
ALTER TABLE `tbl_meta`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_newsletter`
--
ALTER TABLE `tbl_newsletter`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_packageitem`
--
ALTER TABLE `tbl_packageitem`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_packages`
--
ALTER TABLE `tbl_packages`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_payment_history`
--
ALTER TABLE `tbl_payment_history`
  MODIFY `order_history_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `tbl_paypal_setting`
--
ALTER TABLE `tbl_paypal_setting`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_reviews`
--
ALTER TABLE `tbl_reviews`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_reviewsimages`
--
ALTER TABLE `tbl_reviewsimages`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_setting`
--
ALTER TABLE `tbl_setting`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_ticket_purches`
--
ALTER TABLE `tbl_ticket_purches`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_vendor`
--
ALTER TABLE `tbl_vendor`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
