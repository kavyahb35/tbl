<?php

 require_once(APPPATH.'libraries/Facebook/facebook.php');
 
 $config['App_ID'] = '343420756183797';//450453158710367
 $config['App_Secret'] = 'ac5a3b42abe1e3775104f29509d7d476';//d782cac8db097c46f34bcea27294eaa9

 $facebook = new Facebook(array(
  'appId'  => $config['App_ID'],
  'secret' => $config['App_Secret']
 ));

?>
