<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Food extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->helper('new_helper');
        $this->load->library('form_validation');
        $this->load->library('email');
        $this->load->library('session');
        $this->load->library('pagination');
        $this->load->helper('url');
    }
    
    public function foodcategory()
    {
        $this->App->checkVendorAuthenticate();
        $id                   = $this->session->userdata['vendorauth']['Id'];
        $tot                  = $this->App->getPerticularRecord('tbl_foodcategory', 'ClubId', $id);
        $data["listcategory"] = $this->App->getPerticularRecord('tbl_foodcategory', 'ClubId', $id);
        $this->load->view('front/food/foodcategory', $data);
    }
    public function foodcategory_ci_pagination()
    {
        $this->App->checkVendorAuthenticate();
        $id                    = $this->session->userdata['vendorauth']['Id'];
        $tot                   = $this->App->getPerticularRecord('tbl_foodcategory', 'ClubId', $id);
        $config["base_url"]    = base_url() . "food/foodcategory/";
        $config["total_rows"]  = count($tot);
        $config["per_page"]    = 10;
        $config["uri_segment"] = 3;
        $this->pagination->initialize($config);
        $page                 = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["listcategory"] = $this->App->fetch_fooditem('tbl_foodcategory', 'ClubId', $id, $config["per_page"], $page);
        $data["links"]        = $this->pagination->create_links();
        
        $this->load->view('front/include/header');
        $this->load->view('front/food/foodcategory', $data);
        $this->load->view('front/include/footer');
    }
    public function addcategory()
    {
        $this->App->checkVendorAuthenticate();
        $category = $this->input->post('category');
        $id       = $this->session->userdata['vendorauth']['Id'];
        $s        = $this->db->query("select * from tbl_foodcategory where Title='" . $category . "' and ClubId='" . $id . "'");
        $res      = $s->num_rows();
        if ($res > 0) {
            echo json_encode('2');
        } else {
            $trim    = trim($category);
            $ow      = strtolower($trim);
            $string  = str_replace(' ', '-', $ow);
            $str     = preg_replace('/\s+/', '-', $string);
            $chkslug = $this->App->checkExist('tbl_foodcategory', 'Slug', $str);
            if ($chkslug == '1') {
                $r    = rand(1, 4);
                $slug = $str . $r;
            } else {
                $slug = $str;
            }
            $array = array(
                'Title' => $category,
                'Slug' => $slug,
                'Status' => '1',
                'ClubId' => $id,
                'Created' => date('Y-m-d')
            );
            $this->App->insertdata('tbl_foodcategory', $array);
            echo json_encode('1');
        }
        
    }
    public function deleteCategory()
    {
        $this->App->checkVendorAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('tbl_foodcategory', 'Id', $id);
        $this->App->deletedata('tbl_fooditem', 'CategoryId', $id);
        return 1;
    }
    public function updatefrom()
    {
        $this->App->checkVendorAuthenticate();
        $id  = $this->input->post('id');
        $ads = $this->App->getPerticularRecord('tbl_foodcategory', 'Id', $id);
        $sd  = '';
        if (!empty($ads)) {
            foreach ($ads as $tes) {
                $tit     = $tes['Title'];
                $cid     = $tes['Id'];
                $cstatus = $tes['Status'];
                $sd .= '<div class="modal fade" id="myModal2" role="dialog"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="close" data-dismiss="modal">&times;</button><h4 class="modal-title" >Update Category</h4></div><div class="modal-body"><form id="demo-form2" method="post" class="form-horizontal form-label-left"><div id="err2" style="color:red"></div><div id="err3" style="color:red"></div><div class="form-group"><div class="col-md-12 col-sm-12 col-xs-12"><input id="cattitle1" class="form-control col-md-12 col-xs-12" placeholder="Title" required="required" type="text" name="cattitle1" value="' . $tit . '"><input type="hidden" name="catid" id="catid" value="' . $cid . '"></div></div> <div class="ln_solid"></div>
                <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                        <label style="text-align:left">Status</label>
                         <select class="form-control col-md-12 col-xs-12"  id="catstatus" name="catstatus">
                        <option value="1"';
                if ($cstatus == "1") {
                    $sd .= 'selected=selected';
                }
                $sd .= '>Active</option>
                        <option value="0"';
                if ($cstatus == "0") {
                    $sd .= 'selected=selected';
                }
                $sd .= '>Inactive</option>
                         </select>
                          </div>
                      </div>
                <div class="form-group"><div class="col-md-12 col-sm-12 col-xs-12 "> <button type="button" class="btn btn-default" onclick="editcategory()">Submit</button></div></div></form></div></div></div> </div>';
            }
        }
        $sd .= '</div>';
        $data = $sd;
        echo json_encode($data);
    }
    public function editcategory()
    {
        $this->App->checkVendorAuthenticate();
        $category  = $this->input->post('category');
        $catstatus = $this->input->post('catstatus');
        $cid       = $this->input->post('id');
        $id        = $this->session->userdata['vendorauth']['Id'];
        $catstatus = $this->input->post('catstatus');
        $s         = $this->db->query("select * from tbl_foodcategory where Title='" . $category . "' and ClubId='" . $id . "' and Id<>'" . $cid . "'");
        $res       = $s->num_rows();
        if ($res > 0) {
            echo json_encode('2');
        } else {
            $trim    = trim($category);
            $ow      = strtolower($trim);
            $string  = str_replace(' ', '-', $ow);
            $str     = preg_replace('/\s+/', '-', $string);
            $chkslug = $this->App->checkExist('tbl_foodcategory', 'Slug', $str);
            if ($chkslug == '1') {
                $r    = rand(1, 4);
                $slug = $str . $r;
            } else {
                $slug = $str;
            }
            $array = array(
                'Title' => $category,
                'Slug' => $slug,
                'Status' => $catstatus,
                'ClubId' => $id,
                'Created' => date('Y-m-d')
            );
            $this->App->update('tbl_foodcategory', 'Id', $cid, $array);
            echo json_encode('1');
        }
    }
    public function fooditem()
    {
        $this->App->checkVendorAuthenticate();
        $id                   = $this->session->userdata['vendorauth']['Id'];
        $data["listcategory"] = $this->App->getPerticularRecord('tbl_fooditem', 'ClubId', $id);
 $data['categorylist'] = $this->App->passwordChecking('tbl_foodcategory', 'Status', 'ClubId', '1', $id);
        
        $this->load->view('front/food/fooditem', $data);
    }
    
    public function fooditem_ci_pagination()
    {
        $this->App->checkVendorAuthenticate();
        $id                   = $this->session->userdata['vendorauth']['Id'];
        $fooditem             = $this->App->getPerticularRecord('tbl_fooditem', 'ClubId', $id);
        $count                = count($fooditem);
        $data['categorylist'] = $this->App->passwordChecking('tbl_foodcategory', 'Status', 'ClubId', '1', $id);
        
        $config["base_url"]    = base_url() . "food/fooditem/";
        $config["total_rows"]  = $count;
        $config["per_page"]    = 10;
        $config["uri_segment"] = 3;
        $this->pagination->initialize($config);
        $page                 = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["listcategory"] = $this->App->fetch_fooditem('tbl_fooditem', 'ClubId', $id, $config["per_page"], $page);
        $data["links"]        = $this->pagination->create_links();
        
        $this->load->view('front/include/header');
        $this->load->view('front/food/fooditem', $data);
        $this->load->view('front/include/footer');
    }
    public function additem()
    {
        $this->App->checkVendorAuthenticate();
        $category  = $this->input->post('category');
        $itemtitle = $this->input->post('itemtitle');
        $price     = $this->input->post('price');
        $id        = $this->session->userdata['vendorauth']['Id'];
        
        $trim    = trim($itemtitle);
        $ow      = strtolower($trim);
        $string  = str_replace(' ', '-', $ow);
        $str     = preg_replace('/\s+/', '-', $string);
        $chkslug = $this->App->checkExist('tbl_fooditem', 'Slug', $str);
        if ($chkslug == '1') {
            $r    = rand(1, 4);
            $slug = $str . $r;
        } else {
            $slug = $str;
        }
        $array = array(
            'Title' => $itemtitle,
            'Slug' => $slug,
            'Status' => '1',
            'CategoryId' => $category,
            'Price' => $price,
            'ClubId' => $id,
            'Created' => date('Y-m-d')
        );
        $this->App->insertdata('tbl_fooditem', $array);
        echo json_encode('1');
        
    }
    public function deleteitem()
    {
        $this->App->checkVendorAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('tbl_fooditem', 'Id', $id);
        return 1;
    }
    public function updateitemfrom()
    {
        $this->App->checkVendorAuthenticate();
        $id  = $this->input->post('id');
        $ads = $this->App->getPerticularRecord('tbl_fooditem', 'Id', $id);
        
        $vid          = $this->session->userdata['vendorauth']['Id'];
        $categorylist = $this->App->passwordChecking('tbl_foodcategory', 'Status', 'ClubId', '1', $vid);
        $sd           = '';
        if (!empty($ads)) {
            foreach ($ads as $tes) {
                $rice       = $tes['Price'];
                $CategoryId = $tes['CategoryId'];
                $tit        = $tes['Title'];
                $cid        = $tes['Id'];
                $cstatus    = $tes['Status'];
                $sd .= '
                    <div class="modal fade" id="myModal2" role="dialog">
                      <div class="modal-dialog">

                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title" >Update Item</h4>
                          </div>
                          <div class="modal-body">
                          <form id="demo-form2" method="post" class="form-horizontal form-label-left">
                                        <div id="err" style="color:red"></div>
                                        <div id="err1" style="color:red"></div>
                                         <div class="form-group">
                                          <div class="col-md-12 col-sm-12 col-xs-12">
                                          <label style="text-align:left">Category</label>
                                           <select class="form-control col-md-12 col-xs-12"  id="cattitle1" name="cattitle1" >';
                if (!empty($categorylist)) {
                    foreach ($categorylist as $catall) {
                        $pid  = $catall['Id'];
                        $ptit = $catall['Title'];
                        $sd .= '<option value="' . $pid . '"';
                        if ($pid == $CategoryId) {
                            $sd .= 'selected=selected';
                        }
                        $sd .= ' >' . $ptit . '</option>';
                    }
                }
                $sd .= ' </select>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                          <div class="col-md-12 col-sm-12 col-xs-12">
                                            <input id="itemtitle1" class="form-control col-md-12 col-xs-12" placeholder="Title" required="required" type="text" name="itemtitle1" value="' . $tit . '">
                                          <input type="hidden" value="' . $cid . '" name="itemid" id="itemid">
                                          </div>
                                        </div>
                                          <div class="form-group">
                                          <div class="col-md-12 col-sm-12 col-xs-12">
                                            <input id="price1" class="form-control col-md-12 col-xs-12" placeholder="Price" required="required" type="text" name="price1" value="' . $rice . '">
                                          </div>
                                        </div>

                                        <div class="form-group">
                                          <div class="col-md-12 col-sm-12 col-xs-12">
                                          <label style="text-align:left">Status</label>
                                           <select class="form-control col-md-12 col-xs-12"  id="catstatus" name="catstatus">
                                          <option value="1"';
                if ($cstatus == "1") {
                    $sd .= 'selected=selected';
                }
                $sd .= '>Active</option>
                                          <option value="0"';
                if ($cstatus == "0") {
                    $sd .= 'selected=selected';
                }
                $sd .= '>Inactive</option>
                                           </select>
                                            </div>
                                        </div>


                                        <div class="ln_solid"></div>
                                        <div class="form-group">
                                          <div class="col-md-12 col-sm-12 col-xs-12 ">
                                            <button type="button" class="btn btn-default" onclick="editcategory()">Submit</button>
                                          </div>
                                        </div>

                                      </form>

                          </div>
                          
                        </div>

                      </div>
                    </div>

                  </div>';
            }
        }
        $sd .= '</div>';
        $data = $sd;
        echo json_encode($data);
        
    }
    public function edititem()
    {
        $this->App->checkVendorAuthenticate();
        $category  = $this->input->post('category');
        $itemtitle = $this->input->post('itemtitle1');
        $price     = $this->input->post('price1');
        $itemid    = $this->input->post('itemid');
        $id        = $this->session->userdata['vendorauth']['Id'];
        $catstatus = $this->input->post('catstatus');
        
        $trim    = trim($itemtitle);
        $ow      = strtolower($trim);
        $string  = str_replace(' ', '-', $ow);
        $str     = preg_replace('/\s+/', '-', $string);
        $chkslug = $this->App->checkExist('tbl_fooditem', 'Slug', $str);
        if ($chkslug == '1') {
            $r    = rand(1, 4);
            $slug = $str . $r;
        } else {
            $slug = $str;
        }
        $array = array(
            'Title' => $itemtitle,
            'Slug' => $slug,
            'Status' => $catstatus,
            'CategoryId' => $category,
            'Price' => $price,
            'ClubId' => $id,
            'Created' => date('Y-m-d')
        );
        
        $this->App->update('tbl_fooditem', 'Id', $itemid, $array);
        echo json_encode('1');
    }
    
}
