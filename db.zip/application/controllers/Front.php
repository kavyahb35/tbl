<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Front extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->helper('new_helper');
        $this->load->library('pagination');
        $this->load->helper('url');        
        $this->load->library('form_validation');
        $this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
    }
    public function index_bk()
    {
        $data['clubs']  = $this->App->getRecordByLimit('tbl_vendor', 'Status', '2', '0', '1');
        $data['clubs1'] = $this->App->getRecordByLimit('tbl_vendor', 'Status', '2', '1', '1');
        $data['clubs2'] = $this->App->getRecordByLimit('tbl_vendor', 'Status', '2', '2', '1');
        
        $data['clubs3rec'] = $this->App->getRecordByLimit('tbl_vendor', 'Status', '2', '0', '4');
        
        $data['clubs4rec'] = $this->App->getRecordByLimit('tbl_vendor', 'Status', '2', '0', '4');
        $data['Allclub']   = $this->App->getPerticularRecord('tbl_vendor', 'Status', '2');
        $data['Allbanner']   = $this->App->getPerticularRecord('tbl_banner', 'Status', '1');
        
        $this->load->view('front/include/header');
        $this->load->view('front/home', $data);
        $this->load->view('front/include/footer');
    }
      public function index()
    {
         $data['clubs']  = $this->App->getRecordByLimit('tbl_vendor', 'Status', '2', '0', '1');
        $data['clubs1'] = $this->App->getRecordByLimit('tbl_vendor', 'Status', '2', '1', '1');
        $data['clubs2'] = $this->App->getRecordByLimit('tbl_vendor', 'Status', '2', '2', '1');        
        $data['clubs4rec'] = $this->App->getRecordByLimit('tbl_vendor', 'Status', '2', '0', '4');
        
        $res = $this->db->query("select tbl_vendor.* from tbl_vendor join tbl_reviews on tbl_vendor.Id=tbl_reviews.ClubId where Status='2'");
        $arra =$res->result_array();
        if(!empty($arra)){
			foreach($arra as $resf){					
				   $rid[]=$resf['Id'];
				}
			}
			$unic = array_unique($rid);
			 $count=count($unic);
			 $unicarr =array();
			   for($i=0;$i<$count;$i++){
				  $query= $this->db->query("select * from tbl_vendor where Id='".$unic[$i]."'");
				    $unicary = $query->result_array();
				    $unicarr[] = $unicary[0];
				  }	
			
				
				if(!empty($unicarr)){
					$data['clubs3rec'] = $unicarr;
				}else{
					$data['clubs3rec'] =$this->App->getRecordByLimit('tbl_vendor', 'Status', '2', '0', '4');
				}
				
				/* event data */
				$ter = $this->db->query("select tbl_events.* from tbl_vendor join tbl_events on tbl_vendor.Id=tbl_events.ClubId where tbl_vendor.Status='2' and tbl_events.Status='1'");
				$allevent= $ter->result_array();
				$currentdt = date('Y-m-d',strtotime("-1 days"));							
							if(!empty($allevent)){
									foreach($allevent as $evnt){
									    $fromdate = $evnt['FromDate'];	
										$todate = $evnt['ToDate'];	
										$specialdate = $evnt['OneDate'];
										$NoofDays = $evnt['NoofDays'];
									     
									      if($NoofDays=='1')
                                                      { 
                                                         if(strtotime($currentdt) < strtotime($specialdate))
                                                         {
															$getevent[]=$evnt['Id']; 
														}
													}
										   if($NoofDays > '1'){
                                                  if((strtotime($currentdt) < strtotime($fromdate) && strtotime($currentdt) < strtotime($todate)) ||  strtotime($currentdt) < strtotime($todate))
                                                { 
													$getevent[]=$evnt['Id'];
												}
											}	
									}
							}
				$countevent = count($getevent);
				for($i=0;$i<$countevent;$i++){
				  $query= $this->db->query("select * from tbl_events where Id='".$getevent[$i]."'");
				    $unicary = $query->result_array();
				    $allevents[] = $unicary[0];
				  }
				  $data['allevents']=$allevents;
				/* event code */
			
			
       
        $data['Allclub']   = $this->App->getPerticularRecord('tbl_vendor', 'Status', '2');
        $data['Allbanner']   = $this->App->getPerticularRecord('tbl_banner', 'Status', '1');
        
        $this->load->view('front/include/header');
        $this->load->view('front/home', $data);
        $this->load->view('front/include/footer');
    }
    public function login()
    {
        $this->load->view('front/include/header');
        $this->load->view('front/login');
        $this->load->view('front/include/footer');
    }
    public function register()
    {
        $this->load->view('front/include/header');
        $this->load->view('front/ragister');
        $this->load->view('front/include/footer');
    }
    public function clubdetails($slug = '')
    {
        $data['vendordetails'] = $this->App->getPerticularRecord('tbl_vendor', 'Slug', $slug);
        $this->load->view('front/include/header');
        $this->load->view('front/tabclubdetails', $data);
        $this->load->view('front/include/footer');
    }
    public function allclub()
    {
        $data['allrec'] = $this->App->getPerticularRecord('tbl_vendor', 'Status', '2');
        $data['clubs']  = $this->App->getRecordByLimit('tbl_vendor', 'Status', '2', '0', '1');
        $data['clubs1'] = $this->App->getRecordByLimit('tbl_vendor', 'Status', '2', '1', '1');
        $data['clubs2'] = $this->App->getRecordByLimit('tbl_vendor', 'Status', '2', '2', '1');
        $countx = $this->App->getPerticularRecord('tbl_vendor', 'Status', '2');
         $count=count($countx);

        $config["base_url"]    = base_url() . "front/allclub/";
        $config["total_rows"]  = $count;
        $config["per_page"]    = 16;
        $config["uri_segment"] = 3;
        $this->pagination->initialize($config);
        $page            = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["results"] = $this->App->fetch_departments('tbl_vendor', $config["per_page"], $page);
        $data["links"]   = $this->pagination->create_links();
        
        
        $this->load->view('front/include/header');
        $this->load->view('front/listclub', $data);
        $this->load->view('front/include/footer');
    }
    
    public function autosearch()
    {
        $category = $this->input->post('category');
        $det      = $this->db->query("select * from tbl_vendor where Status='2' and (ClubName LIKE '%" . $category . "%' or Address Like '%" . $category . "%')");
        
        $tes = $det->result_array();
        
        $sd = '<div class="main">';
        if (!empty($tes)) {
            foreach ($tes as $tess) {
                $clv    = $tess['ClubName'];
                $id     = $tess['Id'];
                $city   = $tess['City'];
                $layout = $this->App->getPerticularRecord('tbl_clublayout', 'VendorId', $id);
                $img    = $layout[0]['MainImage'];
                $path   = base_url('assets/clubimage/210X150/' . $img);
                $sd .= '<a onclick="searchfun(' . $id . ')"><div class="mop"> <img src="' . $path . '" class="imgsearch"> ' . $clv . '</div></a>';
            }
        }
        $sd .= '</div>';
        $data = $sd;
        echo json_encode($data);
    }
    public function getname()
    {
        $id     = $this->input->post('id');
        $layout = $this->App->getPerticularRecord('tbl_vendor', 'Id', $id);
        $nmn    = $layout[0]['ClubName'];
        echo json_encode($nmn);
    }
    public function search()
    {
        $clubname = $this->input->post('clubname');
        $bookdata = $this->input->post('bookdata');
        $adult    = $this->input->post('adult');
        $child    = $this->input->post('child');
        
        if ($clubname != '' && $bookdata != '' && $adult != '' && $child != '') {
            $que               = $this->db->query("select * from tbl_vendor where (ClubName Like '%" . $clubname . "%' or Address Like '%" . $clubname . "%') and Status='2'");
            $data['putresult'] = $que->result_array();
            $que               = $this->db->query("select * from tbl_vendor where ClubName<>'" . $clubname . "' and Status='2'");
            
        } elseif ($clubname != '' && $bookdata != '' && $adult != '' && $child == '') {
            $que               = $this->db->query("select * from tbl_vendor where (ClubName Like '%" . $clubname . "%' or Address Like '%" . $clubname . "%')  and Status='2'");
            $data['putresult'] = $que->result_array();
            $que               = $this->db->query("select * from tbl_vendor where ClubName<>'" . $clubname . "' and Status='2'");
            
        } elseif ($clubname != '' && $bookdata != '' && $adult == '' || $child == '') {
            $que               = $this->db->query("select * from tbl_vendor where (ClubName Like '%" . $clubname . "%' or Address Like '%" . $clubname . "%') and Status='2'");
            $data['putresult'] = $que->result_array();
            $que               = $this->db->query("select * from tbl_vendor where ClubName<>'" . $clubname . "' and Status='2'");
            
        } elseif ($clubname == '' && $bookdata != '' || $adult == '' || $child == '') {
            
            $que               = $this->db->query("select * from tbl_vendor where Status='2' and (ClubName Like '%" . $clubname . "%' or Address Like '%" . $clubname . "%')");
            $data['putresult'] = $que->result_array();
            
        } else {
            $que               = $this->db->query("select * from tbl_vendor where Status='2' and (ClubName Like '%" . $clubname . "%' or Address Like '%" . $clubname . "%')");
            $data['putresult'] = $que->result_array();
            
        }
        
        $this->load->view('front/include/header');
        $this->load->view('front/searchclub', $data);
        $this->load->view('front/include/footer');
    }
    public function detail($slug = '')
    {
        $data['vendordetails'] = $this->App->getPerticularRecord('tbl_vendor', 'Slug', $slug);
        $this->load->view('front/include/header');
        $this->load->view('front/tabclubdetails', $data);
        $this->load->view('front/include/footer');
        
    }
    public function index1()
    {
        echo 'front';
        $this->App->demo();
        echo test_method('Hello World'); // helper method
        $this->load->view('welcome_message');
    }
    public function menu($slug = '')
    {
        $data['vendordetails'] = $this->App->getPerticularRecord('tbl_vendor', 'Slug', $slug);
        $vendordetails         = $this->App->getPerticularRecord('tbl_vendor', 'Slug', $slug);
        $data['clubid']        = $vendordetails[0]['Id'];
        $this->load->view('front/include/header');
        $this->load->view('front/menu', $data);
        $this->load->view('front/include/footer');
    }
    public function events($slug = '')
    {
        $data['vendordetails'] = $this->App->getPerticularRecord('tbl_vendor', 'Slug', $slug);
        $vendordetails         = $this->App->getPerticularRecord('tbl_vendor', 'Slug', $slug);
        $data['clubid']        = $vendordetails[0]['Id'];
        $this->load->view('front/include/header');
        $this->load->view('front/events', $data);
        $this->load->view('front/include/footer');
    }
    public function eventdetail($slug = '')
    {
        $data['eventdetails'] = $this->App->getPerticularRecord('tbl_events', 'Slug', $slug);
        
        $this->load->view('front/include/header');
        $this->load->view('front/eventdetails', $data);
        $this->load->view('front/include/footer');
    }
    public function gallery($slug = '')
    {
        $data['vendordetails'] = $this->App->getPerticularRecord('tbl_vendor', 'Slug', $slug);
        $vendordetails         = $this->App->getPerticularRecord('tbl_vendor', 'Slug', $slug);
        $data['clubid']        = $vendordetails[0]['Id'];
        $this->load->view('front/include/header');
        $this->load->view('front/gallery', $data);
        $this->load->view('front/include/footer');
    }
    public function newsletter()
    {
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $email = $this->input->post('email');
        if($_POST){
            $chk = $this->App->checkExist('tbl_newsletter', 'Email', $email);
            if ($chk == '1') {
                $err='You have already subscribe our Newsletter.';
            }
        }
        if ($this->form_validation->run() == FALSE || $err != '') {
            if (validation_errors() != '' || $err != '') {
                $data['error'] = validation_errors() . $err;
                $data['err']='2';
                echo json_encode($data);
            }
        } else {
             $arr   = array(
            'Email' => $email,
            'Created' => date('Y-m-d')
            );
            $this->App->insertdata('tbl_newsletter', $arr);
            $message = '<div style="background-color: #fff; margin: 40px; font: 13px/20px normal Helvetica, Arial, sans-serif;color: #4F5155;">
                                    <div id="container" style="margin: 10px;border: 1px solid #D0D0D0;box-shadow: 0 0 8px #D0D0D0;">
                                    <h1 style="color: #fff;background-color: #333;border-bottom: 1px solid #D0D0D0; font-size: 19px;font-weight: normal;margin: 0 0 14px 0;padding: 14px 15px 10px 15px; text-align: center;background: #333;">
                                    <img src="https://www.tablefast.com/assets/fronttheme/img/footer-logo-one.png">
                                    </h1>
                                    <div id="body" style="margin: 0 15px 0 15px;text-align: center;">
                                    
                                    Thank You for Subscribe our Newsletter. We will get back to soon. <br>
                                   
                                    
                                    </div>
                                    <p class="footer" style="font-size: 11px;border-top: 1px solid #D0D0D0; line-height: 32px; padding: 0 10px 0 10px; margin: 20px 0 0 0;text-align: center;background: #333;color: #FFF;">Thank you for working with us. We look forward to seeing you on Tablefast.com.</p>
                                    </div></div>';
            
            
            $from_email = $this->config->item('constantEmail');
            $to_email   = $email;
            //Load email library 
           /* $this->load->library('email');            
            $this->email->from($from_email, 'Tablefast.com');
            $this->email->to($to_email);
            $this->email->subject('Thank you for Subscribe with Tablefast.com');            
            $this->email->message($message);            
            $this->email->send();*/
            
            
            $headers = "MIME-Version: 1.0" . "\r\n";
			$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
			$headers .= "From: ".$from_email;
			$subject ="Thank you for Subscribe with Tablefast.com";
			$to=$email;
			mail($to,$subject,$message,$headers);
			
			$message11 = '<div style="background-color: #fff; margin: 40px; font: 13px/20px normal Helvetica, Arial, sans-serif;color: #4F5155;">
                                    <div id="container" style="margin: 10px;border: 1px solid #D0D0D0;box-shadow: 0 0 8px #D0D0D0;">
                                    <h1 style="color: #fff;background-color: #333;border-bottom: 1px solid #D0D0D0; font-size: 19px;font-weight: normal;margin: 0 0 14px 0;padding: 14px 15px 10px 15px; text-align: center;background: #333;">
                                    <img src="https://www.tablefast.com/assets/fronttheme/img/footer-logo-one.png">
                                    </h1>
                                    <div id="body" style="margin: 0 15px 0 15px;text-align: center;">
                                    
                                   Email : '.$email.'
                                    
                                    </div>
                                    <p class="footer" style="font-size: 11px;border-top: 1px solid #D0D0D0; line-height: 32px; padding: 0 10px 0 10px; margin: 20px 0 0 0;text-align: center;background: #333;color: #FFF;">Thank you for working with us. We look forward to seeing you on Tablefast.com.</p>
                                    </div></div>';
             $to2=$this->config->item('constantEmail');
            
			mail($to2,$subject,$message11,$headers);
            
            echo json_encode('1');
        }
        
    }
}
