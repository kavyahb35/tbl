<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vendor extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->helper('new_helper');
        $this->load->library('form_validation');
        $this->load->library('email');
        $this->load->library('session');
    }
    
    public function index()
    {
	$vendorid=$this->session->userdata['vendorauth']['Id'];  
        $customerid=$this->session->userdata['customerauth']['Id'];
        
        if($vendorid==''){
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'required');
            if ($_POST) {
                $email    = $this->input->post('email');
                $password = md5($this->input->post('password'));
                 $phncheck=$this->App->checkExist('tbl_vendor', 'Email', $email);
                if($phncheck=='1'){
                    $chkauth  = $this->App->passwordCheckingvendor('tbl_vendor', 'Email', 'Password', $email, $password);               
                    if ($chkauth == '0') {
                        $err = 'Password does not match.';
                    }
                }else{
                    $passwordcheck=$this->App->checkExist('tbl_vendor', 'Password', $password);
              
                    if($passwordcheck=='1'){
                    $err = 'Email Id not Valid.';
                    }else{
                        $err = 'Email Id and password does not Valid.';
                    }
                }            
            }
            if ($this->form_validation->run() == FALSE || $err != '') {
                if (validation_errors() != '' || $err != '') {
                    $data['error'] = validation_errors() . $err;
                }
            } else {
                if (!empty($chkauth)) {
                    $arraydata = array(
                        'author' => $chkauth[0]['FirstName'],
                        'Id' => $chkauth[0]['Id'],
                        'ClubName' => $chkauth[0]['ClubName'],
                        'Email' => $chkauth[0]['Email']
                    );
                    $this->session->set_userdata('vendorauth', $arraydata);
                    $apro = array(
                        'Email'=>$chkauth[0]['Email'],
                        'Time'=>date('Y-m-d H:i A'),
                        'IP Address'=>$this->input->server('REMOTE_ADDR')
                    );
                    $apro=json_encode($apro);
                    log_message('vendor', "vendor login : ".$apro);
                    redirect('vendor-dashboard');
                }
            }
            $this->load->view('front/include/header');
            $this->load->view('front/vendor/login', $data);
            $this->load->view('front/include/footer');
	} 
        if($vendorid!='') {
          redirect('vendor-dashboard');
        }
    }
    public function dashboard()
    {
        $this->App->checkVendorAuthenticate();
        $id = $this->session->userdata['vendorauth']['Id'];
          
        $currentdt = date('Y-m-d');        
          $data["listbooking"] =   $this->App->passwordChecking('tbl_booking', 'ClubId','BookingDate', $id,$currentdt);
        $this->load->view('front/booking/bookingrequest', $data);
    }
    public function createstep1()
    {
        $this->App->checkVendorAuthenticate();
        $this->session->userdata['vendorauth']['author'];
        $this->session->userdata['vendorauth']['Id'];
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/step1');
        $this->load->view('front/include/footer');
    }
    public function logout()
    {        
        $vendorid=$this->session->userdata['vendorauth']['Email'];  
        $apro = array(
            'Email'=>$vendorid,
            'Time'=>date('Y-m-d H:i A'),
            'IP Address'=>$this->input->server('REMOTE_ADDR'),
            
            );
        $apro=json_encode($apro);
            
        log_message('vendor', "Vendor Louout : ".$apro);
        $this->session->unset_userdata('vendorauth');   
        redirect();
    }
    public function register()
    {
	$vendorid=$this->session->userdata['vendorauth']['Id'];  
        $customerid=$this->session->userdata['customerauth']['Id'];  
        
        if($vendorid==''){
        $this->form_validation->set_rules('lastname', 'Last Name', 'required');
        $this->form_validation->set_rules('clubname', 'Club Name', 'required');
        $this->form_validation->set_rules('firstname', 'First Name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        if ($_POST) {
            $email    = $this->input->post('email');
            $chkemail = $this->App->checkExist('tbl_vendor', 'Email', $email);
            
            if ($chkemail == '1') {
                
                $err = 'Email Id already Exist.' . '<br>';
            }
            $clbname = $this->input->post('clubname');
            $trim    = trim($clbname);
            $ow      = strtolower($trim);
            $string  = str_replace(' ', '-', $ow);
            $str     = preg_replace('/\s+/', '-', $string);
            $Str = str_replace("'s", '', $str);
          
            $chkslug = $this->App->checkExist('tbl_vendor', 'Slug', $Str);
            if ($chkslug == '1') {
                $r    = rand(1, 4);
                $slug = $Str . $r;
            } else {
                $slug = $Str;
            }            
        }
        if ($this->form_validation->run() == FALSE || $err != '') {
            if (validation_errors() != '' || $err != '') {
                $data['error'] = validation_errors() . $err;
            }
        } else {
			$otp = rand('8964','3467');
            $arr  = array(
                'FirstName' => $this->input->post('firstname'),
                'LastName' => $this->input->post('lastname'),
                'ClubName' => $this->input->post('clubname'),
                'Email' => $this->input->post('email'),
                'Created' => date('Y-m-d'),
                'Status' => '0',
                'Slug' => $slug,
                'txnid'=>$otp
            );
            $iid  = $this->App->insertdata('tbl_vendor', $arr);
            $name = $this->input->post('firstname') . ' ' . $this->input->post('lastname');
            
            
            $email   = $this->input->post('email');
            $url     = base_url('vendor/confirmmailprocess/' . $iid.'/'.$otp);
            
            $dataemail = array(
				'username'=>$name,
				'url'=>$url
				
			);
			$message = $this->load->view('email/customer_verification', $dataemail, TRUE);	
        
            
            $from_email = $this->config->item('constantEmail');
            $to_email   = $email;
            
            //Load email library 
                      
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= "From: ".$from_email;

            $to=$email;
            $subject="Confirm Register";
            mail($to,$subject,$message,$headers);
            
            $data['success'] = 'Thank you for register. Please check your mail for confirm.';
        }
        
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/register', $data);
        $this->load->view('front/include/footer');
	}
        if($vendorid!='') {
            redirect('vendor-dashboard');   
	}
    }
    
    public function confirmmailprocess($id,$otp)
    {
		
		$db=$this->App->passwordChecking('tbl_vendor','Id','txnid',$id,$otp);
		if($db=='0'){
		  $data['error']='Confirmation Token Expired';	
		}
		if(!empty($db)){
			$chkauth   = $this->App->getPerticularRecord('tbl_vendor', 'Id', $id);
           
			$otp = rand('8964','3467');
			$arr = array( 'txnid'=>'','Status'=>'1','State'=>$otp );
            $das=$this->App->update('tbl_vendor','Id',$id,$arr);
            $name = $chkauth[0]['FirstName'];
            $email = $chkauth[0]['Email'];
             $url     = base_url('vendor/resetpassword/' . $id.'/'.$otp);
             
              $dataemail = array(
				'username'=>$name,
				'url'=>$url
			
			);
			$message = $this->load->view('email/customer_resetpassword', $dataemail, TRUE);	
        
            
            $from_email = $this->config->item('constantEmail');
            $to_email   = $email;
            
            //Load email library 
                      
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= "From: ".$from_email;

            $to=$email;
            $subject="Thank you for Register";
            mail($to,$subject,$message,$headers);
            $data['success']='Please check your mail for reset password after login process';	
		     	
		}
			$this->load->view('front/include/header');
            $this->load->view('front/vendor/cancelconfirm', $data);
            $this->load->view('front/include/footer');

	}
   
   
   public function registerbkup37()
    {
	$vendorid=$this->session->userdata['vendorauth']['Id'];  
        $customerid=$this->session->userdata['customerauth']['Id'];  
        
        if($vendorid==''){
        $this->form_validation->set_rules('lastname', 'Last Name', 'required');
        $this->form_validation->set_rules('clubname', 'Club Name', 'required');
        $this->form_validation->set_rules('firstname', 'First Name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        if ($_POST) {
            $email    = $this->input->post('email');
            $chkemail = $this->App->checkExist('tbl_vendor', 'Email', $email);
            
            if ($chkemail == '1') {
                
                $err = 'Email Id already Exist.' . '<br>';
            }
            $clbname = $this->input->post('clubname');
            $trim    = trim($clbname);
            $ow      = strtolower($trim);
            $string  = str_replace(' ', '-', $ow);
            $str     = preg_replace('/\s+/', '-', $string);
            $Str = str_replace("'s", '', $str);
          
            $chkslug = $this->App->checkExist('tbl_vendor', 'Slug', $Str);
            if ($chkslug == '1') {
                $r    = rand(1, 4);
                $slug = $Str . $r;
            } else {
                $slug = $Str;
            }            
        }
        if ($this->form_validation->run() == FALSE || $err != '') {
            if (validation_errors() != '' || $err != '') {
                $data['error'] = validation_errors() . $err;
            }
        } else {
            $arr  = array(
                'FirstName' => $this->input->post('firstname'),
                'LastName' => $this->input->post('lastname'),
                'ClubName' => $this->input->post('clubname'),
                'Email' => $this->input->post('email'),
                'Created' => date('Y-m-d'),
                'Status' => '0',
                'Slug' => $slug
            );
            $iid  = $this->App->insertdata('tbl_vendor', $arr);
            $name = $this->input->post('firstname') . ' ' . $this->input->post('lastname');
            
            
            $email   = $this->input->post('email');
            $url     = base_url('vendor/resetpassword/' . $iid);
            $message = '<div style="background-color: #fff; margin: 40px; font: 13px/20px normal Helvetica, Arial, sans-serif;color: #4F5155;">
                        <div id="container" style="margin: 10px;border: 1px solid #D0D0D0;box-shadow: 0 0 8px #D0D0D0;">
                        <h1 style="color: #fff;background-color: #333;border-bottom: 1px solid #D0D0D0; font-size: 19px;font-weight: normal;margin: 0 0 14px 0;padding: 14px 15px 10px 15px; text-align: center;background: #333;">Tablefast.com</h1>
                        <div id="body" style="margin: 0 15px 0 15px;text-align: center;">
                        <h3 style="text-align:center">Thank you for Register</h3>
                        <p style="text-align:left">Dear ' . $name . ' <br>
                         Welcome to Tablefast.com and thanks for beginning the registration process.<br>
                         <br>We will get back to soon.
                         Kind regards,<br>
                         The Tablefast.com Team<br>
                        </div>
                        <p class="footer" style="font-size: 11px;border-top: 1px solid #D0D0D0; line-height: 32px; padding: 0 10px 0 10px; margin: 20px 0 0 0;text-align: center;background: #333;color: #FFF;">Thank you for working with us. We look forward to seeing you on Tablefast.com.</p>
                        </div></div>';
            
            
            $from_email = $this->config->item('constantEmail');
            $to_email   = $email;
            
            //Load email library 
                      
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= "From: ".$from_email;

            $to=$email;
            $subject="Thank you for Register";
            mail($to,$subject,$message,$headers);
            
            $chkauth   = $this->App->getPerticularRecord('tbl_vendor', 'Id', $iid);
            $arraydata = array(
                'author' => $chkauth[0]['FirstName'],
                'Id' => $chkauth[0]['Id'],
                'ClubName' => $chkauth[0]['ClubName'],
                'Email' => $chkauth[0]['Email']
            );
            
            $this->session->set_userdata('vendorauth', $arraydata);
            redirect('create-step1');
            
            $data['success'] = 'Thank you for register.';
        }
        
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/register', $data);
        $this->load->view('front/include/footer');
	}
        if($vendorid!='') {
            redirect('vendor-dashboard');   
	}
    }
    
    public function emailpage()
    {
        $this->load->view('email/register');
    }
     public function step1()
    {
        $this->form_validation->set_rules('clubname', 'Club Name', 'required');
        $this->form_validation->set_rules('phone', 'Phone', 'required');
        $this->form_validation->set_rules('alphone', 'Phone Name', 'required');
        $this->form_validation->set_rules('city', 'City', 'required');
        $this->form_validation->set_rules('county', 'Country', 'required');
        //$this->form_validation->set_rules('postcode', 'Post Code', 'required');
       // $this->form_validation->set_rules('ifram', 'Proper Address', 'required');
        $this->form_validation->set_rules('contactname', 'Contact Name', 'required');
        $this->form_validation->set_rules('Address', 'Address', 'required');
        
        if ($_POST) {
            $phone = $this->input->post('phone');
            $chk   = $this->App->checkExist('tbl_vendor', 'Phone', $phone);
            if ($chk == '1') {
                $err = 'Phone Number Already Exist<br>';
            }
            $clbname = $this->input->post('clubname');
            $trim    = trim($clbname);
            $ow      = strtolower($trim);
            $string  = str_replace(' ', '-', $ow);
            $id      = $this->session->userdata['vendorauth']['Id'];
            $str     = preg_replace('/\s+/', '-', $string);
            $string  = str_replace(' ( ', '', $str);
             $string  = str_replace(' ) ', '', $string);
            $string  = str_replace('(', '', $string);
            $string  = str_replace('%', '', $string);
            $string  = str_replace(' % ', '', $string);
            $string  = str_replace('?', '', $string);
            $string  = str_replace(' ? ', '', $string);
             $str= str_replace(')', '', $string);

            $str=str_replace("'", '', $str);
            $str=str_replace("' ", '', $str);
            $chkslug = $this->App->checkExistEdit('tbl_vendor', 'Slug', $str, 'Id', $id);
            if ($chkslug == '1') {
                $r    = rand(1, 4);
                $slug = $str . $r;
            } else {
                $slug = $str;
            }
            
            $is1=$this->input->post('ifram1');
            $is=$this->input->post('ifram');
            if($is==''){
                if($is1==''){
                    $err1='Proper Address field required.';
                }
            }else{
                
            }
            
            if($is!=''){ $iaddress=$is;}else{ $iaddress=$is1; }
        }
        if ($this->form_validation->run() == FALSE || $err != '' || $err1 != '' ) {
            if (validation_errors() != '' || $err != '' || $err1 != '') {
                $data['error']       = validation_errors() . $err.$err1;
                $data['clubname']    = $this->input->post('clubname');
                $data['phone']       = $this->input->post('phone');
                $data['alphone']     = $this->input->post('alphone');
                $data['city']        = $this->input->post('city');
                $data['county']      = $this->input->post('county');
                $data['postcode']    = $this->input->post('postcode');
                $data['address']     = $this->input->post('Address');              
                $data['ifram']       = $iaddress;
                $data['contactname'] = $this->input->post('contactname');
            }
        } else {
            $id  = $this->session->userdata['vendorauth']['Id'];
            
            $is1=$this->input->post('ifram1');
            $is=$this->input->post('ifram');
            if($is!=''){ $iaddress=$is;}else{ $iaddress=$is1; }
            $arr = array(
                'ClubName' => $this->input->post('clubname'),
                'City' => $this->input->post('city'),
                'Country' => $this->input->post('county'),
                'Phone' => $this->input->post('phone'),
                'AlternativePhone' => $this->input->post('alphone'),
                'PostCode' => $this->input->post('postcode'),
                'AddressIfram' => $iaddress,
                'ContactName' => $this->input->post('contactname'),
                'Address' => $this->input->post('Address'),
                'Slug' => $slug
            );
            $this->App->update('tbl_vendor', 'Id', $id, $arr);
            redirect('step2');
        }
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/step1', $data);
        $this->load->view('front/include/footer');
    }
    public function step2()
    {
        $this->App->checkVendorAuthenticate();
        $this->form_validation->set_rules('Cuisines', 'Cuisines', 'required');        
        $this->form_validation->set_rules('PerAdultPrice', 'COST FOR TWO', 'required');
        $this->form_validation->set_rules('nobtable', 'No. of Tables', 'required');  
        
        
        $id = $this->session->userdata['vendorauth']['Id'];
        if (!empty($_FILES['uploadimg']['name'])) {						
                
                $pathMain = 'assets/fronttheme/clubimage/';
                if (!is_dir($pathMain))
                    mkdir($pathMain, 0755);	
                $path1Thumb = 'assets/clubimage/1920X600';
                if (!is_dir($path1Thumb))
                    mkdir($path1Thumb, 0755);
 
                $path2Thumb = 'assets/clubimage/600X412';
                if (!is_dir($path2Thumb))
                    mkdir($path2Thumb, 0755);
 
                $path3Thumb = 'assets/clubimage/360X190';
                if (!is_dir($path3Thumb))
                    mkdir($path3Thumb, 0755);
 
                $path4Thumb = 'assets/clubimage/210X150';
                if (!is_dir($path4Thumb))
                    mkdir($path4Thumb, 0755);
                    
                $path5Thumb = 'assets/clubimage/455X300';
                if (!is_dir($path5Thumb))
                    mkdir($path5Thumb, 0755);
                     $path6Thumb = 'assets/clubimage/';
                if (!is_dir($path6Thumb))
                    mkdir($path6Thumb, 0755);
                
 
                $result = $this->App->do_upload("uploadimg", $pathMain);
 
                if (!$result['status'])
                    $data['error'] ="Can not upload Image for " . $result['error'] . " ";
                else
                {                  
                   $this->App->resize_image($pathMain . '/' . $result['upload_data']['file_name'], $path1Thumb . '/'.$result['upload_data']['file_name'],'1920','600');
                   $this->App->resize_image($pathMain . '/' . $result['upload_data']['file_name'], $path2Thumb . '/'.$result['upload_data']['file_name'],'600','412');
                   $this->App->resize_image($pathMain . '/' . $result['upload_data']['file_name'], $path3Thumb . '/'.$result['upload_data']['file_name'],'360','190');
                   $this->App->resize_image($pathMain . '/' . $result['upload_data']['file_name'], $path4Thumb . '/'.$result['upload_data']['file_name'],'210','150');
                   $this->App->resize_image($pathMain . '/' . $result['upload_data']['file_name'], $path5Thumb . '/'.$result['upload_data']['file_name'],'455','300');
                    $this->App->resize_image($pathMain . '/' . $result['upload_data']['file_name'], $path6Thumb . '/'.$result['upload_data']['file_name'],'1920','600');                                     
                    $picture = $result['upload_data']['file_name']; 
                }                       
            
        } else {
            $picture = $this->input->post('oldimg');
        }
        if ($this->form_validation->run() == FALSE) {
            if (validation_errors() != '') {
                $data['error'] = validation_errors();
            }
        } else {
            $id        = $this->session->userdata['vendorauth']['Id'];
            $arr       = array(
                'VendorId' => $id,
                'Cuisines' => $this->input->post('Cuisines'),
                'PerAdultPrice' => $this->input->post('PerAdultPrice'),
                'MainImage' => $picture,
                'Created' => date('Y-m-d'),
                'NoofPax'=>$this->input->post('diningprefer'),
                'PerChildPrice'=>$this->input->post('closedhrs'),
                'NumTable'=>$this->input->post('nobtable'),
            );
            $chktblrec = $this->App->getPerticularRecord('tbl_clublayout', 'VendorId', $id);
            if (empty($chktblrec)) {
                $iid = $this->App->insertdata('tbl_clublayout', $arr);
            } else {
                $this->App->update('tbl_clublayout', 'VendorId', $id, $arr);
            }
            redirect('step3');            
        }        
        $id                    = $this->session->userdata['vendorauth']['Id'];
        $data['vendordetails'] = $this->App->getPerticularRecord('tbl_clublayout', 'VendorId', $id);
        
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/step2', $data);
        $this->load->view('front/include/footer');
    }
    
     public function updatestep1()
    {
        $this->App->checkVendorAuthenticate();
        $this->form_validation->set_rules('clubname', 'Club Name', 'required');
        $this->form_validation->set_rules('phone', 'Phone', 'required');
        $this->form_validation->set_rules('alphone', 'Phone Name', 'required');
        $this->form_validation->set_rules('city', 'City', 'required');
        $this->form_validation->set_rules('county', 'Country', 'required');
        //$this->form_validation->set_rules('postcode', 'Post Code', 'required');
        $this->form_validation->set_rules('address', 'Address', 'required');
        $this->form_validation->set_rules('ifram', 'Proper Address', 'required');
        $this->form_validation->set_rules('contactname', 'Contact Name', 'required');
        
       
        if ($_POST) {
			 $password = trim($this->input->post('password'));
			 $jk          = $this->App->password_strength_check($password);
			if($password!=''){
				 $this->form_validation->set_rules('password', 'Password', 'required');
				 $this->form_validation->set_rules('cpassword', 'Confirm Password', 'required|matches[password]');
				  if ($jk == '0') {
                $err1 = 'Minimum 8 char required. Password must contain one lowercase letter, one capital (uppercase) letter & one number.';
				}
			}
			
			
        }
		
        
        if ($_POST) {
            $id    = $this->session->userdata['vendorauth']['Id'];
            $phone = $this->input->post('phone');
            $chk   = $this->App->checkExistEdit('tbl_vendor', 'Phone', $phone, 'Id', $id);
            
            if ($chk == '1') {
                $err = 'Phone Number Already Exist';
            }
            $clbname = $this->input->post('clubname');
            $trim    = trim($clbname);
            $ow      = strtolower($trim);
            $string  = str_replace(' ', '-', $ow);
            $id      = $this->session->userdata['vendorauth']['Id'];
            $str     = preg_replace('/\s+/', '-', $string);
            $string  = str_replace(' ( ', '', $str);
            $string  = str_replace(' ) ', '', $string);
            $string  = str_replace('(', '', $string);
            $string  = str_replace('%', '', $string);
            $string  = str_replace(' % ', '', $string);
            $string  = str_replace('?', '', $string);
            $string  = str_replace(' ? ', '', $string);
            $str= str_replace(')', '', $string);

           $str=str_replace("'", '', $str);
            $chkslug = $this->App->checkExistEdit('tbl_vendor', 'Slug', $str, 'Id', $id);
            if ($chkslug == '1') {
                $r    = rand(1, 4);
                $slug = $str . $r;
            } else {
                $slug = $str;
            }
        }
        if ($this->form_validation->run() == FALSE || $err != '' || $err1!='') {
            if (validation_errors() != '' || $err != '' || $err1!='') {
                $data['error'] = validation_errors() . $err.$err1;
            }
        } else {
			
            $id  = $this->session->userdata['vendorauth']['Id'];
            if($password!=''){
				$arr = array(
					'ClubName' => $this->input->post('clubname'),
					'City' => $this->input->post('city'),
					'Country' => $this->input->post('county'),
					'Phone' => $this->input->post('phone'),
					'AlternativePhone' => $this->input->post('alphone'),
					'PostCode' => $this->input->post('postcode'),
					'AddressIfram' => $this->input->post('ifram'),
					'ContactName' => $this->input->post('contactname'),
					'Slug' => $slug,
					'Address' => $this->input->post('address'),
					'Password' =>md5($password),
				);
				
			}else{
				$arr = array(
					'ClubName' => $this->input->post('clubname'),
					'City' => $this->input->post('city'),
					'Country' => $this->input->post('county'),
					'Phone' => $this->input->post('phone'),
					'AlternativePhone' => $this->input->post('alphone'),
					'PostCode' => $this->input->post('postcode'),
					'AddressIfram' => $this->input->post('ifram'),
					'ContactName' => $this->input->post('contactname'),
					'Slug' => $slug,
					'Address' => $this->input->post('address'),
				);
			}
			//print_r($arr);die;
            $this->App->update('tbl_vendor', 'Id', $id, $arr);
            redirect('step2');
        }
        $id                    = $this->session->userdata['vendorauth']['Id'];
        $data['vendordetails'] = $this->App->getPerticularRecord('tbl_vendor', 'Id', $id);
        
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/editstep1', $data);
        $this->load->view('front/include/footer');
    }
   
    public function step3()
    {
        $this->App->checkVendorAuthenticate();
        $this->form_validation->set_rules('description', 'Description', 'required');
        $this->form_validation->set_rules('AvailableParking', 'Available Parking', 'required');
        $typeparking = $this->input->post('AvailableParking');
        if ($typeparking == 'paid') {
            $this->form_validation->set_rules('PriceParkingPerhrs', 'Parking Price', 'required');
        }
        if ($_POST) {
            
        }
        if ($this->form_validation->run() == FALSE) {
            if (validation_errors() != '') {
                $data['error'] = validation_errors();
            }
        } else {
            $id  = $this->session->userdata['vendorauth']['Id'];
            $arr = array(
                'Description' => $this->input->post('description'),
                'AvailableParking' => $this->input->post('AvailableParking'),
                'PriceParkingPerhrs' => $this->input->post('PriceParkingPerhrs'),
                'facebook' => $this->input->post('facebook'),
                'googleplus' => $this->input->post('googleplus'),
                'twitter' => $this->input->post('twitter'),
                'linked' => $this->input->post('linked'),
                'youtube' => $this->input->post('youtube'),
                'vimeo' => $this->input->post('vimeo'),
                'instagram' => $this->input->post('instagram'),
            );
            
            $this->App->update('tbl_clublayout', 'VendorId', $id, $arr);
            redirect('step4');
        }
        $id                    = $this->session->userdata['vendorauth']['Id'];
        $data['vendordetails'] = $this->App->getPerticularRecord('tbl_clublayout', 'VendorId', $id);
        
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/step3', $data);
        $this->load->view('front/include/footer');
    }
    public function step4()
    {
        $this->App->checkVendorAuthenticate();
        $this->form_validation->set_rules('multi', 'Number of tables', 'required');
        
        if ($_POST){
            $id = $this->session->userdata['vendorauth']['Id'];
            $this->load->library('upload');
            if ($this->input->post('fileSubmit') && !empty($_FILES['userFiles']['name'])) {
                $filesCount = count($_FILES['userFiles']['name']);
                for ($i = 0; $i < $filesCount; $i++) {
                    $_FILES['userFile']['name']     = $_FILES['userFiles']['name'][$i];
                    $_FILES['userFile']['type']     = $_FILES['userFiles']['type'][$i];
                    $_FILES['userFile']['tmp_name'] = $_FILES['userFiles']['tmp_name'][$i];
                    $_FILES['userFile']['error']    = $_FILES['userFiles']['error'][$i];
                    $_FILES['userFile']['size']     = $_FILES['userFiles']['size'][$i];
                    
                    $uploadPath              = 'assets/clubgallery/';
                    $config['upload_path']   = $uploadPath;
                    $config['allowed_types'] = '*';
                    
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);
                    if ($this->upload->do_upload('userFile')) {
                        $fileData                    = $this->upload->data();
                        $uploadData[$i]['file_name'] = $fileData['file_name'];
                    } else {
                        $data['error'] = $this->upload->display_errors();
                    }
                }
                
                if (!empty($uploadData)) {
                    $c = count($uploadData);
                    for ($i = 0; $i < $c; $i++) {
                        $arr = array(
                            'VendorId' => $id,
                            'Image' => $uploadData[$i]['file_name'],
                            'Created' => date('Y-m-d'),
                            'Status' => '1'
                        );
                        $this->App->insertdata('tbl_clubgallery', $arr);
                    }
                    redirect('step5');
                }
            }
            redirect('step5');
            
        }
        
        $id                    = $this->session->userdata['vendorauth']['Id'];
        $data['vendordetails'] = $this->App->getPerticularRecord('tbl_clubgallery', 'VendorId', $id);
        
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/step4', $data);
        $this->load->view('front/include/footer');
    }
    
    public function step5()
    {
        $this->App->checkVendorAuthenticate();
        $this->form_validation->set_rules('sundayfrom', 'Time', 'required');
        if ($this->form_validation->run() == FALSE) {
            if (validation_errors() != '') {
                $data['error'] = validation_errors();
            }
        } else {
            $id  = $this->session->userdata['vendorauth']['Id'];
            $arr = array(
                
                'SundayFrom' => $this->input->post('sundayfrom'),
                'SundayTo' => $this->input->post('sundayto'),
                'SundayFromClose' => $this->input->post('sundayfromclose'),
                'SundayToClose' => $this->input->post('sundaytoclose'),
                'MondayFrom' => $this->input->post('mondayfrom'),
                'MondayTo' => $this->input->post('mondayto'),
                'MondayFromClose' => $this->input->post('mondayfromclose'),
                'MondayToClose' => $this->input->post('mondaytoclose'),
                'TuesdayFrom' => $this->input->post('tuesdayfrom'),
                'TuesdayTo' => $this->input->post('tuesdayto'),
                'TuesdayFromClose' => $this->input->post('tuesdayfromclose'),
                'TuesdayToClose' => $this->input->post('tuesdaytoclose'),
                'WednesdayFrom' => $this->input->post('wednesdayfrom'),
                'WednesdayTo' => $this->input->post('wednesdayto'),
                'WednesdayFromClose' => $this->input->post('wednesdayfromclose'),
                'WednesdayToClose' => $this->input->post('wednesdaytoclose'),
                'ThursdayFrom' => $this->input->post('thursdayfrom'),
                'ThursdayTo' => $this->input->post('thursdayto'),
                'ThursdayFromClose' => $this->input->post('thursdayfromclose'),
                'ThursdayToClose' => $this->input->post('thursdaytoclose'),
                'FridayFrom' => $this->input->post('fridayfrom'),
                'FridayTo' => $this->input->post('fridayto'),
                'FridayFromClose' => $this->input->post('fridayfromclose'),
                'FridayToClose' => $this->input->post('fridaytoclose'),
                'SaturdayFrom' => $this->input->post('saturdayfrom'),
                'SaturdayTo' => $this->input->post('saturdayto'),
                'SaturdayFromClose' => $this->input->post('saturdayfromclose'),
                'SaturdayToClose' => $this->input->post('saturdaytoclose')
            );
            $this->App->update('tbl_clublayout', 'VendorId', $id, $arr);
            redirect('step6');
        }
        
        $id                    = $this->session->userdata['vendorauth']['Id'];
        $data['vendordetails'] = $this->App->getPerticularRecord('tbl_clublayout', 'VendorId', $id);
        
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/step5', $data);
        $this->load->view('front/include/footer');
    }
    public function deletegallery($id)
    {
        $this->App->checkVendorAuthenticate();
        if ($id != '') {
            $this->App->deletedata('tbl_clubgallery', 'Id', $id);
            echo json_encode('1');
        }
        echo json_encode('1');
    }
    public function step6()
    {
        $this->App->checkVendorAuthenticate();
        $id     = $this->session->userdata['vendorauth']['Id'];
        $cheskk = $this->App->getPerticularRecord('tbl_vendor', 'Id', $id);
        $status = $cheskk[0]['Status'];
        $this->form_validation->set_rules('test', 'test', 'required');
        if ($this->form_validation->run() == FALSE) {
            if (validation_errors() != '') {
                $data['error'] = validation_errors();
            }
        } else {
            
           $paypal_email = $this->config->item('constantEmail');
            $return_url = base_url('vendor/payment_successful/'.$id);
            $cancel_url = base_url('vendor/payment_cancelled');
            $notify_url = base_url('vendor/payments');
            
            $paypalset=$this->App->getRecord('tbl_paypal_setting');
            $item_name = 'Table Fast';
            $item_amount =  $paypalset[0]['Amt'];
            if (!isset($_POST["txn_id"]) && !isset($_POST["txn_type"])){
                    //echo $_POST["txn_id"];echo '<br>';echo $_POST["txn_type"];die;
            $querystring = '';
            
            // Firstly Append paypal account to querystring
            $querystring .= "?business=".urlencode($paypal_email)."&";
            
            // Append amount& currency (£) to quersytring so it cannot be edited in html
            
            //The item name and amount can be brought in dynamically by querying the $_POST['item_number'] variable.
            $querystring .= "item_name=".urlencode($item_name)."&";
            $querystring .= "amount=".urlencode($item_amount)."&";
            
            //loop for posted values and append to querystring
            foreach($_POST as $key => $value){
                $value = urlencode(stripslashes($value));
                $querystring .= $key."=".$value."&";
            }
            
            // Append paypal return addresses
            $querystring .= "return=".urlencode(stripslashes($return_url))."&";
            $querystring .= "cancel_return=".urlencode(stripslashes($cancel_url))."&";
            $querystring .= "notify_url=".urlencode($notify_url);
            
           
            
            // Redirect to paypal IPN
            $sendbox_url = $this->config->item('sendbox_url');
            header('location:'.$sendbox_url.$querystring);
            exit();
            } else {
            //Database Connection
            
            // Response from Paypal

            // read the post from PayPal system and add 'cmd'
            $req = 'cmd=_notify-validate';
            foreach ($_POST as $key => $value) {
                $value = urlencode(stripslashes($value));
                $value = preg_replace('/(.*[^%^0^D])(%0A)(.*)/i','${1}%0D%0A${3}',$value);// IPN fix
                $req .= $key."=".$value."&";
            }
            
            // assign posted variables to local variables
            $data['item_name']            = $_POST['item_name'];
            $data['item_number']         = $_POST['item_number'];
            $data['payment_status']     = $_POST['payment_status'];
            $data['payment_amount']     = $_POST['mc_gross'];
            $data['payment_currency']    = $_POST['mc_currency'];
            $data['txn_id']                = $_POST['txn_id'];
            $data['receiver_email']     = $_POST['receiver_email'];
            $data['payer_email']         = $_POST['payer_email'];
            $data['custom']             = $_POST['custom'];
                
            
            // post back to PayPal system to validate
            $header = "POST /cgi-bin/webscr HTTP/1.0\r\n";
            $header .= "Content-Type: application/x-www-form-urlencoded\r\n";
            $header .= "Content-Length: " . strlen($req) . "\r\n\r\n";
            $sslurl = $this->config->item('sslurl');
            $fp = fsockopen ($sslurl, 443, $errno, $errstr, 30);
            
            if (!$fp) {
                // HTTP ERROR
                
            } else {
                fputs($fp, $header . $req);
                while (!feof($fp)) {
                    $res = fgets ($fp, 1024);
                    if (strcmp($res, "VERIFIED") == 0) {
                        
                        $valid_txnid = $this->App->check_txnid($data['txn_id']);
                        $valid_price = $this->App->check_price($data['payment_amount'], $data['item_number']);
                        
                        if ($valid_txnid && $valid_price) {
                            
                            $orderid = $this->App->updatePayments($data);
                            
                            if ($orderid) {
                                
                            } else {
                                
                            }
                        } else {
                          
                        }
                    
                    } else if (strcmp ($res, "INVALID") == 0) {
                    
                    }
                }
            fclose ($fp);
            }
        }
        }
        $id                    = $this->session->userdata['vendorauth']['Id'];
        $data['vendordetails'] = $this->App->getPerticularRecord('tbl_vendor', 'Id', $id);
        
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/step6', $data);
        $this->load->view('front/include/footer');
    }
    public function payment_successful()
    {    
        $id     = $this->session->userdata['vendorauth']['Id'];
        $cheskk = $this->App->getPerticularRecord('tbl_vendor', 'Id', $id);
        $status = $cheskk[0]['Status'];
        $arr = array(
            'Status' => '1',
        );

        $this->App->update('tbl_vendor', 'Id', $id, $arr);
        redirect('completed');
        
    }
 public function payment_successfulpaypalpro()
    {    
        $id     = $this->session->userdata['vendorauth']['Id'];
        $cheskk = $this->App->getPerticularRecord('tbl_vendor', 'Id', $id);
        $status = $cheskk[0]['Status'];
        $arr = array(
            'Status' => '1',
        );

        $this->App->update('tbl_vendor', 'Id', $id, $arr);
        redirect('vendor/completepayment');
        
    }
    public function payment_cancelled()
    {        
        $this->App->checkVendorAuthenticate();
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/cancelprocess');
        $this->load->view('front/include/footer');
    }
    public function payments()
    {
        $paypal_email = $this->config->item('constantEmail');
        $return_url = base_url('vendor/payment_successful');
        $cancel_url = base_url('vendor/payment_cancelled');
        $notify_url = base_url('vendor/payments');
        
        if (!isset($_POST["txn_id"]) && !isset($_POST["txn_type"])){
            $querystring = '';
            
            $querystring .= "?business=".urlencode($paypal_email)."&";
            
            $querystring .= "item_name=".urlencode($item_name)."&";
            $querystring .= "amount=".urlencode($item_amount)."&";
            
            foreach($_POST as $key => $value){
                $value = urlencode(stripslashes($value));
                $querystring .= $key."=".$value."&";
            }
            
            $querystring .= "return=".urlencode(stripslashes($return_url))."&";
            $querystring .= "cancel_return=".urlencode(stripslashes($cancel_url))."&";
            $querystring .= "notify_url=".urlencode($notify_url);
             $sendbox_url =$this->config->item('sendbox_url');
            header('location:'.$sendbox_url.$querystring);
            exit();
        } else {
           
            $req = 'cmd=_notify-validate';
            foreach ($_POST as $key => $value) {
                $value = urlencode(stripslashes($value));
                $value = preg_replace('/(.*[^%^0^D])(%0A)(.*)/i','${1}%0D%0A${3}',$value);// IPN fix
                $req .= $key."=".$value."&";
            }
            
            $data['item_name']            = $_POST['item_name'];
            $data['item_number']         = $_POST['item_number'];
            $data['payment_status']     = $_POST['payment_status'];
            $data['payment_amount']     = $_POST['mc_gross'];
            $data['payment_currency']    = $_POST['mc_currency'];
            $data['txn_id']                = $_POST['txn_id'];
            $data['receiver_email']     = $_POST['receiver_email'];
            $data['payer_email']         = $_POST['payer_email'];
            $data['custom']             = $_POST['custom'];
            
            $header = "POST /cgi-bin/webscr HTTP/1.0\r\n";
            $header .= "Content-Type: application/x-www-form-urlencoded\r\n";
            $header .= "Content-Length: " . strlen($req) . "\r\n\r\n";
             $sslurl =$this->config->item('sslurl');
            $fp = fsockopen ($sslurl, 443, $errno, $errstr, 30);
            
            if (!$fp) {
               
                
            } else {
                fputs($fp, $header . $req);
                while (!feof($fp)) {
                    $res = fgets ($fp, 1024);
                    if (strcmp($res, "VERIFIED") == 0) {
                       
                        $valid_txnid = check_txnid($data['txn_id']);
                        $valid_price = check_price($data['payment_amount'], $data['item_number']);
                       
                        if ($valid_txnid && $valid_price) {
                            
                            $orderid = updatePayments($data);
                            
                            if ($orderid) {
                               
                            } else {
                                
                            }
                        } else {
                           
                        }
                    
                    } else if (strcmp ($res, "INVALID") == 0) {
                    
                    }
                }
            fclose ($fp);
            }
        }
    }
    
    public function step6_bkup()
    {
        $this->App->checkVendorAuthenticate();
        $id     = $this->session->userdata['vendorauth']['Id'];
        $cheskk = $this->App->getPerticularRecord('vendor', 'Id', $id);
        $status = $cheskk[0]['Status'];
        $this->form_validation->set_rules('test', 'test', 'required');
        if ($this->form_validation->run() == FALSE) {
            if (validation_errors() != '') {
                $data['error'] = validation_errors();
            }
        } else {
            $id = $this->session->userdata['vendorauth']['Id'];
             $ss = $this->input->post('status');
            
             if($ss!=''){ $s=$ss;}else{ $s='0';}  
            
            $arr = array(
                'Status' => $s
            );

            $this->App->update('vendor', 'Id', $id, $arr);
            redirect('completed');
        }
        $id                    = $this->session->userdata['vendorauth']['Id'];
        $data['vendordetails'] = $this->App->getPerticularRecord('tbl_vendor', 'Id', $id);
        
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/step6', $data);
        $this->load->view('front/include/footer');
    }
    public function completepayment()
    {
        $this->App->checkVendorAuthenticate();
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/completeprocesspayment');
        $this->load->view('front/include/footer');
    }
    public function complete()
    {
        $this->App->checkVendorAuthenticate();
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/completeprocess');
        $this->load->view('front/include/footer');
    }
    public function resetpassword($id,$verify)
    {
        $data['userIDds'] = $id;
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('cpassword', 'Confirm Password', 'required|matches[password]');
        
        if($_POST){
        $password = $this->input->post('password');
        $jk       = $this->App->password_strength_check($password);
           
          $chk=$this->App->passwordChecking('tbl_vendor','Id','State',$id,$verify);
          if(empty($chk[0]['Id'])){
              $err1 = '<br>Reset Password URL Expired.<br>';
 
          }else{
        if ($jk == '0') {
                $err = 'Minimum 8 char required. Password must contain one lowercase letter, one capital (uppercase) letter & one number.';
            } 
        }
        
        }
        if ($this->form_validation->run() == FALSE || $err != ''|| $err1 != '') {
            if (validation_errors() != '' || $err != ''|| $err1 != '') {
                $data['error'] = validation_errors() . $err.$err1;
            }
        } else {
            $arr = array(
                'Password' => md5($this->input->post('password')),
                'State'=>'',
            );
            $this->App->update('tbl_vendor', 'Id', $id, $arr);
            $data['success'] = 'Reset Password Successfully. Please Login';
              redirect('vendor-signin');
        }
        
        $data['verify']=$verify;
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/resetpassword', $data);
        $this->load->view('front/include/footer');
    }
    public function previewclub()
    {
        $this->App->checkVendorAuthenticate();
        $id                    = $this->session->userdata['vendorauth']['Id'];
        $data['vendordetails'] = $this->App->getPerticularRecord('tbl_vendor', 'Id', $id);
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/previewclub', $data);
        $this->load->view('front/include/footer');
    }
    public function changepassword()
    {
        $uid = $this->session->userdata['vendorauth']['Id'];
        $this->form_validation->set_rules('oldpassword', 'Old Password', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('cpassword', 'Confirm Password', 'required|matches[password]');
        
        $oldpassword = md5($this->input->post('oldpassword'));
        $password    = $this->input->post('password');
        $jk          = $this->App->password_strength_check($password);
        if ($_POST) {
            $chkauth = $this->App->passwordChecking('tbl_vendor', 'Id', 'Password', $uid, $oldpassword);
            if ($chkauth == '0') {
                $err1 = ' Password does not match.';
            }
            
            if ($jk == '0') {
                $err = 'Minimum 8 char required. Password must contain one lowercase letter, one capital (uppercase) letter & one number.';
            }
        }
        
        if ($this->form_validation->run() == FALSE || $err != '' || $err1 != '') {
            if (validation_errors() != '' || $err != '' || $err1 != '') {
                $data['error'] = validation_errors() . $err . $err1;
            }
        } else {
            $arr = array(
                'Password' => md5($this->input->post('password'))
            );
            $this->App->update('tbl_vendor', 'Id', $uid, $arr);
            $data['success'] = 'Change Password Successfully.';
        }
        $this->App->checkVendorAuthenticate();
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/changepassword', $data);
        $this->load->view('front/include/footer');
    }
    
    public function forgotpassword()
    {
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        if ($_POST) {
            $email    = $this->input->post('email');
            $password = md5($this->input->post('password'));
            $chkauth  = $this->App->getPerticularRecord('tbl_vendor', 'Email', $email);
            if ($chkauth == '0') {
                $err = 'Email Id does not match.';
            }
        }
        if ($this->form_validation->run() == FALSE || $err != '') {
            if (validation_errors() != '' || $err != '') {
                $data['error'] = validation_errors() . $err;
            }
        } else {
            $otp=rand('4531','5356');
        $arr=array('State'=>$otp);
        $this->App->update('tbl_vendor', 'Id', $chkauth[0]['Id'], $arr);
        
            $name=$chkauth[0]['FirstName'].' '.$chkauth[0]['LastName'];
            $url = base_url('vendor/resetpassword/' . $chkauth[0]['Id'].'/'.$otp);
            
            $dataemail = array(
				'username'=>$name,
				'url'=>$url
				
			);
			$message = $this->load->view('email/customer_resetpassword', $dataemail, TRUE);	
        
            $from_email = $this->config->item('constantEmail');
            $to_email = $email;
            //Load email library 
            
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= "From: ".$from_email;

            $to=$email;
            $subject="Reset Password";
            mail($to,$subject,$message,$headers);            
            $data['success']='Send Email successfully. please check your mail for reset password.';
        }
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/forgotpassword', $data);
        $this->load->view('front/include/footer');
    }
 
    public function expresscheckout()
    {
		$this->App->checkVendorAuthenticate();
		$paypalset=$this->App->getRecord('tbl_paypal_setting');
		$expresspaypal =$this->config->item('expresspaypal');
		$paypalexpresspurl =$this->config->item('paypalexpresspurl');
        $arraydata = array(
           'PROXY_HOST' => "localhost",
           'PROXY_PORT' => "80",
           'SandboxFlag' => false,
           'API_UserName' => $paypalset[0]['UserName'],
           'API_Password' => $paypalset[0]['Password'],
           'API_Signature' => $paypalset[0]['Signature'],
           'sBNCode' => "PP-ECWizard",
           'API_Endpoint' => $expresspaypal,
           'PAYPAL_URL' => $paypalexpresspurl,
           'USE_PROXY' => false,
           'version' => "64",
           'BillingPeriod' => $paypalset[0]['BillingPeriod'],
           'BillingFrequency' => $paypalset[0]['BillingFrequency'],
           'TotalBillingCycle' => $paypalset[0]['TotalBillingCycle'],
           'Amt' => $paypalset[0]['Amt'],
           'CurrencyCode' => $paypalset[0]['CurrencyCode'],
           'ExpressPeriod'=>$paypalset[0]['ExpressPeriod'],
           'ExpressFrequency'=>$paypalset[0]['ExpressFrequency']
        );
        $this->session->set_userdata('paypalcredential', $arraydata);

        if (session_id() == "") 
                session_start();
		
        require_once(APPPATH.'libraries/Paypalfunction.php');
        $_SESSION["Payment_Amount"] = 0;

        $currencyCodeType = $paypalset[0]['CurrencyCode'];
        $paymentType = "Sale";

        $returnURL = base_url('vendor/reviews');;
        $paymentAmount=$paypalset[0]['Amt'];
        $cancelURL = base_url('vendor/payment_cancelled');
         $this->load->library('paypalfunction');
        $resArray = $resArray = $this->paypalfunction->CallShortcutExpressCheckout($paymentAmount, $currencyCodeType, $paymentType, $returnURL, $cancelURL);

        $ack = strtoupper($resArray["ACK"]);
        if($ack=="SUCCESS" || $ack=="SUCCESSWITHWARNING")
        {
            $this->paypalfunction->RedirectToPayPal( $resArray["TOKEN"] );
        } 
        else  
        {
                //Display a user friendly Error on the page using any of the following error information returned by PayPal
            $ErrorCode = urldecode($resArray["L_ERRORCODE0"]);
            $ErrorShortMsg = urldecode($resArray["L_SHORTMESSAGE0"]);
            $ErrorLongMsg = urldecode($resArray["L_LONGMESSAGE0"]);
            $ErrorSeverityCode = urldecode($resArray["L_SEVERITYCODE0"]);

            $err = "SetExpressCheckout API call failed. ";
            $err .=  "Detailed Error Message: " . $ErrorLongMsg;
            $err .=  "Short Error Message: " . $ErrorShortMsg;
            $err .=  "Error Code: " . $ErrorCode;
            $err .=  "Error Severity Code: " . $ErrorSeverityCode;
        }

        $this->load->view('front/include/header');
        $this->load->view('front/paypal/orderconfirm',$data);
        $this->load->view('front/include/footer');	
	}
	public function reviews()
	{
            $this->App->checkVendorAuthenticate();
            $token = "";
            if (isset($_REQUEST['token']))
            {
               $token = $_REQUEST['token'];
            }
	
            if ( $token != "" )
            {

                $this->load->library('paypalfunction');
                $this->load->model('Paypalpro');
                if ($_REQUEST['PayerID']!='' && $_REQUEST['token']!='') {
                $message = 'PAYID: ' . $_REQUEST['PayerID'] . "\n".'TRANSACTIONID:'.$_REQUEST['token'];
                }
                 $vId = $this->session->userdata['vendorauth']['Id'];
                $tid=$this->Paypalpro->addOrderHistory($vId, $vId, $message, false);
                $arraydata = array(
                'tid' => $tid,
                );
                $this->session->set_userdata('transactionvalue', $arraydata);
                   
                $resArray = $this->paypalfunction->GetShippingDetails($token);
           
                $ack = strtoupper($resArray["ACK"]);
                if( $ack == "SUCCESS" || $ack == "SUCESSWITHWARNING") 
                {

                    $data['email']	= $resArray["EMAIL"]; // ' Email address of payer.
                    $payerId 			= $resArray["PAYERID"]; // ' Unique PayPal customer account identification number.
                    $payerStatus		= $resArray["PAYERSTATUS"]; // ' Status of payer. Character length and limitations: 10 single-byte alphabetic characters.
                    $salutation			= $resArray["SALUTATION"]; // ' Payer's salutation.
                    $data['firstName']			= $resArray["FIRSTNAME"]; // ' Payer's first name.
                    $middleName			= $resArray["MIDDLENAME"]; // ' Payer's middle name.
                    $data['lastName']			= $resArray["LASTNAME"]; // ' Payer's last name.
                    $suffix				= $resArray["SUFFIX"]; // ' Payer's suffix.
                    $cntryCode			= $resArray["COUNTRYCODE"]; // ' Payer's country of residence in the form of ISO standard 3166 two-character country codes.
                    $business			= $resArray["BUSINESS"]; // ' Payer's business name.
                    $shipToName			= $resArray["SHIPTONAME"]; // ' Person's name associated with this address.
                    $shipToStreet		= $resArray["SHIPTOSTREET"]; // ' First street address.
                    $shipToStreet2		= $resArray["SHIPTOSTREET2"]; // ' Second street address.
                    $shipToCity			= $resArray["SHIPTOCITY"]; // ' Name of city.
                    $shipToState		= $resArray["SHIPTOSTATE"]; // ' State or province
                    $shipToCntryCode	= $resArray["SHIPTOCOUNTRYCODE"]; // ' Country code. 
                    $shipToZip			= $resArray["SHIPTOZIP"]; // ' U.S. Zip code or other country-specific postal code.
                    $addressStatus 		= $resArray["ADDRESSSTATUS"]; // ' Status of street address on file with PayPal   
                    $invoiceNumber		= $resArray["INVNUM"]; // ' Your own invoice or tracking number, as set by you in the element of the same name in SetExpressCheckout request .
                    $phonNumber			= $resArray["PHONENUM"]; // ' Payer's contact telephone number. Note:  PayPal returns a contact telephone number only if your Merchant account profile settings require that the buyer enter one. 
                } 
                else  
                {
                        //Display a user friendly Error on the page using any of the following error information returned by PayPal
                    $ErrorCode = urldecode($resArray["L_ERRORCODE0"]);
                    $ErrorShortMsg = urldecode($resArray["L_SHORTMESSAGE0"]);
                    $ErrorLongMsg = urldecode($resArray["L_LONGMESSAGE0"]);
                    $ErrorSeverityCode = urldecode($resArray["L_SEVERITYCODE0"]);

                    $err = "GetExpressCheckoutDetails API call failed. ";
                    $err .= "<br>Detailed Error Message: " . $ErrorLongMsg;
                    $err .= "<br>Short Error Message: " . $ErrorShortMsg;
                    $err .= "<br>Error Code: " . $ErrorCode;
                    $err .= "<br>Error Severity Code: " . $ErrorSeverityCode;
                    $data['error']=$err;
                }
            }
		
        $this->load->view('front/include/header');
        $this->load->view('front/paypal/review',$data);
        $this->load->view('front/include/footer');
		
	}
	public function orderconfirm()
	{
		$this->App->checkVendorAuthenticate();
		session_start();
		$this->load->library('paypalfunction');
		$PaymentOption = "PayPal";
		if ( $PaymentOption == "PayPal" )
		{
                    $finalPaymentAmount =  $_SESSION["Payment_Amount"];
                  
                    $resArray = $this->paypalfunction->CreateRecurringPaymentsProfile();
                    $ack = strtoupper($resArray["ACK"]);


                    if( $ack == "SUCCESS" || $ack == "SUCCESSWITHWARNING")
                    {
                       
                        $message = '';
                        $this->load->model('Paypalpro');

                        $tId = $this->session->userdata['transactionvalue']['tid'];

                        $ts=$this->db->query("select * from tbl_payment_history where order_history_id='".$tId."'");
                        $rts=$ts->result_array();

                        $msg=$rts[0]['comment'];

                        $message = $msg.'TRANSACTIONID: ' . $resArray['PROFILEID'] . "\n";

                         $vId = $this->session->userdata['vendorauth']['Id'];

                        $aia=array('comment'=>$message);
                        $this->App->update('tbl_payment_history','order_history_id',$tId,$aia);


                        $atr=array('Status'=>'1');
                        $this->App->update('tbl_vendor','Id',$vId,$atr);

                        $transactionId		= $resArray["TRANSACTIONID"]; // ' Unique transaction ID of the payment. Note:  If the PaymentAction of the request was Authorization or Order, this value is your AuthorizationID for use with the Authorization & Capture APIs. 
                        $transactionType 	= $resArray["TRANSACTIONTYPE"]; //' The type of transaction Possible values: l  cart l  express-checkout 
                        $paymentType		= $resArray["PAYMENTTYPE"];  //' Indicates whether the payment is instant or delayed. Possible values: l  none l  echeck l  instant 
                        $orderTime 			= $resArray["ORDERTIME"];  //' Time/date stamp of payment
                        $amt				= $resArray["AMT"];  //' The final amount charged, including any shipping and taxes from your Merchant Profile.
                        $currencyCode		= $resArray["CURRENCYCODE"];  //' A three-character currency code for one of the currencies listed in PayPay-Supported Transactional Currencies. Default: USD. 
                        $feeAmt				= $resArray["FEEAMT"];  //' PayPal fee amount charged for the transaction
                        $settleAmt			= $resArray["SETTLEAMT"];  //' Amount deposited in your PayPal account after a currency conversion.
                        $taxAmt				= $resArray["TAXAMT"];  //' Tax charged on the transaction.
                        $exchangeRate		= $resArray["EXCHANGERATE"];  //' Exchange rate if a currency conversion occurred. Relevant only if your are billing in their non-primary currency. If the customer chooses to pay with a currency other than the non-primary currency, the conversion occurs in the customer’s account.


                        $paymentStatus	= $resArray["PAYMENTSTATUS"]; 
                        $pendingReason	= $resArray["PENDINGREASON"];  
                        $reasonCode		= $resArray["REASONCODE"]; 
                        $data['success']= "Thank you for your payment.";
                    }
                    else  
                    {
                        
                        $ErrorCode = urldecode($resArray["L_ERRORCODE0"]);
                        $ErrorShortMsg = urldecode($resArray["L_SHORTMESSAGE0"]);
                        $ErrorLongMsg = urldecode($resArray["L_LONGMESSAGE0"]);
                        $ErrorSeverityCode = urldecode($resArray["L_SEVERITYCODE0"]);

                        $err= "GetExpressCheckoutDetails API call failed. <br>";
                        $err .= "Detailed Error Message: " . $ErrorLongMsg;
                        $err .= "<br>Short Error Message: " . $ErrorShortMsg;
                        $err .= "<br>Error Code: " . $ErrorCode;
                        $err .= "<br>Error Severity Code: " . $ErrorSeverityCode;
                        $data['error']=$err;
                    }
		}
		 $this->load->view('front/include/header');
        $this->load->view('front/paypal/orderconfirm',$data);
        $this->load->view('front/include/footer');		
    }
    public function prodetails()
    {
        $data['text_credit_card'] = "Credit Card Details";
        $data['text_start_date'] = "Start Date";
        $data['text_wait'] = "Please wait!";
        $data['text_loading'] = "Loading";

        $data['entry_cc_type'] = "Card Type";
        $data['entry_cc_number'] = "Card Number";
        $data['entry_cc_start_date'] = "Card Valid From Date";
        $data['entry_cc_expire_date'] = "Card Expiry Date";
        $data['entry_cc_cvv2'] = "Card Security Code (CVV2)";
        $data['entry_cc_issue'] = "Card Issue Number";

        $data['help_start_date'] = "(if available)";
        $data['help_issue'] = "(for Maestro and Solo cards only)";

        $data['button_confirm'] = 'button_confirm';

        $data['cards'] = array();

        $data['cards'][] = array(
                'text'  => 'Visa',
                'value' => 'VISA'
        );

        $data['cards'][] = array(
                'text'  => 'MasterCard',
                'value' => 'MASTERCARD'
        );

        $data['cards'][] = array(
                'text'  => 'Discover Card',
                'value' => 'DISCOVER'
        );

        $data['cards'][] = array(
                'text'  => 'American Express',
                'value' => 'AMEX'
        );

        $data['cards'][] = array(
                'text'  => 'Maestro',
                'value' => 'SWITCH'
        );

        $data['cards'][] = array(
                'text'  => 'Solo',
                'value' => 'SOLO'
        );

        $data['months'] = array();

        for ($i = 1; $i <= 12; $i++) {
                $data['months'][] = array(
                        'text'  => strftime('%B', mktime(0, 0, 0, $i, 1, 2000)),
                        'value' => sprintf('%02d', $i)
                );
        }

        $today = getdate();

        $data['year_valid'] = array();

        for ($i = $today['year'] - 10; $i < $today['year'] + 1; $i++) {
                $data['year_valid'][] = array(
                        'text'  => strftime('%Y', mktime(0, 0, 0, 1, 1, $i)),
                        'value' => strftime('%Y', mktime(0, 0, 0, 1, 1, $i))
                );
        }

        $data['year_expire'] = array();

        for ($i = $today['year']; $i < $today['year'] + 11; $i++) {
                $data['year_expire'][] = array(
                        'text'  => strftime('%Y', mktime(0, 0, 0, 1, 1, $i)),
                        'value' => strftime('%Y', mktime(0, 0, 0, 1, 1, $i))
                );
        }

	$this->load->view('front/include/header');
        $this->load->view('front/paypalpro/checkout', $data);
        $this->load->view('front/include/footer');
    }
    public function send() {
            $vId = $this->session->userdata['vendorauth']['Id'];
            $payment_type = 'Sale';

           $this->load->model('Paypalpro');

           $order_info = $this->Paypalpro->getOrder();
           $paypalset=$this->App->getRecord('tbl_paypal_setting');

           $request  = 'METHOD=DoDirectPayment';
           $request .= '&VERSION=51.0';
           $request .= '&USER=' . urlencode($paypalset[0]['UserName']);
           $request .= '&PWD=' . urlencode($paypalset[0]['Password']);
           $request .= '&SIGNATURE=' . urlencode($paypalset[0]['Signature']);
           $request .= '&CUSTREF=' . '1';
           $request .= '&PAYMENTACTION=' . $payment_type;
           $request .= '&AMT='.$paypalset[0]['Amt'];
           $request .= '&CREDITCARDTYPE=' . $this->input->post('cc_type');
           $request .= '&ACCT=' . urlencode(str_replace(' ', '', $this->input->post('cc_number')));
           $request .= '&CARDSTART=' . urlencode($this->input->post('cc_start_date_month') . $this->input->post('cc_start_date_year'));
           $request .= '&EXPDATE=' . urlencode($this->input->post('cc_expire_date_month') . $this->input->post('cc_expire_date_year'));
           $request .= '&CVV2=' . urlencode($this->input->post('cc_cvv2'));

           if ($this->input->post('cc_type') == 'SWITCH' || $this->input->post('cc_type') == 'SOLO') {
                   $request .= '&ISSUENUMBER=' . urlencode($this->input->post('cc_issue'));
           }

           $request .= '&FIRSTNAME=' . urlencode($order_info['payment_firstname']);
           $request .= '&LASTNAME=' . urlencode($order_info['payment_lastname']);
           $request .= '&EMAIL=' . urlencode($order_info['email']);
           $request .= '&PHONENUM=' . urlencode($order_info['telephone']);
           $request .= '&IPADDRESS=' . urlencode($this->input->server['REMOTE_ADDR']);
           $request .= '&STREET=' . urlencode($order_info['payment_address_1']);
           $request .= '&CITY=' . urlencode($order_info['payment_city']);
           $request .= '&STATE=' . urlencode(($order_info['payment_iso_code_2'] != 'US') ? $order_info['payment_zone'] : $order_info['payment_zone_code']);
           $request .= '&ZIP=' . urlencode($order_info['payment_postcode']);
           $request .= '&COUNTRYCODE=' . urlencode($order_info['payment_iso_code_2']);
           $request .= '&CURRENCYCODE=' . urlencode($order_info['currency_code']);
           $request .= '&BUTTONSOURCE=' . urlencode('OpenCart_2.0_WPP');

            $request .= '&SHIPTONAME=' . urlencode($order_info['payment_firstname'] . ' ' . $order_info['payment_lastname']);
            $request .= '&SHIPTOSTREET=' . urlencode($order_info['payment_address_1']);
            $request .= '&SHIPTOCITY=' . urlencode($order_info['payment_city']);
            $request .= '&SHIPTOSTATE=' . urlencode(($order_info['payment_iso_code_2'] != 'US') ? $order_info['payment_zone'] : $order_info['payment_zone_code']);
            $request .= '&SHIPTOCOUNTRYCODE=' . urlencode($order_info['payment_iso_code_2']);
            $request .= '&SHIPTOZIP= 390019';
            $expresspaypal =$this->config->item('expresspaypal');
             $curl = curl_init($expresspaypal);

           curl_setopt($curl, CURLOPT_PORT, 443);
           curl_setopt($curl, CURLOPT_HEADER, 0);
           curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
           curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
           curl_setopt($curl, CURLOPT_FORBID_REUSE, 1);
           curl_setopt($curl, CURLOPT_FRESH_CONNECT, 1);
           curl_setopt($curl, CURLOPT_POST, 1);
           curl_setopt($curl, CURLOPT_POSTFIELDS, $request);

           $response = curl_exec($curl);

           curl_close($curl);

           if (!$response) {
                   $this->log->write('DoDirectPayment failed: ' . curl_error($curl) . '(' . curl_errno($curl) . ')');
           }

           $response_info = array();

           parse_str($response, $response_info);

           $json = array();

           if (($response_info['ACK'] == 'Success') || ($response_info['ACK'] == 'SuccessWithWarning')) {
                   $message = '';

                   if (isset($response_info['AVSCODE'])) {
                           $message .= 'AVSCODE: ' . $response_info['AVSCODE'] . "\n";
                   }

                   if (isset($response_info['CVV2MATCH'])) {
                           $message .= 'CVV2MATCH: ' . $response_info['CVV2MATCH'] . "\n";
                   }

                   if (isset($response_info['TRANSACTIONID'])) {
                           $message .= 'TRANSACTIONID: ' . $response_info['TRANSACTIONID'] . "\n";
                   }

                   $this->Paypalpro->addOrderHistory($vId, $vId, $message, false);

                   $json['success'] = 'successtransation';
           } else {
                   $json['error'] = $response_info['L_LONGMESSAGE0'];
           }

           echo json_encode($json);
	} 
	public function successtransation()
	{
	   redirect('vendor/payment_successfulpaypalpro');	
	}
	
	public function prorecurring()
	{
            $data['text_credit_card'] = "Credit Card Details";
            $data['text_start_date'] = "Start Date";
            $data['text_wait'] = "Please wait!";
            $data['text_loading'] = "Loading";

            $data['entry_cc_type'] = "Card Type";
            $data['entry_cc_number'] = "Card Number";
            $data['entry_cc_start_date'] = "Card Valid From Date";
            $data['entry_cc_expire_date'] = "Card Expiry Date";
            $data['entry_cc_cvv2'] = "Card Security Code (CVV2)";
            $data['entry_cc_issue'] = "Card Issue Number";

            $data['help_start_date'] = "(if available)";
            $data['help_issue'] = "(for Maestro and Solo cards only)";

            $data['button_confirm'] = 'button_confirm';

            $this->data['cards'] = array();

            $this->data['cards'][] = array(
                    'text'  => 'Visa', 
                    'value' => 'VISA'
            );

            $this->data['cards'][] = array(
                    'text'  => 'MasterCard', 
                    'value' => 'MASTERCARD'
            );

            $this->data['cards'][] = array(
                    'text'  => 'Discover Card', 
                    'value' => 'DISCOVER'
            );

            $this->data['cards'][] = array(
                    'text'  => 'American Express', 
                    'value' => 'AMEX'
            );

            $this->data['cards'][] = array(
                    'text'  => 'Maestro', 
                    'value' => 'SWITCH'
            );

            $this->data['cards'][] = array(
                    'text'  => 'Solo', 
                    'value' => 'SOLO'
            );		

            $this->data['months'] = array();

            for ($i = 1; $i <= 12; $i++) {
                    $this->data['months'][] = array(
                            'text'  => strftime('%B', mktime(0, 0, 0, $i, 1, 2000)), 
                            'value' => sprintf('%02d', $i)
                    );
            }

            $today = getdate();

            $this->data['year_valid'] = array();

            for ($i = $today['year'] - 10; $i < $today['year'] + 1; $i++) {	
                    $this->data['year_valid'][] = array(
                            'text'  => strftime('%Y', mktime(0, 0, 0, 1, 1, $i)), 
                            'value' => strftime('%Y', mktime(0, 0, 0, 1, 1, $i))
                    );
            }

            $this->data['year_expire'] = array();

            for ($i = $today['year']; $i < $today['year'] + 11; $i++) {
                    $this->data['year_expire'][] = array(
                            'text'  => strftime('%Y', mktime(0, 0, 0, 1, 1, $i)),
                            'value' => strftime('%Y', mktime(0, 0, 0, 1, 1, $i)) 
                    );
            }

	$this->load->view('front/include/header');
        $this->load->view('front/paypalpro/reccheckout', $this->data);
        $this->load->view('front/include/footer');
    }
    public function recurringCancel() {
		//print_r($_POST);die;
        $this->load->model('Paypalprorecurring');        
         $payid=$this->input->post('payid');
        if ($payid!='') {
                $result = $this->Paypalprorecurring->recurringCancel($this->input->post('payid'));
                //    echo $result;die;
                if ($result!='') {
					$vId = $this->session->userdata['vendorauth']['Id'];
					$ass= array('Status' =>'1');
					$this->App->update('tbl_vendor', 'Id', $vId, $ass);
					echo json_encode(1);
                     // $this->session->data['success'] = 'success cancelled';
                } else {
					echo json_encode(2);
                      //  $this->session->data['error'] = sprintf('Error not cancel', $result['L_LONGMESSAGE0']);
                }
        } 
       // $this->redirect($this->url->link('account/recurring/info', 'recurring_id=' . $this->request->get['recurring_id'], 'SSL'));
	}

	public function sendrecurring() {
            $vId = $this->session->userdata['vendorauth']['Id'];
           ini_set('max_execution_time', 0); 
           ini_set('memory_limit','2048M');
           $payment_type = 'Sale';

           $this->load->model('Paypalpro');

           $order_info = $this->Paypalpro->getOrder();
           $paypalset=$this->App->getRecord('tbl_paypal_setting');
           $request  = 'METHOD=DoDirectPayment';
           $request .= '&VERSION=51.0';
           $request .= '&USER=' . urlencode($paypalset[0]['UserName']);
           $request .= '&PWD=' . urlencode($paypalset[0]['Password']);
           $request .= '&SIGNATURE=' . urlencode($paypalset[0]['Signature']);
           $request .= '&CUSTREF=' . '1';
           $request .= '&PAYMENTACTION=' . $payment_type;
           $request .= '&AMT='.$paypalset[0]['Amt'];
           $request .= '&CREDITCARDTYPE=' . $this->input->post('cc_type');
           $request .= '&ACCT=' . urlencode(str_replace(' ', '', $this->input->post('cc_number')));
           $request .= '&CARDSTART=' . urlencode($this->input->post('cc_start_date_month') . $this->input->post('cc_start_date_year'));
           $request .= '&EXPDATE=' . urlencode($this->input->post('cc_expire_date_month') . $this->input->post('cc_expire_date_year'));
           $request .= '&CVV2=' . urlencode($this->input->post('cc_cvv2'));

           if ($this->input->post('cc_type') == 'SWITCH' || $this->input->post('cc_type') == 'SOLO') {
                   $request .= '&ISSUENUMBER=' . urlencode($this->input->post('cc_issue'));
           }

           $request .= '&FIRSTNAME=' . urlencode($order_info['payment_firstname']);
           $request .= '&LASTNAME=' . urlencode($order_info['payment_lastname']);
           $request .= '&EMAIL=' . urlencode($order_info['email']);
           $request .= '&PHONENUM=' . urlencode($order_info['telephone']);
           $request .= '&IPADDRESS=' . urlencode($this->input->server['REMOTE_ADDR']);
           $request .= '&STREET=' . urlencode($order_info['payment_address_1']);
           $request .= '&CITY=' . urlencode($order_info['payment_city']);
           $request .= '&STATE=' . urlencode(($order_info['payment_iso_code_2'] != 'US') ? $order_info['payment_zone'] : $order_info['payment_zone_code']);
           $request .= '&ZIP=' . urlencode($order_info['payment_postcode']);
           $request .= '&COUNTRYCODE=' . urlencode($order_info['payment_iso_code_2']);
           $request .= '&CURRENCYCODE=' . urlencode($order_info['currency_code']);
           $request .= '&BUTTONSOURCE=' . urlencode('OpenCart_2.0_WPP');

           $request .= '&SHIPTONAME=' . urlencode($order_info['payment_firstname'] . ' ' . $order_info['payment_lastname']);
                   $request .= '&SHIPTOSTREET=' . urlencode($order_info['payment_address_1']);
                   $request .= '&SHIPTOCITY=' . urlencode($order_info['payment_city']);
                   $request .= '&SHIPTOSTATE=' . urlencode(($order_info['payment_iso_code_2'] != 'US') ? $order_info['payment_zone'] : $order_info['payment_zone_code']);
                   $request .= '&SHIPTOCOUNTRYCODE=' . urlencode($order_info['payment_iso_code_2']);
                   $request .= '&SHIPTOZIP= 390019';
					$expresspaypal =$this->config->item('expresspaypal');

           $curl = curl_init($expresspaypal);


           curl_setopt($curl, CURLOPT_PORT, 443);
           curl_setopt($curl, CURLOPT_HEADER, 0);
           curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
           curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
           curl_setopt($curl, CURLOPT_FORBID_REUSE, 1);
           curl_setopt($curl, CURLOPT_FRESH_CONNECT, 1);
           curl_setopt($curl, CURLOPT_POST, 1);
           curl_setopt($curl, CURLOPT_POSTFIELDS, $request);

           $response = curl_exec($curl);

           curl_close($curl);

           if (!$response) {
                   $this->log->write('DoDirectPayment failed: ' . curl_error($curl) . '(' . curl_errno($curl) . ')');
           }


           $response_info = array();

           parse_str($response, $response_info);

           $json = array();

           if (($response_info['ACK'] == 'Success') || ($response_info['ACK'] == 'SuccessWithWarning')) {

                $message = '';

                if (isset($response_info['AVSCODE'])) {
                        $message .= 'AVSCODE: ' . $response_info['AVSCODE'] . "\n";
                }
                if (isset($response_info['CVV2MATCH'])) {
                        $message .= 'CVV2MATCH: ' . $response_info['CVV2MATCH'] . "\n";
                }
                if (isset($response_info['TRANSACTIONID'])) {
                        $message .= 'TRANSACTIONID: ' . $response_info['TRANSACTIONID'] . "\n";
                }
                $this->Paypalpro->addOrderHistory($vId, $vId, $message, false);
                    $recurring_products=array('1,1');
                    if(!empty($recurring_products)) {
                            $billing_period = array(
                                    'day' => 'Day',
                                    'week' => 'Week',
                                    'semi_month' => 'SemiMonth',
                                    'month' => 'Month',
                                    'year' => 'Year'
                            );

			$paypalset=$this->App->getRecord('tbl_paypal_setting');
			$card_config['card_recurring']='1';
			if($card_config['card_recurring']=='1') {

                        $request  = 'METHOD=CreateRecurringPaymentsProfile';
                        $request .= '&VERSION=51.0';
                        $request .= '&USER=' . urlencode($paypalset[0]['UserName']);
                        $request .= '&PWD=' . urlencode($paypalset[0]['Password']);
                        $request .= '&SIGNATURE=' . urlencode($paypalset[0]['Signature']);
                        $request .= '&CUSTREF=' . (int)$vId;
                        $request .= '&PAYMENTACTION=' . $payment_type;
                        #$request .= '&AMT=' . $this->currency->format($order_info['total'], $order_info['currency_code'], false, false);
                        $request .= '&CREDITCARDTYPE=' . $this->input->post('cc_type');
                        $request .= '&ACCT=' . urlencode(str_replace(' ', '', $this->input->post('cc_number')));
                        $request .= '&CARDSTART=' . urlencode($this->input->post('cc_start_date_month') . $this->input->post('cc_start_date_year'));
                        $request .= '&EXPDATE=' . urlencode($this->input->post('cc_expire_date_month') . $this->input->post('cc_expire_date_year'));
                        $request .= '&CVV2=' . urlencode($this->input->post('cc_cvv2'));

                        if ($this->input->post('cc_type') == 'SWITCH' || $this->input->post('cc_type') == 'SOLO') { 
                                $request .= '&CARDISSUE=' . urlencode($this->input->post('cc_issue'));
                        }

                        $request .= '&FIRSTNAME=' . urlencode($order_info['payment_firstname']);
                        $request .= '&LASTNAME=' . urlencode($order_info['payment_lastname']);
                        $request .= '&EMAIL=' . urlencode($order_info['email']);
                        $request .= '&PHONENUM=' . urlencode($order_info['telephone']);
                        $request .= '&IPADDRESS=' . urlencode($this->input->server('REMOTE_ADDR'));
                        $request .= '&STREET=' . urlencode($order_info['payment_address_1']);
                        $request .= '&CITY=' . urlencode($order_info['payment_city']);
                        $request .= '&STATE=' . urlencode(($order_info['payment_iso_code_2'] != 'US') ? $order_info['payment_zone'] : $order_info['payment_zone_code']);
                        $request .= '&ZIP=' . urlencode($order_info['payment_postcode']);
                        $request .= '&COUNTRYCODE=' . urlencode($order_info['payment_iso_code_2']);
                        $request .= '&CURRENCYCODE=' . urlencode($order_info['currency_code']);

                        $request .= '&BUTTONSOURCE=' . urlencode('WebWizard_SP');
							
                        $request .= '&SHIPTONAME=' . urlencode($order_info['payment_firstname'] . ' ' . $order_info['payment_lastname']);
                        $request .= '&SHIPTOSTREET=' . urlencode($order_info['payment_address_1']);
                        $request .= '&SHIPTOCITY=' . urlencode($order_info['payment_city']);
                        $request .= '&SHIPTOSTATE=' . urlencode(($order_info['payment_iso_code_2'] != 'US') ? $order_info['payment_zone'] : $order_info['payment_zone_code']);
                        $request .= '&SHIPTOCOUNTRYCODE=' . urlencode($order_info['payment_iso_code_2']);
                        $request .= '&SHIPTOZIP=390019';			


                        $request .= '&PROFILESTARTDATE=' . gmdate("Y-m-d\TH:i:s\Z", mktime(gmdate("H"), gmdate("i")+5, gmdate("s"), gmdate("m"), gmdate("d"), gmdate("y")));
                        $request .= '&BILLINGPERIOD=Year';
                        $request .= '&BILLINGFREQUENCY='.$item['recurring_trial_frequency'];
                        $request .= '&TOTALBILLINGCYCLES='.$item['recurring_trial_cycle'];
                        $request .= '&AMT='.$paypalset[0]['Amt'];
                        $request .= '&CURRENCYCODE='.$paypalset[0]['CurrencyCode']; 
                        ##description
                        #$description = 'BILLINGPERIOD-'.$billing_period[$item['recurring_frequency']].'BILLINGFREQUENCY-'.$item['recurring_cycle'];
                        $descc = 'Tablefast.com Payment ';

                        $description = urlencode($descc);

                        $request .= '&DESC='.$description;


                //trial information
                //if($item['recurring_trial'] == 1) {

                        $request .= '&TRIALBILLINGPERIOD=' . $billing_period[$item['recurring_trial_frequency']];
                        $request .= '&TRIALBILLINGFREQUENCY=' . $item['recurring_trial_cycle'];
                        $request .= '&TRIALTOTALBILLINGCYCLES=' . $item['recurring_trial_duration'];
                        $request .= '&TRIALAMT='.$paypalset[0]['Amt'];

						//} 
$expresspaypal =$this->config->item('expresspaypal');
                        $curl = curl_init($expresspaypal);
			 $testpp = 0;
                    curl_setopt($curl, CURLOPT_PORT, 443);
                    curl_setopt($curl, CURLOPT_HEADER, 0);
                    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
                    curl_setopt($curl, CURLOPT_FORBID_REUSE, 1);
                    curl_setopt($curl, CURLOPT_FRESH_CONNECT, 1);
                    curl_setopt($curl, CURLOPT_POST, 1);
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $request);

                    $response = curl_exec($curl);

                    curl_close($curl);

//echo '123';print_r($request);print_r($response);die;
                    if (!$response) {
                            $json['error']='failed';	}

                    $response_info2 = array();

                    parse_str($response, $response_info2);


                    if (($response_info2['ACK'] == 'Success') || ($response_info2['ACK'] == 'SuccessWithWarning')) {

                    $recurring_id = $this->db->getLastId();

                    $ref = $response_info2['PROFILEID'];

            $message = '';

			if (isset($response_info['AVSCODE'])) {
				$message .= 'AVSCODE: ' . $response_info['AVSCODE'] . "\n";
			}

			if (isset($response_info['CVV2MATCH'])) {
				$message .= 'CVV2MATCH: ' . $response_info['CVV2MATCH'] . "\n";
			}

			if (isset($response_info['TRANSACTIONID'])) {
				$message .= 'TRANSACTIONID: ' . $response_info['TRANSACTIONID'] . "\n";
			}
	$this->Paypalpro->addOrderHistory($vId, $vId, $message, false);
		
						}
						
					}
				}

			$json['success'] = '1';

		} else {
			$json['error'] = $response_info['L_LONGMESSAGE0'];
			$json['err'] = '2';
		}
		echo json_encode($json);
	} 
    
	public function sendrecurring1() {
		 $vId = $this->session->userdata['vendorauth']['Id'];
		
		$payment_type = 'Sale';

		$this->load->model('Paypalpro');

		$order_info = $this->Paypalpro->getOrder();
		$paypalset=$this->App->getRecord('tbl_paypal_setting');
		$request  = 'METHOD=DoDirectPayment';
		$request .= '&VERSION=51.0';
		$request .= '&USER=' . urlencode($paypalset[0]['UserName']);
		$request .= '&PWD=' . urlencode($paypalset[0]['Password']);
		$request .= '&SIGNATURE=' . urlencode($paypalset[0]['Signature']);
		$request .= '&CUSTREF=' . '1';
		$request .= '&PAYMENTACTION=' . $payment_type;
		$request .= '&AMT='.$paypalset[0]['Amt'];
		$request .= '&CREDITCARDTYPE=' . $this->input->post('cc_type');
		$request .= '&ACCT=' . urlencode(str_replace(' ', '', $this->input->post('cc_number')));
		$request .= '&CARDSTART=' . urlencode($this->input->post('cc_start_date_month') . $this->input->post('cc_start_date_year'));
		$request .= '&EXPDATE=' . urlencode($this->input->post('cc_expire_date_month') . $this->input->post('cc_expire_date_year'));
		$request .= '&CVV2=' . urlencode($this->input->post('cc_cvv2'));
		
		if ($this->input->post('cc_type') == 'SWITCH' || $this->input->post('cc_type') == 'SOLO') {
			$request .= '&ISSUENUMBER=' . urlencode($this->input->post('cc_issue'));
		}

		$request .= '&FIRSTNAME=' . urlencode($order_info['payment_firstname']);
		$request .= '&LASTNAME=' . urlencode($order_info['payment_lastname']);
		$request .= '&EMAIL=' . urlencode($order_info['email']);
		$request .= '&PHONENUM=' . urlencode($order_info['telephone']);
		$request .= '&IPADDRESS=' . urlencode($this->input->server['REMOTE_ADDR']);
		$request .= '&STREET=' . urlencode($order_info['payment_address_1']);
		$request .= '&CITY=' . urlencode($order_info['payment_city']);
		$request .= '&STATE=' . urlencode(($order_info['payment_iso_code_2'] != 'US') ? $order_info['payment_zone'] : $order_info['payment_zone_code']);
		$request .= '&ZIP=' . urlencode($order_info['payment_postcode']);
		$request .= '&COUNTRYCODE=' . urlencode($order_info['payment_iso_code_2']);
		$request .= '&CURRENCYCODE=' . urlencode($order_info['currency_code']);
		$request .= '&BUTTONSOURCE=' . urlencode('OpenCart_2.0_WPP');

		$request .= '&SHIPTONAME=' . urlencode($order_info['payment_firstname'] . ' ' . $order_info['payment_lastname']);
			$request .= '&SHIPTOSTREET=' . urlencode($order_info['payment_address_1']);
			$request .= '&SHIPTOCITY=' . urlencode($order_info['payment_city']);
			$request .= '&SHIPTOSTATE=' . urlencode(($order_info['payment_iso_code_2'] != 'US') ? $order_info['payment_zone'] : $order_info['payment_zone_code']);
			$request .= '&SHIPTOCOUNTRYCODE=' . urlencode($order_info['payment_iso_code_2']);
			$request .= '&SHIPTOZIP= 390019';
		
	$expresspaypal =$this->config->item('expresspaypal');
		$curl = curl_init($expresspaypal);
	

		curl_setopt($curl, CURLOPT_PORT, 443);
		curl_setopt($curl, CURLOPT_HEADER, 0);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl, CURLOPT_FORBID_REUSE, 1);
		curl_setopt($curl, CURLOPT_FRESH_CONNECT, 1);
		curl_setopt($curl, CURLOPT_POST, 1);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $request);

		$response = curl_exec($curl);

		curl_close($curl);

		if (!$response) {
			$this->log->write('DoDirectPayment failed: ' . curl_error($curl) . '(' . curl_errno($curl) . ')');
		}


		$response_info = array();

		parse_str($response, $response_info);

		$json = array();

		if (($response_info['ACK'] == 'Success') || ($response_info['ACK'] == 'SuccessWithWarning')) {

			###

			##
			$message = '';

			if (isset($response_info['AVSCODE'])) {
				$message .= 'AVSCODE: ' . $response_info['AVSCODE'] . "\n";
			}

			if (isset($response_info['CVV2MATCH'])) {
				$message .= 'CVV2MATCH: ' . $response_info['CVV2MATCH'] . "\n";
			}

			if (isset($response_info['TRANSACTIONID'])) {
				$message .= 'TRANSACTIONID: ' . $response_info['TRANSACTIONID'] . "\n";
			}

			$this->Paypalpro->addOrderHistory($vId, $vId, $message, false);

                        $recurring_products=array('1,1');
                        if(!empty($recurring_products)) {



                                $billing_period = array(
                                        'day' => 'Day',
                                        'week' => 'Week',
                                        'semi_month' => 'SemiMonth',
                                        'month' => 'Month',
                                        'year' => 'Year'
                                );

			$paypalset=$this->App->getRecord('tbl_paypal_setting');
			foreach($recurring_products as $item) {

                            $request  = 'METHOD=CreateRecurringPaymentsProfile';
                            $request .= '&VERSION=51.0';
                            $request .= '&USER=' . urlencode($paypalset[0]['UserName']);
                            $request .= '&PWD=' . urlencode($paypalset[0]['Password']);
                            $request .= '&SIGNATURE=' . urlencode($paypalset[0]['Signature']);
                            $request .= '&CUSTREF=' . (int)$vId;
                            $request .= '&PAYMENTACTION=' . $payment_type;
                            #$request .= '&AMT=' . $this->currency->format($order_info['total'], $order_info['currency_code'], false, false);
                            $request .= '&CREDITCARDTYPE=' . $this->input->post('cc_type');
                            $request .= '&ACCT=' . urlencode(str_replace(' ', '', $this->input->post('cc_number')));
                            $request .= '&CARDSTART=' . urlencode($this->input->post('cc_start_date_month') . $this->input->post('cc_start_date_year'));
                            $request .= '&EXPDATE=' . urlencode($this->input->post('cc_expire_date_month') . $this->input->post('cc_expire_date_year'));
                            $request .= '&CVV2=' . urlencode($this->input->post('cc_cvv2'));

                            if ($this->input->post('cc_type') == 'SWITCH' || $this->input->post('cc_type') == 'SOLO') { 
                                    $request .= '&CARDISSUE=' . urlencode($this->input->post('cc_issue'));
                            }

                            $request .= '&FIRSTNAME=' . urlencode($order_info['payment_firstname']);
                            $request .= '&LASTNAME=' . urlencode($order_info['payment_lastname']);
                            $request .= '&EMAIL=' . urlencode($order_info['email']);
                            $request .= '&PHONENUM=' . urlencode($order_info['telephone']);
                            $request .= '&IPADDRESS=' . urlencode($this->input->server('REMOTE_ADDR'));
                            $request .= '&STREET=' . urlencode($order_info['payment_address_1']);
                            $request .= '&CITY=' . urlencode($order_info['payment_city']);
                            $request .= '&STATE=' . urlencode(($order_info['payment_iso_code_2'] != 'US') ? $order_info['payment_zone'] : $order_info['payment_zone_code']);
                            $request .= '&ZIP=' . urlencode($order_info['payment_postcode']);
                            $request .= '&COUNTRYCODE=' . urlencode($order_info['payment_iso_code_2']);
                            $request .= '&CURRENCYCODE=' . urlencode($order_info['currency_code']);

                            $request .= '&BUTTONSOURCE=' . urlencode('WebWizard_SP');
		
							
                            $request .= '&SHIPTONAME=' . urlencode($order_info['payment_firstname'] . ' ' . $order_info['payment_lastname']);
                            $request .= '&SHIPTOSTREET=' . urlencode($order_info['payment_address_1']);
                            $request .= '&SHIPTOCITY=' . urlencode($order_info['payment_city']);
                            $request .= '&SHIPTOSTATE=' . urlencode(($order_info['payment_iso_code_2'] != 'US') ? $order_info['payment_zone'] : $order_info['payment_zone_code']);
                            $request .= '&SHIPTOCOUNTRYCODE=' . urlencode($order_info['payment_iso_code_2']);
                            $request .= '&SHIPTOZIP=390019';			
												
							
                            $request .= '&PROFILESTARTDATE=' . gmdate("Y-m-d\TH:i:s\Z", mktime(gmdate("H"), gmdate("i")+5, gmdate("s"), gmdate("m"), gmdate("d"), gmdate("y")));
                            $request .= '&BILLINGPERIOD='.$paypalset[0]['BillingPeriod'];
                            $request .= '&BILLINGFREQUENCY='.$paypalset[0]['BillingFrequency'];
                            $request .= '&TOTALBILLINGCYCLES='.$paypalset[0]['TotalBillingCycle'];
                            $request .= '&AMT='.$paypalset[0]['Amt'];
                            $request .= '&CURRENCYCODE='.$paypalset[0]['CurrencyCode']; 
                            ##description
                            #$description = 'BILLINGPERIOD-'.$billing_period[$item['recurring_frequency']].'BILLINGFREQUENCY-'.$item['recurring_cycle'];
                            $descc = 'Tablefast.com Payment ';

                            $description = urlencode($descc);

                            $request .= '&DESC='.$description;


                            //trial information
                            //if($item['recurring_trial'] == 1) {

                                            $request .= '&TRIALBILLINGPERIOD=' . $billing_period[$item['recurring_trial_frequency']];
                                            $request .= '&TRIALBILLINGFREQUENCY=' . $item['recurring_trial_cycle'];
                                            $request .= '&TRIALTOTALBILLINGCYCLES=' . $item['recurring_trial_duration'];
                                            $request .= '&TRIALAMT='.$paypalset[0]['Amt'];

                            //} 
						$expresspaypal =$this->config->item('expresspaypal');
                        $curl = curl_init($expresspaypal);
						$testpp = 0;
                        curl_setopt($curl, CURLOPT_PORT, 443);
                        curl_setopt($curl, CURLOPT_HEADER, 0);
                        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
                        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
                        curl_setopt($curl, CURLOPT_FORBID_REUSE, 1);
                        curl_setopt($curl, CURLOPT_FRESH_CONNECT, 1);
                        curl_setopt($curl, CURLOPT_POST, 1);
                        curl_setopt($curl, CURLOPT_POSTFIELDS, $request);

                        $response = curl_exec($curl);

                        curl_close($curl);
                        if (!$response) {
                                $this->log->write('DoDirectPayment failed: ' . curl_error($curl) . '(' . curl_errno($curl) . ')');
                        }
                        $response_info2 = array();
                        parse_str($response, $response_info2);
                        if (($response_info2['ACK'] == 'Success') || ($response_info2['ACK'] == 'SuccessWithWarning')) {
                        

                        $recurring_id = $this->db->getLastId();

                        $ref = $response_info2['PROFILEID'];
						}
						
					}
				}
			$json['success'] = '1';

		} else {
			$json['error'] = $response_info['L_LONGMESSAGE0'];
			$json['err'] = '2';
		}
   
		echo json_encode($json);
	} 
    public function payoptions()
    {
		$data['text_credit_card'] = "Credit Card Details";
		$data['text_start_date'] = "Start Date";
		$data['text_wait'] = "Please wait!";
		$data['text_loading'] = "Loading";

		$data['entry_cc_type'] = "Card Type";
		$data['entry_cc_number'] = "Card Number";
		$data['entry_cc_start_date'] = "Card Valid From Date";
		$data['entry_cc_expire_date'] = "Card Expiry Date";
		$data['entry_cc_cvv2'] = "Card Security Code (CVV2)";
		$data['entry_cc_issue'] = "Card Issue Number";

		$data['help_start_date'] = "(if available)";
		$data['help_issue'] = "(for Maestro and Solo cards only)";

		$data['button_confirm'] = 'button_confirm';

		$data['cards'] = array();

		$data['cards'][] = array(
			'text'  => 'Visa', 
			'value' => 'VISA'
		);

		$data['cards'][] = array(
			'text'  => 'MasterCard', 
			'value' => 'MASTERCARD'
		);

		$data['cards'][] = array(
			'text'  => 'Discover Card', 
			'value' => 'DISCOVER'
		);

		$data['cards'][] = array(
			'text'  => 'American Express', 
			'value' => 'AMEX'
		);

		$data['cards'][] = array(
			'text'  => 'Maestro', 
			'value' => 'SWITCH'
		);

		$data['cards'][] = array(
			'text'  => 'Solo', 
			'value' => 'SOLO'
		);		

		$data['months'] = array();

		for ($i = 1; $i <= 12; $i++) {
			$data['months'][] = array(
				'text'  => strftime('%B', mktime(0, 0, 0, $i, 1, 2000)), 
				'value' => sprintf('%02d', $i)
			);
		}

		$today = getdate();

		$data['year_valid'] = array();

		for ($i = $today['year'] - 10; $i < $today['year'] + 1; $i++) {	
			$data['year_valid'][] = array(
				'text'  => strftime('%Y', mktime(0, 0, 0, 1, 1, $i)), 
				'value' => strftime('%Y', mktime(0, 0, 0, 1, 1, $i))
			);
		}

		$data['year_expire'] = array();

		for ($i = $today['year']; $i < $today['year'] + 11; $i++) {
			$data['year_expire'][] = array(
				'text'  => strftime('%Y', mktime(0, 0, 0, 1, 1, $i)),
				'value' => strftime('%Y', mktime(0, 0, 0, 1, 1, $i)) 
			);
		}
	    $this->load->view('front/include/header');
        $this->load->view('front/paypalpro/reccheckout',$data);
        $this->load->view('front/include/footer');
	}
	
	public function transactions()
	{
		$this->App->checkVendorAuthenticate();
        $id = $this->session->userdata['vendorauth']['Id'];
        $query = $this->db->query("select * from tbl_payment_history where order_id = '".$id."' ORDER BY `order_history_id` ASC");
        $data['transaction'] = $query->result_array();
        $this->load->view('front/vendor/transactionreport', $data);
	}
	public function cancelrurringpayment()
	{
			
		$payid = $this->input->post('payid');
		  $API_UserName =  $this->CI->session->userdata['paypalcredential']['API_UserName'];
		  $API_Password =  $this->CI->session->userdata['paypalcredential']['API_Password'];
		  $API_Signature =  $this->CI->session->userdata['paypalcredential']['API_Signature'];
		    $version =  $this->CI->session->userdata['paypalcredential']['version'];
		$curl = curl_init();
		$expresspaypal= $this->config->item('expresspaypal');
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_URL,$expresspaypal);
		curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query(array(
			'USER' => trim($API_UserName),  //Your API User
			'PWD' => trim($API_Password),  //Your API Password
			'SIGNATURE' => trim($API_Signature),   //Your API Signature

			'VERSION' => trim($version),
			'METHOD' => 'ManageRecurringPaymentsProfileStatus',
			'PROFILEID' => $payid,         //here add your profile id                      
			'ACTION'    => 'Cancel' //this can be selected in these default paypal variables (Suspend, Cancel, Reactivate)
		)));

		$response =    curl_exec($curl);

		curl_close($curl);

		$nvp = array();

		if (preg_match_all('/(?<name>[^\=]+)\=(?<value>[^&]+)&?/', $response, $matches)) {
			foreach ($matches['name'] as $offset => $name) {
				$nvp[$name] = urldecode($matches['value'][$offset]);
			}
		}
		$data = $nvp['L_LONGMESSAGE0'];
		echo json_encode($data);
	}
    
}
