<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Club extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->helper('new_helper');
        $this->load->library('form_validation');
        $this->load->library('email');
        $this->load->library('session');
    }
    
    public function facility()
    {
        
        $this->App->checkVendorAuthenticate();
        $id = $this->session->userdata['vendorauth']['Id'];
        $data["listcategory"] = $this->App->getPerticularRecord('tbl_facility', 'ClubId', $id);
        $this->load->view('front/food/facility', $data);
    }
    public function addfacility()
    {
        $this->App->checkVendorAuthenticate();
        $category = $this->input->post('category');
        $description = $this->input->post('description');
        $id = $this->session->userdata['vendorauth']['Id'];
        $s = $this->db->query("select * from tbl_facility where Title='" . $category . "' and ClubId='" . $id . "'");
        $res = $s->num_rows();
        if ($res > 0) {
            echo json_encode('2');
        } else {
            $trim = trim($category);
            $ow = strtolower($trim);
            $string = str_replace(' ', '-', $ow);
            $str = preg_replace('/\s+/', '-', $string);
            $chkslug = $this->App->checkExist('tbl_facility', 'Slug', $str);
            if ($chkslug == '1') {
                $r = rand(1, 4);
                $slug = $str . $r;
            } else {
                $slug = $str;
            }
            $array = array(
                'Title' => $category,
                'Description' => $description,
                'Slug' => $slug,
                'Status' => '1',
                'ClubId' => $id,
                'Created' => date('Y-m-d')
            );
            $this->App->insertdata('tbl_facility', $array);
            echo json_encode('1');
        }
    }
    
    public function updatefrom()
    {
        $this->App->checkVendorAuthenticate();
        $id  = $this->input->post('id');
        $ads = $this->App->getPerticularRecord('tbl_facility', 'Id', $id);
        $sd  = '';
        if (!empty($ads)) {
            foreach ($ads as $tes) {
                $tit = $tes['Title'];
                $cid = $tes['Id'];
                $cstatus = $tes['Status'];
                $Description = $tes['Description'];
                $sd .= '<div class="modal fade" id="myModal2" role="dialog"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="close" data-dismiss="modal">&times;</button><h4 class="modal-title" >Update Category</h4></div><div class="modal-body"><form id="demo-form2" method="post" class="form-horizontal form-label-left"><div id="err2" style="color:red"></div><div id="err3" style="color:red"></div><div class="form-group"><div class="col-md-12 col-sm-12 col-xs-12"><input id="cattitle1" class="form-control col-md-12 col-xs-12" placeholder="Title" required="required" type="text" name="cattitle1" value="' . $tit . '"><input type="hidden" name="catid" id="catid" value="' . $cid . '"></div></div> <div class="ln_solid"></div>
                <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                        <textarea id="desc1" class="form-control col-md-12 col-xs-12" placeholder="Description" required="required" name="desc1">' . $Description . '</textarea> 
                         </div>
                      </div>
                <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                        <label style="text-align:left">Status</label>
                         <select class="form-control col-md-12 col-xs-12"  id="catstatus" name="catstatus">
                        <option value="1"';
                if ($cstatus == "1") {
                    $sd .= 'selected=selected';
                }
                $sd .= '>Active</option>
                        <option value="0"';
                if ($cstatus == "0") {
                    $sd .= 'selected=selected';
                }
                $sd .= '>Inactive</option>
                         </select>
                          </div>
                      </div>
                <div class="form-group"><div class="col-md-12 col-sm-12 col-xs-12 "> <button type="button" class="btn btn-default" onclick="editcategory()">Submit</button></div></div></form></div></div></div> </div>';
            }
        }
        $sd .= '</div>';
        $data = $sd;
        echo json_encode($data);
    }
    public function editcategory()
    {
        $this->App->checkVendorAuthenticate();
        $category  = $this->input->post('category');
        $desc = $this->input->post('desc');
        $catstatus = $this->input->post('catstatus');
        $cid = $this->input->post('id');
        $id = $this->session->userdata['vendorauth']['Id'];
        $catstatus = $this->input->post('catstatus');
        $s = $this->db->query("select * from tbl_facility where Title='" . $category . "' and ClubId='" . $id . "' and Id<>'" . $cid . "'");
        $res = $s->num_rows();
        if ($res > 0) {
            echo json_encode('2');
        } else {
            $trim = trim($category);
            $ow = strtolower($trim);
            $string = str_replace(' ', '-', $ow);
            $str = preg_replace('/\s+/', '-', $string);
            $chkslug = $this->App->checkExist('tbl_facility', 'Slug', $str);
            if ($chkslug == '1') {
                $r = rand(1, 4);
                $slug = $str . $r;
            } else {
                $slug = $str;
            }
            $array = array(
                'Title' => $category,
                'Description' => $desc,
                'Slug' => $slug,
                'Status' => $catstatus,
                'ClubId' => $id,
                'Created' => date('Y-m-d')
            );
            $this->App->update('tbl_facility', 'Id', $cid, $array);
            echo json_encode('1');
        }
    }
    public function deletefacility()
    {
        $this->App->checkVendorAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('tbl_facility', 'Id', $id);
        return 1;
    }
}
