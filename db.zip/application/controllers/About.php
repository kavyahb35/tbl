<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class About extends CI_Controller
{   
    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->helper('new_helper');
    }
    public function index()
    {
        $this->load->view('front/include/header');
        $this->load->view('front/about');
        $this->load->view('front/include/footer');
    }
    public function index1()
    {
        echo 'front';
        $this->App->demo();
        echo test_method('Hello World'); // helper method        
        $this->load->view('welcome_message');
    }
}