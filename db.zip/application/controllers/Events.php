<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Events extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->helper('new_helper');
        $this->load->library('form_validation');
        $this->load->library('email');
        $this->load->library('session');
        $this->load->library('pagination');
        $this->load->helper('url');
    }
    
    public function index()
    {
        $this->App->checkVendorAuthenticate();
        $id = $this->session->userdata['vendorauth']['Id'];
        $data["listcategory"] = $this->App->getPerticularRecord('tbl_events', 'ClubId', $id);        
        $data["listtypeevent"] = $this->App->passwordChecking('tbl_event_type','ClubId', 'Status',$id, '1');
        $this->load->view('front/events/listevent', $data);
    }
    public function types()
    {
		$this->App->checkVendorAuthenticate();
        $id = $this->session->userdata['vendorauth']['Id'];
        $data["listcategory"] = $this->App->getPerticularRecord('tbl_event_type', 'ClubId', $id);
        $this->load->view('front/events/listeventtype', $data);
	}
	
    public function index_ci_pagination()
    {
        $this->App->checkVendorAuthenticate();
        $id = $this->session->userdata['vendorauth']['Id'];
        $tot = $this->App->getPerticularRecord('tbl_events', 'ClubId', $id);
        $config["base_url"] = base_url() . "events/index/";
        $config["total_rows"] = count($tot);
        $config["per_page"] = 10;
        $config["uri_segment"] = 3;
        $this->pagination->initialize($config);
        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["listcategory"] = $this->App->fetch_fooditem('tbl_events', 'ClubId', $id, $config["per_page"], $page);
        $data["links"] = $this->pagination->create_links();
        
        $this->load->view('front/include/header');
        $this->load->view('front/events/listevent', $data);
        $this->load->view('front/include/footer');
    }
    public function addevent()
    {   
        $this->form_validation->set_rules('eventtitle', 'Title', 'required');
        $this->form_validation->set_rules('description', 'Description', 'required');
        //$this->form_validation->set_rules('price', 'Price', 'required');
        $this->form_validation->set_rules('fromtime', 'From Time', 'required');
        $this->form_validation->set_rules('totime', 'To Time', 'required');
         $this->form_validation->set_rules('days', 'No. of days', 'required');
        
        $id = $this->session->userdata['vendorauth']['Id'];
        
        if($_POST){
						
            $currentdt = date('Y-m-d');
            $fromdate=$this->input->post('fromdate');
            $todate=$this->input->post('todate');
            $specialdate=$this->input->post('specialdate');
            
            if($fromdate!='' && $todate==''){
				 $this->form_validation->set_rules('fromdate', 'From Date', 'required');
			}
			 if($fromdate=='' && $todate!=''){
				 $this->form_validation->set_rules('todate', 'To Date', 'required');
			}
			 if($fromdate=='' && $todate==''){
				 $this->form_validation->set_rules('specialdate', 'Date', 'required');
			}
            
            $fromdate = date('Y-m-d', strtotime($fromdate));
            $todate = date('Y-m-d', strtotime($todate));
            $specialdate = date('Y-m-d', strtotime($specialdate));
            
            
           /* if($specialdate!=''){
				if (strtotime($currentdt) <= strtotime($specialdate) ) {
                
				}else{
					$err='Please Select greater than or equal date<br>';
					}
			}
			 if($fromdate!='' && $todate!=''){
				if( (strtotime($fromdate) >= strtotime($currentdt)) && (strtotime($todate) >= strtotime($currentdt)) ){
					
				}else{
					$err='Please Select greater than or equal date<br>';
					}
			}*/
              
        }
        if ($this->form_validation->run() == FALSE || $err !=''|| $err1 !=''|| $err2 !='') {
            if (validation_errors() != '' || $err !=''|| $err1 !=''|| $err2 !='') {
                $data['error'] = validation_errors().$err.$err1.$err2;
                
                 $id = $this->session->userdata['vendorauth']['Id'];
        $data["listcategory"] = $this->App->getPerticularRecord('tbl_events', 'ClubId', $id);
        $this->load->view('front/events/listevent', $data);
            }
        } else {
            $id = $this->session->userdata['vendorauth']['Id'];
            $days = $this->input->post('days');
            if ($days == '1') {
                $ds = '1';
            } else {
                $ds = $this->input->post('nooddays');
            }
            
            
            if (!empty($_FILES['uploadsfl']['name'])) {
                $config['upload_path']   = 'assets/events/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['file_name']     = $_FILES['uploadsfl']['name'];

                $this->load->library('upload', $config);
                $this->upload->initialize($config);

                if ($this->upload->do_upload('uploadsfl')) {
                    $uploadData = $this->upload->data();
                    $picture = $uploadData['file_name'];
                }
            }
            $clbname = $this->input->post('eventtitle');
            $trim = trim($clbname);
            $ow = strtolower($trim);
            $string = str_replace(' ', '-', $ow);
            $id = $this->session->userdata['vendorauth']['Id'];
            $str = preg_replace('/\s+/', '-', $string);
            $chkslug = $this->App->checkExistEdit('tbl_events', 'Slug', $str, 'Id', $id);
            if ($chkslug == '1') {
                $r = rand(1, 4);
                $slug = $str . $r;
            } else {
                $slug = $str;
            }
            $eventtype = $this->input->post('eventtype');
            $eventtypes = implode(',',$eventtype);
            $arr = array(
                'ClubId' => $id,
                'Title' => $this->input->post('eventtitle'),
                'Description' => $this->input->post('description'),
                'FromDate' => $fromdate,
                'ToDate' => $todate,
                'NoofDays' => $ds,
                'OneDate' => $specialdate,
                'TimeFrom' => $this->input->post('fromtime'),
                'TimeTo' => $this->input->post('totime'),
                'Status' => '1',
                'Price' => $this->input->post('price'),
                'Image' => $picture,
                'Created' => date('Y-m-d'),
                'Slug' => $slug,
                'eventtype'=> $eventtypes,
            );
            $iid = $this->App->insertdata('tbl_events', $arr);
            
            
            //---- event ticket update-----
             $eventtype = $this->input->post('eventtype');
            $count =  count($eventtype);
            for($i=0;$i<$count;$i++){
				$eventtypes = $this->App->getPerticularRecord('tbl_event_type', 'Id', $eventtype[$i]); 
				 $nooftickets = $eventtypes[0]['NoofTickets'];
				
				 $eventtab = array(
				    'ClubId' => $id,
					'EventId' => $iid,
					'EventTypeId' => $eventtype[$i],
					'NoofTicket' => $nooftickets,
					'UsedTicket' => '',
					'Created' => date('Y-m-d'),
				 );
				 $this->App->insertdata('tbl_event_ticket_update', $eventtab);
			 }
            
            //------end code------------------------
            
            redirect('events');
             $id = $this->session->userdata['vendorauth']['Id'];
        $data["listcategory"] = $this->App->getPerticularRecord('tbl_events', 'ClubId', $id);        
        $data["listtypeevent"] = $this->App->getPerticularRecord('tbl_event_type', 'Status', '1');
        $this->load->view('front/events/listevent', $data);
        }
    }
    
    
    public function deleteevent()
    {
        $this->App->checkVendorAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('tbl_events', 'Id', $id);
        return 1;
    }
    public function updateeventfrom()
    {
        $this->App->checkVendorAuthenticate();
        $id = $this->input->post('id');
        $ads = $this->App->getPerticularRecord('tbl_events', 'Id', $id);
        $sd  = '';
        if (!empty($ads)) {
            foreach ($ads as $tes) {
                $ClubId = $tes['ClubId'];
                $Title = $tes['Title'];
                $Description = $tes['Description'];
                $FromDate = $tes['FromDate'];
                $ToDate = $tes['ToDate'];
                $NoofDays = $tes['NoofDays'];
                $OneDate = $tes['OneDate'];
                $TimeFrom = $tes['TimeFrom'];
                $TimeTo  = $tes['TimeTo'];
                $Image = $tes['Image'];
                $Status = $tes['Status'];
                $Price = $tes['Price'];
                $sd .= '<div class="modal fade" id="myModal" role="dialog"> <div class="modal-dialog">hello </div>';
            }
        }
        $sd .= '</div>';
        $data = $sd;
        echo json_encode($data);
    }
    public function editevent($slug)
    {
        $this->form_validation->set_rules('eventtitle', 'Title', 'required');
        $this->form_validation->set_rules('description', 'Description', 'required');
        //$this->form_validation->set_rules('price', 'Price', 'required');
        $id = $this->session->userdata['vendorauth']['Id'];
        
        
        if($_POST){
            $currentdt = date('Y-m-d');
           $fromdate=$this->input->post('fromdate');
          $todate=$this->input->post('todate');
         $specialdate=$this->input->post('specialdate');

             /*if($specialdate!='0000-00-00'){
				if (strtotime($currentdt) <= strtotime($specialdate) ) {
                
				}else{
					$err='Please Select greater than or equal date<br>';
					}
			}
			 if($fromdate!='0000-00-00' && $todate!='0000-00-00'){
				if( (strtotime($fromdate) >= strtotime($currentdt)) && (strtotime($todate) >= strtotime($currentdt)) ){
					
				}else{
					$err='Please Select greater than or equal date<br>';
					}
			}*/
            
        }
        
        if ($this->form_validation->run() == FALSE || $err!='' || $err1!='' || $err2!='') {
            if (validation_errors() != '' || $err!='' || $err1!='' || $err2!='') {
                $data['error'] = validation_errors().$err.$err1.$err2;
                
            }
        } else {
            
            if (!empty($_FILES['uploadsfl']['name'])) {
                $config['upload_path']   = 'assets/events/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['file_name']     = $_FILES['uploadsfl']['name'];

                //Load upload library and initialize configuration
                $this->load->library('upload', $config);
                $this->upload->initialize($config);

                if ($this->upload->do_upload('uploadsfl')) {
                    $uploadData = $this->upload->data();
                    $picture    = $uploadData['file_name'];
                }
            } else {
                $picture = $this->input->post('oldimg');
            }
            $id   = $this->session->userdata['vendorauth']['Id'];
            $days = $this->input->post('days');
            if ($days == '1') {
                $ds = '1';
            } else {
                $ds = $this->input->post('nooddays');
            }
            
            $clbname = $this->input->post('eventtitle');
            $trim = trim($clbname);
            $ow = strtolower($trim);
            $string  = str_replace(' ', '-', $ow);
            $id = $this->session->userdata['vendorauth']['Id'];
            $str = preg_replace('/\s+/', '-', $string);
            $chkslug = $this->App->checkExistEdit('tbl_events', 'Slug', $str, 'Id', $id);
            if ($chkslug == '1') {
                $r       = rand(1, 4);
                $slugold = $str . $r;
            } else {
                $slugold = $str;
            }
            $eventtype = $this->input->post('eventtype');
            $eventtypes = implode(',',$eventtype);
            $arr = array(
                'ClubId' => $id,
                'Title' => $this->input->post('eventtitle'),
                'Description' => $this->input->post('description'),
                'FromDate' => $this->input->post('fromdate'),
                'ToDate' => $this->input->post('todate'),
                'NoofDays' => $ds,
                'OneDate' => $this->input->post('specialdate'),
                'TimeFrom' => $this->input->post('fromtime'),
                'TimeTo' => $this->input->post('totime'),
                'Status' => $this->input->post('status'),
                'Price' => $this->input->post('price'),
                'Image' => $picture,
                'Created' => date('Y-m-d'),
                'eventtype'=> $eventtypes,
            );
            $iid = $this->App->update('tbl_events', 'Slug', $slug, $arr);
            
            //---- event ticket update-----
             $eventtype = $this->input->post('eventtype');
            $count =  count($eventtype);
            for($i=0;$i<$count;$i++){
				
				$eventdet = $this->App->getPerticularRecord('tbl_events', 'Slug', $slug); 
				
				 $eventid = $eventdet[0]['Id'];
				
				$eventtypes = $this->App->getPerticularRecord('tbl_event_type', 'Id', $eventtype[$i]); 
				 $nooftickets = $eventtypes[0]['NoofTickets'];
				 
				 $r = $this->db->query("select * from tbl_event_ticket_update where ClubId='".$id."' and EventId='".$eventid."' and EventTypeId='".$eventtype[$i]."'");
				 $no = $r->num_rows();
				 if($no > 0){
					 
			     }else {
				
					 $eventtab = array(
						'ClubId' => $id,
						'EventId' => $eventid,
						'EventTypeId' => $eventtype[$i],
						'NoofTicket' => $nooftickets,
						'UsedTicket' => '',
						'Created' => date('Y-m-d'),
					 );
					 $this->App->insertdata('tbl_event_ticket_update', $eventtab);
				 }
			 }
            
            //------end code------------------------
            
            redirect('events');
        }
        $data['eventdetails'] = $this->App->getPerticularRecord('tbl_events', 'Slug', $slug);        
         $data["listtypeevent"] = $this->App->passwordChecking('tbl_event_type','ClubId', 'Status',$id, '1');
        $this->load->view('front/include/header');
        $this->load->view('front/events/editevents', $data);
        $this->load->view('front/include/footer');
    }
    
    
     public function addeventtype()
    {
        
        $this->form_validation->set_rules('eventtitle', 'Title', 'required');
        $this->form_validation->set_rules('description', 'Description', 'required');
        $this->form_validation->set_rules('price', 'Price', 'required');
        $this->form_validation->set_rules('notickets', 'No. of tickets', 'required');
        
        
        $id = $this->session->userdata['vendorauth']['Id'];
        if($_POST){
			$eventtitle = $this->input->post('eventtitle');
			$result = $this->App->passwordChecking('tbl_event_type','ClubId','Title',$id,$eventtitle);
			if(!empty($result)){
			    $err ='Event Type already Exist.';	
			}			
		}
        
        if ($this->form_validation->run() == FALSE || $err!='') {
            if (validation_errors() != '' || $err!='') {
                $data['error'] = validation_errors().$err;
                
                 $id = $this->session->userdata['vendorauth']['Id'];
				 $data["listcategory"] = $this->App->getPerticularRecord('tbl_events', 'ClubId', $id);
				 $this->load->view('front/events/listevent', $data);
            }
        } else {
            $id = $this->session->userdata['vendorauth']['Id'];
           
            
            $clbname = $this->input->post('eventtitle');
           
            $arr = array(
                'ClubId' => $id,
                'Title' => $this->input->post('eventtitle'),
                'ShortDescription' => $this->input->post('description'),
                'Status' => '1',
                'Amount' => $this->input->post('price'),
                'Created' => date('Y-m-d'),
                'NoofTickets' => $this->input->post('notickets'),
            );
            $iid = $this->App->insertdata('tbl_event_type', $arr);
            redirect('events/types');
             $id = $this->session->userdata['vendorauth']['Id'];
			$data["listcategory"] = $this->App->getPerticularRecord('tbl_event_type', 'ClubId', $id);
			$this->load->view('front/events/listeventtype', $data);
        }
    }
    public function editeventtype($id)
    {
		 $this->form_validation->set_rules('eventtitle', 'Title', 'required');
        $this->form_validation->set_rules('description', 'Description', 'required');
        $this->form_validation->set_rules('price', 'Price', 'required');
         $this->form_validation->set_rules('notickets', 'No. of  tickets', 'required');
        $vid = $this->session->userdata['vendorauth']['Id'];
        
        
        if($_POST){
            $currentdt = date('Y-m-d');
            $fromdate=$this->input->post('fromdate');
			$todate=$this->input->post('todate');
			$specialdate=$this->input->post('specialdate');

			$eventtitle = $this->input->post('eventtitle');
			$result = $this->App->passwordChecking('tbl_event_type','ClubId','Title',$vid,$eventtitle);
			$re= $this->db->query("select * from tbl_event_type where ClubId ='".$vid."' and Title='".$eventtitle."' and Id<>'".$id."'");
			$rse = $re->num_rows();
			if($rse > 0){
			    $err ='Event Type already Exist.';	
			}	
        }
        
        if ($this->form_validation->run() == FALSE || $err!='' ) {
            if (validation_errors() != '' || $err!='') {
                $data['error'] = validation_errors().$err;
                
            }
        } else {            
            $clbname = $this->input->post('eventtitle');
            
             $arr = array(
                'ClubId' => $vid,
                'Title' => $this->input->post('eventtitle'),
                'ShortDescription' => $this->input->post('description'),
                'Status' => $this->input->post('status'),
                'Amount' => $this->input->post('price'),
                'Created' => date('Y-m-d'),
                'NoofTickets' => $this->input->post('notickets'),
            );
            $iid = $this->App->update('tbl_event_type', 'Id', $id, $arr);
            redirect('events/types');
        }
        $data['eventdetails'] = $this->App->getPerticularRecord('tbl_event_type', 'Id', $id);
        $this->load->view('front/include/header');
        $this->load->view('front/events/editeventstype', $data);
        $this->load->view('front/include/footer');
	}
	public function deleteeventtype()
	{
	 $this->App->checkVendorAuthenticate();
        $id = $this->input->post('id');
	        $this->App->deletedata('tbl_event_type', 'Id', $id);
        return 1;	
	}
	public function book($vendorid,$evnetid,$typeid)
	{
		
		$vendoridss=$this->session->userdata['vendorauth']['Id'];  
		if($vendoridss!=''){
			$this->session->unset_userdata('vendorauth');  
			$arr = array(
				'clubid'=>$vendorid,
				'typeid'=>$typeid,
				'evnetid'=>$evnetid,
			);
			$this->session->set_userdata('bookevent', $arr);
			redirect('sign-in'); 
		}
		
		$customerid=$this->session->userdata['customerauth']['Id'];  
		if($customerid!=''){
			$data['text_credit_card'] = "Credit Card Details";
			$data['text_start_date'] = "Start Date";
			$data['text_wait'] = "Please wait!";
			$data['text_loading'] = "Loading";

			$data['entry_cc_type'] = "Card Type";
			$data['entry_cc_number'] = "Card Number";
			$data['entry_cc_start_date'] = "Card Valid From Date";
			$data['entry_cc_expire_date'] = "Card Expiry Date";
			$data['entry_cc_cvv2'] = "Card Security Code (CVV2)";
			$data['entry_cc_issue'] = "Card Issue Number";

			$data['help_start_date'] = "(if available)";
			$data['help_issue'] = "(for Maestro and Solo cards only)";

			$data['button_confirm'] = 'button_confirm';

			$data['cards'] = array();

			$data['cards'][] = array(
				'text'  => 'Visa', 
				'value' => 'VISA'
			);

			$data['cards'][] = array(
				'text'  => 'MasterCard', 
				'value' => 'MASTERCARD'
			);

			$data['cards'][] = array(
				'text'  => 'Discover Card', 
				'value' => 'DISCOVER'
			);

			$data['cards'][] = array(
				'text'  => 'American Express', 
				'value' => 'AMEX'
			);

			$data['cards'][] = array(
				'text'  => 'Maestro', 
				'value' => 'SWITCH'
			);

			$data['cards'][] = array(
				'text'  => 'Solo', 
				'value' => 'SOLO'
			);		

			$data['months'] = array();

			for ($i = 1; $i <= 12; $i++) {
				$data['months'][] = array(
					'text'  => strftime('%B', mktime(0, 0, 0, $i, 1, 2000)), 
					'value' => sprintf('%02d', $i)
				);
			}

			$today = getdate();

			$data['year_valid'] = array();

			for ($i = $today['year'] - 10; $i < $today['year'] + 1; $i++) {	
				$data['year_valid'][] = array(
					'text'  => strftime('%Y', mktime(0, 0, 0, 1, 1, $i)), 
					'value' => strftime('%Y', mktime(0, 0, 0, 1, 1, $i))
				);
			}

			$data['year_expire'] = array();

			for ($i = $today['year']; $i < $today['year'] + 11; $i++) {
				$data['year_expire'][] = array(
					'text'  => strftime('%Y', mktime(0, 0, 0, 1, 1, $i)),
					'value' => strftime('%Y', mktime(0, 0, 0, 1, 1, $i)) 
				);
			} 
			$data['vendorid'] = $vendorid;
			$data['typeid'] = $typeid;
			$data['evnetid'] = $evnetid;
			
			$this->load->view('front/include/header');
			$this->load->view('front/events/checkout', $data);
			$this->load->view('front/include/footer');
		}else{
			$arr = array(
					'clubid'=>$vendorid,
				'typeid'=>$typeid,
				'evnetid'=>$evnetid,
			);
			$this->session->set_userdata('bookevent', $arr);
			redirect('sign-in');
		}
	    
	}
		public function sendrecurring() {
			//print_r($_POST);die;
            $customerId = $this->session->userdata['customerauth']['Id'];
            $vendorid = $this->input->post('vendorid');
            $typeid = $this->input->post('typeid');
            $evnetid = $this->input->post('evnetid');
            $defaultamt = $this->input->post('defaultamt');
            $totamt = $this->input->post('totamt');
            
            $qty =$totamt / $defaultamt;
            
            if($totamt!=''){
			    $payamt = $totamt;
			}else{
				$payamt = $defaultamt;
			}
			
			if($_POST)
			{
				$r = $this->db->query("select * from tbl_event_ticket_update where ClubId='".$vendorid."' and EventId='".$evnetid."' and EventTypeId='".$typeid."'");
				$noresult = $r->result_array();
				$tottic = $noresult[0]['NoofTicket'];
				$UsedTicket = $noresult[0]['UsedTicket'];
				$availableticket =  $tottic-$UsedTicket;
				if($availableticket > 0){
					$ava = $availableticket;
				}else {
					$ava = '0';
				}
				if($ava > $qty){
				
				   $arr = array(
				   'CustomerId'=> $customerId,
				   'ClubId'=> $vendorid,
				   'EventId'=> $evnetid,
				   'EventType'=> $typeid,
				   'Amount'=> $payamt,
				   'Comment'=> '',
				   'Created'=> date('Y-m-d'),
				   'Status'=> '0'
				   );	
				   $inserdid = $this->App->insertdata('tbl_ticket_purches',$arr);
			   }else{
				    $json['error'] = 'Tickets not available in submitted quantity.';
					$json['err'] = '2';
					echo json_encode($json);
					exit;
				   }
			}
			
            
           ini_set('max_execution_time', 0); 
           ini_set('memory_limit','2048M');
           $payment_type = 'Sale';

           $this->load->model('Paypalpro');

           $order_info = $this->Paypalpro->getOrderCustomer($inserdid);
           $paypalset=$this->App->getRecord('tbl_paypal_setting');
           $request  = 'METHOD=DoDirectPayment';
           $request .= '&VERSION=51.0';
           $request .= '&USER=' . urlencode($paypalset[0]['UserName']);
           $request .= '&PWD=' . urlencode($paypalset[0]['Password']);
           $request .= '&SIGNATURE=' . urlencode($paypalset[0]['Signature']);
           $request .= '&CUSTREF=' . '1';
           $request .= '&PAYMENTACTION=' . $payment_type;
           $request .= '&AMT='.$payamt;
           $request .= '&CREDITCARDTYPE=' . $this->input->post('cc_type');
           $request .= '&ACCT=' . urlencode(str_replace(' ', '', $this->input->post('cc_number')));
           $request .= '&CARDSTART=' . urlencode($this->input->post('cc_start_date_month') . $this->input->post('cc_start_date_year'));
           $request .= '&EXPDATE=' . urlencode($this->input->post('cc_expire_date_month') . $this->input->post('cc_expire_date_year'));
           $request .= '&CVV2=' . urlencode($this->input->post('cc_cvv2'));

           if ($this->input->post('cc_type') == 'SWITCH' || $this->input->post('cc_type') == 'SOLO') {
                   $request .= '&ISSUENUMBER=' . urlencode($this->input->post('cc_issue'));
           }

           $request .= '&FIRSTNAME=' . urlencode($order_info['payment_firstname']);
           $request .= '&LASTNAME=' . urlencode($order_info['payment_lastname']);
           $request .= '&EMAIL=' . urlencode($order_info['email']);
           $request .= '&PHONENUM=' . urlencode($order_info['telephone']);
           $request .= '&IPADDRESS=' . urlencode($this->input->server['REMOTE_ADDR']);
           $request .= '&STREET=' . urlencode($order_info['payment_address_1']);
           $request .= '&CITY=' . urlencode($order_info['payment_city']);
           $request .= '&STATE=' . urlencode(($order_info['payment_iso_code_2'] != 'US') ? $order_info['payment_zone'] : $order_info['payment_zone_code']);
           $request .= '&ZIP=' . urlencode($order_info['payment_postcode']);
           $request .= '&COUNTRYCODE=' . urlencode($order_info['payment_iso_code_2']);
           $request .= '&CURRENCYCODE=' . urlencode($order_info['currency_code']);
           $request .= '&BUTTONSOURCE=' . urlencode('OpenCart_2.0_WPP');

           $request .= '&SHIPTONAME=' . urlencode($order_info['payment_firstname'] . ' ' . $order_info['payment_lastname']);
                   $request .= '&SHIPTOSTREET=' . urlencode($order_info['payment_address_1']);
                   $request .= '&SHIPTOCITY=' . urlencode($order_info['payment_city']);
                   $request .= '&SHIPTOSTATE=' . urlencode(($order_info['payment_iso_code_2'] != 'US') ? $order_info['payment_zone'] : $order_info['payment_zone_code']);
                   $request .= '&SHIPTOCOUNTRYCODE=' . urlencode($order_info['payment_iso_code_2']);
                   $request .= '&SHIPTOZIP= 390019';
					$expresspaypal =$this->config->item('expresspaypal');

           $curl = curl_init($expresspaypal);


           curl_setopt($curl, CURLOPT_PORT, 443);
           curl_setopt($curl, CURLOPT_HEADER, 0);
           curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
           curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
           curl_setopt($curl, CURLOPT_FORBID_REUSE, 1);
           curl_setopt($curl, CURLOPT_FRESH_CONNECT, 1);
           curl_setopt($curl, CURLOPT_POST, 1);
           curl_setopt($curl, CURLOPT_POSTFIELDS, $request);

           $response = curl_exec($curl);

           curl_close($curl);

           if (!$response) {
                   $this->log->write('DoDirectPayment failed: ' . curl_error($curl) . '(' . curl_errno($curl) . ')');
           }


           $response_info = array();

           parse_str($response, $response_info);

           $json = array();

           if (($response_info['ACK'] == 'Success') || ($response_info['ACK'] == 'SuccessWithWarning')) {

                $message = '';

                if (isset($response_info['AVSCODE'])) {
                        $message .= 'AVSCODE: ' . $response_info['AVSCODE'] . "\n";
                }
                if (isset($response_info['CVV2MATCH'])) {
                        $message .= 'CVV2MATCH: ' . $response_info['CVV2MATCH'] . "\n";
                }
                if (isset($response_info['TRANSACTIONID'])) {
                        $message .= 'TRANSACTIONID: ' . $response_info['TRANSACTIONID'] . "\n";
                }
                $this->Paypalpro->addOrderHistoryCustomer($inserdid, $inserdid, $message, false);
                    $recurring_products=array('1,1');
                    if(!empty($recurring_products)) {
                            $billing_period = array(
                                    'day' => 'Day',
                                    'week' => 'Week',
                                    'semi_month' => 'SemiMonth',
                                    'month' => 'Month',
                                    'year' => 'Year'
                            );

			$paypalset=$this->App->getRecord('tbl_paypal_setting');
			$card_config['card_recurring']='1';
			if($card_config['card_recurring']=='1') {

                        $request  = 'METHOD=CreateRecurringPaymentsProfile';
                        $request .= '&VERSION=51.0';
                        $request .= '&USER=' . urlencode($paypalset[0]['UserName']);
                        $request .= '&PWD=' . urlencode($paypalset[0]['Password']);
                        $request .= '&SIGNATURE=' . urlencode($paypalset[0]['Signature']);
                        $request .= '&CUSTREF=' . (int)$vId;
                        $request .= '&PAYMENTACTION=' . $payment_type;
                        #$request .= '&AMT=' . $this->currency->format($order_info['total'], $order_info['currency_code'], false, false);
                        $request .= '&CREDITCARDTYPE=' . $this->input->post('cc_type');
                        $request .= '&ACCT=' . urlencode(str_replace(' ', '', $this->input->post('cc_number')));
                        $request .= '&CARDSTART=' . urlencode($this->input->post('cc_start_date_month') . $this->input->post('cc_start_date_year'));
                        $request .= '&EXPDATE=' . urlencode($this->input->post('cc_expire_date_month') . $this->input->post('cc_expire_date_year'));
                        $request .= '&CVV2=' . urlencode($this->input->post('cc_cvv2'));

                        if ($this->input->post('cc_type') == 'SWITCH' || $this->input->post('cc_type') == 'SOLO') { 
                                $request .= '&CARDISSUE=' . urlencode($this->input->post('cc_issue'));
                        }

                        $request .= '&FIRSTNAME=' . urlencode($order_info['payment_firstname']);
                        $request .= '&LASTNAME=' . urlencode($order_info['payment_lastname']);
                        $request .= '&EMAIL=' . urlencode($order_info['email']);
                        $request .= '&PHONENUM=' . urlencode($order_info['telephone']);
                        $request .= '&IPADDRESS=' . urlencode($this->input->server('REMOTE_ADDR'));
                        $request .= '&STREET=' . urlencode($order_info['payment_address_1']);
                        $request .= '&CITY=' . urlencode($order_info['payment_city']);
                        $request .= '&STATE=' . urlencode(($order_info['payment_iso_code_2'] != 'US') ? $order_info['payment_zone'] : $order_info['payment_zone_code']);
                        $request .= '&ZIP=' . urlencode($order_info['payment_postcode']);
                        $request .= '&COUNTRYCODE=' . urlencode($order_info['payment_iso_code_2']);
                        $request .= '&CURRENCYCODE=' . urlencode($order_info['currency_code']);

                        $request .= '&BUTTONSOURCE=' . urlencode('WebWizard_SP');
							
                        $request .= '&SHIPTONAME=' . urlencode($order_info['payment_firstname'] . ' ' . $order_info['payment_lastname']);
                        $request .= '&SHIPTOSTREET=' . urlencode($order_info['payment_address_1']);
                        $request .= '&SHIPTOCITY=' . urlencode($order_info['payment_city']);
                        $request .= '&SHIPTOSTATE=' . urlencode(($order_info['payment_iso_code_2'] != 'US') ? $order_info['payment_zone'] : $order_info['payment_zone_code']);
                        $request .= '&SHIPTOCOUNTRYCODE=' . urlencode($order_info['payment_iso_code_2']);
                        $request .= '&SHIPTOZIP=390019';			


                        $request .= '&PROFILESTARTDATE=' . gmdate("Y-m-d\TH:i:s\Z", mktime(gmdate("H"), gmdate("i")+5, gmdate("s"), gmdate("m"), gmdate("d"), gmdate("y")));
                        $request .= '&BILLINGPERIOD=Year';
                        $request .= '&BILLINGFREQUENCY='.$item['recurring_trial_frequency'];
                        $request .= '&TOTALBILLINGCYCLES='.$item['recurring_trial_cycle'];
                        $request .= '&AMT='.$paypalset[0]['Amt'];
                        $request .= '&CURRENCYCODE='.$paypalset[0]['CurrencyCode']; 
                        ##description
                        #$description = 'BILLINGPERIOD-'.$billing_period[$item['recurring_frequency']].'BILLINGFREQUENCY-'.$item['recurring_cycle'];
                        $descc = 'Tablefast.com Payment ';

                        $description = urlencode($descc);

                        $request .= '&DESC='.$description;


                //trial information
                //if($item['recurring_trial'] == 1) {

                        $request .= '&TRIALBILLINGPERIOD=' . $billing_period[$item['recurring_trial_frequency']];
                        $request .= '&TRIALBILLINGFREQUENCY=' . $item['recurring_trial_cycle'];
                        $request .= '&TRIALTOTALBILLINGCYCLES=' . $item['recurring_trial_duration'];
                        $request .= '&TRIALAMT='.$paypalset[0]['Amt'];

						//} 
						$expresspaypal =$this->config->item('expresspaypal');
                        $curl = curl_init($expresspaypal);
						$testpp = 0;
						curl_setopt($curl, CURLOPT_PORT, 443);
						curl_setopt($curl, CURLOPT_HEADER, 0);
						curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
						curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
						curl_setopt($curl, CURLOPT_FORBID_REUSE, 1);
						curl_setopt($curl, CURLOPT_FRESH_CONNECT, 1);
						curl_setopt($curl, CURLOPT_POST, 1);
						curl_setopt($curl, CURLOPT_POSTFIELDS, $request);

						$response = curl_exec($curl);

						curl_close($curl);

						if (!$response) {
								$json['error']='failed';	}

						$response_info2 = array();

						parse_str($response, $response_info2);


						if (($response_info2['ACK'] == 'Success') || ($response_info2['ACK'] == 'SuccessWithWarning')) {

						$recurring_id = $this->db->getLastId();

						$ref = $response_info2['PROFILEID'];

						$message = '';

						if (isset($response_info['AVSCODE'])) {
							$message .= 'AVSCODE: ' . $response_info['AVSCODE'] . "\n";
						}

						if (isset($response_info['CVV2MATCH'])) {
							$message .= 'CVV2MATCH: ' . $response_info['CVV2MATCH'] . "\n";
						}

						if (isset($response_info['TRANSACTIONID'])) {
							$message .= 'TRANSACTIONID: ' . $response_info['TRANSACTIONID'] . "\n";
						}
						$this->Paypalpro->addOrderHistoryCustomer($inserdid, $inserdid, $message, false);
		
						}
						
					}
				}
            $json['success'] = $inserdid;
			$json['succ'] = '1';

		} else {
			$json['error'] = $response_info['L_LONGMESSAGE0'];
			$json['err'] = '2';
		}
		echo json_encode($json);
	} 
	public function successPayment($id)
	{
	    $this->App->checkCustomerAuthenticate();
        $this->load->view('front/include/header');
        $this->load->view('front/events/completeprocess');
        $this->load->view('front/include/footer');
	}
	public function completedtransaction()
    {
		$this->App->checkVendorAuthenticate();
        $id = $this->session->userdata['vendorauth']['Id'];
        $data["listcompleteticket"] = $this->App->getPerticularRecord('tbl_ticket_purches', 'ClubId', $id);
        $this->load->view('front/events/completedtransaction', $data);
	}
	public function pendingtransaction()
    {
		$this->App->checkVendorAuthenticate();
        $id = $this->session->userdata['vendorauth']['Id'];
        $data["listcompleteticket"] = $this->App->getPerticularRecord('tbl_ticket_purches', 'ClubId', $id);
        $this->load->view('front/events/pendingtransaction', $data);
	}
    public function viewticketsevent($slug)
    {
		$this->App->checkVendorAuthenticate();
        $id = $this->session->userdata['vendorauth']['Id'];
        $eventdetails = $this->App->getPerticularRecord('tbl_events', 'Slug', $slug);   
        $eventid = $eventdetails[0]['Id'];   
         
         
        $data["listcompleteticket"] = $this->App->passwordChecking('tbl_event_ticket_update','ClubId','EventId', $id,$eventid);
       
        $this->load->view('front/events/listticketevent', $data);
	}
    
    
    
    
}
