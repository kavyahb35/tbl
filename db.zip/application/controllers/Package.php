<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Package extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->helper('new_helper');
        $this->load->library('form_validation');
        $this->load->library('email');
        $this->load->library('session');
        $this->load->library('pagination');
        $this->load->helper('url');
    }
    
    public function combolist()
    {
        $this->App->checkVendorAuthenticate();
        $id                   = $this->session->userdata['vendorauth']['Id'];
        $data["listpackage"] = $this->App->getPerticularRecord('tbl_packages', 'ClubId', $id);
        $this->load->view('front/package/listpackage', $data);
    }
    public function addpackage()
    {
		
		$this->App->checkVendorAuthenticate();
        $id = $this->session->userdata['vendorauth']['Id'];
         $this->form_validation->set_rules('eventtitle', 'Package name', 'required');
        $this->form_validation->set_rules('description', 'Facilities', 'required');
        $this->form_validation->set_rules('item[]', 'Item', 'required');
        $this->form_validation->set_rules('price', 'Price', 'required');
        
         if ($this->form_validation->run() == FALSE || $err !=''|| $err1 !=''|| $err2 !='') {
            if (validation_errors() != '' || $err !=''|| $err1 !=''|| $err2 !='') {
                $data['error'] = validation_errors().$err.$err1.$err2;
                $data['title']=$this->input->post('eventtitle');

$data['description']=$this->input->post('description');
                
            }
        } else {
			if (!empty($_FILES['uploadsfl']['name'])) {
                $config['upload_path']   = 'assets/package/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['file_name']     = $_FILES['uploadsfl']['name'];

                $this->load->library('upload', $config);
                $this->upload->initialize($config);

                if ($this->upload->do_upload('uploadsfl')) {
                    $uploadData = $this->upload->data();
                    $picture = $uploadData['file_name'];
                }
            }
             $arr = array(
                'ClubId' => $id,
                'Title' => $this->input->post('eventtitle'),
                'ShortDetails' => $this->input->post('description'),
                'ActPrice' => $this->input->post('price'),
                'Image' => $picture,
                'Status'=>$this->input->post('status'),
                'Created' => date('Y-m-d'),
            );
            //print_r($arr);die;
            $iid = $this->App->insertdata('tbl_packages', $arr);
            $count=count($this->input->post('item'));
            $item=$this->input->post('item');
            $tot='0';
            for($i=0;$i<$count;$i++){
				
				$itemdet = $this->App->getPerticularRecord('tbl_fooditem', 'Id', $item[$i]);
				$price=$itemdet[0]['Price'];
				$CategoryId=$itemdet[0]['CategoryId'];
				$tot=$tot+$price;
				$arry=array(
				'PackageId'=>$iid,
				'CategoryId'=>$CategoryId,
				'ItemId'=>$item[$i],
				'Price'=>$price,
				'Status'=>'1',
				'Created'=>date('Y-m-d'),
				);
				
					$this->App->insertdata('tbl_packageitem',$arry);
				}
				$pricepack=array('Price'=>$tot);
				$this->App->update('tbl_packages','Id',$iid,$pricepack);
				
			redirect('package/combolist');
		}
        
        
        $data["listcategory"] = $this->App->passwordChecking('tbl_foodcategory', 'ClubId','Status', $id,'1');
        	
        $data['vid']=$id;
        $this->load->view('front/include/header');
		$this->load->view('front/package/addpackage', $data);
        $this->load->view('front/include/footer');
	}
	
	
	public function editpackage($pid='')
    {
		$data['pid']=$pid;
		$this->App->checkVendorAuthenticate();
        $id = $this->session->userdata['vendorauth']['Id'];
         $this->form_validation->set_rules('eventtitle', 'Title', 'required');
        $this->form_validation->set_rules('description', 'Description', 'required');
        $this->form_validation->set_rules('item[]', 'Item', 'required');
//        $this->form_validation->set_rules('price', 'Price', 'required');
        
         if ($this->form_validation->run() == FALSE || $err !=''|| $err1 !=''|| $err2 !='') {
            if (validation_errors() != '' || $err !=''|| $err1 !=''|| $err2 !='') {
                $data['error'] = validation_errors().$err.$err1.$err2;
                
                
            }
        } else {
			if (!empty($_FILES['uploadsfl']['name'])) {
                $config['upload_path']   = 'assets/package/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['file_name']     = $_FILES['uploadsfl']['name'];

                $this->load->library('upload', $config);
                $this->upload->initialize($config);

                if ($this->upload->do_upload('uploadsfl')) {
                    $uploadData = $this->upload->data();
                    $picture = $uploadData['file_name'];
                }
            }else{
				$picture = $this->input->post('oldimg');
				}
             $arr = array(
                'ClubId' => $id,
                'Title' => $this->input->post('eventtitle'),
                'ShortDetails' => $this->input->post('description'),
                'ActPrice' => $this->input->post('price'),
                'Image' => $picture,
                'Status'=>$this->input->post('status'),
                'Created' => date('Y-m-d'),
            );
            $this->App->update('tbl_packages','Id',$pid,$arr);
            $count=count($this->input->post('item'));
            $item=$this->input->post('item');
            $tot='0';
            
            if($count > 0){
				 $this->App->deletedata('tbl_packageitem', 'PackageId', $pid);
			}
            for($i=0;$i<$count;$i++){
				
				
				
					$itemdet = $this->App->getPerticularRecord('tbl_fooditem', 'Id', $item[$i]);
					$price=$itemdet[0]['Price'];
					$CategoryId=$itemdet[0]['CategoryId'];
					$tot=$tot+$price;
					$arry=array(
					'PackageId'=>$pid,
					'CategoryId'=>$CategoryId,
					'ItemId'=>$item[$i],
					'Price'=>$price,
					'Status'=>'1',
					'Created'=>date('Y-m-d'),
					);
					
						$this->App->insertdata('tbl_packageitem',$arry);
					
				}
				$pricepack=array('Price'=>$tot);
				$this->App->update('tbl_packages','Id',$pid,$pricepack);
				
			redirect('package/combolist');
		}
        
        
        $data["listcategory"] = $this->App->passwordChecking('tbl_foodcategory', 'ClubId','Status', $id,'1');
        $vid = $this->session->userdata['vendorauth']['Id'];
        $data["packages"] = $this->App->getPerticularRecord('tbl_packages', 'Id',$pid);
		$packitem = $this->App->getPerticularRecord('tbl_packageitem', 'PackageId',$pid);
		if(!empty($packitem)){
			foreach($packitem as $pitem){
				$ipid[]=$pitem['ItemId'];
				
				}
		}
		$data['impitem']=$ipid;
      // print_r($data['impitem']);die;
        $data['pid']=$pid;
        $data['vid']=$id;
        
        $this->load->view('front/include/header');
		$this->load->view('front/package/editpackage', $data);
        $this->load->view('front/include/footer');
	}
	
	
    
    
    public function deletepackage()
    {
        $this->App->checkVendorAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('tbl_packages', 'Id', $id);
        $this->App->deletedata('tbl_packageitem', 'PackageId', $id);
        return 1;
    }
   public function viewpackage($pid='')
    {
		$data['pid']=$pid;
		$this->App->checkVendorAuthenticate();
        $id = $this->session->userdata['vendorauth']['Id'];
       
        
        $data["listcategory"] = $this->App->passwordChecking('tbl_foodcategory', 'ClubId','Status', $id,'1');
        $vid = $this->session->userdata['vendorauth']['Id'];
        $data["packages"] = $this->App->getPerticularRecord('tbl_packages', 'Id',$pid);
		$packitem = $this->App->getPerticularRecord('tbl_packageitem', 'PackageId',$pid);
		if(!empty($packitem)){
			foreach($packitem as $pitem){
				$ipid[]=$pitem['ItemId'];
				
				}
		}
		$data['impitem']=$ipid;
        $data['pid']=$pid;
        $data['vid']=$id;
        
        $this->load->view('front/include/header');
		$this->load->view('front/package/viewpackage', $data);
        $this->load->view('front/include/footer');
	}
	
    
}
