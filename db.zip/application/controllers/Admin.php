<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller
{    
    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->helper('new_helper');
        $this->load->library('form_validation');
        $this->load->library('email');
        $this->load->library('session');
        $this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
    }
    public function index()
    {
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        if ($_POST) {
            $username = $this->input->post('username');
            $password = md5($this->input->post('password'));
            $chkauth  = $this->App->passwordChecking('tbl_admin', 'UserName', 'Password', $username, $password);
            if ($chkauth == '0') {
                $err = 'Username and Password does not match.';
            }            
        }
        if ($this->form_validation->run() == FALSE || $err != '') {
            if (validation_errors() != '' || $err != '') {
                $data['error'] = validation_errors() . $err;
            }
        } else {
            if (!empty($chkauth)) {                
                $arraydata = array(
                    'username' => $chkauth[0]['UserName'],
                    'Id' => $chkauth[0]['Id'],
                    'Email' => $chkauth[0]['Email']
                );                
                $this->session->set_userdata('adminauth', $arraydata);

                 $apro = array(
				'Email'=>$chkauth[0]['Email'],
				'Time'=>date('Y-m-d H:i A'),
				'IP Address'=>$this->input->server('REMOTE_ADDR'),
				
				);
			   $apro=json_encode($apro);
				
				 log_message('admin', "Admin login : ".$apro);

                redirect('admin/dashboard');
            }
        }
        $this->load->view('admin/login', $data);
    }
    public function dashboard()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->session->userdata['adminauth']['Id'];
        $tot = $this->App->getRecord('tbl_vendor');
        $data['totalclub'] = count($tot);        
        $totapprove = $this->App->getPerticularRecord('tbl_vendor', 'Status', '2');
        $data['totalApproved'] = count($totapprove);        
        $totreject = $this->App->getPerticularRecord('tbl_vendor', 'Status', '3');
        $data['totalrejected'] = count($totreject);        
        $tottrash = $this->App->getPerticularRecord('tbl_vendor', 'Status', '4');
        $data['totaltrash'] = count($tottrash);        
        $totdraft = $this->App->getPerticularRecord('tbl_vendor', 'Status', '0');
        $data['totaldraft'] = count($totdraft);
        $totPending = $this->App->getPerticularRecord('tbl_vendor', 'Status', '1');
        $data['totalPending'] = count($totPending);
        
        
        $data['approvedclub'] = $this->App->getRecordByLimit('tbl_vendor','Status','2','0','5');
        $data['Pendingclub'] = $this->App->getRecordByLimit('tbl_vendor','Status','3','0','5');
        
        
        $totcustomer = $this->App->getPerticularRecord('tbl_customer', 'Status', '1');
        $data['totalcustomer'] = count($totcustomer);
        $totbooking = $this->App->getRecord('tbl_booking');
        $data['totalbooking'] = count($totbooking);
        $totcontact = $this->App->getRecord('tbl_contact');
        $data['totalcontact'] = count($totcontact);
        $totreviews = $this->App->getRecord('tbl_reviews');
        $data['totalreviews'] = count($totreviews);
        $totnewsletter = $this->App->getRecord('tbl_newsletter', 'Status', '1');
        $data['totalnewsletter'] = count($totnewsletter);
        
        $this->load->view('admin/dashboard', $data);        
    }
    public function profile()
    {
        $this->App->checkAdminAuthenticate();
        $this->form_validation->set_rules('Username', 'Username', 'required');
        $this->form_validation->set_rules('Email', 'Email', 'required|valid_email');
        
        if ($this->form_validation->run() == FALSE || $err != '') {
            if (validation_errors() != '' || $err != '') {
                $data['error'] = validation_errors() . $err;
            }
        } else {
            $password = $this->input->post('password');
            if ($password != '') {
                $arr = array(
                    'UserName' => $this->input->post('Username'),
                    'Email' => $this->input->post('Email'),
                    'Password' => md5($this->input->post('password'))
                );
            } else {
                $arr = array(
                    'UserName' => $this->input->post('Username'),
                    'Email' => $this->input->post('Email')
                );
            }
            $id = $this->session->userdata['adminauth']['Id'];
            $this->App->update('tbl_admin', 'Id', $id, $arr);
            $data['success'] = 'Change Profile Successfully.';
        }
        $id = $this->session->userdata['adminauth']['Id'];
        $data['admindetails'] = $this->App->getPerticularRecord('tbl_admin', 'Id', $id);
        $this->load->view('admin/profile', $data);
    }
    public function logout()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->session->userdata['adminauth']['Email'];
       
         
        $apro = array(
                'Email'=>$id,
                'Time'=>date('Y-m-d H:i A'),
                'IP Address'=>$this->input->server('REMOTE_ADDR'),				
                );
            $apro=json_encode($apro);

            log_message('admin', "Admin Logout : ".$apro);
        $this->session->unset_userdata('adminauth');
        redirect('admin');
    }
    public function listClub()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->session->userdata['adminauth']['Id'];
        $data['listvendor'] = $this->App->getRecord('tbl_vendor');
        $this->load->view('admin/club/listclub', $data);
    }
    public function approveClub()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
     
        $clubdetail = $this->App->getPerticularRecord('tbl_vendor', 'Id', $id);
        $name = $clubdetail[0]['FirstName'] . ' ' . $clubdetail[0]['LastName'];
        $email = $clubdetail[0]['Email'];
        $clubname = $clubdetail[0]['ClubName'];
        $phone = '91'.$clubdetail[0]['Phone'];
        
        $sms="Congratulations! Your ".$clubname." is Approved. You just signed your Accommodation Agreement with Tablefast.com. , Please check your email and reset password for login.";
        $otp=rand('4531','5356');
        $arr=array('State'=>$otp);
        $this->App->update('tbl_vendor', 'Id', $id, $arr);
        $url = base_url('vendor/resetpassword/' . $id.'/'.$otp);
        $dataemail = array(
			'username'=>$name,
			'url'=>$url
        );
        $message = $this->load->view('email/club_approved', $dataemail, TRUE);
        
        $from_email = $this->config->item('constantEmail');
        $to_email = $email;
        
			$headers = "MIME-Version: 1.0" . "\r\n";
			$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
			$headers .= "From: ".$from_email;
			$to=$to_email;
			$subject = "Thank you for partnering with Tablefast.com";
			$mail=mail($to,$subject,$message,$headers);
        
        $arr = array(
            'Status' => '2'
        );
        $this->App->update('tbl_vendor', 'Id', $id, $arr);
      
        return 1;
    }
    public function rejectClub()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
        $arr = array(
            'Status' => '3'
        );
        $clubdetail = $this->App->getPerticularRecord('tbl_vendor', 'Id', $id);
        $name = $clubdetail[0]['FirstName'] . ' ' . $clubdetail[0]['LastName'];
        $email = $clubdetail[0]['Email'];
        $phone = '91'.$clubdetail[0]['Phone'];
         $clubname = $clubdetail[0]['ClubName'];
        
        $url = base_url('vendor/resetpassword/' . $id);
          $dataemail = array(
			'username'=>$name,
			'clubname'=>$clubname
        );
        $message = $this->load->view('email/club_rejected', $dataemail, TRUE);
           
        
        $from_email = $this->config->item('constantEmail');
        $to_email = $email;
        
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: ".$from_email;						
        $to=$to_email;
        $subject = "Reject your Club Application by tablefast.com";
        mail($to,$subject,$message,$headers);
        
        $this->App->update('tbl_vendor', 'Id', $id, $arr);
        
        return 1;
    }
    public function trashClub()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
        $arr = array(
            'Status' => '4'
        );
        $this->App->update('tbl_vendor', 'Id', $id, $arr);
        return 1;
    }
   public function deletegallery($id)
    {
       
        if ($id != '') {
            $this->App->deletedata('tbl_clubgallery', 'Id', $id);
            echo json_encode('1');
        }
        echo json_encode('1');
    }
    public function deleteClub()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('tbl_vendor', 'Id', $id);
        $this->App->deletedata('tbl_foodcategory', 'ClubId', $id);
        $this->App->deletedata('tbl_fooditem', 'ClubId', $id);
        $this->App->deletedata('tbl_clubgallery', 'VendorId', $id);
        $this->App->deletedata('tbl_clublayout', 'VendorId', $id);
         $this->App->deletedata('tbl_events', 'ClubId', $id);
          $this->App->deletedata('tbl_facility', 'ClubId', $id);
        return 1;
    }
    public function trashClubList()
    {
        $this->App->checkAdminAuthenticate();
        $th=$this->db->query("select * from tbl_vendor where Status='4' or Status='0'");
        $data['listvendor'] = $th->result_array();
        $this->load->view('admin/club/trashclublist', $data);
    }
    public function viewclub($id = '')
    {
        $this->App->checkAdminAuthenticate();
        $data['clubidget'] = $id;
        $data['vendordetails'] = $this->App->getPerticularRecord('tbl_vendor', 'Id', $id);
        $this->load->view('admin/club/viewclub', $data);
    }
    public function listcategory()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->session->userdata['adminauth']['Id'];
        $data['listcategory'] = $this->App->getRecord('tbl_foodcategory');
        $this->load->view('admin/club/listfoodcategory', $data);
    }
    public function listcategoryitem()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->session->userdata['adminauth']['Id'];
        $data['listcategory'] = $this->App->getRecord('tbl_fooditem');
        $this->load->view('admin/club/listfooditem', $data);
    }
    public function deletecategory()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('tbl_foodcategory', 'Id', $id);
        $this->App->deletedata('tbl_fooditem', 'CategoryId', $id);
        return 1;
    }
    public function deletecategoryitem()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('tbl_fooditem', 'Id', $id);
        return 1;
    }
    public function eventdetail($slug)
    {
        $this->App->checkAdminAuthenticate();
        $data['eventdetails'] = $this->App->getPerticularRecord('tbl_events', 'Slug', $slug);
        $this->load->view('admin/club/viewevent', $data);
    }
    public function deleteevent()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('tbl_events', 'Id', $id);
        return 1;
    }
    public function listevents()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->session->userdata['adminauth']['Id'];
        $data['listevents'] = $this->App->getRecord('tbl_events');
        $this->load->view('admin/club/listevents', $data);
    }
    public function listcontact()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->session->userdata['adminauth']['Id'];
        $data['listcontact'] = $this->App->getRecord('tbl_contact');
        $this->load->view('admin/listcontacts', $data);
    }
    public function deletecontact()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('tbl_contact', 'Id', $id);
        return 1;
    }
    public function listnewsletter()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->session->userdata['adminauth']['Id'];
        $data['listnewsletter'] = $this->App->getRecord('tbl_newsletter');
        $this->load->view('admin/listnewsletter', $data);
    }
    public function deletenewsletter()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('tbl_newsletter', 'Id', $id);
        return 1;
    }
    public function listcustomer()
    {
        $this->App->checkAdminAuthenticate();
        $data['activecustomer']=$this->App->getPerticularRecord('tbl_customer','Status','1');
        $this->load->view('admin/club/listcustomer', $data);
        
    }
    public function inactivecustomer()
    {
        $this->App->checkAdminAuthenticate();
        $data['activecustomer']=$this->App->getPerticularRecord('tbl_customer','Status','0');
        $this->load->view('admin/club/listinactivecustomer', $data);
    }
    public function booking($id='')
    {
        $dates=$this->input->post('reservation');
        $o=explode('-', $dates);
        $fromt=$o[0];
        $to=$o[1];
        $fromdate = date('Y-m-d', strtotime($fromt));
        $todate = date('Y-m-d', strtotime($to));
        $clubs=$this->input->post('clubs');
        $bookingstatus=$this->input->post('bookingstatus');
            
        $this->App->checkAdminAuthenticate();
            if($_POST){               
                if($clubs!='' && $bookingstatus!='')
                {   $data['clubi']=$clubs;
                    $data['bookingstatus']=$bookingstatus;
                    $re=$this->db->query("select * from tbl_booking where CustomerId='".$id."' and ClubId='".$clubs."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingStatus='".$bookingstatus."'");
                    $data['bookingrecord']=$re->result_array();   
                }
                else if($clubs!='' && $bookingstatus=='')
                {   $data['clubi']=$clubs;
                    $re=$this->db->query("select * from tbl_booking where CustomerId='".$id."' and ClubId='".$clubs."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."'");                    
                    $data['bookingrecord']=$re->result_array();   
                }
                else if($clubs=='' && $bookingstatus!='')
                {
                    $data['bookingstatus']=$bookingstatus;
                    $re=$this->db->query("select * from tbl_booking where CustomerId='".$id."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingStatus='".$bookingstatus."'");
                    $data['bookingrecord']=$re->result_array();   
                }
                else if($clubs=='' && $bookingstatus=='')
                {
                    $re=$this->db->query("select * from tbl_booking where CustomerId='".$id."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' ");
                    $data['bookingrecord']=$re->result_array();   
                }
                else{
                    $data['bookingrecord']=$this->App->getPerticularRecord('tbl_booking','CustomerId',$id);
                }                
            }
            else {
            $data['bookingrecord']=$this->App->getPerticularRecord('tbl_booking','CustomerId',$id);
            }           
            $data['cid']=$id;
            
        $this->load->view('admin/club/listbooking', $data);        
    }
        
    public function pendingbooking($id)
    {
        $this->App->checkAdminAuthenticate();            
        $data['bookingrecord']=$this->App->getPerticularRecord('tbl_booking','CustomerId',$id);
        $data['cid']=$id;
        $this->load->view('admin/club/listpendingbooking', $data);        
    }
    public function deletecustomer()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('tbl_customer', 'Id', $id);
        return 1;
    }
    public function deletebooking()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('tbl_booking', 'Id', $id);
        return 1;
    }        
    public function perclubbooking($id)
    {
        $dates=$this->input->post('reservation');
        $o=explode('-', $dates);
        $fromt=$o[0];
        $to=$o[1];
        $fromdate = date('Y-m-d', strtotime($fromt));
        $todate = date('Y-m-d', strtotime($to));
            
        $username=$this->input->post('username');
        $phone=$this->input->post('phone');
        $bookingstatus=$this->input->post('bookingstatus');
        $bono=$this->input->post('bookingno');
        $bookingno= str_replace("B00","",$bono);
            
        $this->App->checkAdminAuthenticate();
            if($_POST){
                
                if($username!='' && $phone!='' && $bookingstatus!='' && $bookingno!='')
                {
                    $data['bookingno']='B00'.$bookingno;
                    $data['username']=$username;
                    $data['phone']=$phone;
                    $data['boookingstatus']=$bookingstatus;
                    $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and Phone ='".$phone."' and tbl_BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingStatus='".$bookingstatus."' and BookingNo ='".$bookingno."'");
                    $data['bookingrecord']=$re->result_array(); 
                }
               else if($username!='' && $phone!='' && $bookingstatus!='' && $bookingno=='')
                {
                    $data['username']=$username;
                    $data['phone']=$phone;
                    $data['boookingstatus']=$bookingstatus;
                    $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingStatus='".$bookingstatus."' ");
                    $data['bookingrecord']=$re->result_array();
                }
                else if($username!='' && $phone!='' && $bookingstatus=='' && $bookingno!='')
                {
                    $data['bookingno']='B00'.$bookingno;
                    $data['username']=$username;
                    $data['phone']=$phone;
                    $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."'  and BookingNo ='".$bookingno."'");
                    $data['bookingrecord']=$re->result_array();
                }
                else if($username!='' && $phone!='' && $bookingstatus=='' && $bookingno=='')
                {
                    $data['username']=$username;
                    $data['phone']=$phone;
                    $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."'");
                    $data['bookingrecord']=$re->result_array();
                }
                else if($username!='' && $phone=='' && $bookingstatus!='' && $bookingno!='')
                {
                    $data['bookingno']='B00'.$bookingno;
                    $data['username']=$username;
                    $data['boookingstatus']=$bookingstatus;
                    $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingStatus='".$bookingstatus."' and BookingNo ='".$bookingno."'");
                    $data['bookingrecord']=$re->result_array();
                }
                else if($username!='' && $phone=='' && $bookingstatus!='' && $bookingno=='')
                {
                    $data['username']=$username;
                    $data['boookingstatus']=$bookingstatus;
                    $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingStatus='".$bookingstatus."' ");
                    $data['bookingrecord']=$re->result_array();
                }
                else if($username!='' && $phone=='' && $bookingstatus=='' && $bookingno!='')
                {
                    $data['username']=$username;                    $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
                    $data['bookingrecord']=$re->result_array();
                }
                else if($username!='' && $phone=='' && $bookingstatus=='' && $bookingno=='')
                {
                    $data['username']=$username;
                    $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and  BookingDate BETWEEN '".$fromdate."' AND '".$todate."' ");
                    $data['bookingrecord']=$re->result_array();
                }
                 else if($username=='' && $phone!='' && $bookingstatus!='' && $bookingno!='')
                {
                    $data['bookingno']='B00'.$bookingno;
                    $data['phone']=$phone;
                    $data['boookingstatus']=$bookingstatus;
                    $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingStatus='".$bookingstatus."' and BookingNo ='".$bookingno."'");
                    $data['bookingrecord']=$re->result_array();
                }
                else if($username=='' && $phone!='' && $bookingstatus!='' && $bookingno=='')
                {
                    $data['phone']=$phone;
                    $data['boookingstatus']=$bookingstatus;
                    $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingStatus='".$bookingstatus."' ");
                    $data['bookingrecord']=$re->result_array();
                }
               else if($username=='' && $phone!='' && $bookingstatus=='' && $bookingno!='')
                {
                    $data['bookingno']='B00'.$bookingno;
                    $data['phone']=$phone;
                    $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
                    $data['bookingrecord']=$re->result_array();
                }
                else if($username=='' && $phone!='' && $bookingstatus=='' && $bookingno=='')
                {
                    $data['phone']=$phone;
                    $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."'");
                    $data['bookingrecord']=$re->result_array();
                }
                else if($username=='' && $phone=='' && $bookingstatus!='' && $bookingno!='')
                {
                    $data['bookingno']='B00'.$bookingno;
                    $data['boookingstatus']=$bookingstatus;
                    $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingStatus='".$bookingstatus."' and BookingNo ='".$bookingno."'");
                    $data['bookingrecord']=$re->result_array();
                }
                else if($username=='' && $phone=='' && $bookingstatus!='' && $bookingno=='')
                {
                    $data['boookingstatus']=$bookingstatus;
                    $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingStatus='".$bookingstatus."' ");
                    $data['bookingrecord']=$re->result_array();
                }
                else if($username=='' && $phone=='' && $bookingstatus=='' && $bookingno!='')
                {
                    $data['bookingno']='B00'.$bookingno;
                    $re=$this->db->query("select * from tbl_booking where ClubId='".$id."'  and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
                    $data['bookingrecord']=$re->result_array();
                }
               else if($username=='' && $phone=='' && $bookingstatus=='' && $bookingno=='')
                {
                    
                    $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."'");
                    $data['bookingrecord']=$re->result_array();
                } 
                else{
                  $data['bookingrecord']=$this->App->getPerticularRecord('tbl_booking','ClubId',$id);
              }        
                                
            }
            else {
        $data['bookingrecord']=$this->App->getPerticularRecord('tbl_booking','ClubId',$id);
            }           
                 $data['cid']=$id;            
        $this->load->view('admin/club/ownclub/listbooking', $data);        
    }
        
    public function perclubpendingbooking($id)
    {
        $this->App->checkAdminAuthenticate();  
            
        $dates=$this->input->post('reservation');
        $o=explode('-', $dates);
        $fromt=$o[0];
        $to=$o[1];
        $fromdate = date('Y-m-d', strtotime($fromt));
        $todate = date('Y-m-d', strtotime($to));
        $bono=$this->input->post('bookingno');
        $bookingno= str_replace("B00","",$bono);

        $username=$this->input->post('username');
        $phone=$this->input->post('phone');
        if($_POST){
            if($username!='' && $phone!='' && $bookingno!='')
            {
                 $data['bookingno']='B00'.$bookingno;
                $data['username']=$username;
                $data['phone']=$phone;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
                $data['bookingrecord']=$re->result_array(); 
            }
            else if($username!='' && $phone=='' && $bookingno!='')
            {
                 $data['bookingno']='B00'.$bookingno;
                $data['username']=$username;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
                $data['bookingrecord']=$re->result_array(); 
            }
            else if($username=='' && $phone!=''  && $bookingno!='')
            {
                 $data['bookingno']='B00'.$bookingno;
                $data['phone']=$phone;
                 $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
                $data['bookingrecord']=$re->result_array(); 
            }
            else if($username=='' && $phone==''  && $bookingno!='')
            {
                 $data['bookingno']='B00'.$bookingno;
                 $re=$this->db->query("select * from tbl_booking where ClubId='".$id."'  and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
                $data['bookingrecord']=$re->result_array(); 
            }


            else if($username!='' && $phone!=''  && $bookingno=='')
            {
                $data['username']=$username;
                $data['phone']=$phone;
                 $re=$this->db->query("select * from tbl_booking where ClubId='".$id."'  and BookingDate BETWEEN '".$fromdate."' AND '".$todate."'");
                $data['bookingrecord']=$re->result_array(); 
            }
            else if($username!='' && $phone==''  && $bookingno=='')
            {
                $data['username']=$username;
                 $re=$this->db->query("select * from tbl_booking where ClubId='".$id."'  and BookingDate BETWEEN '".$fromdate."' AND '".$todate."'");
                $data['bookingrecord']=$re->result_array(); 
            }
            else if($username=='' && $phone!=''  && $bookingno=='')
            {
                $data['phone']=$phone;
                 $re=$this->db->query("select * from tbl_booking where ClubId='".$id."'  and BookingDate BETWEEN '".$fromdate."' AND '".$todate."'");
                $data['bookingrecord']=$re->result_array(); 
            }
            else if($username=='' && $phone==''  && $bookingno=='')
            {
                 $re=$this->db->query("select * from tbl_booking where ClubId='".$id."'  and BookingDate BETWEEN '".$fromdate."' AND '".$todate."'");
                $data['bookingrecord']=$re->result_array(); 
            }             
            else {
                $data['bookingrecord']=$this->App->getPerticularRecord('tbl_booking','ClubId',$id);
            }                
        }else{
            $data['bookingrecord']=$this->App->getPerticularRecord('tbl_booking','ClubId',$id);
        }

        $data['cid']=$id;
        $this->load->view('admin/club/ownclub/listpendingbooking', $data);        
    }
        
    public function listreview($id)
    {
		
        $this->App->checkAdminAuthenticate();
        $data['listreview'] = $this->App->getPerticularRecord('tbl_reviews','BookingId',$id);
        
        $this->load->view('admin/club/detailsreview', $data);  
    }
    public function deletereviews()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('reviews', 'Id', $id);
        return 1;
    }
    public function listfacility()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->session->userdata['adminauth']['Id'];
        $data['listfacility'] = $this->App->getRecord('tbl_facility');
        $this->load->view('admin/club/listfacility', $data);
    }
    public function deletefacility()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('tbl_facility', 'Id', $id);
        return 1;
    }
    public function listbooking()
    {
         $this->App->checkAdminAuthenticate();
        $id = $this->session->userdata['adminauth']['Id'];
        $dates=$this->input->post('reservation');
        $o=explode('-', $dates);
        $fromt=$o[0];
        $to=$o[1];
        $fromdate = date('Y-m-d', strtotime($fromt));
        $todate = date('Y-m-d', strtotime($to));
        $clubs=$this->input->post('clubs');
        $bookingstatus=$this->input->post('bookingstatus');
            
        $this->App->checkAdminAuthenticate();
            if($_POST){
               
                if($clubs!='' && $bookingstatus!='')
                {   $data['clubi']=$clubs;
                    $data['bookingstatus']=$bookingstatus;
                    $re=$this->db->query("select * from tbl_booking where  ClubId='".$clubs."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingStatus='".$bookingstatus."'");
                    $data['listbooking']=$re->result_array();   
                }
                else if($clubs!='' && $bookingstatus=='')
                {   $data['clubi']=$clubs;
                    $re=$this->db->query("select * from tbl_booking where  ClubId='".$clubs."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."'");
                    
                    $data['listbooking']=$re->result_array();   
                }
                else if($clubs=='' && $bookingstatus!='')
                {
                    $data['bookingstatus']=$bookingstatus;
                    $re=$this->db->query("select * from tbl_booking where  BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingStatus='".$bookingstatus."'");
                    $data['listbooking']=$re->result_array();   
                }
                else if($clubs=='' && $bookingstatus=='')
                {
                    $re=$this->db->query("select * from tbl_booking where  BookingDate BETWEEN '".$fromdate."' AND '".$todate."' ");

                    $data['listbooking']=$re->result_array();   
                }
                else{
                     $data['listbooking'] = $this->App->getRecord('tbl_booking');
                }
                
            }
            else {
            $data['listbooking'] = $this->App->getRecord('tbl_booking');
            }
      
        $this->load->view('admin/club/listmainbooking', $data);
    }
    
    public function addClub()
    {
        $this->form_validation->set_rules('firstname', 'First Name', 'required');
        $this->form_validation->set_rules('lastname', 'Last Name', 'required');
        $this->form_validation->set_rules('clubname', 'Club Name', 'required');
        $this->form_validation->set_rules('phone', 'Phone', 'required');
        $this->form_validation->set_rules('alphone', 'Phone Name', 'required');
        $this->form_validation->set_rules('city', 'City', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('county', 'Country', 'required');
        $this->form_validation->set_rules('Address', 'Address', 'required');
        
        if ($_POST) {
            $phone = $this->input->post('phone');
            $chk   = $this->App->checkExist('tbl_vendor', 'Phone', $phone);
            if ($chk == '1') {
                $err = 'Phone Number Already Exist<br>';
            }
            $clbname = $this->input->post('clubname');
            $trim    = trim($clbname);
            $ow      = strtolower($trim);
            $string  = str_replace(' ', '-', $ow);
            $id      = $this->session->userdata['vendorauth']['Id'];
            $str     = preg_replace('/\s+/', '-', $string);
            $string  = str_replace(' ( ', '', $str);
            $string  = str_replace(' ) ', '', $string);
            $string  = str_replace('(', '', $string);
            $string  = str_replace('%', '', $string);
            $string  = str_replace(' % ', '', $string);
            $string  = str_replace('?', '', $string);
            $string  = str_replace(' ? ', '', $string);
            $string  = str_replace(')', '', $string);

            $str=str_replace("'", '', $str);
            $chkslug = $this->App->checkExistEdit('tbl_vendor', 'Slug', $str, 'Id', $id);
            if ($chkslug == '1') {
                $r    = rand(1, 4);
                $slug = $str . $r;
            } else {
                $slug = $str;
            }
            
             $is1=$this->input->post('ifram1');
           echo '<br><br>';
             $is=$this->input->post('ifram');
            
            if($is==''){
                if($is1==''){
                    $err1='1Proper Address field required.';
                }
            }else{
                
            }
            
            
            if($is!=''){ $iaddress=$is;}else{ $iaddress=$is1; }
        }
        if ($this->form_validation->run() == FALSE || $err != '' || $err1 != '' ) {
            if (validation_errors() != '' || $err != '' || $err1 != '') {
                $data['error']       = validation_errors() . $err.$err1;
               
                $data['clubname']    = $this->input->post('clubname');
                $data['phone']       = $this->input->post('phone');
                $data['alphone']     = $this->input->post('alphone');
                $data['city']        = $this->input->post('city');
                $data['county']      = $this->input->post('county');
                $data['postcode']    = $this->input->post('postcode');
                $data['address']     = $this->input->post('Address');              
                $data['ifram']       = $iaddress;
                $data['firstname'] = $this->input->post('firstname');
                $data['lastname'] = $this->input->post('lastname');
                $data['email'] = $this->input->post('email');
            }
        } else {
            $id  = $this->session->userdata['vendorauth']['Id'];            
            $is1=$this->input->post('ifram1');
            $is=$this->input->post('ifram');
            if($is!=''){ $iaddress=$is;}else{ $iaddress=$is1; }
            $arr = array(
                'FirstName' => $this->input->post('firstname'),
                'LastName' => $this->input->post('lastname'),
                'Email' => $this->input->post('email'),
                'ClubName' => $this->input->post('clubname'),
                'City' => $this->input->post('city'),
                'Country' => $this->input->post('county'),
                'Phone' => $this->input->post('phone'),
                'AlternativePhone' => $this->input->post('alphone'),
                'PostCode' => $this->input->post('postcode'),
                'AddressIfram' => $iaddress,
                'ContactName' => $this->input->post('firstname').' '.$this->input->post('lastname'),
                'Address' => $this->input->post('Address'),
                'Slug' => $slug
            );                
            $idd=$this->App->insertdata('tbl_vendor', $arr);
            redirect('admin/step2/'.$idd);
        }
        $this->load->view('admin/vendor/addvendor', $data);
    }
    public function step2($idd='')
    {
        $data['idd']=$idd;
        $this->form_validation->set_rules('Cuisines', 'Cuisines', 'required');        
        $this->form_validation->set_rules('PerAdultPrice', 'COST FOR TWO', 'required');
        $this->form_validation->set_rules('NumTable','No. of Tables','required');
        $id = $this->session->userdata['vendorauth']['Id'];

        if (!empty($_FILES['uploadimg']['name'])) {						
                
                $pathMain = 'assets/fronttheme/clubimage/';
                if (!is_dir($pathMain))
                    mkdir($pathMain, 0755);	
                $path1Thumb = 'assets/clubimage/1920X600';
                if (!is_dir($path1Thumb))
                    mkdir($path1Thumb, 0755);
 
                $path2Thumb = 'assets/clubimage/600X412';
                if (!is_dir($path2Thumb))
                    mkdir($path2Thumb, 0755);
 
                $path3Thumb = 'assets/clubimage/360X190';
                if (!is_dir($path3Thumb))
                    mkdir($path3Thumb, 0755);
 
                $path4Thumb = 'assets/clubimage/210X150';
                if (!is_dir($path4Thumb))
                    mkdir($path4Thumb, 0755);
                    
                $path5Thumb = 'assets/clubimage/455X300';
                if (!is_dir($path5Thumb))
                    mkdir($path5Thumb, 0755);
                     $path6Thumb = 'assets/clubimage/';
                if (!is_dir($path6Thumb))
                    mkdir($path6Thumb, 0755);
                
 
                $result = $this->App->do_upload("uploadimg", $pathMain);
 
                if (!$result['status'])
                    $data['error'] ="Can not upload Image for " . $result['error'] . " ";
                else
                {                  
                   $this->App->resize_image($pathMain . '/' . $result['upload_data']['file_name'], $path1Thumb . '/'.$result['upload_data']['file_name'],'1920','600');
                   $this->App->resize_image($pathMain . '/' . $result['upload_data']['file_name'], $path2Thumb . '/'.$result['upload_data']['file_name'],'600','412');
                   $this->App->resize_image($pathMain . '/' . $result['upload_data']['file_name'], $path3Thumb . '/'.$result['upload_data']['file_name'],'360','190');
                   $this->App->resize_image($pathMain . '/' . $result['upload_data']['file_name'], $path4Thumb . '/'.$result['upload_data']['file_name'],'210','150');
                   $this->App->resize_image($pathMain . '/' . $result['upload_data']['file_name'], $path5Thumb . '/'.$result['upload_data']['file_name'],'455','300');
                    $this->App->resize_image($pathMain . '/' . $result['upload_data']['file_name'], $path6Thumb . '/'.$result['upload_data']['file_name'],'1920','600');                                     
                    $picture = $result['upload_data']['file_name']; 
                }                       
            
        } else {
            $picture = $this->input->post('oldimg');
        }

        if ($this->form_validation->run() == FALSE) {
            if (validation_errors() != '') {
                $data['error'] = validation_errors();
            }
        } else {
            $id        = $idd;
            $arr       = array(
                'VendorId' => $id,
                'Cuisines' => $this->input->post('Cuisines'),
                'PerAdultPrice' => $this->input->post('PerAdultPrice'),
                'MainImage' => $picture,
                'Created' => date('Y-m-d'),
                'NoofPax'=>$this->input->post('diningprefer'),
                'PerChildPrice'=>$this->input->post('closedhrs'),
                'NumTable'=>$this->input->post('NumTable'),
            );
            $chktblrec = $this->App->getPerticularRecord('tbl_clublayout', 'VendorId', $id);
            if (empty($chktblrec)) {
                $iid = $this->App->insertdata('tbl_clublayout', $arr);
            } else {
                $this->App->update('tbl_clublayout', 'VendorId', $idd, $arr);
            }
            redirect('admin/step3/'.$idd);            
        }     
        $data['vendordetails'] = $this->App->getPerticularRecord('tbl_clublayout', 'VendorId', $idd);
               
        $this->load->view('admin/vendor/step2', $data);
    }
    public function step3($id)
    {
        $data['idd']=$id;
         $this->form_validation->set_rules('description', 'Description', 'required');
        $this->form_validation->set_rules('AvailableParking', 'Available Parking', 'required');
        $typeparking = $this->input->post('AvailableParking');
        if ($typeparking == 'paid') {
            $this->form_validation->set_rules('PriceParkingPerhrs', 'Parking Price', 'required');
        }
        if ($_POST) {
            
        }
        if ($this->form_validation->run() == FALSE) {
            if (validation_errors() != '') {
                $data['error'] = validation_errors();
            }
        } else {
           
            $arr = array(
                'Description' => $this->input->post('description'),
                'AvailableParking' => $this->input->post('AvailableParking'),
                'PriceParkingPerhrs' => $this->input->post('PriceParkingPerhrs'),
                'facebook' => $this->input->post('facebook'),
                'googleplus' => $this->input->post('googleplus'),
                'twitter' => $this->input->post('twitter'),
                'linked' => $this->input->post('linked'),
                'youtube' => $this->input->post('youtube'),
                'vimeo' => $this->input->post('vimeo'),
                'instagram' => $this->input->post('instagram'),
            );
            $this->App->update('tbl_clublayout', 'VendorId', $id, $arr);
            redirect('admin/step4/'.$id);
        }
        $data['vendordetails'] = $this->App->getPerticularRecord('tbl_clublayout', 'VendorId', $id);
        $this->load->view('admin/vendor/step3', $data);
    }
    public function step4($id)
    {
        $data['idd']=$id;
         $this->form_validation->set_rules('multi', 'Number of tables', 'required');
        
        if($_POST) {
            $this->load->library('upload');
            if (!empty($_FILES['userFiles']['name'])) {
               
                $filesCount = count($_FILES['userFiles']['name']);
                for ($i = 0; $i < $filesCount; $i++) {
                    $_FILES['userFile']['name']     = $_FILES['userFiles']['name'][$i];
                    $_FILES['userFile']['type']     = $_FILES['userFiles']['type'][$i];
                    $_FILES['userFile']['tmp_name'] = $_FILES['userFiles']['tmp_name'][$i];
                    $_FILES['userFile']['error']    = $_FILES['userFiles']['error'][$i];
                    $_FILES['userFile']['size']     = $_FILES['userFiles']['size'][$i];
                    
                    $uploadPath              = 'assets/clubgallery/';
                    $config['upload_path']   = $uploadPath;
                    $config['allowed_types'] = '*';
                    
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);
                    if ($this->upload->do_upload('userFile')) {
                        $fileData                    = $this->upload->data();
                        $uploadData[$i]['file_name'] = $fileData['file_name'];
                    } else {
                        $data['error'] = $this->upload->display_errors();
                    }
                }
                
                if (!empty($uploadData)) {
                    $c = count($uploadData);
                    for ($i = 0; $i < $c; $i++) {
                        $arr = array(
                            'VendorId' => $id,
                            'Image' => $uploadData[$i]['file_name'],
                            'Created' => date('Y-m-d'),
                            'Status' => '1'
                        );
                        $this->App->insertdata('tbl_clubgallery', $arr);
                    }
                    redirect('admin/step5/'.$id);
                }
            }
            redirect('admin/step5/'.$id);
            
        }
        $data['vendordetails'] = $this->App->getPerticularRecord('tbl_clubgallery', 'VendorId', $id);
        $this->load->view('admin/vendor/step4', $data);
    }
    public function step5($id='')
    {
        $data['idd']=$id;
         $this->form_validation->set_rules('sundayfrom', 'Time', 'required');
        if ($this->form_validation->run() == FALSE) {
            if (validation_errors() != '') {
                $data['error'] = validation_errors();
            }
        } else {
            
            $arr = array(
                
                'SundayFrom' => $this->input->post('sundayfrom'),
                'SundayTo' => $this->input->post('sundayto'),
                'SundayFromClose' => $this->input->post('sundayfromclose'),
                'SundayToClose' => $this->input->post('sundaytoclose'),
                'MondayFrom' => $this->input->post('mondayfrom'),
                'MondayTo' => $this->input->post('mondayto'),
                'MondayFromClose' => $this->input->post('mondayfromclose'),
                'MondayToClose' => $this->input->post('mondaytoclose'),
                'TuesdayFrom' => $this->input->post('tuesdayfrom'),
                'TuesdayTo' => $this->input->post('tuesdayto'),
                'TuesdayFromClose' => $this->input->post('tuesdayfromclose'),
                'TuesdayToClose' => $this->input->post('tuesdaytoclose'),
                'WednesdayFrom' => $this->input->post('wednesdayfrom'),
                'WednesdayTo' => $this->input->post('wednesdayto'),
                'WednesdayFromClose' => $this->input->post('wednesdayfromclose'),
                'WednesdayToClose' => $this->input->post('wednesdaytoclose'),
                'ThursdayFrom' => $this->input->post('thursdayfrom'),
                'ThursdayTo' => $this->input->post('thursdayto'),
                'ThursdayFromClose' => $this->input->post('thursdayfromclose'),
                'ThursdayToClose' => $this->input->post('thursdaytoclose'),
                'FridayFrom' => $this->input->post('fridayfrom'),
                'FridayTo' => $this->input->post('fridayto'),
                'FridayFromClose' => $this->input->post('fridayfromclose'),
                'FridayToClose' => $this->input->post('fridaytoclose'),
                'SaturdayFrom' => $this->input->post('saturdayfrom'),
                'SaturdayTo' => $this->input->post('saturdayto'),
                'SaturdayFromClose' => $this->input->post('saturdayfromclose'),
                'SaturdayToClose' => $this->input->post('saturdaytoclose')
            );
            $this->App->update('tbl_clublayout', 'VendorId', $id, $arr);
             $vendordert=$this->App->getPerticularRecord('tbl_vendor', 'Id', $id);
            
           $stat=$vendordert[0]['Status'];
             if($stat=='2'){
                 redirect('admin/listClub');
             }else{
                 redirect('admin/step6/'.$id);
             }
            
        }
        $data['vendordetails'] = $this->App->getPerticularRecord('tbl_clublayout', 'VendorId', $id);
        $this->load->view('admin/vendor/step5', $data);
    }
    public function step6($id){
         $data['idd']=$id;
        if($_POST){
            $arr=array('Status'=>'2');
            $this->App->update('tbl_vendor', 'Id', $id, $arr);
            $clubdetail = $this->App->getPerticularRecord('tbl_vendor', 'Id', $id);
        $name = $clubdetail[0]['FirstName'] . ' ' . $clubdetail[0]['LastName'];
        $email = $clubdetail[0]['Email'];
        $clubname = $clubdetail[0]['ClubName'];
        $phone = '91'.$clubdetail[0]['Phone'];
        
        $sms="Congratulations! Your ".$clubname." is Approved. You just signed your Accommodation Agreement with Tablefast.com. , Please check your email and reset password for login.";
        $otp=rand('4531','5356');
        $arr=array('State'=>$otp);
        $this->App->update('tbl_vendor', 'Id', $id, $arr);
        $url = base_url('vendor/resetpassword/' . $id.'/'.$otp);
        
        $dataemail = array(
			'username'=>$name,
			'url'=>$url
        );
        $message = $this->load->view('email/club_approved', $dataemail, TRUE);
        
		$from_email = $this->config->item('constantEmail');
		$to_email = $email;
		
		$headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$headers .= "From: ".$from_email;
		$to=$email;
		$subject = "Thank you for partnering with Tablefast.com";
		mail($to,$subject,$message,$headers);
		
		redirect('admin/listClub');
        }
         $data['vendordetails'] = $this->App->getPerticularRecord('tbl_vendor', 'Id', $id);
        
        $this->load->view('admin/vendor/step6', $data);
    }
    public function updatestep1($id){
        $data['idd']=$id;
        $this->form_validation->set_rules('phone', 'Phone', 'required');
        $this->form_validation->set_rules('alphone', 'Phone Name', 'required');
        $this->form_validation->set_rules('city', 'City', 'required');
        $this->form_validation->set_rules('county', 'Country', 'required');
        $this->form_validation->set_rules('ifram', 'Proper Address', 'required');
        if ($_POST) {
            $phone = $this->input->post('phone');
            $chk   = $this->App->checkExistEdit('tbl_vendor', 'Phone', $phone, 'Id', $id);
           
            $clbname = $this->input->post('clubname');
            $trim    = trim($clbname);
            $ow      = strtolower($trim);
            $string  = str_replace(' ', '-', $ow);
			 $string  = str_replace(' ( ', '', $string);
			 $string  = str_replace(' ) ', '', $string);
			$string  = str_replace('(', '', $string);
			$string  = str_replace('%', '', $string);
			$string  = str_replace(' % ', '', $string);
			$string  = str_replace('?', '', $string);
			$string  = str_replace(' ? ', '', $string);
			 $string  = str_replace(')', '', $string);
            $str     = preg_replace('/\s+/', '-', $string);
           $str=str_replace("'", '', $str);
            $chkslug = $this->App->checkExistEdit('tbl_vendor', 'Slug', $str, 'Id', $id);
            if ($chkslug == '1') {
                $r    = rand(1, 4);
                $slug = $str . $r;
            } else {
                $slug = $str;
            }
        }
        if ($this->form_validation->run() == FALSE || $err != '') {
            if (validation_errors() != '' || $err != '') {
                $data['error'] = validation_errors() . $err;
            }
        } else {
            $arr = array(
                'ClubName' => $this->input->post('clubname'),
                'City' => $this->input->post('city'),
                'Country' => $this->input->post('county'),
                'Phone' => $this->input->post('phone'),
                'AlternativePhone' => $this->input->post('alphone'),
                'PostCode' => $this->input->post('postcode'),
                'AddressIfram' => $this->input->post('ifram'),
                'Slug' => $slug,
				'Address' => $this->input->post('address'),
            );
            $this->App->update('tbl_vendor', 'Id', $id, $arr);
            redirect('admin/step2/'.$id);
        }
        $data['vendordetails'] = $this->App->getPerticularRecord('tbl_vendor', 'Id', $id);
        $this->load->view('admin/vendor/updatestep1', $data);
    }
    public function listbanner()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->session->userdata['adminauth']['Id'];
        $data['listbanner'] = $this->App->getRecord('tbl_banner');
        $this->load->view('admin/banner/listbanner', $data);
    }
    public function addbanner($id='')
    {
        $this->App->checkAdminAuthenticate();
        $data['id']=$id;
        $this->form_validation->set_rules('status', 'Status', 'required');
         if ($this->form_validation->run() == FALSE || $err != ''|| $err1 != '') {
            if (validation_errors() != '' || $err != ''|| $err1 != '') {
                $data['error'] = validation_errors() . $err.$err1;
            }
        } else {
            if (!empty($_FILES['uploadimg']['name'])) {
            $config['upload_path']   = 'assets/fronttheme/banner/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['file_name']     = $_FILES['uploadimg']['name'];
            
            //Load upload library and initialize configuration
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            
            if ($this->upload->do_upload('uploadimg')) {
                $uploadData = $this->upload->data();
                $picture    = $uploadData['file_name'];
            }else{
                $picture = $this->input->post('oldimg');
            } 
            } else {
                $picture = $this->input->post('oldimg');
            }
            $arr=array(
                'BannerImage'=>$picture,
                'Status'=>$this->input->post('status'),
            );
            if($id!=''){
                $this->App->update('tbl_banner','Id',$id,$arr);
                redirect('admin/listbanner');
            }else{               
                $this->App->insertdata('tbl_banner',$arr);
                redirect('admin/listbanner');
            }
        }
        if($id!=''){
          $data['bannerdetails'] = $this->App->getPerticularRecord('tbl_banner', 'Id', $id);  
        }
        
        $this->load->view('admin/banner/addbanner',$data);
    }
    public function deletebanner()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('tbl_banner', 'Id', $id);
        return 1;
    }
    
    public function listsetting()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->session->userdata['adminauth']['Id'];
        $data['listsetting'] = $this->App->getRecord('tbl_setting');
        $this->load->view('admin/setting/managesetting', $data); 
    }
    public function setting($id='')
    {
          $this->App->checkAdminAuthenticate();
        $data['id']=$id;
        $this->form_validation->set_rules('address', 'Address', 'required');
        $this->form_validation->set_rules('Email', 'Email', 'required|valid_email');
        
        if ($this->form_validation->run() == FALSE || $err != ''|| $err1 != '') {
            if (validation_errors() != '' || $err != ''|| $err1 != '') {
                $data['error'] = validation_errors() . $err.$err1;
            }
        } else {
            if (!empty($_FILES['uploadimg']['name'])) {
            $config['upload_path']   = 'assets/logo/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['file_name']     = $_FILES['uploadimg']['name'];
            
            //Load upload library and initialize configuration
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            
            if ($this->upload->do_upload('uploadimg')) {
                $uploadData = $this->upload->data();
                $pictureheader    = $uploadData['file_name'];
            }else{
                $pictureheader = $this->input->post('oldimgheader');
            } 
            } else {
                $pictureheader = $this->input->post('oldimgheader');
            }
            //----------------------------------------------------------------
            
            if (!empty($_FILES['uploadimg1']['name'])) {
            $config['upload_path']   = 'assets/logo/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['file_name']     = $_FILES['uploadimg1']['name'];
            
            //Load upload library and initialize configuration
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            
            if ($this->upload->do_upload('uploadimg1')) {
                $uploadData = $this->upload->data();
                $picturefooter    = $uploadData['file_name'];
            }else{
                $picturefooter = $this->input->post('oldimgfooter');
            } 
            } else {
                $picturefooter = $this->input->post('oldimgfooter');
            }
            
            $arr=array(
                'ContactNumber'=>$this->input->post('ContactNumber'),
                'Address'=>$this->input->post('address'),
                'Email'=>$this->input->post('Email'),
                'Facebook'=>$this->input->post('Facebook'),
                'Google'=>$this->input->post('Google'),
                'Linked'=>$this->input->post('Linked'),
                'Twitter'=>$this->input->post('Twitter'),
                'HeaderLogo'=>$pictureheader,
                'FooterLogo'=>$picturefooter,
            );
            $res=$this->db->query("Select * from tbl_setting limit 1");
            $result=$res->result_array();
            if(!empty($result)){
                $id=$result[0]['Id'];
                 $this->App->update('tbl_setting','Id',$id,$arr); 
            }else{
                $this->App->insertdata('tbl_setting',$arr);
            }
            redirect('admin/listsetting');            
        }
       
        $data['listsetting'] = $this->App->getRecord('tbl_setting');
        $this->load->view('admin/setting/setting', $data); 
    }
    public function listmetapages()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->session->userdata['adminauth']['Id'];
        $data['listpage'] = $this->App->getRecord('tbl_meta');
        $this->load->view('admin/seo/listpage', $data);
    }
    public function addmetapages($id='')
    {  
        $this->App->checkAdminAuthenticate();
        $data['id']=$id;
        $this->form_validation->set_rules('side', 'Site', 'required');
        $this->form_validation->set_rules('title', 'Meta Title', 'required');
         $this->form_validation->set_rules('status', 'Status', 'required');
        
        if($_POST){
            $pageid= $this->input->post('side');
            $title = $this->input->post('title');
            $description = $this->input->post('description');
            $keyword = $this->input->post('keyword');
            $status = $this->input->post('status');
            if($id == ''){
                $check = $this->App->checkExist('tbl_meta','PageId',$pageid);
                if(!empty($check)){
                    $err='Page content already exist.';
                }
                
            }else{
                $check = $this->App->checkExistEdit('tbl_meta','PageId',$pageid,'Id',$id);
                if(!empty($check)){
                    $err='Page content already exist.';
                }
            }
        }
        if ($this->form_validation->run() == FALSE || $err != ''|| $err1 != '') {
            if (validation_errors() != '' || $err != ''|| $err1 != '') {
                $data['error'] = validation_errors() . $err.$err1;
            }
        } else {
           
             $arr=array(
                    'PageId'=>$pageid,
                    'Title'=>$title,
                    'Description'=>$description,
                    'MetaKeyword'=>$keyword,
                    'Status'=>$this->input->post('status'),
                    'Created'=>date('Y-m-d'),
                );
            if($id!=''){
                $this->App->update('tbl_meta','Id',$id,$arr);
                redirect('admin/listmetapages');
            }else{
               
                $this->App->insertdata('tbl_meta',$arr);
                redirect('admin/listmetapages');
            }
        }
        if($id!=''){
          $data['bannerdetails'] = $this->App->getPerticularRecord('tbl_meta', 'Id', $id);  
        }
        
        $this->load->view('admin/seo/addpage',$data);
    }
    public function deletemetapages()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('tbl_meta', 'Id', $id);
        return 1;
    }
    public function listcontent()
    {
	$this->App->checkAdminAuthenticate();
        $id = $this->session->userdata['adminauth']['Id'];
        $data['listpage'] = $this->App->getRecord('tbl_information');
        $this->load->view('admin/setting/listpage', $data);
    }
    public function infocontent($id)
    {
        $data['iid']=$id;
        $this->App->checkAdminAuthenticate();
        
        $this->form_validation->set_rules('title', 'Title', 'required');
        $this->form_validation->set_rules('description', 'Description', 'required');
        if ($this->form_validation->run() == FALSE || $err != '') {
            if (validation_errors() != '' || $err != '') {
                $data['error'] = validation_errors() . $err;
            }
        } else {
            $arr = array(
                'Subtitle' => $this->input->post('title'),
                'Description' => $this->input->post('description'),
                'Status' => $this->input->post('status'),
                'Created' => date('Y-m-d')
            );
            $this->App->update('tbl_information','Id',$id, $arr);
            redirect('admin/listcontent');
	}
        $data['listpage'] = $this->App->getPerticularRecord('tbl_information','Id',$id);
        $this->load->view('admin/setting/pagecontent', $data);
    }
	
	
    public function paypallistsetting()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->session->userdata['adminauth']['Id'];
        $data['listsetting'] = $this->App->getRecord('tbl_paypal_setting');
        $this->load->view('admin/setting/paypalmanagesetting', $data); 
    }
    public function paypalsetting($id='')
    {
        $this->App->checkAdminAuthenticate();
        $data['id']=$id;
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'password', 'required');
        $this->form_validation->set_rules('signature', 'Signature', 'required');
        $this->form_validation->set_rules('CurrencyCode', ' Currency Code', 'required');
        $this->form_validation->set_rules('BillingPeriod', 'Billing Period', 'required');
        $this->form_validation->set_rules('BillingFrequency', 'Billing Frequency', 'required');
        $this->form_validation->set_rules('TotalBillingCycle', ' Total Billing Cycle', 'required');        
        $this->form_validation->set_rules('Amt', 'Amount', 'required');
         $this->form_validation->set_rules('ExpressPeriod', 'Paypal Express Period', 'required');
          $this->form_validation->set_rules('ExpressFrequency', 'Paypal Express Frequency', 'required');
        
        
        if ($this->form_validation->run() == FALSE || $err != ''|| $err1 != '') {
            if (validation_errors() != '' || $err != ''|| $err1 != '') {
                $data['error'] = validation_errors() . $err.$err1;
            }
        } else {
            $arr=array(
                   'UserName'=>$this->input->post('username'),
                   'Password'=>$this->input->post('password'),
                   'Signature'=>$this->input->post('signature'),
                   'CurrencyCode'=>$this->input->post('CurrencyCode'),
                   'BillingPeriod'=>$this->input->post('BillingPeriod'),
                   'BillingFrequency'=>$this->input->post('BillingFrequency'),
                   'TotalBillingCycle'=>$this->input->post('TotalBillingCycle'),
                   'Amt'=>$this->input->post('Amt'),
                   'Paymentisocode2'=>'IE',
                   'Paymentisocode3'=>'IRL',
                   'Paymentzonecode'=>'CO',
                   'Shippingisocode2'=>'IE',
                   'Shippingisocode3'=>'IRL',
                   'Shippingzonecode'=>'CO',
                   'Languagecode'=>'en-gb',
                   'PaymentZoneId'=>'1589',
                   'PaymentZone'=>'Cork',
                   'Status'=>'1',
                   'Created'=>date('Y-m-d'),
                   'ExpressFrequency'=>$this->input->post('ExpressFrequency'),
                   'ExpressPeriod'=>$this->input->post('ExpressPeriod'),

               );
            $res=$this->db->query("Select * from tbl_paypal_setting limit 1");
            $result=$res->result_array();
            if(!empty($result)){
                $id=$result[0]['Id'];
                 $this->App->update('tbl_paypal_setting','Id',$id,$arr); 
            }else{
                $this->App->insertdata('tbl_paypal_setting',$arr);
            }
            redirect('admin/paypallistsetting');
       }       
        $data['listsetting'] = $this->App->getRecord('tbl_paypal_setting');
        $this->load->view('admin/setting/paypalsetting', $data); 
    }
    public function listtransaction()
    {		
		$this->App->checkAdminAuthenticate();
        $id = $this->session->userdata['adminauth']['Id'];
        $data['listbooking'] = $this->App->getRecord('tbl_payment_history');
        $this->load->view('admin/club/listtransaction', $data);
    } 
    public function listavailabeltable($vid)
    {
        $this->App->checkAdminAuthenticate();
         $data['listbook'] = $this->App->getPerticularRecord('tbl_booking_calender', 'VendorId', $vid);
        $numbook = $this->App->getPerticularRecord('tbl_clublayout', 'VendorId', $vid);
		$data['totaltable']=$numbook[0]['NumTable'];
        $this->load->view('admin/club/listviewbook', $data);
    }
    public function deleteavailabeltable()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('tbl_booking_calender', 'Id', $id);
        return 1;
    }
    /* 17 july */
    
     public function listcompleteticketbook()
    {
        $this->App->checkAdminAuthenticate();
        $data['activecustomer']=$this->App->getPerticularRecord('tbl_ticket_purches','Status','1');
        $this->load->view('admin/club/listcompletepaymentricket', $data);
        
    }
    public function listpendingticketbook()
    {
        $this->App->checkAdminAuthenticate();
        $data['activecustomer']=$this->App->getPerticularRecord('tbl_ticket_purches','Status','0');
        $this->load->view('admin/club/listpendingpaymentricket', $data);
        
    }
    public function deletebookevent()
    {
		$this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('tbl_ticket_purches', 'Id', $id);
        return 1;
	}
	public function listeventtype()
	{
		$this->App->checkAdminAuthenticate();
        $id = $this->session->userdata['adminauth']['Id'];
        $data['listeventtype'] = $this->App->getRecord('tbl_event_type');
        $this->load->view('admin/club/listeventtype', $data);
	}
	public function addeventtype($id='')
	{
		$this->App->checkAdminAuthenticate();
		$data['id']=$id;
        $this->form_validation->set_rules('title', 'Event Type', 'required');
        $this->form_validation->set_rules('description', 'Description', 'required');
        $this->form_validation->set_rules('price', 'Price', 'required');
        $this->form_validation->set_rules('clubname', 'Club Name', 'required');
          $this->form_validation->set_rules('notickets', 'No. of tickets', 'required');
        
        if($_POST){
			$clubname = $this->input->post('clubname');
			$title = $this->input->post('title');
			if($id==''){
				$result = $this->App->passwordChecking('tbl_event_type','ClubId','Title',$clubname,$title);
				if(!empty($result)){
					$err ='Event Type already Exist.';	
				}	
			}		
		}
        
        
        if ($this->form_validation->run() == FALSE || $err != '') {
            if (validation_errors() != '' || $err != '') {
                $data['error'] = validation_errors() . $err;
            }
        } else {
          $arr = array(
                'ClubId' =>  $this->input->post('clubname'),
                'Title' => $this->input->post('title'),
                'ShortDescription' => $this->input->post('description'),
                'Status' => $this->input->post('status'),
                'Amount' => $this->input->post('price'),
                'Created' => date('Y-m-d'),
                'NoofTickets' => $this->input->post('notickets'),
            );
            if($id==''){
				$iid = $this->App->insertdata('tbl_event_type', $arr);
				$data['success'] = 'Event Type insert successfully.';
			}else{
				$iid = $this->App->update('tbl_event_type','Id',$id, $arr);
				$data['success'] = 'Event Type updated successfully.';
			}
        }
        $data['eventtypedetails'] = $this->App->getPerticularRecord('tbl_event_type', 'Id', $id);
        $this->load->view('admin/club/addeventtype', $data);
	}
	public function deleteeventtype()
    {
		$this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('tbl_event_type', 'Id', $id);
        return 1;
	}
	public function addevent()
	{
		//print_r($_POST);die;
		$this->App->checkAdminAuthenticate();
		$data['id']=$id;
         $this->form_validation->set_rules('eventtitle', 'Title', 'required');
        $this->form_validation->set_rules('description', 'Description', 'required');
        
        if($_POST){
						
            $currentdt = date('Y-m-d');
            $fromdate=$this->input->post('fromdate');
            $todate=$this->input->post('todate');
            $specialdate=$this->input->post('specialdate');
            
            if($fromdate!='' && $todate==''){
				 $this->form_validation->set_rules('fromdate', 'From Date', 'required');
			}
			 if($fromdate=='' && $todate!=''){
				 $this->form_validation->set_rules('todate', 'To Date', 'required');
			}
			 if($fromdate=='' && $todate==''){
				 $this->form_validation->set_rules('specialdate', 'Date', 'required');
			}
            
            $fromdate = date('Y-m-d', strtotime($fromdate));
            $todate = date('Y-m-d', strtotime($todate));
            $specialdate = date('Y-m-d', strtotime($specialdate));
            
            
           /* if($specialdate!=''){
				if (strtotime($currentdt) <= strtotime($specialdate) ) {
                
				}else{
					$err='Please Select greater than or equal date<br>';
					}
			}
			 if($fromdate!='' && $todate!=''){
				if( (strtotime($fromdate) >= strtotime($currentdt)) && (strtotime($todate) >= strtotime($currentdt)) ){
					
				}else{
					$err='Please Select greater than or equal date<br>';
					}
			}*/
              
        }
        
        
        if ($this->form_validation->run() == FALSE || $err !=''|| $err1 !=''|| $err2 !='') {
            if (validation_errors() != '' || $err !=''|| $err1 !=''|| $err2 !='') {
                $data['error'] = validation_errors().$err.$err1.$err2;
                
            }
        } else {
            $id = $this->input->post('clubname');
            $days = $this->input->post('days');
            if ($days == '1') {
                $ds = '1';
            } else {
                $ds = $this->input->post('nooddays');
            }
            
            
            if (!empty($_FILES['uploadsfl']['name'])) {
                $config['upload_path']   = 'assets/events/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['file_name']     = $_FILES['uploadsfl']['name'];

                $this->load->library('upload', $config);
                $this->upload->initialize($config);

                if ($this->upload->do_upload('uploadsfl')) {
                    $uploadData = $this->upload->data();
                    $picture = $uploadData['file_name'];
                }
            }
            $clbname = $this->input->post('eventtitle');
            $trim = trim($clbname);
            $ow = strtolower($trim);
            $string = str_replace(' ', '-', $ow);
            $id = $this->session->userdata['vendorauth']['Id'];
            $str = preg_replace('/\s+/', '-', $string);
            $chkslug = $this->App->checkExistEdit('tbl_events', 'Slug', $str, 'Id', $id);
            if ($chkslug == '1') {
                $r = rand(1, 4);
                $slug = $str . $r;
            } else {
                $slug = $str;
            }
            $eventtype = $this->input->post('eventtype');
            $eventtypes = implode(',',$eventtype);
            $arr = array(
                'ClubId' => $this->input->post('clubname'),
                'Title' => $this->input->post('eventtitle'),
                'Description' => $this->input->post('description'),
                'FromDate' => $fromdate,
                'ToDate' => $todate,
                'NoofDays' => $ds,
                'OneDate' => $specialdate,
                'TimeFrom' => $this->input->post('fromtime'),
                'TimeTo' => $this->input->post('totime'),
                'Status' => '1',
                'Price' => $this->input->post('price'),
                'Image' => $picture,
                'Created' => date('Y-m-d'),
                'Slug' => $slug,
                'eventtype'=> $eventtypes,
            );
            $iid = $this->App->insertdata('tbl_events', $arr);
            
              //---- event ticket update-----
             $eventtype = $this->input->post('eventtype');
            $count =  count($eventtype);
            for($i=0;$i<$count;$i++){
				$eventtypes = $this->App->getPerticularRecord('tbl_event_type', 'Id', $eventtype[$i]); 
				 $nooftickets = $eventtypes[0]['NoofTickets'];
				
				 $eventtab = array(
				    'ClubId' => $this->input->post('clubname'),
					'EventId' => $iid,
					'EventTypeId' => $eventtype[$i],
					'NoofTicket' => $nooftickets,
					'UsedTicket' => '',
					'Created' => date('Y-m-d'),
				 );
				 $this->App->insertdata('tbl_event_ticket_update', $eventtab);
			 }
            
            //------end code------------------------
            redirect('admin/listevents');
             $id = $this->input->post('clubname');
             $data['success'] ='Insert Event Successfully';
		 }
        $data["listcategory"] = $this->App->getPerticularRecord('tbl_events', 'ClubId', $id);        
        $data["listtypeevent"] = $this->App->getPerticularRecord('tbl_event_type', 'Status', '1');
        $this->load->view('admin/club/addevents', $data);
	}
	public function editevent($id='')
	{
		$this->form_validation->set_rules('clubname', 'Club name', 'required');
		$this->form_validation->set_rules('eventtitle', 'Title', 'required');
        $this->form_validation->set_rules('description', 'Description', 'required');
        //$this->form_validation->set_rules('price', 'Price', 'required');
        $vid = $this->input->post('clubname');
        
        
        if($_POST){
            $currentdt = date('Y-m-d');
           $fromdate=$this->input->post('fromdate');
          $todate=$this->input->post('todate');
         $specialdate=$this->input->post('specialdate');

             /*if($specialdate!='0000-00-00'){
				if (strtotime($currentdt) <= strtotime($specialdate) ) {
                
				}else{
					$err='Please Select greater than or equal date<br>';
					}
			}
			 if($fromdate!='0000-00-00' && $todate!='0000-00-00'){
				if( (strtotime($fromdate) >= strtotime($currentdt)) && (strtotime($todate) >= strtotime($currentdt)) ){
					
				}else{
					$err='Please Select greater than or equal date<br>';
					}
			}*/
            
        }
        
        if ($this->form_validation->run() == FALSE || $err!='' || $err1!='' || $err2!='') {
            if (validation_errors() != '' || $err!='' || $err1!='' || $err2!='') {
                $data['error'] = validation_errors().$err.$err1.$err2;
                
            }
        } else {
            
            if (!empty($_FILES['uploadsfl']['name'])) {
                $config['upload_path']   = 'assets/events/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['file_name']     = $_FILES['uploadsfl']['name'];

                //Load upload library and initialize configuration
                $this->load->library('upload', $config);
                $this->upload->initialize($config);

                if ($this->upload->do_upload('uploadsfl')) {
                    $uploadData = $this->upload->data();
                    $picture    = $uploadData['file_name'];
                }
            } else {
                $picture = $this->input->post('oldimg');
            }
            $vid = $this->input->post('clubname');
            $days = $this->input->post('days');
            if ($days == '1') {
                $ds = '1';
            } else {
                $ds = $this->input->post('nooddays');
            }
            
            $clbname = $this->input->post('eventtitle');
            $trim = trim($clbname);
            $ow = strtolower($trim);
            $string  = str_replace(' ', '-', $ow);
             $vid = $this->input->post('clubname');
            $str = preg_replace('/\s+/', '-', $string);
            $chkslug = $this->App->checkExistEdit('tbl_events', 'Slug', $str, 'Id', $id);
            if ($chkslug == '1') {
                $r       = rand(1, 4);
                $slugold = $str . $r;
            } else {
                $slugold = $str;
            }
            $eventtype = $this->input->post('eventtype');
            $eventtypes = implode(',',$eventtype);
            $arr = array(
                'ClubId' => $vid,
                'Title' => $this->input->post('eventtitle'),
                'Description' => $this->input->post('description'),
                'FromDate' => $this->input->post('fromdate'),
                'ToDate' => $this->input->post('todate'),
                'NoofDays' => $ds,
                'OneDate' => $this->input->post('specialdate'),
                'TimeFrom' => $this->input->post('fromtime'),
                'TimeTo' => $this->input->post('totime'),
                'Status' => $this->input->post('status'),
                'Price' => $this->input->post('price'),
                'Image' => $picture,
                'Created' => date('Y-m-d'),
                'Slug' => $slugold,
                'eventtype'=> $eventtypes,
            );
            $iid = $this->App->update('tbl_events', 'Id', $id, $arr);
            
            //---- event ticket update-----
             $eventtype = $this->input->post('eventtype');
            $count =  count($eventtype);
            for($i=0;$i<$count;$i++){
				
				
				 $eventid = $id;
				
				$eventtypes = $this->App->getPerticularRecord('tbl_event_type', 'Id', $eventtype[$i]); 
				 $nooftickets = $eventtypes[0]['NoofTickets'];
				 
				 $r = $this->db->query("select * from tbl_event_ticket_update where ClubId='".$vid."' and EventId='".$eventid."' and EventTypeId='".$eventtype[$i]."'");
				 $no = $r->num_rows();
				 if($no > 0){
					 
			     }else {
				
					 $eventtab = array(
						'ClubId' => $vid,
						'EventId' => $eventid,
						'EventTypeId' => $eventtype[$i],
						'NoofTicket' => $nooftickets,
						'UsedTicket' => '',
						'Created' => date('Y-m-d'),
					 );
					 $this->App->insertdata('tbl_event_ticket_update', $eventtab);
				 }
			 }
            
            //------end code------------------------
            
           redirect('admin/listevents');
        }
		$data["eventdetails"] = $this->App->getPerticularRecord('tbl_events', 'Id', $id); 
		
        $this->load->view('admin/club/editevents', $data);
	}
	
	
	
	public function geteventype()
	{
		$id =$this->input->post('id');
		$eventtype =$this->App->getPerticularRecord('tbl_event_type', 'ClubId', $id);
		
		if(!empty($eventtype)){
			$div = ' <div class="m1">';
		   foreach($eventtype as  $type)	
		   {
			   $typeid = $type['Id'];   
			   $title = $type['Title'];
			   $div .= '<p class="m12"> <input required="required" type="checkbox" name="eventtype[]" value="'.$typeid.'" >'. $title .'</p>';
		   }
		   $div .='</div>'; 
		}
		$data = $div;
		echo json_encode($data);
	}
	public function viewticketevent($id)
	{
		$this->App->checkAdminAuthenticate();
        $eventdetails = $this->App->getPerticularRecord('tbl_events', 'Id', $id);   
        $clubid = $eventdetails[0]['ClubId'];   
        $data["listcompleteticket"] = $this->App->passwordChecking('tbl_event_ticket_update','ClubId','EventId', $clubid,$id);
        $this->load->view('admin/club/listticketevents', $data);
	}
	public function invoicegenerate($oid)
	{
		$this->App->checkAdminAuthenticate();
		$query = $this->db->query("select * from tbl_payment_history where order_history_id = '" . $oid . "'");        
        $data['paymentdetails'] = $query->result_array();
		$this->load->view('admin/invoice',$data);		
	}
	public function cronjobEmail()
	{
		$vendor = $this->App->getPerticularRecord('tbl_vendor', 'Status','2');

		if(!empty($vendor)){
			foreach($vendor as $vendordetails){
				$vid = $vendordetails['Id'];
				$query = $this->db->query("select * from tbl_payment_history where order_id='".$vid."' ORDER BY `order_status_id` DESC limit 1");
				
				$paymentdetails = $query->result_array();
				

				if(!empty($paymentdetails)){
					foreach($paymentdetails as $payment){
						$datetime = $payment['date_added'];
						$paymentdate = date("Y-m-d", strtotime($datetime));
						$next_year = date("Y-m-d", strtotime("$paymentdate +1 year"));
						$next_year_last_month = date("Y-m-d", strtotime("$next_year -1 month"));
						$currentdate = date("Y-m-d");
						
						
						
						if($next_year_last_month == $currentdate){
							$clubname = $vendordetails['ClubName'];
							$clubemail = $vendordetails['Email'];
							$username = $vendordetails['FirstName'].' '.$vendordetails['LastName']; 
							$dataemail = array(
								'clubname'=>$clubname,
								'username'=>$username,
								'next_year_last_month'=>$next_year_last_month
							);
							$message = $this->load->view('email/expired_membership', $dataemail, TRUE);				
							
							
							$from_email = $this->config->item('constantEmail');
							$to_email   = $email;
							
							//Load email library 
									  
							$headers = "MIME-Version: 1.0" . "\r\n";
							$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
							$headers .= "From: ".$from_email;

							$to=$clubemail;
							$subject="Club Membership notification mail";
							mail($to,$subject,$message,$headers);
						}
					}
				}
			}
		}
	}
	
       
}

