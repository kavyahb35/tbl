<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Booking extends CI_Controller
{
    /*  Note : booking table : 
        column Status :
        0 : only fill form but not confirm booking customer site
        1 : Customer boking confirm
        column BookingStatus :
        0 : Processing Request
        1 : Confirm booking (Vendor approve booking)
        2 : vendor reject booking
        3 : customer cancel booking
        4 : customer modify booking
        5 : complete Booking
    */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->helper('new_helper');
        $this->load->library('form_validation');
        $this->load->library('email');
        $this->load->library('session');
    }
    
    public function index($slug = '')
    {        
        $cdatechekc=date('Y-m-d');
        $currentdate=$this->input->post('date');
        $currenttime=$this->input->post('myDatepicker1');        
        $noofmember=$this->input->post('noofmember');
        
        $this->form_validation->set_rules('date', 'Booking Date', 'required');
        $this->form_validation->set_rules('myDatepicker1', 'Booking Time', 'required');
        $this->form_validation->set_rules('noofmember', 'No. of Pax', 'required');
        $this->form_validation->set_rules('firstname', 'First Name', 'required');
        //$this->form_validation->set_rules('lastname', 'Last Name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('phone', 'Phone', 'required|min_length[10]');
        
        if ($_POST) {
            $otp = rand('2324','4568');
            $clubdetails = $this->App->getPerticularRecord('tbl_vendor', 'Slug', $slug);
            $vid=$clubdetails[0]['Id'];
            $times=$this->getcurrenttime($vid,$currentdate);
            $d=explode('-',$times);
            $Start=$d[0];
            $End=$d[1];
            $etime = date('H:i:s',strtotime($End));
            $stime = date('H:i:s',strtotime($Start));
            $cctime = date('H:i:s',strtotime($currenttime));


            $email =$this->input->post('email');
            $bookdt = $this->input->post('myDatepicker1');
             $th=$this->input->post('date');
            $sdatet= date('Y-m-d', strtotime($th));
            
            $bookdet = $this->App->getPerticularRecord('tbl_clublayout', 'VendorId', $vid);
            $totbooking = $bookdet[0]['NumTable'];
            
            $querycal= $this->db->query("select * from tbl_booking_calender where VendorId='".$vid."' and BookingDate='".$sdatet."' limit 1");
            $calendor = $querycal->result_array();
            $numrow = $querycal->num_rows();
            
            if($numrow > 0){
				$r = $calendor[0]['NobTable'];
				$totbooking = $totbooking+1;
				
				if($r > $totbooking){
				    $err6 = 'All Tables already reserved for a day.Please try to reserve table for another day.';	
				}
			}
            
            
            
            $query= $this->db->query("select * from tbl_booking where Email='".$email."' and BookingDate ='".$sdatet."' and  BookingTime='".$bookdt."' and ClubId='".$vid."'");
           $the = $query->num_rows();
              if($the > 0){
                 $err8 ='You have already reserved this table.';
              }

         if (($cctime > $stime) && ($cctime < $etime))
            {
                $clubdetails = $this->App->getPerticularRecord('tbl_vendor', 'Slug', $slug);
                $vid=$clubdetails[0]['Id'];

                $hrsdetails = $this->App->getPerticularRecord('tbl_clublayout', 'VendorId', $vid);
                $hr=$hrsdetails[0]['PerChildPrice'];
                if($_POST){
                    date_default_timezone_set('Asia/Kolkata');
                    $n_cur_dt = date('Y-m-d');
                    $n_cur_time1 = date('H:i A', time());
                    $n_cur_time = date("g:i A");
                    $gettime = date("H:i A", strtotime($n_cur_time)); 
                    $j='+'.$hr.' hours';
                    $currenttimefind=date('H:i A',strtotime($j,strtotime($gettime)));
                    $currenttime=date('H:i A',strtotime($currenttime));
                    if($currentdate==$n_cur_dt){
                        if($currenttimefind > $currenttime)	{
                            $err2='Table booking time closed before '.$hr .' hours.';
                        }else{
                        }
                    }
                }
            }
            else
            {
              $err='Please Select Opening to closing time schedule';
            }
            if (strtotime($cdatechekc) <= strtotime($currentdate) ) {
            }else{
               $err1='Please Select Proper date (greater than  or equal to today)';
            }
         }
         if ($this->form_validation->run() == FALSE || $err != ''|| $err1 != '' || $err2 != '' || $err8!='' || $err6!='') {
            if (validation_errors() != '' || $err != ''|| $err1 != '' || $err2 != '' || $err8!='' || $err6!='') {
                $data['error'] = $err.$err1.$err2.$err8.$err6;
                $data['bookingdate']=$this->input->post('date');
                $data['myDatepicker1']=$this->input->post('myDatepicker1');
                $data['noofmember']=$this->input->post('noofmember');
                $data['firstname']=$this->input->post('firstname');
                $data['lastname']=$this->input->post('lastname');
                $data['email']=$this->input->post('email');
                $data['phone']=$this->input->post('phone');
            }
        } else {
            $phone=$this->input->post('phone');
            $customerdetails = $this->App->getPerticularRecord('tbl_customer', 'Phone', $phone);
             
             $authid=$this->session->userdata['customerauth']['Id'];
             if($customerdetails[0]['Id']!=''){
                $cs=$customerdetails[0]['Id'];
             }elseif($authid!=''){
                $cs= $authid;
             }else{ $cs='';}
            
             //-------Added booking serias no.---------------------
                
            $te=$this->App->getRecordByLimit('tbl_booking','ClubId',$vid,'0','1');
            $ts=$this->db->query("SELECT * FROM `tbl_booking` WHERE ClubId='".$vid."' ORDER BY `tbl_booking`.`Id` DESC limit 0,1");
            $te=$ts->result_array();
            if(!empty($te)){
               $no=$te[0]['Id']; 
               $no=$no+1;
             }else{
                 $no='1';

             }
            $th=$this->input->post('date');
            $sdatet= date('Y-m-d', strtotime($th));
            //-----ended code ------------------------------------
                 
             if(!empty($customerdetails) || $authid!=''){
                 $booking=array(
                   'ClubId'=>$vid,
                   'BookingNo'=>$no,
                   'FirstName'=>$this->input->post('firstname'),
                   'LastName'=>$this->input->post('lastname'),
                   'Email'=>$this->input->post('email'),
                   'Phone'=>$this->input->post('phone'),
                   'BookingDate'=> $sdatet,
                   'BookingTime'=>$this->input->post('myDatepicker1'),
                   'NoofPax'=>$this->input->post('noofmember'),
                   'DiningPreferences'=>$this->input->post('diningprefer'),
                   'Created'=>date('Y-m-d H:i'),
                   'Status'=>'0',
                   'BookingStatus'=>'0',
                   'OTP'=>$otp,                     
                   'CustomerId'=>$cs,
                 );
                 $bid=$this->App->insertdata('tbl_booking', $booking);
             }else{
                 //insert customer details
                 $customer=array(
                    'Email'=>$this->input->post('email'),
                    'Phone'=>$this->input->post('phone'),
                    'FirstName'=>$this->input->post('firstname'),
                    'LastName'=>$this->input->post('lastname'),
                    'Created'=>date('Y-m-d'),
                    'Status'=>'0',
                 );
                 $custid=$this->App->insertdata('tbl_customer', $customer);
                  $booking=array(
                   'ClubId'=>$vid,
                   'BookingNo'=>$no,
                   'FirstName'=>$this->input->post('firstname'),
                   'LastName'=>$this->input->post('lastname'),
                   'Email'=>$this->input->post('email'),
                   'Phone'=>$this->input->post('phone'),
                   'BookingDate'=>$sdatet,
                   'BookingTime'=>$this->input->post('myDatepicker1'),
                   'NoofPax'=>$this->input->post('noofmember'),
                   'DiningPreferences'=>$this->input->post('diningprefer'),
                   'Created'=>date('Y-m-d H:i'),
                   'Status'=>'0',
                   'BookingStatus'=>'0',
                   'OTP'=>$otp,
                   'CustomerId'=>$custid,
                 );     
                $bid= $this->App->insertdata('tbl_booking', $booking);
             }
              //------send sms --------------------------------
                $phn=$this->input->post('phone');
                $phone = '91'.$phn;
                $sms=$otp.' is your tablefast verification code enjoy';
                
                 
                $url=base_url('booking/confirmmail/'.$bid);
                $msg='Please <a href="'.$url.'" target="_blank" style="color:navy;font-size:20px"> Click Here</a> for confirm booking .';
                 
                $email = $this->input->post('email');
                $dataemail = array(
					'msg' => $msg,'username'=>$this->input->post('firstname')
                );
                $message = $this->load->view('email/club_booking', $dataemail, TRUE);
            
            $from_email = $this->config->item('constantEmail');
            $to_email   = $email;
            //Load email library 
            $subject = "Otp Verification code  for Tablefast.com";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= "From: ".$from_email;
            $to=$email;
            mail($to,$subject,$message,$headers);
            $data['success']='Processing your request. Please check your mail and confirm booking.';
            $data['bookingid']=$bid;
        }
        
        $clubdetails = $this->App->getPerticularRecord('tbl_vendor', 'Slug', $slug);
        $data['clubdetails']=$clubdetails;
        $this->load->view('front/include/header');
        $this->load->view('front/customer/booking', $data);
        $this->load->view('front/include/footer');
    }
    public function confirmmail($bid)
    {
        if($bid!=''){
            $arr=array(
            'Status'=>'1',
            'BookingStatus'=>'0',
        );                
        $this->App->update('tbl_booking', 'Id', $bid, $arr);
        
        $bookingdetails = $this->App->getPerticularRecord('tbl_booking','Id',$bid);
        if(!empty($bookingdetails)){
		   $vid=$bookingdetails[0]['ClubId'];
		   $BookingDate=$bookingdetails[0]['BookingDate'];
		   $q= $this->db->query("select * from tbl_booking_calender where VendorId='".$vid."' and BookingDate='".$BookingDate."' ");
		    $vendordetails = $q->result_array();	
		    if(!empty($vendordetails)){
				$cid = $vendordetails[0]['Id'];
				    $NobTable = $vendordetails[0]['NobTable'];
					$non =$NobTable + 1 ;
					$arraych= array(
					  'VendorId' =>$vid,
					  'BookingDate'=>$BookingDate,
					  'NobTable'=>$non,
					  );
					   $this->App->update('tbl_booking_calender', 'VendorId', $vid, $arraych);
			}else{
				$ClubId = $bookingdetails[0]['ClubId'];
				    $BookingDate = $bookingdetails[0]['BookingDate'];
				   
					  $non = '1';
					  $arraych= array(
					  'VendorId' =>$ClubId,
					  'BookingDate'=>$BookingDate,
					  'NobTable'=>'1',
					  );
					  $this->App->insertdata('tbl_booking_calender',$arraych);
				
			}
		}
        
        
        
        redirect('booking-success/'.$bid);	
        }
    } 
    public function getcurrenttime($vid,$date)
    {        
        $timestamp = strtotime($date);
        $currentday = date('D', $timestamp);
        $layout = $this->App->getPerticularRecord('tbl_clublayout', 'VendorId', $vid);
        if (!empty($layout)) {
            $SundayFrom = $layout[0]['SundayFrom'];
            $SundayTo = $layout[0]['SundayTo'];
            $SundayFromClose = $layout[0]['SundayFromClose'];
            $SundayToClose = $layout[0]['SundayToClose'];
            $MondayFrom = $layout[0]['MondayFrom'];
            $MondayTo = $layout[0]['MondayTo'];
            $MondayFromClose = $layout[0]['MondayFromClose'];
            $MondayToClose = $layout[0]['MondayToClose'];
            $TuesdayFrom = $layout[0]['TuesdayFrom'];
            $TuesdayTo = $layout[0]['TuesdayTo'];
            $TuesdayToClose = $layout[0]['TuesdayToClose'];
            $WednesdayFrom = $layout[0]['WednesdayFrom'];
            $WednesdayTo = $layout[0]['WednesdayTo'];
            $WednesdayFromClose = $layout[0]['WednesdayFromClose'];
            $WednesdayToClose = $layout[0]['WednesdayToClose'];
            $ThursdayFrom = $layout[0]['ThursdayFrom'];
            $ThursdayTo = $layout[0]['ThursdayTo'];
            $ThursdayFromClose = $layout[0]['ThursdayFromClose'];
            $ThursdayToClose = $layout[0]['ThursdayToClose'];
            $FridayFrom = $layout[0]['FridayFrom'];
            $FridayTo = $layout[0]['FridayTo'];
            $FridayFromClose = $layout[0]['FridayFromClose'];
            $FridayToClose = $layout[0]['FridayToClose'];
            $SaturdayFrom = $layout[0]['SaturdayFrom'];
            $SaturdayTo = $layout[0]['SaturdayTo'];
            $SaturdayFromClose = $layout[0]['SaturdayFromClose'];
            $SaturdayToClose = $layout[0]['SaturdayToClose'];
            
            if ($currentday == 'Mon') {
                $s = $MondayFrom . '-' . $MondayTo;
                
            } elseif ($currentday == 'Tue') {
                $s = $TuesdayFrom . '-'  . $TuesdayTo;
            } elseif ($currentday == 'Wed') {
                $s = $WednesdayFrom . '-'  . $WednesdayTo;
            } elseif ($currentday == 'Thu') {
                $s = $ThursdayFrom . '-' . $ThursdayTo;
            } elseif ($currentday == 'Fri') {
                $s = $FridayFrom . '-' . $FridayTo;
            } elseif ($currentday == 'Sat') {
                $s = $SaturdayFrom . '-' . $SaturdayTo;
            } elseif ($currentday == 'Sun') {
                $s = $SundayFrom . '-' . $SundayTo;
            } else {
                $s = $SundayFrom . '-' . $SundayTo;
            }
            return $s;
        }
    }
    public function gettime()
    {        
        $vid = $this->input->post('cid');
        $data = $this->input->post('date');
        $timestamp = strtotime($data);
        $currentday = date('D', $timestamp);
        $layout = $this->App->getPerticularRecord('tbl_clublayout', 'VendorId', $vid);
        if (!empty($layout)) {
            $SundayFrom = $layout[0]['SundayFrom'];
            $SundayTo = $layout[0]['SundayTo'];
            $SundayFromClose = $layout[0]['SundayFromClose'];
            $SundayToClose = $layout[0]['SundayToClose'];
            $MondayFrom = $layout[0]['MondayFrom'];
            $MondayTo = $layout[0]['MondayTo'];
            $MondayFromClose = $layout[0]['MondayFromClose'];
            $MondayToClose = $layout[0]['MondayToClose'];
            $TuesdayFrom = $layout[0]['TuesdayFrom'];
            $TuesdayTo = $layout[0]['TuesdayTo'];
            $TuesdayToClose = $layout[0]['TuesdayToClose'];
            $WednesdayFrom = $layout[0]['WednesdayFrom'];
            $WednesdayTo = $layout[0]['WednesdayTo'];
            $WednesdayFromClose = $layout[0]['WednesdayFromClose'];
            $WednesdayToClose = $layout[0]['WednesdayToClose'];
            $ThursdayFrom = $layout[0]['ThursdayFrom'];
            $ThursdayTo = $layout[0]['ThursdayTo'];
            $ThursdayFromClose = $layout[0]['ThursdayFromClose'];
            $ThursdayToClose = $layout[0]['ThursdayToClose'];
            $FridayFrom = $layout[0]['FridayFrom'];
            $FridayTo = $layout[0]['FridayTo'];
            $FridayFromClose = $layout[0]['FridayFromClose'];
            $FridayToClose = $layout[0]['FridayToClose'];
            $SaturdayFrom = $layout[0]['SaturdayFrom'];
            $SaturdayTo = $layout[0]['SaturdayTo'];
            $SaturdayFromClose = $layout[0]['SaturdayFromClose'];
            $SaturdayToClose = $layout[0]['SaturdayToClose'];
            
            if ($currentday == 'Mon') {
                $s = $MondayFrom . ' - ' . $MondayTo;
                $hrtime = explode(':', $MondayFrom);
                $k = explode(':', $MondayTo);
                
                
                for ($i = $hrtime; $i < $k; $i++) {
                    echo $i;
                }
            } elseif ($currentday == 'Tue') {
                $s = $TuesdayFrom . ' - ' . $TuesdayTo;
            } elseif ($currentday == 'Wed') {
                $s = $WednesdayFrom . ' - ' . $WednesdayTo;
            } elseif ($currentday == 'Thu') {
                $s = $ThursdayFrom . ' - ' . $ThursdayTo;
            } elseif ($currentday == 'Fri') {
                $s = $FridayFrom . ' - ' . $FridayTo;
            } elseif ($currentday == 'Sat') {
                $s = $SaturdayFrom . ' - ' . $SaturdayTo;
            } elseif ($currentday == 'Sun') {
                $s = $SundayFrom . ' - ' . $SundayTo;
            } else {
                $s = $SundayFrom . ' - ' . $SundayTo;
            }
            die;
        }
    }
    public function otpverify()
    {      
        $bookid=$this->input->post('bookid');
        $otp=$this->input->post('otp');
       
        if($bookid!='' && $otp!=''){
            $tech=$this->App->passwordChecking('tbl_booking','Id','OTP',$bookid,$otp);
            if(!empty($tech)){
                $arr=array(
                    'Status'=>'1',
                    'BookingStatus'=>'0',
                );                
                $this->App->update('tbl_booking', 'Id', $bookid, $arr);
                echo json_encode('1');
            }else{
                echo json_encode('3');
            }
        }else{
            echo json_encode('2');
        }
    }
    public function bookingsuccess($id)
    {
        $data['id']=$id;
        $bookingdetail=$this->App->getPerticularRecord('tbl_booking','Id',$id);
        $userid=$bookingdetail[0]['CustomerId'];
        $BookingNo=$bookingdetail[0]['BookingNo'];
        $FirstName=$bookingdetail[0]['FirstName'];
        $LastName=$bookingdetail[0]['LastName'];
        $email=$bookingdetail[0]['Email'];
        $phone=$bookingdetail[0]['Phone'];
        $bookingdate=$bookingdetail[0]['BookingDate'];
        $bookingtime=$bookingdetail[0]['BookingTime'];
        $ClubId=$bookingdetail[0]['ClubId'];
        $vendordetail=$this->App->getPerticularRecord('tbl_vendor','Id',$ClubId);
        $clubnm=$vendordetail[0]['ClubName'];
        $clubphn=$vendordetail[0]['Phone'];
        $clubemail=$vendordetail[0]['Email'];
        $clbaddress=$vendordetail[0]['Address'];
        $name=$FirstName.' '.$LastName;
        
        $ara=array(
        'Status'=>'1',
        );
        $this->App->update('tbl_customer','Id',$userid,$ara);
        
        //------send sms --------------------------------
        $subject="Booking Request for ".$clubnm;
        
        $dataemail =  array(
			'username' => $name,
			'clubnm' => $clubnm,
			'clbaddress' => $clbaddress,
			'clubphn' => $clubphn,
			'clubemail' => $clubemail,
			'clubnm' => $clubnm,
			'BookingNo' => $BookingNo,
			'bookingdate' => $bookingdate,
			'bookingtime' => $bookingtime,
			'phone' => $phone,
			'email' => $email,
        );
        $message = $this->load->view('email/club_booking_confirm', $dataemail, TRUE);
        
        $from_email = $this->config->item('constantEmail');
        $to_email = $email;
        //Load email library 			
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: ".$from_email. "\r\n" .
        "CC: ".$clubemail;
        $to=$email;
        mail($to,$subject,$message,$headers);
        //---end mail --send sms ----
        $msg1='Request : booking for '.$clubnm .', '.$clbaddress.' , Customer Details : '.$name .' , Booking No : B00'.$BookingNo.' , Booking Date : '.$bookingdate .' - '.$bookingtime ;
                
        $data['bookingdetail']=$bookingdetail;        
        $data['clubdetails']=$this->App->getPerticularRecord('tbl_vendor','Id',$bookingdetail[0]['ClubId']);
        
        $this->load->view('front/include/header');
        $this->load->view('front/customer/bookingdetails', $data);
        $this->load->view('front/include/footer');
    }
    public function resendotp()
    {
        $bookid=$this->input->post('bookid');        
        $bookingdetail=$this->App->getPerticularRecord('tbl_booking','Id',$bookid);
        if(!empty($bookingdetail)){
            $email=$bookingdetail[0]['Email'];
            $phn=$bookingdetail[0]['Phone'];
            $otp=rand('2324','4568');
            $aup=array(
                'OTP'=>$otp,
            );
            $this->App->update('tbl_booking','Id',$bookid,$aup);
            $dataemail = array(
				'msg'=>$msg,'username'=>$bookingdetail[0]['FirstName']
            );
            $message = $this->load->view('email/club_booking', $dataemail, TRUE);				
					  
            
            $from_email = $this->config->item('constantEmail');
            $to_email   = $email;
            //Load email library 
                       
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= "From: ".$from_email;
            $subject = "Resend OTP Verification code  for Tablefast.com";

            $to=$email;
            mail($to,$subject,$message,$headers);            
            
            echo json_encode('1');
        }else{
           echo json_encode('2');
        }        
    }
    
     public function requestBookingAll()
    {
        $this->App->checkVendorAuthenticate();
        $id = $this->session->userdata['vendorauth']['Id'];
        
        $dates=$this->input->post('reservation');
        $o=explode('-', $dates);
        $fromt=$o[0];
        $to=$o[1];
        $fromdate = date('Y-m-d', strtotime($fromt));
        $todate = date('Y-m-d', strtotime($to));
        $username=$this->input->post('username');
        $phone=$this->input->post('phone');
        $bono=$this->input->post('bookingno');
        $bookingno= str_replace("B00","",$bono);           
            
        if($_POST){
            if($username!='' && $phone!='' && $bookingno!='')
            {

                $data['bookingno']='B00'.$bookingno;
                $data['username']=$username;
                $data['phone']=$phone;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
                $data['listbooking']=$re->result_array(); 
            }
            else if($username!='' && $phone!='' && $bookingno=='')
            {
                $data['username']=$username;
                $data['phone']=$phone;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."'");
                $data['listbooking']=$re->result_array(); 
            }
            else if($username!='' && $phone=='' && $bookingno!='')
            {

                $data['bookingno']='B00'.$bookingno;
                $data['username']=$username;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
                $data['listbooking']=$re->result_array(); 
            }
           else if($username!='' && $phone=='' && $bookingno=='')
            {
                $data['username']=$username;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' ");
                $data['listbooking']=$re->result_array(); 
            }
            else if($username=='' && $phone!='' && $bookingno!='')
            {
                $data['bookingno']='B00'.$bookingno;
                $data['phone']=$phone;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
                $data['listbooking']=$re->result_array(); 
            }
            else if($username=='' && $phone!='' && $bookingno=='')
            {
                $data['phone']=$phone;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."'");
                $data['listbooking']=$re->result_array(); 
            }
            else if($username=='' && $phone=='' && $bookingno!='')
            {
                $data['bookingno']='B00'.$bookingno;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
                $data['listbooking']=$re->result_array(); 
            }
            else if($username=='' && $phone=='' && $bookingno=='')
            {

                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' ");
                $data['listbooking']=$re->result_array(); 
            }
            else{
                  $data["listbooking"] = $this->App->getPerticularRecord('tbl_booking', 'ClubId', $id);
            }

        }else{

          $data["listbooking"] = $this->App->getPerticularRecord('tbl_booking', 'ClubId', $id);
        }
        $this->load->view('front/booking/bookingrequestall', $data);
    }
   
    
    public function requestBooking()
    {
        $this->App->checkVendorAuthenticate();
        $id = $this->session->userdata['vendorauth']['Id'];
          
        $currentdt = date('Y-m-d');        
          $data["listbooking"] =   $this->App->passwordChecking('tbl_booking', 'ClubId','BookingDate', $id,$currentdt);
        // $data["listbooking"] = $this->App->getPerticularRecord('tbl_booking', 'ClubId', $id);
        $this->load->view('front/booking/bookingrequest', $data);
    }
    public function confirmBooking()
    {
        $this->App->checkVendorAuthenticate();
        $id = $this->session->userdata['vendorauth']['Id'];
        
        $dates=$this->input->post('reservation');
        $o=explode('-', $dates);
        $fromt=$o[0];
        $to=$o[1];
        $fromdate = date('Y-m-d', strtotime($fromt));
        $todate = date('Y-m-d', strtotime($to));
        $username=$this->input->post('username');
        $phone=$this->input->post('phone');
        $bono=$this->input->post('bookingno');
        $bookingno= str_replace("B00","",$bono);
            
        if($_POST){
           if($username!='' && $phone!='' && $bookingno!='')
           {

               $data['bookingno']='B00'.$bookingno;
               $data['username']=$username;
               $data['phone']=$phone;
               $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
               $data['listbooking']=$re->result_array(); 
           }
           else if($username!='' && $phone!='' && $bookingno=='')
           {
               $data['username']=$username;
               $data['phone']=$phone;
               $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."'");
               $data['listbooking']=$re->result_array(); 
           }
           else if($username!='' && $phone=='' && $bookingno!='')
           {

               $data['bookingno']='B00'.$bookingno;
               $data['username']=$username;
               $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
               $data['listbooking']=$re->result_array(); 
           }
          else if($username!='' && $phone=='' && $bookingno=='')
           {
               $data['username']=$username;
               $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' ");
               $data['listbooking']=$re->result_array(); 
           }
           else if($username=='' && $phone!='' && $bookingno!='')
           {
               $data['bookingno']='B00'.$bookingno;
               $data['phone']=$phone;
               $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
               $data['listbooking']=$re->result_array(); 
           }
           else if($username=='' && $phone!='' && $bookingno=='')
           {
               $data['phone']=$phone;
               $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."'");
               $data['listbooking']=$re->result_array(); 
           }
           else if($username=='' && $phone=='' && $bookingno!='')
           {
               $data['bookingno']='B00'.$bookingno;
               $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
               $data['listbooking']=$re->result_array(); 
           }
           else if($username=='' && $phone=='' && $bookingno=='')
           {
               $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' ");
               $data['listbooking']=$re->result_array(); 
           }
           else{
                 $data["listbooking"] = $this->App->getPerticularRecord('tbl_booking', 'ClubId', $id);
           }
        }else{

         $data["listbooking"] = $this->App->getPerticularRecord('tbl_booking', 'ClubId', $id);
       }        
        $this->load->view('front/booking/bookingconfirm', $data);
    }
    public function cancelBooking()
    {
        $this->App->checkVendorAuthenticate();
        $id = $this->session->userdata['vendorauth']['Id'];
        
        $dates=$this->input->post('reservation');
        $o=explode('-', $dates);
        $fromt=$o[0];
        $to=$o[1];
        $fromdate = date('Y-m-d', strtotime($fromt));
        $todate = date('Y-m-d', strtotime($to));
        $username=$this->input->post('username');
        $phone=$this->input->post('phone');
        $bono=$this->input->post('bookingno');
        $bookingno= str_replace("B00","",$bono);           
            
        if($_POST){
            if($username!='' && $phone!='' && $bookingno!='')
            {

                $data['bookingno']='B00'.$bookingno;
                $data['username']=$username;
                $data['phone']=$phone;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
                $data['listbooking']=$re->result_array(); 
            }
            else if($username!='' && $phone!='' && $bookingno=='')
            {
                $data['username']=$username;
                $data['phone']=$phone;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."'");
                $data['listbooking']=$re->result_array(); 
            }
            else if($username!='' && $phone=='' && $bookingno!='')
            {

                $data['bookingno']='B00'.$bookingno;
                $data['username']=$username;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
                $data['listbooking']=$re->result_array(); 
            }
           else if($username!='' && $phone=='' && $bookingno=='')
            {
                $data['username']=$username;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' ");
                $data['listbooking']=$re->result_array(); 
            }
            else if($username=='' && $phone!='' && $bookingno!='')
            {
                $data['bookingno']='B00'.$bookingno;
                $data['phone']=$phone;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
                $data['listbooking']=$re->result_array(); 
            }
            else if($username=='' && $phone!='' && $bookingno=='')
            {
                $data['phone']=$phone;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."'");
                $data['listbooking']=$re->result_array(); 
            }
            else if($username=='' && $phone=='' && $bookingno!='')
            {
                $data['bookingno']='B00'.$bookingno;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
                $data['listbooking']=$re->result_array(); 
            }
            else if($username=='' && $phone=='' && $bookingno=='')
            {

                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' ");
                $data['listbooking']=$re->result_array(); 
            }
            else{
                  $data["listbooking"] = $this->App->getPerticularRecord('tbl_booking', 'ClubId', $id);
            }

        }else{

          $data["listbooking"] = $this->App->getPerticularRecord('tbl_booking', 'ClubId', $id);
        }  
          
        $this->load->view('front/booking/bookingcancel', $data);
    }
    public function completeBooking()
    {
        $this->App->checkVendorAuthenticate();
        $id = $this->session->userdata['vendorauth']['Id'];
        
        $dates=$this->input->post('reservation');
        $o=explode('-', $dates);
        $fromt=$o[0];
        $to=$o[1];
        $fromdate = date('Y-m-d', strtotime($fromt));
        $todate = date('Y-m-d', strtotime($to));
        $username=$this->input->post('username');
        $phone=$this->input->post('phone');
        $bono=$this->input->post('bookingno');
        $bookingno= str_replace("B00","",$bono);
            
        if($_POST){
            if($username!='' && $phone!='' && $bookingno!='')
            {

                $data['bookingno']='B00'.$bookingno;
                $data['username']=$username;
                $data['phone']=$phone;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
                $data['listbooking']=$re->result_array(); 
            }
            else if($username!='' && $phone!='' && $bookingno=='')
            {
                $data['username']=$username;
                $data['phone']=$phone;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."'");
                $data['listbooking']=$re->result_array(); 
            }
            else if($username!='' && $phone=='' && $bookingno!='')
            {

                $data['bookingno']='B00'.$bookingno;
                $data['username']=$username;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
                $data['listbooking']=$re->result_array(); 
            }
           else if($username!='' && $phone=='' && $bookingno=='')
            {
                $data['username']=$username;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' ");
                $data['listbooking']=$re->result_array(); 
            }
            else if($username=='' && $phone!='' && $bookingno!='')
            {
                $data['bookingno']='B00'.$bookingno;
                $data['phone']=$phone;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
                $data['listbooking']=$re->result_array(); 
            }
            else if($username=='' && $phone!='' && $bookingno=='')
            {
                $data['phone']=$phone;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."'");
                $data['listbooking']=$re->result_array(); 
            }
            else if($username=='' && $phone=='' && $bookingno!='')
            {
                $data['bookingno']='B00'.$bookingno;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
                $data['listbooking']=$re->result_array(); 
            }
            else if($username=='' && $phone=='' && $bookingno=='')
            {

                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' ");
                $data['listbooking']=$re->result_array(); 
            }
            else{
                  $data["listbooking"] = $this->App->getPerticularRecord('tbl_booking', 'ClubId', $id);
            }
        }else{

          $data["listbooking"] = $this->App->getPerticularRecord('tbl_booking', 'ClubId', $id);
        }  
        $this->load->view('front/booking/bookingcomplete', $data);
    }
    public function rejectBooking()
    {
        $this->App->checkVendorAuthenticate();
        $id = $this->session->userdata['vendorauth']['Id'];
        
        $dates=$this->input->post('reservation');
        $o=explode('-', $dates);
        $fromt=$o[0];
        $to=$o[1];
        $fromdate = date('Y-m-d', strtotime($fromt));
        $todate = date('Y-m-d', strtotime($to));
        $username=$this->input->post('username');
        $phone=$this->input->post('phone');
        $bono=$this->input->post('bookingno');
        $bookingno= str_replace("B00","",$bono);            
        if($_POST){
            if($username!='' && $phone!='' && $bookingno!='')
            {

                $data['bookingno']='B00'.$bookingno;
                $data['username']=$username;
                $data['phone']=$phone;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
                $data['listbooking']=$re->result_array(); 
            }
            else if($username!='' && $phone!='' && $bookingno=='')
            {
                $data['username']=$username;
                $data['phone']=$phone;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."'");
                $data['listbooking']=$re->result_array(); 
            }
            else if($username!='' && $phone=='' && $bookingno!='')
            {

                $data['bookingno']='B00'.$bookingno;
                $data['username']=$username;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
                $data['listbooking']=$re->result_array(); 
            }
           else if($username!='' && $phone=='' && $bookingno=='')
            {
                $data['username']=$username;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and (FirstName like '".$username."' or LastName like '".$username."') and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' ");
                $data['listbooking']=$re->result_array(); 
            }
            else if($username=='' && $phone!='' && $bookingno!='')
            {
                $data['bookingno']='B00'.$bookingno;
                $data['phone']=$phone;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
                $data['listbooking']=$re->result_array(); 
            }
            else if($username=='' && $phone!='' && $bookingno=='')
            {
                $data['phone']=$phone;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and Phone ='".$phone."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."'");
                $data['listbooking']=$re->result_array(); 
            }
            else if($username=='' && $phone=='' && $bookingno!='')
            {
                $data['bookingno']='B00'.$bookingno;
                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' and BookingNo ='".$bookingno."'");
                $data['listbooking']=$re->result_array(); 
            }
            else if($username=='' && $phone=='' && $bookingno=='')
            {

                $re=$this->db->query("select * from tbl_booking where ClubId='".$id."' and BookingDate BETWEEN '".$fromdate."' AND '".$todate."' ");
                $data['listbooking']=$re->result_array(); 
            }
            else{
                  $data["listbooking"] = $this->App->getPerticularRecord('tbl_booking', 'ClubId', $id);
            }

        }else{

          $data["listbooking"] = $this->App->getPerticularRecord('tbl_booking', 'ClubId', $id);
        }
        $this->load->view('front/booking/bookingreject', $data);
    }
    public function deleterequest()
    {
        $this->App->checkVendorAuthenticate();
        $id = $this->input->post('id');
        
        $this->App->deletedata('tbl_booking', 'Id', $id);
        return 1;
    }
    public function approvedrequest()
    {        
        $this->App->checkVendorAuthenticate();             
        $id=$this->input->post('id');
        $bookingdetail = $this->App->getPerticularRecord('tbl_booking', 'Id', $id);
        $clubdetails = $this->App->getPerticularRecord('tbl_vendor', 'Id', $bookingdetail[0]['ClubId']);
        if(!empty($bookingdetail)){
            $arr=array(
                'BookingStatus'=>'1',
            );
        $this->App->update('tbl_booking', 'Id', $id, $arr);
        
        $name = $bookingdetail[0]['FirstName'] . ' ' . $bookingdetail[0]['LastName'];
        $email = $bookingdetail[0]['Email'];
        $phone = $bookingdetail[0]['Phone'];
        $BookingNo = $bookingdetail[0]['BookingNo'];
        $bookingdate = $bookingdetail[0]['BookingDate'];
        $bookingtime = $bookingdetail[0]['BookingTime'];
        $noofpax = $bookingdetail[0]['NoofPax'];
        
        $clubnm = $clubdetails[0]['ClubName'];
        $clbaddress = $clubdetails[0]['Address'].' <br>'.$clubdetails[0]['City'].' - '.$clubdetails[0]['PostCode'].' ,'.$clubdetails[0]['Country'];
        $clubphn = $clubdetails[0]['Phone'];
        $clubemail = $clubdetails[0]['Email'];
        
        
        $url = base_url('sign-in');
        // -- Send email --
        $subject="Confirmed | Booking for ".$clubnm;
        
        $dataemail = array(
			'username'=>$name,
			'clubnm'=>$clubnm,
			'clbaddress'=>$clbaddress,
			'clubemail'=>$clubemail,
			'clubphn'=>$clubphn,
			'BookingNo'=>$BookingNo,
			'bookingdate'=>$bookingdate,
			'bookingtime'=>$bookingtime,
			'noofpax'=>$noofpax,
			'phone'=>$phone,
			'email'=>$email
			
        );
        $message = $this->load->view('email/club_booking_confirm', $dataemail, TRUE);				
							        
        $from_email = $this->config->item('constantEmail');
        $to_email = $email;
        //Load email library 
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: ".$from_email. "\r\n" .
        "CC: ".$clubemail;

        $to=$email;
        mail($to,$subject,$message,$headers);
        
        return 1;
        }
    }
    public function rejectrequest()
    {
        
        $this->App->checkVendorAuthenticate();             
        $id=$this->input->post('id');
        $bookingdetail = $this->App->getPerticularRecord('tbl_booking', 'Id', $id);
        $clubdetails = $this->App->getPerticularRecord('tbl_vendor', 'Id', $bookingdetail[0]['ClubId']);
        if(!empty($bookingdetail)){
            $arr=array(
                'BookingStatus'=>'2',
            );
        $this->App->update('tbl_booking', 'Id', $id, $arr);
        
        
        
        //----------No. of table count pr date------------------------------
         $bookingdetails = $this->App->getPerticularRecord('tbl_booking','Id',$id);
        if(!empty($bookingdetails)){
		   $vid=$bookingdetails[0]['ClubId'];
		   $BookingDate=$bookingdetails[0]['BookingDate'];
		   $q= $this->db->query("select * from tbl_booking_calender where VendorId='".$vid."' and BookingDate='".$BookingDate."' ");
		    $vendordetails = $q->result_array();	
		    if(!empty($vendordetails)){
				$cid = $vendordetails[0]['Id'];
				    $NobTable = $vendordetails[0]['NobTable'];
					$non =$NobTable - 1 ;
					$arraych= array(
					  'NobTable'=>$non,
					  );
					   $this->App->update('tbl_booking_calender', 'Id', $cid, $arraych);
			}
		}
        
        //----------Ended code-----------------------------------------------
        
        $name = $bookingdetail[0]['FirstName'] . ' ' . $bookingdetail[0]['LastName'];
        $email = $bookingdetail[0]['Email'];
        $BookingNo = $bookingdetail[0]['BookingNo'];
        $phone = $bookingdetail[0]['Phone'];
        $bookingdate = $bookingdetail[0]['BookingDate'];
        $bookingtime = $bookingdetail[0]['BookingTime'];
        $noofpax = $bookingdetail[0]['NoofPax'];
        
        $clubnm = $clubdetails[0]['ClubName'];
        $clbaddress = $clubdetails[0]['Address'].' <br>'.$clubdetails[0]['City'].' - '.$clubdetails[0]['PostCode'].' ,'.$clubdetails[0]['Country'];
        $clubphn = $clubdetails[0]['Phone'];
        $clubemail = $clubdetails[0]['Email'];
        
        
        $url = base_url('booking/cancelverify/'.$id);
        // -- Send email --
        $subject="Rejected | Booking for ".$clubnm;
        
        $dataemail = array(
			'username'=>$name,
			'clubnm'=>$clubnm,
			'clbaddress'=>$clbaddress,
			'clubemail'=>$clubemail,
			'clubphn'=>$clubphn,
			'BookingNo'=>$BookingNo,
			'bookingdate'=>$bookingdate,
			'bookingtime'=>$bookingtime,
			'noofpax'=>$noofpax,
			'phone'=>$phone,
			'email'=>$email
			
        );
        $message = $this->load->view('email/club_booking_reject', $dataemail, TRUE);	
        
        $from_email = $this->config->item('constantEmail');
        $to_email = $email;
        //Load email library 
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: ".$from_email. "\r\n" .
        "CC: ".$clubemail;

        $to=$email;
        mail($to,$subject,$message,$headers);
        
         $msg1='Rejected : booking for '.$clubnm .', '.$clbaddress.' '.$name .', Booking No: B00'.$BookingNo.',  Booking Date : '.$bookingdate .' - '.$bookingtime .', No. of Pax - '.$noofpax;
        
        return 1;
        }
    }
    
     public function cancelrequest()
    {
        $this->App->checkVendorAuthenticate();             
        $id=$this->input->post('id');
        $bookingdetail = $this->App->getPerticularRecord('tbl_booking', 'Id', $id);
        $clubdetails = $this->App->getPerticularRecord('tbl_vendor', 'Id', $bookingdetail[0]['ClubId']);
        if(!empty($bookingdetail)){
            $arr=array(
                'BookingStatus'=>'3',
            );
        $this->App->update('tbl_booking', 'Id', $id, $arr);
        //----------No. of table count pr date------------------------------
         $bookingdetails = $this->App->getPerticularRecord('tbl_booking','Id',$id);
        if(!empty($bookingdetails)){
		   $vid=$bookingdetails[0]['ClubId'];
		   $BookingDate=$bookingdetails[0]['BookingDate'];
		   $q= $this->db->query("select * from tbl_booking_calender where VendorId='".$vid."' and BookingDate='".$BookingDate."' ");
		    $vendordetails = $q->result_array();	
		    if(!empty($vendordetails)){
				$cid = $vendordetails[0]['Id'];
				    $NobTable = $vendordetails[0]['NobTable'];
					$non =$NobTable - 1 ;
					$arraych= array(
					  'NobTable'=>$non,
					  );
					   $this->App->update('tbl_booking_calender', 'Id', $cid, $arraych);
			}
		}
        
        //----------Ended code-----------------------------------------------
        
        $name = $bookingdetail[0]['FirstName'] . ' ' . $bookingdetail[0]['LastName'];
        $email = $bookingdetail[0]['Email'];
          $BookingNo = $bookingdetail[0]['BookingNo'];
        $phone = $bookingdetail[0]['Phone'];
        $bookingdate = $bookingdetail[0]['BookingDate'];
        $bookingtime = $bookingdetail[0]['BookingTime'];
        $noofpax = $bookingdetail[0]['NoofPax'];
        
        $clubnm = $clubdetails[0]['ClubName'];
        $clbaddress = $clubdetails[0]['Address'].' <br>'.$clubdetails[0]['City'].' - '.$clubdetails[0]['PostCode'].' ,'.$clubdetails[0]['Country'];
        $clubphn = $clubdetails[0]['Phone'];
        $clubemail = $clubdetails[0]['Email'];
        
        
        $url = base_url('booking/cancelverify/'.$id);
        // -- Send email --
        $subject="Canceled | Booking for ".$clubnm;
         $dataemail = array(
			'username'=>$name,
			'clubnm'=>$clubnm,
			'clbaddress'=>$clbaddress,
			'clubemail'=>$clubemail,
			'clubphn'=>$clubphn,
			'BookingNo'=>$BookingNo,
			'bookingdate'=>$bookingdate,
			'bookingtime'=>$bookingtime,
			'noofpax'=>$noofpax,
			'phone'=>$phone,
			'email'=>$email
			
        );
        $message = $this->load->view('email/club_booking_cancel', $dataemail, TRUE);	
        
        $from_email = $this->config->item('constantEmail');
        $to_email = $email;
        //Load email library 
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: ".$from_email. "\r\n" .
        "CC: ".$clubemail;

        $to=$email;
        mail($to,$subject,$message,$headers);
               
        return 1;
        }
    }
    
    public function completerequest()
    {        
        $this->App->checkVendorAuthenticate();             
        $id=$this->input->post('id');
        $bookingdetail = $this->App->getPerticularRecord('tbl_booking', 'Id', $id);
        $clubdetails = $this->App->getPerticularRecord('tbl_vendor', 'Id', $bookingdetail[0]['ClubId']);
        if(!empty($bookingdetail)){
            $arr=array(
                'BookingStatus'=>'5',
                  'CompletedDate'=>date('Y-m-d H:i:s'),

            );
        $this->App->update('tbl_booking', 'Id', $id, $arr);
        
        //----------No. of table count pr date------------------------------
         $bookingdetails = $this->App->getPerticularRecord('tbl_booking','Id',$id);
        if(!empty($bookingdetails)){
		   $vid=$bookingdetails[0]['ClubId'];
		   $BookingDate=$bookingdetails[0]['BookingDate'];
		   $q= $this->db->query("select * from tbl_booking_calender where VendorId='".$vid."' and BookingDate='".$BookingDate."' ");
		    $vendordetails = $q->result_array();	
		    if(!empty($vendordetails)){
				$cid = $vendordetails[0]['Id'];
				    $NobTable = $vendordetails[0]['NobTable'];
					$non =$NobTable - 1 ;
					$arraych= array(
					  'NobTable'=>$non,
					  );
					   $this->App->update('tbl_booking_calender', 'Id', $cid, $arraych);
			}
		}
        
        //----------Ended code-----------------------------------------------
        
        $name = $bookingdetail[0]['FirstName'] . ' ' . $bookingdetail[0]['LastName'];
        $email = $bookingdetail[0]['Email'];
        $phone = $bookingdetail[0]['Phone'];
        $BookingNo = $bookingdetail[0]['BookingNo'];
        $bookingdate = $bookingdetail[0]['BookingDate'];
        $bookingtime = $bookingdetail[0]['BookingTime'];
        $noofpax = $bookingdetail[0]['NoofPax'];
        
        $clubnm = $clubdetails[0]['ClubName'];
        $clbaddress = $clubdetails[0]['Address'].' <br>'.$clubdetails[0]['City'].' - '.$clubdetails[0]['PostCode'].' ,'.$clubdetails[0]['Country'];
        $clubphn = $clubdetails[0]['Phone'];
        $clubemail = $clubdetails[0]['Email'];
        
        
        $url = base_url('booking/cancelverify/'.$id);
        // -- Send email --
        $subject="Completed | Booking for ".$clubnm;
         $dataemail = array(
			'username'=>$name,
			'clubnm'=>$clubnm,
			'clbaddress'=>$clbaddress,
			'clubemail'=>$clubemail,
			'clubphn'=>$clubphn,
			'BookingNo'=>$BookingNo,
			'bookingdate'=>$bookingdate,
			'bookingtime'=>$bookingtime,
			'noofpax'=>$noofpax,
			'phone'=>$phone,
			'email'=>$email
			
        );
        $message = $this->load->view('email/club_booking_complete', $dataemail, TRUE);	
        
      
        $from_email = $this->config->item('constantEmail');
        $to_email = $email;
        //Load email library 
               
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: ".$from_email. "\r\n" .
        "CC: ".$clubemail;

        $to=$email;
        mail($to,$subject,$message,$headers);
	       
        return 1;
        }   
    }
    public function jsonfun($msg1,$msg2,$phn1,$phn2)
    {
        $customer=array(
            "message"=>$msg1,
            "to"=>array($phn1),
        );
        $vendor=array(
            "message"=>$msg2,
            "to"=>array($phn2),
        );
        $main=array($customer,$vendor);
        $re=array(
            "sender"=>"TBLFST",
            "route"=>"4",
            "country"=>"91",
            "sms"=>$main,
        );
        $f= json_encode($re);
        return $f;
    }
    
    public function tablebookingview()
    {
		$this->App->checkVendorAuthenticate();
        $vid = $this->session->userdata['vendorauth']['Id'];
        $data['listbook'] = $this->App->getPerticularRecord('tbl_booking_calender', 'VendorId', $vid);
        $numbook = $this->App->getPerticularRecord('tbl_clublayout', 'VendorId', $vid);
		$data['totaltable']=$numbook[0]['NumTable'];
        $this->load->view('front/booking/tablebookinglist', $data);
	}
	public function checkbooingupdates()
	{
	   $cdatechekc=date('Y-m-d');
       $currentdate = $this->input->post('data');
       $currenttime = $this->input->post('time');
       $noofmember = $this->input->post('noofmember');
       $vid = $this->input->post('vid');
        if ($_POST) {
			
            $times=$this->getcurrenttime($vid,$currentdate);
            $d=explode('-',$times);
            $Start=$d[0];
            $End=$d[1];
            $etime = date('H:i:s',strtotime($End));
            $stime = date('H:i:s',strtotime($Start));
            $cctime = date('H:i:s',strtotime($currenttime));

            $bookdt = $this->input->post('time');
             $th=$this->input->post('date');
            $sdatet= date('Y-m-d', strtotime($th));
            
            $bookdet = $this->App->getPerticularRecord('tbl_clublayout', 'VendorId', $vid);
            $totbooking = $bookdet[0]['NumTable'];
            
            $querycal= $this->db->query("select * from tbl_booking_calender where VendorId='".$vid."' and BookingDate='".$currentdate."' ");
            //echo $this->db->last_query();die;
            $calendor = $querycal->result_array();
            $numrow = $querycal->num_rows();
            $err = '';
            
            if($numrow > 0){
				$r = $calendor[0]['NobTable'];
				 $totbooking = $totbooking;
				
				if($r > $totbooking){
					//echo '123';die;
				    $err = 'All Tables already reserved for a day.Please try to reserve table for another day.<br>';	
				     $data['err']='2';
				    $data['error']=$err;	
				   
				    echo json_encode($data);
				    
				}else{
					if (($cctime > $stime) || ($cctime < $etime))
					{	
						$clubdetails = $this->App->getPerticularRecord('tbl_vendor', 'Slug', $slug);
						$vid=$clubdetails[0]['Id'];

						$hrsdetails = $this->App->getPerticularRecord('tbl_clublayout', 'VendorId', $vid);
						$hr=$hrsdetails[0]['PerChildPrice'];
						
							date_default_timezone_set('Asia/Kolkata');
							$n_cur_dt = date('Y-m-d');
							$n_cur_time1 = date('H:i A', time());
							$n_cur_time = date("g:i A");
							$gettime = date("H:i A", strtotime($n_cur_time)); 
							$j='+'.$hr.' hours';
							$currenttimefind=date('H:i A',strtotime($j,strtotime($gettime)));
							$currenttime=date('H:i A',strtotime($currenttime));
							//echo $currentdate.'--'.$n_cur_dt;die;
							if($currentdate==$n_cur_dt){
								if($currenttimefind > $currenttime)	{
									$err .='Table booking time closed before '.$hr .' hours.<br>';
									  $data['err']='2';
									$data['error']=$err;	
									echo json_encode($data);
								}else{
								}
							}
						
					}else if (($cctime > $stime) && ($cctime < $etime))
					{	//echo 'as1';die;
						$clubdetails = $this->App->getPerticularRecord('tbl_vendor', 'Slug', $slug);
						$vid=$clubdetails[0]['Id'];

						$hrsdetails = $this->App->getPerticularRecord('tbl_clublayout', 'VendorId', $vid);
						$hr=$hrsdetails[0]['PerChildPrice'];
						
							date_default_timezone_set('Asia/Kolkata');
							$n_cur_dt = date('Y-m-d');
							$n_cur_time1 = date('H:i A', time());
							$n_cur_time = date("g:i A");
							$gettime = date("H:i A", strtotime($n_cur_time)); 
							$j='+'.$hr.' hours';
							$currenttimefind=date('H:i A',strtotime($j,strtotime($gettime)));
							$currenttime=date('H:i A',strtotime($currenttime));
							if($currentdate==$n_cur_dt){
								if($currenttimefind > $currenttime)	{
									$err .='Table booking time closed before '.$hr .' hours.<br>';
									$data['err']='2';
									$data['error']=$err;	
									echo json_encode($data);
								}else{
								}
							}
						
					}
					else
					{//	echo '124d';die;
					  $err .='Please Select Opening to closing time schedule';
					    $data['err']='2';
						$data['error']=$err;	
						echo json_encode($data);
					}				
				}
						
				
			}else{
				if($err!=''){
				    $data['err']='2';
				    $data['error']=$err;
				    echo json_encode($data);
				}else{
					$data['succ']='1';
					$arraydata = array(
						'sesdates' => $this->input->post('data'),
						'sestime' =>$this->input->post('time'),
						'sesnoofmember' => $this->input->post('noofmember')
					);                
					$this->session->set_userdata('bookingnewsession', $arraydata);
					echo json_encode($data);
				}	
			}
            

        
            
         }
       
	}
}


