<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contact extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->helper('new_helper');
    }
    public function index()
    {
        $this->form_validation->set_rules('fname', 'First Name', 'required');
        $this->form_validation->set_rules('lname', 'Last Name', 'required');
        $this->form_validation->set_rules('cemail', 'Email', 'required');
        $this->form_validation->set_rules('phone', 'Phone', 'required');
        $this->form_validation->set_rules('subject', 'Subject', 'required');
        $this->form_validation->set_rules('message', 'Message', 'required');
        
        if ($this->form_validation->run() == FALSE || $err != '') {
            if (validation_errors() != '' || $err != '') {
                $data['error'] = validation_errors() . $err;
            }
        } else {
            $arr = array(
                'FirstName' => $this->input->post('fname'),
                'LastName' => $this->input->post('lname'),
                'Email' => $this->input->post('cemail'),
                'Phone' => $this->input->post('phone'),
                'Subject' => $this->input->post('subject'),
                'Message' => $this->input->post('message'),
                'Created' => date('Y-m-d')
            );
            $this->App->insertdata('tbl_contact', $arr);
            $email = $this->input->post('cemail');
            $name=$this->input->post('fname').' '.$this->input->post('lname');
            $phone = $this->input->post('phone');
            $subject= $this->input->post('subject');
            $msg= $this->input->post('message');

		    $dataemail = array(
				'name'=>$name,
				'phone'=>$phone,
				'subject'=>$subject,
				'msg'=>$msg
				
			);
			$message = $this->load->view('email/contact_customer', $dataemail, TRUE);	
			 
            $from_email = $this->config->item('constantEmail');
            $to_email   = $email;
            //------mail function ------------------------------------------

            $to = $this->config->item('constantEmail');
            $subject = "Thank you for Contact us with Tablefast.com";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= "From: ".$to;
            $to1=$email;
            mail($to1,$subject,$message,$headers);
            
              $dataemail = array(
				'name'=>$name,
				'phone'=>$phone,
				'subject'=>$subject,
				'msg'=>$msg
				
			);
			$message1 = $this->load->view('email/contact_admin', $dataemail, TRUE);	
            
            $to = $this->config->item('constantEmail');
            mail($to,$subject,$message1,$headers);
            //--------------------------------------------------
            $data['success'] = 'Thank you for Contact us. We will get back soon.';
        }
        $this->load->view('front/include/header');
        $this->load->view('front/contact', $data);
        $this->load->view('front/include/footer');
    }
  
}
