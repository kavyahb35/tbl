<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer extends CI_Controller
{
    /*  Note : booking table : 
        column Status :
        0 : only fill form but not confirm booking customer site
        1 : Customer boking confirm
        column BookingStatus :
        0 : Processing Request
        1 : Confirm booking (Vendor approve booking)
        2 : vendor reject booking
        3 : customer cancel booking
        4 : customer modify booking
        5 : complete Booking
    */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->helper('new_helper');
    }

    public function demologinfb(){

        require_once(APPPATH.'libraries/Facebook/config.php');
        require_once(APPPATH.'libraries/Facebook/facebook.php');
        require_once(APPPATH.'libraries/Facebook/storedata.php');
        $user = $facebook->getUser();		
        $this->load->view('front/customer/login_code');
    }
    public function fbcallbk(){
        $username=$this->input->post('username');
        $email=$this->input->post('email');
        $fbkey=$this->input->post('fbkey');
        if($fbkey!='' && $username!=''){
            $emailcheck=$this->App->getPerticularRecord('tbl_customer','Fbloginkey',$fbkey);
            if(!empty($emailcheck)){
                $arr=array(
                    'Fbloginkey'=>$fbkey,
                  );    
                $this->App->update('tbl_customer','Id',$emailcheck[0]['Id'],$arr); 
                 $arraydata = array(
                'Name' => $emailcheck[0]['FirstName'],
                'Id' => $emailcheck[0]['Id'],
                'Email' => $emailcheck[0]['Email']
                );
                $this->session->set_userdata('customerauth', $arraydata);
                echo json_encode('3');
            }else{
                $clbname = $username;
                $trim    = trim($clbname);
                $ow      = strtolower($trim);
                $string  = str_replace(' ', '-', $ow);
                $str     = preg_replace('/\s+/', '-', $string);
                $chkslug = $this->App->checkExist('tbl_customer', 'Slug', $str);
                if ($chkslug == '1') {
                    $r    = rand(1, 4);
                    $slug = $str . $r;
                } else {
                    $slug = $str;
                }
                $name=$username;
                 $arr=array(
                  'Email'=>$email,
                  'FirstName'=>$username,
                  'Fbloginkey'=>$fbkey,
                  'Status'=>'0',
                  'Created'=>date('Y-m-d'),
                  'Slug'=>$slug,
                );    

                $ids=$this->App->insertdata('tbl_customer',$arr);
                $emailcheck=$this->App->getPerticularRecord('tbl_customer','Id',$ids);
                $arraydata = array(
                'Name' => $emailcheck[0]['FirstName'],
                'Id' => $emailcheck[0]['Id'],
                'Email' => $emailcheck[0]['Email']
                );
                $this->session->set_userdata('customerauth', $arraydata);
                echo json_encode('1');
                }
        }else{
           echo json_encode('2');
        }
    }

    public function loginwithfb()
    {
       echo '12323'; 
    }
    public function index()
    {
        require_once(APPPATH.'libraries/Google/autoload.php');
        
        $vendorid=$this->session->userdata['vendorauth']['Id'];  
        $customerid=$this->session->userdata['customerauth']['Id'];  
        
        if($vendorid!='' && $customerid!=''){ redirect();}
         if($customerid==''){
        
        $this->form_validation->set_rules('contact', 'Email Id', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required');
        if ($_POST) {
            $contact    = $this->input->post('contact');
            $password = md5($this->input->post('password'));
            
            $phncheck=$this->App->checkExist('tbl_customer', 'Email', $contact);
            if($phncheck=='1'){
                $chkauth  = $this->App->passwordCheckingcustomer('tbl_customer', 'Email', 'Password', $contact, $password);
                
                if ($chkauth == '0') {
                    $err = 'Password does not match.';
                }
            }else{
                $passwordcheck=$this->App->checkExist('tbl_customer', 'Password', $password);
                if($passwordcheck=='1'){
                $err = 'Email Id not Valid.';
                }else{
                    $err = 'Email Id and password does not Valid.';
                }
            }
            
        }
        if ($this->form_validation->run() == FALSE || $err != '') {
            if (validation_errors() != '' || $err != '') {
                $data['error'] = validation_errors() . $err;
            }
        } else {    
            if (!empty($chkauth)) {
                $arraydata = array(
                    'Name' => $chkauth[0]['FirstName'],
                    'Id' => $chkauth[0]['Id'],
                    'Email' => $chkauth[0]['Email']
                );
                $this->session->set_userdata('customerauth', $arraydata);
                $apro = array(
                            'Email'=>$chkauth[0]['Email'],
                            'Time'=>date('Y-m-d H:i A'),
                            'IP Address'=>$this->input->server('REMOTE_ADDR'),

                            );
                $apro=json_encode($apro);
                log_message('customer', "Customer login : ".$apro);
                
                $clubid=$this->session->userdata['bookevent']['clubid']; 
                 $evnetid=$this->session->userdata['bookevent']['evnetid']; 
                  $typeid=$this->session->userdata['bookevent']['typeid']; 
                if($clubid!='' && $evnetid!='' && $typeid!=''){
					redirect('events/book/'.$clubid.'/'.$evnetid.'/'.$typeid);
				}else{
					redirect('dashboard');
				}
                
            }
        }
        $this->load->view('front/include/header');
        $this->load->view('front/customer/login',$data);
        $this->load->view('front/include/footer');
	}
        if($vendorid!=''){ redirect('vendor-dashboard'); }
	if($customerid!=''){ redirect('dashboard'); }
    }
    
    public function register()
    {   
        require_once(APPPATH.'libraries/Google/autoload.php');
        $vendorid=$this->session->userdata['vendorauth']['Id'];  
        $customerid=$this->session->userdata['customerauth']['Id'];  
        
        if($vendorid!='' && $customerid!=''){ redirect();}
        if($customerid==''){
        $this->form_validation->set_rules('lastname', 'Last Name', 'required');
        $this->form_validation->set_rules('phone', 'Phone number', 'required');
        $this->form_validation->set_rules('firstname', 'First Name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('cpassword', 'Confirm Password', 'required|matches[password]');
        if ($_POST) {
            $phone    = $this->input->post('phone');
            $chkphone = $this->App->checkExist('tbl_customer', 'Phone', $phone);
            $email    = $this->input->post('email');
            $chkemail = $this->App->checkExist('tbl_customer', 'Email', $email);
            
            if ($chkemail == '1') {                
                $err = 'Email already Exist.' . '<br>';
            }
            if ($chkphone == '1') {                
                $err1 = 'Phone number already Exist.' . '<br>';
            }
            
            $password = $this->input->post('password');
            $jk       = $this->App->password_strength_check($password);
            if ($jk == '0') {
                $err2 = 'Minimum 8 char required. Password must contain one lowercase letter, one capital (uppercase) letter & one number.';
            }
            $clbname = $this->input->post('firstname').'-'.$this->input->post('lastname');
            $trim    = trim($clbname);
            $ow      = strtolower($trim);
            $string  = str_replace(' ', '-', $ow);
            $str     = preg_replace('/\s+/', '-', $string);
            $chkslug = $this->App->checkExist('tbl_customer', 'Slug', $str);
            if ($chkslug == '1') {
                $r    = rand(1, 4);
                $slug = $str . $r;
            } else {
                $slug = $str;
            }
            
        }
        if ($this->form_validation->run() == FALSE || $err != '' || $err1 != '' || $err2 != '') {
            if (validation_errors() != '' || $err != '' || $err1 != '' || $err2 != '') {
                $data['error'] = validation_errors() . $err.$err1.$err2;
            }
        } else {
            $otp=rand('2324','4568');
            $arr  = array(
                'FirstName' => $this->input->post('firstname'),
                'LastName' => $this->input->post('lastname'),
                'Email' => $this->input->post('email'),
                'Phone' => $this->input->post('phone'),
                'Password' => md5($this->input->post('password')),
                'Created' => date('Y-m-d'),
                'Status' => '0',
                'Slug' => $slug,
                'OTP'=>$otp,
            );
            $iid  = $this->App->insertdata('tbl_customer', $arr);
            $name = $this->input->post('firstname') . ' ' . $this->input->post('lastname');
            $email   = $this->input->post('email');
            
            $succurl=base_url('customer/verification/'.$iid.'/'.$otp);
            $msg=$otp.' is your tablefast verification code enjoy';
            
            $dataemail = array(
				'username'=>$name,
				'url'=>$succurl
				
			);
			$message = $this->load->view('email/customer_verification', $dataemail, TRUE);	
            
            $from_email = $this->config->item('constantEmail');
            $to_email   = $email;
            
            //Load email library 
            $this->load->library('email');
            
            $this->email->from($from_email, 'Tablefast.com');
            $this->email->to($to_email);
            $this->email->subject('OTP Verification for Register');            
            $this->email->message($message);            
            $this->email->send();           
            
            $data['iid']=$iid;
            $data['success'] = 'Thank you for register. Please check your mail for verification.';
        }
        
        $this->load->view('front/include/header');
        $this->load->view('front/customer/register',$data);
        $this->load->view('front/include/footer');
        }
        if($vendorid!=''){ redirect('vendor-dashboard'); }
	if($customerid!=''){ redirect('dashboard'); }
    }
    public function verification($id,$otp)
    {
        if($id!='' && $otp!=''){
             $cusdetail=$this->App->passwordChecking('tbl_customer','Id','OTP',$id,$otp);
             if(!empty($cusdetail)){
                 $arr=array(
                 'Status'=>'1',
                 'OTP'=>'',
                 );     
                 $this->App->update('tbl_customer','Id',$id,$arr);
                 $this->load->view('front/include/header');
                 $this->load->view('front/customer/successverify');
                 $this->load->view('front/include/footer');
             }else{
                
            $this->load->view('front/include/header');
            $this->load->view('front/customer/cancelverify');
            $this->load->view('front/include/footer');     
            }
             
        }else{
            $this->load->view('front/include/header');
            $this->load->view('front/customer/cancelverify');
            $this->load->view('front/include/footer');     
        }
        
    }
    public function loginwithphone()
    {        
        $phone=$this->input->post('phone');
        $customerdetail = $this->App->getPerticularRecord('tbl_customer', 'Email', $phone);
        if(!empty($customerdetail)){
            $cid=$customerdetail[0]['Id'];
            $phn=$customerdetail[0]['Phone'];
            $email=$customerdetail[0]['Email'];
            $name=$customerdetail[0]['FirstName'].' '.$customerdetail[0]['LastName'];
            $otp = rand('2324','4568');
            $arr=array(
                'OTP'=>$otp,
            );
            $this->App->update('tbl_customer', 'Id', $cid, $arr);
            $msg=$otp.' is your tablefast verification code enjoy';
           
           $url = base_url('customer/resetpasswordemail/' . $cid.'/'.$otp);
           
            $dataemail = array(
				'username'=>$name,
				'url'=>$succurl
				
			);
			$message = $this->load->view('email/customer_resetpassword', $dataemail, TRUE);	

            $from_email = $this->config->item('constantEmail');
            $to_email   = $email;
            //Load email library 
            
            
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= "From: ".$from_email. "\r\n";


            $to=$email;
            $subject="Forgot Password";
            mail($to,$subject,$message,$headers);
            
            $data['succ']='1';
            $data['cid']=$cid;
            echo json_encode($data);
        }else{
            echo json_encode('2');
        }        
    }
    public function loginotpverify()
    {
        $otp=$this->input->post('otp');
        $cid=$this->input->post('cid');
        
        $customerdetail = $this->App->passwordChecking('tbl_customer', 'Id','OTP', $cid,$otp);
        if(!empty($customerdetail)){
            $cid=$customerdetail[0]['Id'];
            $phn=$customerdetail[0]['Phone'];
            $email=$customerdetail[0]['Email'];
            $FirstName=$customerdetail[0]['FirstName'];
            $LastName=$customerdetail[0]['LastName'];
           
            $data['succ']='1';
            echo json_encode('1');
        }else{
            echo json_encode('2');
        }
    }
    public function dashboard()
    {
        
        $this->App->checkCustomerAuthenticate();
        $id = $this->session->userdata['customerauth']['Id'];
        $data["listbooking"] = $this->App->passwordChecking('tbl_booking', 'CustomerId','BookingStatus',$id,'0');
        $this->load->view('front/include/header');
        $this->load->view('front/customer/dashboard',$data);
        $this->load->view('front/include/footer');
    }
    public function logout()
    {       
        $vendorid=$this->session->userdata['customerauth']['Email'];  
        $apro = array(
            'Email'=>$vendorid,
            'Time'=>date('Y-m-d H:i A'),
            'IP Address'=>$this->input->server('REMOTE_ADDR'),
            
            );
           $apro=json_encode($apro);
            
        log_message('customer', "Customer Louout : ".$apro);
        $this->session->unset_userdata('customerauth');
        $this->session->unset_userdata('bookevent');
        unset($_SESSION['access_token']);
		session_destroy(); 
        redirect();
    }
    public function changepassword()
    {
        $this->App->checkCustomerAuthenticate();
        $uid = $this->session->userdata['customerauth']['Id'];
        $this->form_validation->set_rules('oldpassword', 'Old Password', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('cpassword', 'Confirm Password', 'required|matches[password]');
        
        $oldpassword = md5($this->input->post('oldpassword'));
        $password    = $this->input->post('password');
        $jk          = $this->App->password_strength_check($password);
        if ($_POST) {
            $chkauth = $this->App->passwordChecking('tbl_customer', 'Id', 'Password', $uid, $oldpassword);
            if ($chkauth == '0') {
                $err1 = ' Password does not match.';
            }
            
            if ($jk == '0') {
                $err = 'Minimum 8 char required. Password must contain one lowercase letter, one capital (uppercase) letter & one number.';
            }
        }
        
        if ($this->form_validation->run() == FALSE || $err != '' || $err1 != '') {
            if (validation_errors() != '' || $err != '' || $err1 != '') {
                $data['error'] = validation_errors() . $err . $err1;
            }
        } else {
            $arr = array(
                'Password' => md5($this->input->post('password'))
            );
            $this->App->update('tbl_customer', 'Id', $uid, $arr);
            $data['success'] = 'Change Password Successfully.';
        }
       
        $this->load->view('front/include/header');
        $this->load->view('front/customer/changepassword', $data);
        $this->load->view('front/include/footer');
    }
    public function profile()
    {
        $this->App->checkCustomerAuthenticate();
        $uid = $this->session->userdata['customerauth']['Id'];
        $this->form_validation->set_rules('firstname', 'First Name', 'required');
        $this->form_validation->set_rules('address', 'Address', 'required');
        $this->form_validation->set_rules('yourself', 'yourself', 'required');
        $this->form_validation->set_rules('email', 'email', 'required|valid_email');
        $this->form_validation->set_rules('phone', 'phone', 'required');
        if ($_POST) {
            $phone    = $this->input->post('phone');
            $chkphone = $this->App->checkExistEdit('tbl_customer', 'Phone', $phone,'Id',$uid);
            $email    = $this->input->post('Email');
            $chkemail = $this->App->checkExistEdit('tbl_customer', 'Email', $email,'Id',$uid);
            
            if ($chkemail == '1') {                
                $err = 'Email already Exist.' . '<br>';
            }
            if ($chkphone == '1') {                
                $err1 = 'Phone number already Exist.' . '<br>';
            }
        }
        
        if ($this->form_validation->run() == FALSE || $err != '' || $err1 != '') {
            if (validation_errors() != '' || $err != '' || $err1 != '') {
                $data['error'] = validation_errors() . $err . $err1;
            }
        } else {
             if (!empty($_FILES['image']['name'])) {
            $config['upload_path']   = 'assets/customerprofile/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['file_name']     = $_FILES['image']['name'];
            
            //Load upload library and initialize configuration
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            
               if ($this->upload->do_upload('image')) {
                    $uploadData = $this->upload->data();
                    $picture    = $uploadData['file_name'];
                }
            } else {
                $picture = $this->input->post('oldimg');
            }
           
            $arr = array(
                'Email' => $this->input->post('email'),
                'Phone' => $this->input->post('phone'),
                'FirstName' => $this->input->post('firstname'),
                'LastName' => $this->input->post('lastname'),
                'ProfileImage' =>$picture,
                'Address' => $this->input->post('address'),
                'Yourself' => $this->input->post('yourself'),
                'Status'=>'1',
                
            );
            $this->App->update('tbl_customer', 'Id', $uid, $arr);
            $data['success'] = 'Update Profile Successfully.';
        }
        $cid = $this->session->userdata['customerauth']['Id'];
        $data['profiles']=$this->App->getPerticularRecord('tbl_customer','Id',$cid);
        $this->load->view('front/include/header');
        $this->load->view('front/customer/profile', $data);
        $this->load->view('front/include/footer');
    }
     public function requestBooking()
    {
        $this->App->checkCustomerAuthenticate();
        $id = $this->session->userdata['customerauth']['Id'];
        $data["listbooking"] = $this->App->passwordChecking('tbl_booking', 'CustomerId','BookingStatus',$id,'0');
        $this->load->view('front/include/header');
        $this->load->view('front/customer/booking/bookingrequest', $data);
        $this->load->view('front/include/footer');
    }
    public function confirmBooking()
    {
        $this->App->checkCustomerAuthenticate();
        $id = $this->session->userdata['customerauth']['Id'];
        $data["listbooking"] = $this->App->passwordChecking('tbl_booking', 'CustomerId','BookingStatus',$id,'1');
        $this->load->view('front/include/header');
        $this->load->view('front/customer/booking/bookingconfirm', $data);
        $this->load->view('front/include/footer');
    }
    public function cancelBooking()
    {
        $this->App->checkCustomerAuthenticate();
        $id = $this->session->userdata['customerauth']['Id'];
        $data["listbooking"] = $this->App->passwordChecking('tbl_booking', 'CustomerId','BookingStatus',$id,'3');
        $this->load->view('front/include/header');
        $this->load->view('front/customer/booking/bookingcancel', $data);
        $this->load->view('front/include/footer');
    }
    public function completeBooking()
    {
        $this->App->checkCustomerAuthenticate();
        $id = $this->session->userdata['customerauth']['Id'];
        $data["listbooking"] = $this->App->passwordChecking('tbl_booking', 'CustomerId','BookingStatus',$id,'5');
        $this->load->view('front/include/header');
        $this->load->view('front/customer/booking/bookingcomplete', $data);
        $this->load->view('front/include/footer');
    }
    public function rejectBooking()
    {
        $this->App->checkCustomerAuthenticate();
        $id = $this->session->userdata['customerauth']['Id'];
        $data["listbooking"] = $this->App->passwordChecking('tbl_booking', 'CustomerId','BookingStatus',$id,'2');
        $this->load->view('front/include/header');
        $this->load->view('front/customer/booking/bookingreject', $data);
        $this->load->view('front/include/footer');
    }
    
    public function cancel($id='')
    {
        
       $this->App->checkCustomerAuthenticate();
       $this->form_validation->set_rules('cancelreason', 'Reason', 'required');
       
       if ($this->form_validation->run() == FALSE || $err != ''|| $err1 != '') {
            if (validation_errors() != '' || $err != ''|| $err1 != '') {
                $data['error'] = validation_errors() . $err.$err1;
            }
        } else {
            
            $otp = rand('2324','4568');
            $booking=array(
                   'CancelReason'=>$this->input->post('cancelreason'),
                   'CancelDate'=>date('Y-m-d H:i'),
                   'BookingStatus'=>'3',
                 );
            $this->App->update('tbl_booking','Id',$id,$booking);
          
             $bookindetail=$this->App->getPerticularRecord('tbl_booking', 'Id', $id);
                $phn=$bookindetail[0]['Phone'];
                $email=$bookindetail[0]['Email'];
                
                $name = $bookingdetail[0]['FirstName'] . ' ' . $bookingdetail[0]['LastName'];
                $BookingNo = $bookingdetail[0]['BookingNo'];
                $bookingdate = $bookingdetail[0]['BookingDate'];
                $bookingtime = $bookingdetail[0]['BookingTime'];
                $noofpax = $bookingdetail[0]['NoofPax'];
                $CancelReason = $bookingdetail[0]['CancelReason'];
                $CancelDate = $bookingdetail[0]['CancelDate'];
                
                $clubdetails = $this->App->getPerticularRecord('tbl_vendor', 'Id', $bookingdetail[0]['ClubId']);
                $clubnm = $clubdetails[0]['ClubName'];
                $clbaddress = $clubdetails[0]['Address'].' <br>'.$clubdetails[0]['City'].' - '.$clubdetails[0]['PostCode'].' ,'.$clubdetails[0]['Country'];
                $clubphn = $clubdetails[0]['Phone'];
                $clubemail = $clubdetails[0]['Email'];
                
                
                
                $msg='Your Booking Request is cancel.';
                //------send sms --------------------------------
            
                $phone = '91'.$phn;
                $clubphone = '91'.$clubphn;
                $sms=$msg;
               
                $email = $this->input->post('email');
                
                 $dataemail = array(
					'username'=>$name,
					'clubnm'=>$clubnm,
					'clbaddress'=>$clbaddress,
					'clubemail'=>$clubemail,
					'clubphn'=>$clubphn,
					'BookingNo'=>$BookingNo,
					'bookingdate'=>$bookingdate,
					'bookingtime'=>$bookingtime,
					'noofpax'=>$noofpax,
					'phone'=>$phone,
					'email'=>$email,
					'CancelDate'=>$CancelDate,
					'CancelReason'=>$CancelReason
					
				);
				$message = $this->load->view('email/club_booking _cancelrequest', $dataemail, TRUE);
            
            $from_email = $this->config->item('constantEmail');
            $to_email   = $email;
            //Load email library 
            
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= "From: ".$from_email. "\r\n" .
            "CC: ".$clubemail;


            $to=$email;
            $subject="Cancel Booking Request";
            mail($to,$subject,$message,$headers);

            $data['success']='Cancel your booking.';
            redirect('cancelled');
        }
       
       $bookindetail=$this->App->getPerticularRecord('tbl_booking', 'Id', $id);
       $data['modify']=$bookindetail;
         $data['clubdetails'] = $this->App->getPerticularRecord('tbl_vendor', 'Id', $modify[0]['ClubId']);
       $this->load->view('front/include/header');
       $this->load->view('front/customer/cancelbooking', $data);
       $this->load->view('front/include/footer'); 
    }
    
    public function modify_booking($id='')
    {         
        $this->App->checkCustomerAuthenticate();
        $cdatechekc=date('Y-m-d');
        $currentdate=$this->input->post('date');
        $currenttime=$this->input->post('myDatepicker1');        
        $noofmember=$this->input->post('noofmember');
        
        $this->form_validation->set_rules('date', 'Booking Date', 'required');
        $this->form_validation->set_rules('myDatepicker1', 'Booking Time', 'required');
        $this->form_validation->set_rules('noofmember', 'No. of Pax', 'required');
        $this->form_validation->set_rules('firstname', 'First Name', 'required');
       // $this->form_validation->set_rules('lastname', 'Last Name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('phone', 'Phone', 'required');
        
        if ($_POST) {
                $otp = rand('2324','4568');
                $bookindetail=$this->App->getPerticularRecord('tbl_booking', 'Id', $id);
                $clubdetails = $this->App->getPerticularRecord('tbl_vendor', 'Id', $bookindetail[0]['ClubId']);
                $vid=$clubdetails[0]['Id'];
                $times=$this->getcurrenttime($vid,$currentdate);
                $d=explode('-',$times);
                 $Start=$d[0];
                 $End=$d[1];
                  $etime = date('H:i:s',strtotime($End));
                  $stime = date('H:i:s',strtotime($Start));
                  $cctime = date('H:i:s',strtotime($currenttime));
             
             if (($cctime > $stime) && ($cctime < $etime))
                {
                 $clubdetails = $this->App->getPerticularRecord('tbl_vendor', 'Slug', $slug);
                $vid=$clubdetails[0]['Id'];

                $hrsdetails = $this->App->getPerticularRecord('tbl_clublayout', 'VendorId', $vid);
                 $hr=$hrsdetails[0]['PerChildPrice'];
                 if($_POST){
                    date_default_timezone_set('Asia/Kolkata');
                    $n_cur_dt = date('Y-m-d');
                    $n_cur_time1 = date('H:i A', time());
                    $n_cur_time = date("g:i A");
                    $gettime = date("H:i A", strtotime($n_cur_time));
                     $j='+'.$hr.' hours';

                    $currenttimefind=date('H:i A',strtotime($j,strtotime($gettime)));
                    $currenttime=date('H:i A',strtotime($currenttime));
                        if($currentdate==$n_cur_dt){
                        if($currenttimefind > $currenttime)	{
                             $err2='Table booking time closed before '.$hr .' hours.';
                        }else{
                        }
                        }
                   }
                }
                else
                {
                  $err='Please Select Opening to closing time schedule';
                }
                
                if (strtotime($cdatechekc) <= strtotime($currentdate) ) {
                    
                }else{
                   $err1='Please Select Proper date (greater than or equal to today)';
                }
         }
          if ($this->form_validation->run() == FALSE || $err != ''|| $err1 != '') {
            if (validation_errors() != '' || $err != ''|| $err1 != '') {
                $data['error'] = validation_errors() . $err.$err1;
            }
        } else {
            $booking=array(
                   'FirstName'=>$this->input->post('firstname'),
                   'LastName'=>$this->input->post('lastname'),
                   'Email'=>$this->input->post('email'),
                   'BookingDate'=>$this->input->post('date'),
                   'BookingTime'=>$this->input->post('myDatepicker1'),
                   'NoofPax'=>$this->input->post('noofmember'),
                   'DiningPreferences'=>$this->input->post('diningprefer'),
                   'ModifyDate'=>date('Y-m-d H:i'),
                   'OTP'=>$otp,    
                 );
            $this->App->update('tbl_booking','Id',$id,$booking);
           // $curl = curl_init();
                $phn=$this->input->post('phone');
                $msg=$otp.' is your tablefast verification code enjoy';
                 //------send sms --------------------------------
            
                $phone = '91'.$phn;
                $sms=$msg;
               

                $email = $this->input->post('email');
                
                $dataemail = array(
					'username'=>$this->input->post('firstname'),
					'msg'=>$msg
					
				);
				$message = $this->load->view('email/club_booking', $dataemail, TRUE);	
				
             
            
            
            $from_email = $this->config->item('constantEmail');
            $to_email   = $email;
            //Load email library 
                     
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= "From: ".$from_email;


            $to=$email;
            $subject="Otp Verification code  for Tablefast.com";
            mail($to,$subject,$message,$headers);

            $data['success']='Modify your booking.';
            $data['bookingid']=$bid;
            redirect('success-booking/'.$id);
        }
        
        
       $modify=$this->App->getPerticularRecord('tbl_booking','Id',$id);
       $data['modify']=$modify;
       $Clubdetails=$this->App->getPerticularRecord('tbl_vendor','Id',$modify[0]['ClubId']);
       $data['clubdetails']=$Clubdetails;
       $this->load->view('front/include/header');
       $this->load->view('front/customer/editbooking', $data);
       $this->load->view('front/include/footer'); 
    }
    public function getcurrenttime($vid,$date)
    {        
        $timestamp = strtotime($date);
        $currentday = date('D', $timestamp);
        $layout = $this->App->getPerticularRecord('tbl_clublayout', 'VendorId', $vid);
        if (!empty($layout)) {
            $SundayFrom = $layout[0]['SundayFrom'];
            $SundayTo = $layout[0]['SundayTo'];
            $SundayFromClose = $layout[0]['SundayFromClose'];
            $SundayToClose = $layout[0]['SundayToClose'];
            $MondayFrom = $layout[0]['MondayFrom'];
            $MondayTo = $layout[0]['MondayTo'];
            $MondayFromClose = $layout[0]['MondayFromClose'];
            $MondayToClose = $layout[0]['MondayToClose'];
            $TuesdayFrom = $layout[0]['TuesdayFrom'];
            $TuesdayTo = $layout[0]['TuesdayTo'];
            $TuesdayToClose = $layout[0]['TuesdayToClose'];
            $WednesdayFrom = $layout[0]['WednesdayFrom'];
            $WednesdayTo = $layout[0]['WednesdayTo'];
            $WednesdayFromClose = $layout[0]['WednesdayFromClose'];
            $WednesdayToClose = $layout[0]['WednesdayToClose'];
            $ThursdayFrom = $layout[0]['ThursdayFrom'];
            $ThursdayTo = $layout[0]['ThursdayTo'];
            $ThursdayFromClose = $layout[0]['ThursdayFromClose'];
            $ThursdayToClose = $layout[0]['ThursdayToClose'];
            $FridayFrom = $layout[0]['FridayFrom'];
            $FridayTo = $layout[0]['FridayTo'];
            $FridayFromClose = $layout[0]['FridayFromClose'];
            $FridayToClose = $layout[0]['FridayToClose'];
            $SaturdayFrom = $layout[0]['SaturdayFrom'];
            $SaturdayTo = $layout[0]['SaturdayTo'];
            $SaturdayFromClose = $layout[0]['SaturdayFromClose'];
            $SaturdayToClose = $layout[0]['SaturdayToClose'];
            
            if ($currentday == 'Mon') {
                $s = $MondayFrom . '-' . $MondayTo;
                
            } elseif ($currentday == 'Tue') {
                $s = $TuesdayFrom . '-'  . $TuesdayTo;
            } elseif ($currentday == 'Wed') {
                $s = $WednesdayFrom . '-'  . $WednesdayTo;
            } elseif ($currentday == 'Thu') {
                $s = $ThursdayFrom . '-' . $ThursdayTo;
            } elseif ($currentday == 'Fri') {
                $s = $FridayFrom . '-' . $FridayTo;
            } elseif ($currentday == 'Sat') {
                $s = $SaturdayFrom . '-' . $SaturdayTo;
            } elseif ($currentday == 'Sun') {
                $s = $SundayFrom . '-' . $SundayTo;
            } else {
                $s = $SundayFrom . '-' . $SundayTo;
            }
            return $s;
        }
    }
    
    public function bookingsuccess($id)
    {
        $this->App->checkCustomerAuthenticate();
        $data['id']=$id;
        $bookingdetail=$this->App->getPerticularRecord('tbl_booking','Id',$id);
        $data['bookingdetail']=$bookingdetail;
        
        $data['clubdetails']=$this->App->getPerticularRecord('tbl_vendor','Id',$bookingdetail[0]['ClubId']);
        
        $this->load->view('front/include/header');
        $this->load->view('front/customer/bookingdetailsmodify', $data);
        $this->load->view('front/include/footer');
    }
    
    public function deletebooking($id)
    {
        $this->App->checkCustomerAuthenticate();
        $this->App->deletedata('tbl_booking', 'Id', $id);
        return 1;
    }
    public function reviewrating($id)
    {
        $this->App->checkCustomerAuthenticate();
        $this->form_validation->set_rules('star', 'Star', 'required');
        $this->form_validation->set_rules('reviews', 'Reviews', 'required');
        if ($this->form_validation->run() == FALSE) {
            if (validation_errors() != '' ) {
                $data['error'] = validation_errors();
            }
        } else {
            $cbid=$this->input->post('clubid');
            $chekc=$this->App->passwordChecking('tbl_reviews','ClubId','BookingId',$cbid,$id);
            if(!empty($chekc)){
                $arr=array(
                'ClubId'=>$this->input->post('clubid'),
                'BookingId'=> $id,
                'Review'=>$this->input->post('star'),
                'Reviewscomment'=>$this->input->post('reviews'),
                'PublishStatus'=>'1',
                'Created'=>date('Y-m-d'),
            );
            
            $iid = $this->App->update('tbl_reviews','BookingId',$id, $arr);
            }else{
                $arr=array(
                'ClubId'=>$this->input->post('clubid'),
                'BookingId'=> $id,
                'Review'=>$this->input->post('star'),
                'Reviewscomment'=>$this->input->post('reviews'),
                'PublishStatus'=>'1',
                'Created'=>date('Y-m-d'),
            );
               $iid = $this->App->insertdata('tbl_reviews', $arr); 
            }
            
         
            //--  upload multiple image for reviews  --
            $this->load->library('upload');
            if (!empty($_FILES['userFiles']['name'])) {
                $filesCount = count($_FILES['userFiles']['name']);
                for ($i = 0; $i < $filesCount; $i++) {
                    $_FILES['userFile']['name']     = $_FILES['userFiles']['name'][$i];
                    $_FILES['userFile']['type']     = $_FILES['userFiles']['type'][$i];
                    $_FILES['userFile']['tmp_name'] = $_FILES['userFiles']['tmp_name'][$i];
                    $_FILES['userFile']['error']    = $_FILES['userFiles']['error'][$i];
                    $_FILES['userFile']['size']     = $_FILES['userFiles']['size'][$i];
                    
                    $uploadPath              = 'assets/reviewimg/';
                    $config['upload_path']   = $uploadPath;
                    $config['allowed_types'] = '*';
                    
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);
                    if ($this->upload->do_upload('userFile')) {
                        $fileData                    = $this->upload->data();
                        $uploadData[$i]['file_name'] = $fileData['file_name'];
                    } else {
                        $data['error'] = $this->upload->display_errors();
                    }
                }
                
                if (!empty($uploadData)) {
                    $c = count($uploadData);
                    for ($i = 0; $i < $c; $i++) {
                        $arr = array(
                            'ReviewId' => $id,
                            'Image' => $uploadData[$i]['file_name'],
                        );
                        $this->App->insertdata('tbl_reviewsimages', $arr);
                    }
                }
            }
            redirect('complete-booking');
            //--    ended code for multiple image upload --
            $data['success']='Thank you for given reviews';
        }
        
        $data['reviewsdetails']=$this->App->getPerticularRecord('tbl_reviews','BookingId',$id);
        $bookingdetail=$this->App->getPerticularRecord('tbl_booking','Id',$id);
        $data['bookingdetail']=$bookingdetail;
        $clubdetails=$this->App->getPerticularRecord('tbl_vendor','Id',$bookingdetail[0]['ClubId']);
        $data['clubdetails']=$clubdetails;
        
        $this->load->view('front/include/header');
        $this->load->view('front/customer/reviewrating', $data);
        $this->load->view('front/include/footer');
    }
    
    public function deletegallery($id)
    {
       $this->App->checkCustomerAuthenticate();
       $this->App->deletedata('tbl_reviewsimages', 'Id', $id);
    }
    public function otpresetpassword()
    {
        $pwd=$this->input->post('pwd');
        $cpwd=$this->input->post('cpwd');
        $cid=$this->input->post('cid');
        
        $this->form_validation->set_rules('pwd', 'Password', 'required');
        $this->form_validation->set_rules('cpwd', 'Confirm Password', 'required|matches[pwd]');
        if($_POST){
            $password    = $this->input->post('pwd');
            $jk          = $this->App->password_strength_check($password);
            if ($jk == '0') {
                $err = 'Minimum 8 char required. Password must contain one lowercase letter, one capital (uppercase) letter & one number.';
            }
            
        }
         if ($this->form_validation->run() == FALSE || $err!='') {
            if (validation_errors() != ''|| $err!='') {
                $error = validation_errors().$err;
                $errs=preg_replace('/<p[^>]*>/', '', $error);
                $newcontent = preg_replace("</p>", "", $errs);
                $spaceString = str_replace( '<', '',$newcontent);
                $spaceString = str_replace( '>', '',$spaceString);
                $data['error']=$spaceString;
                $data['err']='2';

                echo json_encode($data);
            }
        } else {
            $arr=array(
                'Password'=>md5($this->input->post('pwd')),
            );
            $this->App->update('tbl_customer', 'Id', $cid, $arr);
            $customerdetail = $this->App->getPerticularRecord('tbl_customer', 'Id',$cid);
             
            $data['succ']='1';
            echo json_encode($data);
        }
        
    }
    
    //-----------------------------------------------------------------------
    public function otpverify()
    {      
        $bookid=$this->input->post('bookid');
        $otp=$this->input->post('otp');
       
        if($bookid!='' && $otp!=''){
            $tech=$this->App->passwordChecking('tbl_customer','Id','OTP',$bookid,$otp);
            if(!empty($tech)){
                $arr=array(
                    'Status'=>'1',
                );                
                $this->App->update('tbl_customer', 'Id', $bookid, $arr);
                
                echo json_encode('1');
            }else{
                echo json_encode('3');
            }
        }else{
            echo json_encode('2');
        }
    }
    public function resendotp()
    {
        $bookid=$this->input->post('bookid');    
        $bookingdetail=$this->App->getPerticularRecord('tbl_customer','Id',$bookid);
        if(!empty($bookingdetail)){
            $email=$bookingdetail[0]['Email'];
            $phn=$bookingdetail[0]['Phone'];
            $otp=rand('2324','4568');
            $aup=array(
                'OTP'=>$otp,
            );
            $this->App->update('tbl_customer','Id',$bookid,$aup);
             
            $msg=$otp.' is your tablefast verification code enjoy';
            
            //------send sms --------------------------------
              
                $phone = '91'.$phn;
                $sms=$msg;
              
			$dataemail = array(
				'username'=>$bookingdetail[0]['FirstName'],
				'msg'=>$msg
				
			);
			$message = $this->load->view('email/club_booking', $dataemail, TRUE);	
			
            
            
            $from_email = $this->config->item('constantEmail');
            $to_email   = $email;
            //Load email library 
            
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= "From: ".$from_email;
            $to=$email;
            $subject="Resend OTP Verification code  for Tablefast.com";
            mail($to,$subject,$message,$headers);
            
            
            echo json_encode('1');
        }else{
           echo json_encode('2');
        }        
    }
    
    public function checkgoogleplus(){
        
            require_once(APPPATH.'libraries/Google/autoload.php');    
            
            $client_id = '757471865886-5i5rima1m0sb8a9legols2b7fdhu1erp.apps.googleusercontent.com'; 
            $client_secret = 'MkA7xF5-d2GBpOp1NmC2quQu';
            $redirect_uri = base_url('customer/checkgoogleplus');

            $client = new Google_Client();
            $client->setClientId($client_id);
            $client->setClientSecret($client_secret);
            $client->setRedirectUri($redirect_uri);
            $client->addScope("email");
            $client->addScope("profile");

            $service = new Google_Service_Oauth2($client);
              
            if (isset($_GET['code'])) {
              $client->authenticate($_GET['code']);
              $_SESSION['access_token'] = $client->getAccessToken();
              header('Location: ' . filter_var($redirect_uri, FILTER_SANITIZE_URL));
              exit;
            }

            if (isset($_SESSION['access_token']) && $_SESSION['access_token']) {
              $client->setAccessToken($_SESSION['access_token']);
            } else {
              $authUrl = $client->createAuthUrl();
            }


            if (isset($authUrl)){ 
                redirect('sign-in');                
            } else {
                
                $user = $service->userinfo->get(); //get user info 
                
                $name= $user->name;
                $email= $user->email;
                $pic= $user->picture;
                $gkey= $user->id;
                
                $emailcheck=$this->App->getPerticularRecord('tbl_customer','Email',$email);
                if(!empty($emailcheck)){
                // update
                     $arr=array(
                      'Gploginkey'=>$gkey,
                    );    
                    $this->App->update('tbl_customer','Id',$emailcheck[0]['Id'],$arr);
                      $arraydata = array(
                    'Name' => $emailcheck[0]['FirstName'],
                    'Id' => $emailcheck[0]['Id'],
                    'Email' => $emailcheck[0]['Email']
                    );
                    $this->session->set_userdata('customerauth', $arraydata);
                    redirect('dashboard');
                    
                }else{
                 //insert
                  $otp=rand('4531','5356');
                  $clbname = $user->givenName.'-'.$user->familyName;
                    $trim    = trim($clbname);
                    $ow      = strtolower($trim);
                    $string  = str_replace(' ', '-', $ow);
                    $str     = preg_replace('/\s+/', '-', $string);
                    $chkslug = $this->App->checkExist('tbl_customer', 'Slug', $str);
                    if ($chkslug == '1') {
                        $r    = rand(1, 4);
                        $slug = $str . $r;
                    } else {
                        $slug = $str;
                    }
                    $name=$user->givenName.' '.$user->familyName;
                 $arr=array(
                      'Email'=>$email,
                      'FirstName'=>$user->givenName,
                      'LastName'=>$user->familyName,
                      'Gploginkey'=>$gkey,
                      'Status'=>'0',
                      'Created'=>date('Y-m-d'),
                      'OTP'=>$otp,
                      'Slug'=>$slug,
                    );    
                    
                    $ids=$this->App->insertdata('tbl_customer',$arr);
                    
                    
                    $url = base_url('customer/resetpassword/' . $ids.'/'.$otp);
                    
                    $dataemail = array(
						'username'=>$name,
						'url'=>$url
						
					);
					$message = $this->load->view('email/customer_verification', $dataemail, TRUE);	

                    $from_email = $this->config->item('constantEmail');
                    $to_email = $email;
                    //Load email library 
                                        
                    $headers = "MIME-Version: 1.0" . "\r\n";
                    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                    $headers .= "From: ".$from_email;
                    $to=$email;
                    $subject="Reset Password for Tablefast.com";
                    mail($to,$subject,$message,$headers);                    
                    $data['ids']=$ids;
                    
                    $this->load->view('front/include/header');
                    $this->load->view('front/customer/successlogin');
                    $this->load->view('front/include/footer');
                }
            }
    }
    public function resetpasswordemail($id,$verify)
    {
        $data['userIDds'] = $id;
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('cpassword', 'Confirm Password', 'required|matches[password]');

        if($_POST){
        $password = $this->input->post('password');
         $chk=$this->App->passwordChecking('tbl_customer','Id','OTP',$id,$verify);
          if(empty($chk[0]['Id'])){
              $err1 = 'Reset Password URL Expired.<br>';
          }else{
        $jk       = $this->App->password_strength_check($password);
            if ($jk == '0') {
                $err = '<br>Minimum 8 char required. Password must contain one lowercase letter, one capital (uppercase) letter & one number.';
            } 
        }


        }
        if ($this->form_validation->run() == FALSE || $err != ''|| $err1 != '') {
            if (validation_errors() != '' || $err != ''|| $err1 != '') {
                $data['error'] = validation_errors() . $err.$err1;
            }
        } else {
            $arr = array(
                'Password' => md5($this->input->post('password')),
                'OTP'=>'',
            );
            $this->App->update('tbl_customer', 'Id', $id, $arr);
            $data['success'] = 'Reset Password Successfully. Please Login'; 
        }
            
         $data['verify']=$verify;
         $this->load->view('front/include/header');
         $this->load->view('front/customer/resetpasswordemail',$data);
         $this->load->view('front/include/footer');
    }
    
    public function resetpassword($id,$verify)
    {
            $data['userIDds'] = $id;
            $this->form_validation->set_rules('password', 'Password', 'required');
            $this->form_validation->set_rules('cpassword', 'Confirm Password', 'required|matches[password]');
            
            if($_POST){
            $password = $this->input->post('password');
             $chk=$this->App->passwordChecking('tbl_customer','Id','OTP',$id,$verify);
              if(empty($chk[0]['Id'])){
                  $err1 = 'Reset Password URL Expired.<br>';
              }else{
            $jk       = $this->App->password_strength_check($password);
                if ($jk == '0') {
                    $err = '<br>Minimum 8 char required. Password must contain one lowercase letter, one capital (uppercase) letter & one number.';
                } 
                }
            }
            if ($this->form_validation->run() == FALSE || $err != ''|| $err1 != '') {
                if (validation_errors() != '' || $err != ''|| $err1 != '') {
                    $data['error'] = validation_errors() . $err.$err1;
                }
            } else {
                $arr = array(
                    'Password' => md5($this->input->post('password')),
                    'OTP'=>'',
                );
                $this->App->update('tbl_customer', 'Id', $id, $arr);
                $data['success'] = 'Reset Password Successfully. Please Login'; 
                 $arraydata = array(
                    'Name' => $chk[0]['FirstName'],
                    'Id' => $chk[0]['Id'],
                    'Email' => $chk[0]['Email']
                    );
                    $this->session->set_userdata('tbl_customerauth', $arraydata);
                  redirect('profile');
            }
            
         $data['verify']=$verify;
         $this->load->view('front/include/header');
         $this->load->view('front/customer/resetpassword',$data);
         $this->load->view('front/include/footer');
    }
    public function fbprofile()
    {
        $this->App->checkCustomerAuthenticate();
        $uid = $this->session->userdata['customerauth']['Id'];
        $this->form_validation->set_rules('firstname', 'First Name', 'required');
        $this->form_validation->set_rules('address', 'Address', 'required');
        $this->form_validation->set_rules('email', 'email', 'required|valid_email');
        $this->form_validation->set_rules('phone', 'phone', 'required');
        if ($_POST) {
            $phone    = $this->input->post('phone');
            $chkphone = $this->App->checkExistEdit('tbl_customer', 'Phone', $phone,'Id',$uid);
            $email    = $this->input->post('Email');
            $chkemail = $this->App->checkExistEdit('tbl_customer', 'Email', $email,'Id',$uid);
            
            if ($chkemail == '1') {                
                $err = 'Email already Exist.' . '<br>';
            }
            if ($chkphone == '1') {                
                $err1 = 'Phone number already Exist.' . '<br>';
            }
             $password = $this->input->post('password');
            $jk       = $this->App->password_strength_check($password);
            if ($jk == '0') {
                $err2 = 'Minimum 8 char required. Password must contain one lowercase letter, one capital (uppercase) letter & one number.';
            }
        }
        
        if ($this->form_validation->run() == FALSE || $err != '' || $err1 != '' || $err2 != '') {
            if (validation_errors() != '' || $err != '' || $err1 != '' || $err2 != '') {
                $data['error'] = validation_errors() . $err . $err1 . $err2;
            }
        } else {
             if (!empty($_FILES['image']['name'])) {
            $config['upload_path']   = 'assets/customerprofile/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['file_name']     = $_FILES['image']['name'];
            
            //Load upload library and initialize configuration
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            
               if ($this->upload->do_upload('image')) {
                    $uploadData = $this->upload->data();
                    $picture    = $uploadData['file_name'];
                }
            } else {
                $picture = $this->input->post('oldimg');
            }
           if($password!=''){
                $arr = array(
                        'Email' => $this->input->post('email'),
                        'Phone' => $this->input->post('phone'),
                        'FirstName' => $this->input->post('firstname'),
                        'LastName' => $this->input->post('lastname'),
                        'ProfileImage' =>$picture,
                        'Address' => $this->input->post('address'),
                        'Yourself' => $this->input->post('yourself'),
                        'Status'=>'1',
                        'Password'=>md5($this->input->post('password')),

                );
             }else{
                $arr = array(
                        'Email' => $this->input->post('email'),
                        'Phone' => $this->input->post('phone'),
                        'FirstName' => $this->input->post('firstname'),
                        'LastName' => $this->input->post('lastname'),
                        'ProfileImage' =>$picture,
                        'Address' => $this->input->post('address'),
                        'Yourself' => $this->input->post('yourself'),
                        'Status'=>'1',

                );
             }
            $this->App->update('tbl_customer', 'Id', $uid, $arr);
            $data['success'] = 'Update Profile Successfully.';
        }
        $cid = $this->session->userdata['customerauth']['Id'];
        $data['profiles']=$this->App->getPerticularRecord('tbl_customer','Id',$cid);
        $this->load->view('front/include/header');
        $this->load->view('front/customer/fbprofile', $data);
        $this->load->view('front/include/footer');
    }
    public function completedtransaction()
    {
		$this->App->checkCustomerAuthenticate();
        $id = $this->session->userdata['customerauth']['Id'];
        $data["listcompleteticket"] = $this->App->getPerticularRecord('tbl_ticket_purches', 'CustomerId', $id);
        $this->load->view('front/customer/booking/completedtransaction', $data);
	}
	public function pendingtransaction()
    {
		$this->App->checkCustomerAuthenticate();
        $id = $this->session->userdata['customerauth']['Id'];
        $data["listcompleteticket"] = $this->App->getPerticularRecord('tbl_ticket_purches', 'CustomerId', $id);
        $this->load->view('front/customer/booking//pendingtransaction', $data);
	}
}
