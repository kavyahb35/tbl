<?php
class App extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    public function insertdata($tblname, $array)
    {
        $i = '0';
        $this->db->insert($tblname, $array);
      //  echo $this->db->last_query();die;
        return $this->db->insert_id();
    }
    public function deletedata($tblname, $para, $value)
    {
        
        $this->db->where($para, $value);
        $this->db->delete($tblname);
    }
    public function update($tblname, $parameter, $value, $arr)
    {
        $this->db->where($parameter, $value);
        $this->db->update($tblname, $arr);
    }
    public function getRecord($tblname)
    {
        $query = $this->db->get($tblname);
        if (!empty($query)) {
            return $query->result_array();
        }
        return 0;
    }
    public function getPerticularRecord($tblname, $parameter, $value)
    {
        $query = $this->db->query("select * from " . $tblname . " where " . $parameter . " = '" . $value . "' ORDER BY `Id` DESC");
        $queryresult = $query->result_array();  

        if (!empty($query)) {
            return $query->result_array();
        }
        return 0;
    }
    public function checkExist($tblname, $parameter, $value)
    {
        $query = $this->db->query("select * from " . $tblname . " where " . $parameter . " = '" . $value . "'");
        
        $query = $query->result_array();
        if (!empty($query)) {
            return 1;
        }
        return 0;
    }
    public function checkExistEdit($tblname, $parameter, $value, $para, $val)
    {
        $query = $this->db->query("select * from " . $tblname . " where " . $parameter . " = '" . $value . "' and " . $para . " <> '" . $val . "'");
        
        $query = $query->result_array();
        if (!empty($query)) {
            return 1;
        }
        return 0;
    }
     public function passwordCheckingvendor($tblname, $para1, $para2, $val1, $val2)
    {
        $query  = $this->db->query("select * from " . $tblname . " where " . $para1 . " = '" . $val1 . "' and " . $para2 . " = '" . $val2 . "' and (Status='1' OR Status='2')");
       
        $queryresult = $query->result_array();
        if (!empty($queryresult)) {
            return $queryresult;
        }
        return 0;
    }
    public function passwordChecking($tblname, $para1, $para2, $val1, $val2)
    {
        $query       = $this->db->query("select * from " . $tblname . " where " . $para1 . " = '" . $val1 . "' and " . $para2 . " = '" . $val2 . "'");
     
        $queryresult = $query->result_array();
        if (!empty($queryresult)) {
            return $queryresult;
        }
        return 0;
    }
    public function passwordCheckingcustomer($tblname, $para1, $para2, $val1, $val2)
    {
        $query = $this->db->query("select * from " . $tblname . " where " . $para1 . " = '" . $val1 . "' and " . $para2 . " = '" . $val2 . "' and Status='1'");
        $queryresult = $query->result_array();
        if (!empty($queryresult)) {
            return $queryresult;
        }
        return 0;
    }
    public function checkAdminAuthenticate()
    {
        $username = $this->session->userdata['adminauth']['username'];
        if ($username == '') {
            redirect('Admin');
        }
    }
    public function checkVendorAuthenticate()
    {
        $Id = $this->session->userdata['vendorauth']['Id'];
        if ($Id == '') {
            redirect('Vendor');
        }
    }
    public function checkCustomerAuthenticate()
    {
        $Id = $this->session->userdata['customerauth']['Id'];
        if ($Id == '') {
            redirect('customer');
        }
    }
    public function getRecordByLimit($tblname, $para1, $val1, $l1, $l2)
    {
        $query = $this->db->query("select * from " . $tblname . " where " . $para1 . " = '" . $val1 . "' ORDER BY `Id` DESC limit " . $l1 . "," . $l2 . " ");
        $queryresult = $query->result_array(); 
		   
        if (!empty($queryresult)) {
            return $queryresult;
        }
        return 0;
    }
    public function get_data($where, $fields, $limit, $start)
    {
        return $this->get($where, $fields, $limit, $start);
    }    
    public function record_count($tblname)
    {
        return $this->db->count_all($tblname);
    }     
    public function fetch_departments($tblname, $limit, $start)
    {
        $query = $this->db->query("select * from " . $tblname . " where Status='2' ORDER BY `Id` DESC limit " . $start . "," . $limit . "");
        if ($query->num_rows() > 0) {
            foreach ($query->result_array() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
    }
    public function password_strength_check($password, $min_len = 8, $max_len = 70, $req_digit = 1, $req_lower = 1, $req_upper = 1, $req_symbol = 1)
    {
        $regex = '/^';
        if ($req_digit > 0) {
            $regex .= '(?=.*\d)';
        } 
        if ($req_lower > 0) {
            $regex .= '(?=.*[a-z])';
        } 
        if ($req_upper > 0) {
            $regex .= '(?=.*[A-Z])';
        } 
        /*if ($req_symbol > 0) {
            $regex .= '(?=.*[^a-zA-Z\d])';
        } */
        $regex .= '.{' . $min_len . ',' . $max_len . '}$/';
        
        if (preg_match($regex, $password)) {
            return 1;
        } else {
            return 0;
        }
    }
    public function fetch_food($tblname, $limit, $start)
    {
        $query = $this->db->query("select * from " . $tblname . " where Status='1' ORDER BY `Id` DESC limit " . $start . "," . $limit . "");
        if ($query->num_rows() > 0) {
            foreach ($query->result_array() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
    }
    public function fetch_fooditem($tblname, $par, $val, $limit, $start)
    {
        $query = $this->db->query("select * from " . $tblname . " where " . $par . "= '" . $val . "' and Status='1' ORDER BY `Id` DESC limit " . $start . "," . $limit . "");
        if ($query->num_rows() > 0) {
            foreach ($query->result_array() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
    } 	
    function check_txnid($tnxid){
		global $link;
		return true;
		$valid_txnid = true;
		$sql = mysql_query("SELECT * FROM `payments` WHERE txnid = '$tnxid'", $link);
		if ($row = mysql_fetch_array($sql)) {
			$valid_txnid = false;
		}
		return $valid_txnid;
    }

    function check_price($price, $id){
        $valid_price = false;
        return true;
    }

    function updatePayments($data){
		global $link;		
		if (is_array($data)) {
			$sql = mysql_query("INSERT INTO `payments` (txnid, payment_amount, payment_status, itemid, createdtime) VALUES (
					'".$data['txn_id']."' ,
					'".$data['payment_amount']."' ,
					'".$data['payment_status']."' ,
					'".$data['item_number']."' ,
					'".date("Y-m-d H:i:s")."'
					)", $link);
			return mysql_insert_id($link);
		}   
    }
    function do_upload($htmlFieldName, $path)
    {
        $config['file_name'] = time();
        $config['upload_path'] = $path;
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '2000';
        $config['max_width'] = '2000';
        $config['max_height'] = '2000';
        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        unset($config);
        if (!$this->upload->do_upload($htmlFieldName))
        {
            return array('error' => $this->upload->display_errors(), 'status' => 0);
        } else
        {
            return array('status' => 1, 'upload_data' => $this->upload->data());
        }
    }
    function resize_image($sourcePath, $desPath, $width = '500', $height = '500')
    {
		$this->load->library('image_lib');
        $this->image_lib->clear();
        $config['image_library'] = 'gd2';
        $config['source_image'] = $sourcePath;
        $config['new_image'] = $desPath;
        $config['quality'] = '100%';
        $config['create_thumb'] = TRUE;
        $config['maintain_ratio'] = true;
        $config['thumb_marker'] = '';
        $config['width'] = $width;
        $config['height'] = $height;
        $this->image_lib->initialize($config);
 
        if ($this->image_lib->resize())
            return true;
        return false;
    }
    
}
