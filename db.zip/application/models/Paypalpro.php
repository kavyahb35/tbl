<?php
class Paypalpro extends CI_Model
{
    public function getOrder() {
		 $Id = $this->session->userdata['vendorauth']['Id'];
		 
		 $paymentset = $this->db->query("select * from tbl_paypal_setting");
			$paymentsetting= $paymentset->result_array();
		 
		 
			$order_quer = $this->db->query("select * from tbl_vendor where Id='".$Id."'");
			$order_query= $order_quer->result_array();
				$payment_iso_code_2 = $paymentsetting[0]['Paymentisocode2'];
				$payment_iso_code_3 = $paymentsetting[0]['Paymentisocode3'];
				
				$payment_zone_code = $paymentsetting[0]['Paymentzonecode'];
			
			 $shipping_iso_code_2=$paymentsetting[0]['Shippingisocode2'];
				 $shipping_iso_code_3=$paymentsetting[0]['Shippingisocode3'];

			$shipping_zone_code = $paymentsetting[0]['Shippingzonecode'];

			
			$language_code = $paymentsetting[0]['Languagecode'];

			$ar= array(
				'order_id'                => $order_query[0]['Id'],
				'customer_id'             => $order_query[0]['Id'],
				'firstname'               => $order_query[0]['FirstName'],
				'lastname'                => $order_query[0]['LastName'],
				'email'                   => $order_query[0]['Email'],
				'telephone'               => $order_query[0]['Phone'],
				'payment_firstname'       => $order_query[0]['FirstName'],
				'payment_lastname'        => $order_query[0]['LastName'],
				'payment_address_1'       => $order_query[0]['Address'],
				'payment_postcode'        => $order_query[0]['PostCode'],
				'payment_city'            => $order_query[0]['City'],
				'payment_zone_id'         => $paymentsetting[0]['PaymentZoneId'],
				'payment_zone'            => $paymentsetting[0]['PaymentZone'],
				'payment_zone_code'       => $payment_zone_code,
				'payment_iso_code_2'      => $payment_iso_code_2,
				'payment_iso_code_3'      => $payment_iso_code_3,
				'shipping_zone_code'      => $shipping_zone_code,
				'shipping_iso_code_2'     => $shipping_iso_code_2,
				'shipping_iso_code_3'     => $shipping_iso_code_3,
				'currency_code'     => $paymentsetting[0]['CurrencyCode'],
			);
			return $ar;
		
	}

	
		public function addOrderHistory($order_id, $order_status_id, $comment = '', $notify = false, $override = false) {
		
		$order_info = $this->getOrder();

                $res=$this->db->query("select * from tbl_payment_history where order_id='".$order_id."' ORDER BY  `order_history_id` DESC limit 1");
		$no=$res->num_rows();
		$result=$res->result_array();
		if($no > 0){
		   $sr=$result[0]['order_status_id'];	
		   $sr=$sr+1;
		}else { $sr='1';}
		
		if ($order_info) {
			$safe = true;
			$arr=array('1,2,3,5,12');
			$this->db->query("INSERT INTO tbl_payment_history SET order_id = '" . (int)$order_id . "', order_status_id = '" . (int)$sr . "', notify = '" . (int)$notify . "', comment = " . $this->db->escape($comment) . ", date_added = NOW()");
			return $this->db->insert_id();
			
		}
	}
	  public function getOrderCustomer($inserdid) {
			$Id = $this->session->userdata['customerauth']['Id'];
		 
			$paymentset = $this->db->query("select * from tbl_paypal_setting");
			$paymentsetting= $paymentset->result_array();
		 
			$order_quer = $this->db->query("select * from tbl_ticket_purches where Id ='".$inserdid."'");
			$order_query= $order_quer->result_array();
			
			$custid = $order_query[0]['CustomerId'];
			$customer_det = $this->db->query("select * from tbl_customer where Id ='".$custid."'");
			$customer_detail= $customer_det->result_array();
			
			
			$payment_iso_code_2 = $paymentsetting[0]['Paymentisocode2'];
			$payment_iso_code_3 = $paymentsetting[0]['Paymentisocode3'];
				
			$payment_zone_code = $paymentsetting[0]['Paymentzonecode'];
			
			$shipping_iso_code_2=$paymentsetting[0]['Shippingisocode2'];
			$shipping_iso_code_3=$paymentsetting[0]['Shippingisocode3'];

			$shipping_zone_code = $paymentsetting[0]['Shippingzonecode'];

			
			$language_code = $paymentsetting[0]['Languagecode'];

			$ar= array(
				'order_id'                => $order_query[0]['Id'],
				'customer_id'             => $customer_detail[0]['CustomerId'],
				'firstname'               => $customer_detail[0]['FirstName'],
				'lastname'                => $customer_detail[0]['LastName'],
				'email'                   => $customer_detail[0]['Email'],
				'telephone'               => $customer_detail[0]['Phone'],
				'payment_firstname'       => $customer_detail[0]['FirstName'],
				'payment_lastname'        => $customer_detail[0]['LastName'],
				'payment_address_1'       => $customer_detail[0]['Address'],
				'payment_postcode'        => '',
				'payment_city'            => '',
				'payment_zone_id'         => $paymentsetting[0]['PaymentZoneId'],
				'payment_zone'            => $paymentsetting[0]['PaymentZone'],
				'payment_zone_code'       => $payment_zone_code,
				'payment_iso_code_2'      => $payment_iso_code_2,
				'payment_iso_code_3'      => $payment_iso_code_3,
				'shipping_zone_code'      => $shipping_zone_code,
				'shipping_iso_code_2'     => $shipping_iso_code_2,
				'shipping_iso_code_3'     => $shipping_iso_code_3,
				'currency_code'     => $paymentsetting[0]['CurrencyCode'],
			);
			return $ar;
		
	}
	public function addOrderHistoryCustomer($order_id, $order_status_id, $comment = '', $notify = false, $override = false) {
		
		$dat = array(
		'Comment' => $comment,
		'Created' => date('Y-m-d H:i A'),
		'Status' => '1'
		);
		$this->db->where('Id', $order_id);
		$this->db->update('tbl_ticket_purches', $dat); 
		
		
		
		
		/*   Ticket table details  */
		 $query = $this->db->query("select * from tbl_ticket_purches where Id='".$order_id."'");
		 $ticketdetails = $query->result_array();
		 $amount = $ticketdetails[0]['Amount'];
		 $Comment = $ticketdetails[0]['Comment'];
		 $Created = $ticketdetails[0]['Created'];
		 $EventId = $ticketdetails[0]['EventId'];
		 $CustomerId = $ticketdetails[0]['CustomerId'];
		 $ClubId = $ticketdetails[0]['ClubId'];
		 $EventType = $ticketdetails[0]['EventType'];
		 $OrderId = $ticketdetails[0]['Id'];
		 
		 /*   event table details  */
		 $query1 = $this->db->query("select * from tbl_events where Id='".$EventId."'");
		 $eventdetails = $query1->result_array();
		 $eventTitle = $eventdetails[0]['Title'];
		  if($eventdetails[0]['NoofDays']=='1'){
              $dt=$eventdetails[0]['OneDate'];
           }else{ 
			   $dt=$eventdetails[0]['FromDate'].' To '.$eventdetails[0]['ToDate'];
		  }
		  $time = $eventdetails[0]['TimeFrom'].' To '.$eventdetails[0]['TimeTo'];
		  
		 /*   event type table details  */
		 $query2 = $this->db->query("select * from tbl_event_type where Id='".$EventType."'");
		 $eventtypedetails = $query2->result_array();
		 $eventtypeTitle = $eventtypedetails[0]['Title'];
		 $eventtypeAmount = $eventtypedetails[0]['Amount'];
		 $NoofTickets = $eventtypedetails[0]['NoofTickets'];
		  
		 /*   customer table details  */
		 $query3 = $this->db->query("select * from tbl_customer where Id='".$CustomerId."'");
		 $customerdetails = $query3->result_array();
		 $name = $customerdetails[0]['FirstName'].' '.$customerdetails[0]['LastName'];
		 $Email = $customerdetails[0]['Email'];
		 $Phone = $customerdetails[0]['Phone'];
		  
		 /*  vendor event type table details  */
		 $query2 = $this->db->query("select * from  tbl_vendor where Id='".$ClubId."'");
		 $clubdetails = $query2->result_array();
		 $clubname = $clubdetails[0]['ClubName'];
		 $clubEmail = $clubdetails[0]['Email'];
		 
		 $qty = $amount / $eventtypeAmount;
		
		
		/* Update no. of tickets */
		$r = $this->db->query("select * from tbl_event_ticket_update where ClubId='".$ClubId."' and EventId='".$EventId."' and EventTypeId='".$EventType."'");
		$noresult = $r->result_array();
		$norows = $r->num_rows();
		$nooftickets = $noresult[0]['NoofTicket'];
		$UsedTicket = $noresult[0]['UsedTicket'];
		$tid = $noresult[0]['Id'];
		if($norows > 0){
		   $UsedTicket = $UsedTicket + $qty;
		   $arr = array(
				'UsedTicket'=> $UsedTicket,
				'Created'=>date('Y-m-d')
		   ); 	
		   $this->db->where('Id', $tid);
			$this->db->update('tbl_event_ticket_update', $arr); 
		}else{
			$i = '1';
		   $arr = array(
				'UsedTicket'=> $i,
				'Created'=>date('Y-m-d')
		   ); 	
		   $this->db->where('Id', $tid);
			$this->db->update('tbl_event_ticket_update', $arr); 
		}
		
		
		//------send email --------------------------------
		
		
		 
		 
		 
		 /*email for customer*/
		
        $subject="Thank you for parched event tickets.";
        $dataemail = array(
			'username'=>$name,
			'clubname'=>$clubname,
			'eventTitle'=>$eventTitle,
			'eventtypeTitle'=>$eventtypeTitle,
			'dt'=>$dt,
			'time'=>$time,
			'OrderId'=>$OrderId,
			'qty'=>$qty,
			'amount'=>$amount,
			'Comment'=>$Comment
			
        );
        $message = $this->load->view('email/paypal_event', $dataemail, TRUE);
        
        
        $from_email = $this->config->item('constantEmail');
        //Load email library 			
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: ".$from_email;
        $to=$Email;
        mail($to,$subject,$message,$headers);
        
        /* Vendor & Admin Mail */
        $subject1="Parched event tickets.";
        
         $dataemail = array(
			'username'=>$name,
			'Email'=>$Email,
			'Phone'=>$Phone,
			'OrderId'=>$OrderId,
			'qty'=>$qty,
			'amount'=>$amount,
			'Comment'=>$Comment,
			'clubname'=>$clubname,
			'eventTitle'=>$eventTitle,
			'eventtypeTitle'=>$eventtypeTitle,
			'dt'=>$dt,
			'time'=>$time
			
        );
        $message1 = $this->load->view('email/paypal_vendor', $dataemail, TRUE);
        
        $from_email1 = $this->config->item('constantEmail');
        //Load email library 			
        $headers1 = "MIME-Version: 1.0" . "\r\n";
        $headers1 .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers1 .= "From: ".$from_email1. "\r\n" .
        "CC: ".$from_email1;
        $to1=$clubEmail;
        mail($to1,$subject1,$message1,$headers1);
        
        //---end mail --send sms ----     
		
		return $order_id;
	}

}
