<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
   <head>
      <title>Tablefast Email Template  </title>
   </head>
   <body style="width:600px;margin:0 auto">
      <div>
         <div class="container" style="background:#313a45">
            <table align="center" border="0" cellpadding="0" cellspacing="0" style="width:600px; background:#313a45">
               <tbody>
                  <tr>
                     <td style="width:40px;" width="40">&nbsp;</td>
                     <td align="center" valign="top">
                        <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
                           <tbody>
                              <tr>
                                 <td height="28" style="line-height:1px;font-size:1px;height:28px;">&nbsp;</td>
                              </tr>
                              <tr>
                                 <td align="center" valign="top">
                                    <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
                                       <tbody>
                                          <tr>
                                             <td align="left" valign="top">
                                                <table align="center" border="0" cellpadding="0" cellspacing="0" style="width:68%;">
                                                   <tbody>
                                                      <tr>
                                                         <td align="center" valign="top">
                                                            <table align="center" border="0" cellpadding="0" cellspacing="0" style="width:100%;">
                                                               <tbody>
                                                                  <tr>
                                                                     <td align="left" valign="top">
                                                                        <table align="left" border="0" cellpadding="0" cellspacing="0" style="width:100%;">
                                                                           <tbody>
                                                                              <tr>
                                                                                 <td height="7" style="line-height:1px;font-size:1px;height:7px;">&nbsp;</td>
                                                                              </tr>
                                                                              <tr>
                                                                                 <td align="center" valign="top">
                                                                                    <a class="daria-goto-anchor" data-orig-href="" data-vdir-href="" href="https://www.tablefast.com/" rel="noopener noreferrer" style="text-decoration:none;" target="_blank"><img alt="Tablefast" border="0" class="img-responsive" src="https://www.tablefast.com/assets/logo/footer-logo-one1.png" style="display:block;font-family:Oswald,sans-serif;font-size:18px;line-height:21px;color:#ffffff;font-weight:bold;" width="100%" /> </a>
                                                                                 </td>
                                                                              </tr>
                                                                              <tr>
                                                                                 <td height="7" style="line-height:1px;font-size:1px;height:7px;">&nbsp;</td>
                                                                              </tr>
                                                                           </tbody>
                                                                        </table>
                                                                     </td>
                                                                  </tr>
                                                               </tbody>
                                                            </table>
                                                         </td>
                                                      </tr>
                                                   </tbody>
                                                </table>
                                             </td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </td>
                              </tr>
                              <tr>
                                 <td height="20" style="line-height:1px;font-size:1px;height:20px;">&nbsp;</td>
                              </tr>
                           </tbody>
                        </table>
                     </td>
                     <td style="width:40px;" width="40">&nbsp;</td>
                  </tr>
               </tbody>
            </table>
         </div>
         <div class="container" style="">
            <div class="main">
               <table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff">
                  <tbody>
                     <tr>
                        <td>
                           <div>
                              <table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff">
                                 <tbody>
                                    <tr>
                                       <td valign="top" style="padding-top:0px;font-family:Helvetica neue,Helvetica,Arial,Verdana,sans-serif;color:#205081;font-size:20px;line-height:32px;text-align:left;font-weight:bold;padding-top:20px;text-align:center" align="left">
                                          <span> Parched event tickets.</span>
                                       </td>
                                    </tr>
                                 </tbody>
                              </table>
                           </div>
                        </td>
                     </tr>
                     <tr>
                        <td style="color:#cccccc;padding-top:10px;" valign="top">
                           <hr color="#cccccc" size="1">
                        </td>
                     </tr>
                     <tr>
                        <td valign="top" align="left">
                           <div></div>
                        </td>
                     </tr>
                     <tr>
                        <td valign="top" align="left">
                           <div>
                           </div>
                        </td>
                     </tr>
                     <tr>
                        <td valign="top" align="left">
                           <div>
                              <table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff">
                                 <tbody>
                                    <tr valign="top">
                                       <td valign="top" style="padding-top:20px;font-family:Helvetica,Helvetica neue,Arial,Verdana,sans-serif;color:#333333;font-size:14px;line-height:24px;text-align:left;font-weight:none;" align="left">
                                          <span>Dear</span><span> <?php echo $username; ?></span>,
                                       </td>
                                    </tr>
                                 </tbody>
                              </table>
                           </div>
                        </td>
                     </tr>
                     <tr>
                        <td valign="top" style="padding-top:10px;font-family:Helvetica,Helvetica neue,Arial,Verdana,sans-serif;color:#333333;font-size:14px;line-height:20px;text-align:left;font-weight:none;" align="left">
                         <p style="text-align:Center;font-size:20px"> Parched  Event Ticket Details </p> 
                    
                    <p style="color: #9b9b9b;font-size: 15px;text-align: left; border-bottom: 1px solid #9b9b9b;">Customer Details </p>
                   <p style="color: #000;font-size: 12px;text-align: left; ">
                  Name : <?php echo $name; ?><br>
                   Email : <?php echo $Email; ?><br>
                    Phone : <?php echo $Phone; ?><br>
                    Ticket No. : P00<?php echo $OrderId; ?><br>
                   No. of Ticket : <?php echo $qty; ?><br>
                   Total ticket Amount : <?php echo $amount; ?><br>
                        Transaction Details : <?php echo $Comment; ?><br></p><br>
                   
                    <p style="color: #9b9b9b;font-size: 15px;text-align: left; border-bottom: 1px solid #9b9b9b;">Event Details</p>
                    <p style="color: #000;font-size: 12px;text-align: left; ">
                    <b><?php echo $clubname; ?></b><br>
                    Event Name : <?php echo $eventTitle; ?><br>
                    Event Type : <?php echo $eventtypeTitle; ?> <br> 
                    Event Time : <?php echo $dt; ?> Time : <?php echo $time; ?></p><br>


                        </td>
                     </tr>
                      
                     
                     <tr>
                        <td valign="top" align="left">
                           <div>
                              <table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" align="center">
                                 <tbody>
                                    <tr valign="top">
                                       <td valign="top" style="padding-top:10px;font-family:Helvetica,Helvetica neue,Arial,Verdana,sans-serif;color:#333333;font-size:14px;line-height:24px;text-align:left;font-weight:none;" align="left">
                                          <span>Cheers,</span><br>
                                          <span>The Tablefast</span>
                                       </td>
                                    </tr>
                                 </tbody>
                              </table>
                           </div>
                        </td>
                     </tr>
                     <tr>
                        <td valign="top" align="left">
                           <div></div>
                        </td>
                     </tr>
                  </tbody>
               </table>
            </div>
         </div>
         <div>
            <table align="center" border="0" cellpadding="0" cellspacing="0" width="600px">
               <tbody>
                  <tr>
                     <td style="/*! color:#cccccc; */padding-top:10px;" valign="top">
                        <hr size="1" color="#cccccc">
                     </td>
                  </tr>
                  <tr>
                     <td height="31" style="height:31px;">&nbsp;</td>
                  </tr>
               </tbody>
            </table>
         </div>
         <div style="background:#313a45">
            <table align="center" bgcolor="#313a45" border="0" cellpadding="0" cellspacing="0" width="600px">
               <tbody>
                  <tr>
                     <td style="width:90px;" width="90">&nbsp;</td>
                     <td align="center" valign="top">
                        <table align="center" border="0" cellpadding="0" cellspacing="0" style="width:420px;" width="100%">
                           <tbody>
                              <tr>
                                 <td height="44" style="height:44px;">&nbsp;</td>
                              </tr>
                              <tr>
                                 <td height="44" style="font-family:Oswald,sans-serif;font-size:9px;line-height:16px;color:#9c9c9c;text-transform:uppercase;">
                                    <p style="text-decoration:none;color:#fff;
                                       text-align: center;">This message was sent to you by Tablefast.com</p>
                                 </td>
                              </tr>
                              <tr>
                                 <td align="center" style="line-height:0px;font-size:0px;" valign="top">
                                    <a class="daria-goto-anchor" data-orig-href="" data-vdir-href="" href="https://www.tablefast.com" rel="noopener noreferrer" style="text-decoration:none;">
                                    <img alt="Tablefast" border="0" data-file-id="248733" height="59" src="https://www.tablefast.com/assets/logo/footer-logo-one1.png" style="border: 0px initial ; display: block; font-family: Oswald,sans-serif; font-size: 14px; line-height: 16px;  color: rgb(255, 255, 255); font-weight: bold; width: 198px; height: 38px; margin: 0px;" /> </a>
                                 </td>
                              </tr>
                              <tr>
                                 <td height="15" style="line-height:1px;font-size:1px;height:15px;">&nbsp;</td>
                              </tr>
                              <tr>
                                 <td align="center" style="font-family:Oswald,sans-serif;font-size:9px;line-height:16px;color:#9c9c9c;text-transform:uppercase;" valign="top"><a class="daria-goto-anchor" rel="noopener noreferrer" style="text-decoration:none;color:#fff;" target="_blank" href="http://r2p.cueserve.com"> Tablefast.Com<br/>
                                    Edinburgh, UK <br />12 Simpson Loan,<br/>
                                    info@tablefast.com </a>
                                 </td>
                              </tr>
                              <tr>
                                 <td height="35" style="height:35px;">&nbsp;</td>
                              </tr>
                           </tbody>
                        </table>
                     </td>
                     <td style="width:90px;" width="90">&nbsp;</td>
                  </tr>
               </tbody>
            </table>
         </div>
      </div>
    
   </body>
</html>
