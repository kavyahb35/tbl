 <title><?php echo $metasetting[0]['Title'];?></title>
 <meta name="description" content="<?php echo $metasetting[0]['Description'];?>">
 <meta name="keyword" content="<?php echo $metasetting[0]['MetaKeyword'];?>">