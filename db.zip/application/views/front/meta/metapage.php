 <?php $s = $this->uri->segment(3);$e= $this->uri->segment(4);
          if(current_url()==base_url())
          { $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','1','1');
            $this->load->view('front/meta/metacontent',$data);
          }
          elseif(base_url('about-us')==current_url())
          {
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','3','1');
              $this->load->view('front/meta/metacontent',$data);              
          }
          elseif(base_url('contact-us')==current_url())
          {
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','4','1');
              $this->load->view('front/meta/metacontent',$data);
          }

          elseif(current_url()==base_url('club-list'))
          {
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','2','1');              
              $this->load->view('front/meta/metacontent',$data);
          }
          
          
          
          elseif(current_url()==base_url('sign-in'))
          {
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','5','1');              
              $this->load->view('front/meta/metacontent',$data);
          }
          elseif(current_url()==base_url('sign-up'))
          {
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','6','1');              
              $this->load->view('front/meta/metacontent',$data);
          }
         
          elseif(current_url()==base_url('customer/resetpassword/'.$s.'/'.$e))
          {
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','8','1');              
              $this->load->view('front/meta/metacontent',$data);
          }
          elseif(current_url()==base_url('dashboard'))
          {
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','9','1');              
              $this->load->view('front/meta/metacontent',$data);
          }
          elseif(current_url()==base_url('profile'))
          {
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','10','1');              
              $this->load->view('front/meta/metacontent',$data);
          }
          elseif(current_url()==base_url('change-password'))
          {
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','11','1');              
              $this->load->view('front/meta/metacontent',$data);
          }
          elseif(current_url()==base_url('detail/'.$s))
          {
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','12','1');              
              $this->load->view('front/meta/metacontent',$data);
          }
          elseif(current_url()==base_url('booking-club/'.$s))
          {
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','13','1');              
              $this->load->view('front/meta/metacontent',$data);
          }
          elseif(current_url()==base_url('success-booking/'.$s))
          {
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','14','1');              
              $this->load->view('front/meta/metacontent',$data);
          }
          elseif(current_url()==base_url('cancel-booking/'.$s))
          {
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','15','1');              
              $this->load->view('front/meta/metacontent',$data);
          }
          
          
          
          
          
          elseif(current_url()==base_url('admin'))
          {
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','16','1');              
              $this->load->view('front/meta/metacontent',$data);
          }
          elseif(current_url()==base_url('admin/dashboard'))
          {
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','17','1');              
              $this->load->view('front/meta/metacontent',$data);
          }
          elseif(current_url()==base_url('vendor-signin'))
          {
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','18','1');              
              $this->load->view('front/meta/metacontent',$data);
          }
          elseif(current_url()==base_url('vendor-signup'))
          {
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','19','1');              
              $this->load->view('front/meta/metacontent',$data);
          }
          elseif(current_url()==base_url('vendor-forgot-password'))
          {
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','20','1');              
              $this->load->view('front/meta/metacontent',$data);
          }
          elseif(current_url()==base_url('vendor/resetpassword/'.$s.'/'.$e))
          {
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','21','1');              
              $this->load->view('front/meta/metacontent',$data);
          }
          elseif(current_url()==base_url('vendor-change-password'))
          {
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','22','1');              
              $this->load->view('front/meta/metacontent',$data);
          }
          elseif(current_url()==base_url('update-step1'))
          {
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','23','1');              
              $this->load->view('front/meta/metacontent',$data);
          }
          elseif(current_url()==base_url('vendor-dashboard'))
          {
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','24','1');              
              $this->load->view('front/meta/metacontent',$data);
          }
          elseif(base_url('terms-and-conditions')==current_url())
          {
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','25','1');
              $this->load->view('front/meta/metacontent',$data);
          }
         elseif(base_url('privacy-policy')==current_url())
          {
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','26','1');
              $this->load->view('front/meta/metacontent',$data);
          }



          else{
              $data['metasetting'] = $this->App->passwordChecking('tbl_meta','PageId','Status','1','1');
            $this->load->view('front/meta/metacontent',$data);
          }
          
          
          
  ?>