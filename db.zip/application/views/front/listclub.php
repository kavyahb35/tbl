<!-- start breadcrumb -->
<section class="breadcrumb_main_area margin-bottom-80">
  <div class="container-fluid">
    <div class="row">
      <div class="breadcrumb_main nice_title">
        <h2>Clubs
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
            
          </div>
        </div>         
        <!-- end offer start -->
      </div>
    </div>
  </div>            
</section>
<!-- start other detect room section -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<section class="other_room_area">
  <div class="container">
    <div class="row">
      <div class="other_room">
        <div class="section_title nice_title content-center">
          <h3>List of Tables
          </h3>
        </div>
        <div class="section_content">
          <!-- start hotel booking -->
          <!-- end hotel booking -->
          <!-- start single room details -->
          <div class="accomodation_single_room">
            <div class="container">
              <div class="row">
                <?php if(!empty($results)){ 
foreach($results as $clb) {
$cid=$clb['Id'];
$clublayout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$cid);
$img=$clublayout[0]['MainImage'];
$PerAdultPrice=$clublayout[0]['PerAdultPrice'];?>  
                <div class="col-lg-3 col-md-3 col-sm-3 yellowbox">
                  <div class="single_room_wrapper clearfix padding-bottom-30">
                    <figure class="uk-overlay1 uk-overlay-hover1">
                      <div class="room_media mk">
                        <a id="i30<?php echo $clb['Id'];?>" href="<?php echo base_url('detail/'.$clb['Slug']);?>" >
                          <?php if($img!=''){ 
                                if (file_exists(FCPATH.'assets/clubimage/455X300/'.$img)){?>
                          <img src="<?php echo base_url('assets/clubimage/455X300/'.$img);?>" alt="" class="ew">
                          <?php }else{ ?>
                              <img src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="" class="ew">
                         
                          <?php } } else{ ?>
                          <img src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="" class="ew">
                          <?php } ?> 
                          </div>
                        <div id="i10<?php echo $clb['Id'];?>" class="room_title border-bottom-whitesmoke clearfix">
                          <div class="left_room_title floatleft">
                            <a href="<?php echo base_url('detail/'.$clb['Slug']);?>">
                              <h6 class="claimedRight" maxlength="50">
                                <?php 
echo $r=trim($clb['ClubName']);
 ?>
                              </h6>
<style>.claimedRight {
  display: block;
  width: 110px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
figure.uk-overlay1.uk-overlay-hover1 {
    width: 100%;
}</style>
                            </a>
                            <p><?php echo $PerAdultPrice.' QAR';?>
                              <span>
                              </span>
                            </p>
                          </div>
                          <div class="left_room_title floatright">
<?php $vendorid=$this->session->userdata['vendorauth']['Id'];                                        
if($vendorid==''){ ?>
                      
                            <a href="<?php echo base_url('detail/'.$clb['Slug']);?>" class="btn ">Book
                            </a><?php }?>

                          </div>
                        </div>
                       <!-- <div id="i20<?php echo $clb['Id'];?>" class="rrt uk-overlay-panel uk-overlay-background single_wrapper_details clearfix animated bounceInDown">
                          <div class="border-dark-1 padding-22 clearfix single_wrapper_details_pad dre">
                            <a href="<?php echo base_url('detail/'.$clb['Slug']);?>">
                              <h5 >
                                <?php echo $clb['ClubName'];?>
                              </h5>
                            </a>
                            <p>
                              <?php 
$big=$clublayout[0]['Description'];
$foo = preg_replace('/\s+/', ' ', $big);
$foo = str_replace('<p>&nbsp;</p>','',$big);
$small = substr($foo, 0, 100);
echo  $small.'...';?>
                            </p>
                            <div class="single_room_cost clearfix">
                              <div class="floatright">
<?php $vendorid=$this->session->userdata['vendorauth']['Id'];                                        
if($vendorid==''){ ?>
                      
                                <a href="<?php echo base_url('detail/'.$clb['Slug']);?>" class="btn ">Book
                                </a><?php }  ?>

                              </div>
                            </div>
                          </div>
                        </div>-->
                         <script> /*
	$(function() {
		  $('#i20<?php echo $clb['Id']; ?>').hide(); 
$('#i10<?php echo $clb['Id'];?>').hover(function() { 
    $('#i20<?php echo $clb['Id'];?>').show(); 
}, function() { 
    $('#i20<?php echo $clb['Id'];?>').hide(); 
});
$('#i30<?php echo $clb['Id'];?>').hover(function() { 
    $('#i20<?php echo $clb['Id'];?>').show(); 
}, function() { 
    $('#i20<?php echo $clb['Id'];?>').hide(); 
});


});
*/

</script>
                        </figure>
                      </div>
                      
                     
                  </div>
                  <?php }
} ?>
                </div>
                <div class="row">
                  <nav class="text-center margin-top-65 margin-bottom-75">
                    <ul class="pagination">
                      <?php echo $links; ?>
                    </ul>
                  </nav> 
                </div>
              </div>
              <!-- end single room details -->
            </div>
          </div>
        </div>
      </div>
      </section>
    <!-- end other detect room section -->
    <!-- start contact us area -->
    <!-- end contact us area -->
    <style>
      .border-dark-1 a {
        text-decoration: none;
      }
      body#accomodation_page .single_wrapper_details .single_room_cost .btn, body#accomodation_page .single_wrapper_details .single_room_cost .floatright .btn {
        margin-bottom: -36px !important;
      }
      body#accomodation_page .single_wrapper_details .single_wrapper_details_pad, body#accomodation_page .single_wrapper_details .single_wrapper_details_pad {
        height: auto;
        width: 100%;
      }
      img.eightimg {
        height: 412px; width: 100%;
      }
      img.rm {
        height: 150px; width: 100%;
      }
      img.uo {
     height: 188px;
    width: 360px;
    max-width: 100%;
  }
      .room_media {
        margin-bottom: 28px;
        text-align: center;
      }
      .padding-22 {
        padding: 27px 22px;
        text-align: justify;
      }
      img.ew {
        height: 150px; width: 100%;
      }
    </style>
