<!-- start breadcrumb -->
<section class="breadcrumb_main_area margin-bottom-80">
  <div class="container-fluid">
    <div class="row">
      <div class="breadcrumb_main nice_title">
        <h2>Search TableFast
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
            
          </div>
        </div>
        <!-- end offer start -->
      </div>
    </div>
  </div>
</section>
<!-- end breadcrunb -->
<!-- start other detect room section -->
<section class="other_room_area">
  <div class="container">
    <div class="row">
      <div class="other_room">
        <div class="section_title nice_title content-center">
          <!--  <h3>Other Decent Table</h3>-->
        </div>
        <!----------------------------------------------------------------------------------------------->
        <div class="accomodation_single_room">
          <div class="container">
            <div class="row">
              <div class="col-md-9  col-lg-9 col-sm-12">
                <?php if(!empty($putresult)){ 
foreach($putresult as $clb) {
$cid=$clb['Id'];

 $que=$this->db->query("SELECT ROUND(AVG(Review),1) as totalcal FROM `tbl_reviews` WHERE ClubId='".$cid."'");
                    $res=$que->result_array();
                    $tto=$res[0]['totalcal'];
                 

$clublayout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$cid);
$img=$clublayout[0]['MainImage'];
$NoofPax=$clublayout[0]['PerAdultPrice'];
$Cuisines=$clublayout[0]['Cuisines'];
$currentday= date('l');
$SundayFrom=$clublayout[0]['SundayFrom'];
$SundayTo=$clublayout[0]['SundayTo'];
$SundayFromClose=$clublayout[0]['SundayFromClose'];
$SundayToClose=$clublayout[0]['SundayToClose'];
$MondayFrom=$clublayout[0]['MondayFrom'];
$MondayTo=$clublayout[0]['MondayTo'];
$MondayFromClose=$clublayout[0]['MondayFromClose'];
$MondayToClose=$clublayout[0]['MondayToClose'];
$TuesdayFrom=$clublayout[0]['TuesdayFrom'];
$TuesdayTo=$clublayout[0]['TuesdayTo'];
$TuesdayToClose=$clublayout[0]['TuesdayToClose'];
$WednesdayFrom=$clublayout[0]['WednesdayFrom'];
$WednesdayTo=$clublayout[0]['WednesdayTo'];
$WednesdayFromClose=$clublayout[0]['WednesdayFromClose'];
$WednesdayToClose=$clublayout[0]['WednesdayToClose'];
$ThursdayFrom=$clublayout[0]['ThursdayFrom'];
$ThursdayTo=$clublayout[0]['ThursdayTo'];
$ThursdayFromClose=$clublayout[0]['ThursdayFromClose'];
$ThursdayToClose=$clublayout[0]['ThursdayToClose'];
$FridayFrom=$clublayout[0]['FridayFrom'];
$FridayTo=$clublayout[0]['FridayTo'];
$FridayFromClose=$clublayout[0]['FridayFromClose'];
$FridayToClose=$clublayout[0]['FridayToClose'];
$SaturdayFrom=$clublayout[0]['SaturdayFrom'];
$SaturdayTo=$clublayout[0]['SaturdayTo'];
$SaturdayFromClose=$clublayout[0]['SaturdayFromClose'];
$SaturdayToClose=$clublayout[0]['SaturdayToClose'];
if($currentday =='Monday'){
$dt= $MondayFrom.' - '.$MondayTo;
} elseif($currentday =='Tuesday'){
$dt= $TuesdayFrom.' - '.$TuesdayTo;
}
elseif($currentday =='Wednesday'){
$dt= $WednesdayFrom.' - '.$WednesdayTo;
}
elseif($currentday =='Thursday'){
$dt= $ThursdayFrom.' - '.$ThursdayTo;
}
elseif($currentday =='Friday'){
$dt= $FridayFrom.' - '.$FridayTo;
}
elseif($currentday =='Saturday'){
$dt= $SaturdayFrom.' - '.$SaturdayTo;
}
elseif($currentday =='Sunday'){
$dt= $SundayFrom.' - '.$SundayTo;
}
else{
$dt= $SundayFrom.' - '.$SundayTo;
}
?>
                <div class="boxclx">
                  <div clas=" row">
                    <div class="col-lg-4 col-md-4 col-sm-12">
                      <div class="mk">
                        <a href="<?php echo base_url('detail/'.$clb['Slug']);?>">
                          <?php if($img!=''){ 
                               if (file_exists(FCPATH.'assets/clubimage/'.$img)){
                              ?>
                          <img src="<?php echo base_url('assets/clubimage/'.$img);?>" alt="" class="ew">
                               <?php }else{
                                   
                                ?>
                          <img src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="" class="ew">
                          <?php   
                               } }else{ ?>
                          <img src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="" class="ew">
                          <?php } ?>
                        </a>
                          
                      </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-12">
                      <div class="col-md-12">
                        <a href="<?php echo base_url('detail/'.$clb['Slug']);?>">
                          <h3 class="titlecls">
                            <?php echo $clb['ClubName'];?>
                               <span class="njk"><?php echo $tto;?></span>
                          </h3>
                        </a>
                         </div>
                          <div class="col-md-12">
                          <div class="col-md-8">
                        <p class="col"> 
                          <label>
                            <i class="fa fa-map-marker">
                            </i> 
                            
                             <?php echo $clb['Address']; ?>
                             <?php echo '<br>'.$clb['City'].'-'.$clb['PostCode'].' ,<br>'.$clb['Country']; ?>
                          </label>
                        </p>
                         
                        </div>
                        <div class="col-md-4">
                          
                         <a  href="<?php echo base_url('detail/'.$clb['Slug']);?>" class="btn bmp mo">View Menu
                        </a>
<?php $vendorid=$this->session->userdata['vendorauth']['Id'];                                        
if($vendorid==''){ ?>
                         <a  href="<?php echo base_url('detail/'.$clb['Slug']);?>" class="btn btn-warning bmp ">Book Now
                        </a><?php }?>
                        </div>
                        </div>
                        
                  
                 
                 
                 
                 
                 
                 
                 
                 
                  </div>
                </div>
                <div clas=" row">
                  <div class="col-lg-12 col-md-12 col-sm-12 mg">
                    <div class="row">
                      <div class="col-md-3 col-lg-3 col-sm-3">
                        <label class='pol'>CUISINES
                        </label>
                      </div>
                      <div class="col-md-9 col-lg-9 col-sm-9">
                        <p class='pol1'>
                          <?php echo $Cuisines; ?>
                        </p>
                      </div>
                    </div>
                    <div class="row"> 
                      <div class="col-md-3 col-lg-3 col-sm-3">
                        <label class='pol'>COST FOR TWO
                        </label>
                      </div>
                      <div class="col-md-9 col-lg-9 col-sm-9">
                        <p class='pol1'>
                          <?php echo $NoofPax.' QAR';?>
                        </p>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-3 col-lg-3 col-sm-3">
                        <label class='pol'>HOURS
                        </label>
                      </div>
                      <div class="col-md-9 col-lg-9 col-sm-9">
                        <p class='pol1'>
                          <?php echo $dt;?> (Mon-Sun)
                        </p>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-3 col-lg-3 col-sm-3">
                        <label class='pol'>CONTACT
                        </label>
                      </div>
                      <div class="col-md-9 col-lg-9 col-sm-9">
                        <p class='pol'>
                          <i class="fa fa-phone">
                          </i> 
                          <?php echo $clb['Phone'];?>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <?php }
}else {
    echo '<div style="text-align:center;font-size:24px">Search Result not found.</div>';
}?>
              </div>
          <div class="col-md-3 col-lg-3 col-sm-12 ">
            <!-- start hotel booking -->
            <div class="col-lg-12 col-md-12 col-sm-4">
              <div class="hotel_booking_area clearfix">
                <div class="hotel_booking">
                  <form id="form1" role="form" action="<?php echo base_url('search');?>" method="post" class="">
                    <div class="col-lg-12 col-md-12">
                      <div class="room_book">
                        <h6>Book Your
                        </h6>
                        <p>Table
                        </p>
                      </div>
                    </div>
                    <div class="form-group col-lg-12 col-md-12">
                      <div class="input-group border-bottom-dark-2">
                          <input class="form-control" type="text" name="clubname" id="clubname" placeholder="ClubName or Address" required onkeyup="showResult(this.value)"/>
                        <div class="input-group-addon">
                          <i class="fa fa-map-marker">
                          </i>
                        </div>  
                      </div>
                      <div id="kpl">
                      </div>
                    </div> 
                    <script>
                      function showResult(val){
                        var url="<?php echo base_url('front/autosearch');?>";
                        $.ajax({
                          type: 'post',
                          dataType : 'json',
                          url: url,
                          data: "category="+val,
                          success: function (data) {
                            $("#kpl").html(data);
                          }
                        }
                              );
                      }
                    </script>
                    <div class="form-group col-lg-12 col-md-12">
                      <div class="input-group border-bottom-dark-2">
                        <input class="date-picker" id="datepicker" name="bookdata" placeholder="Arrival" type="text">
                        <div class="input-group-addon">
                          <i class="fa fa-calendar">
                          </i>
                        </div>   
                      </div>
                    </div>
                    <div class="col-lg-12 col-md-12">
                      <div class="row">
                        <div class="form-group col-lg-6 col-md-6 icon_arrow">
                          <div class="input-group border-bottom-dark-2">
                            <select class="form-control" name="adult" id="adult">
                              <option selected="selected" disabled="disabled">1 Adult
                              </option>
                              <option value="1">1 Adult
                              </option>
                              <option value="2">2 Adult
                              </option>
                              <option value="3">3 Adult
                              </option>
                              <option value="4">4 Adult
                              </option>
                              <option value="5">5 Adult
                              </option>
                              <option value="6">6 Adult
                              </option>
                              <option value="7">7 Adult
                              </option>
                              <option value="8">8 Adult
                              </option>
                              <option value="9">9 Adult
                              </option>
                              <option value="10">10 Adult
                              </option>
                              <option value="11">11 Adult
                              </option>
                              <option value="12">12 Adult
                              </option>
                              <option value="13">13 Adult
                              </option>
                              <option value="14">14 Adult
                              </option>
                              <option value="15">15 Adult
                              </option>
                              <option value="16">16 Adult
                              </option>
                              <option value="17">17 Adult
                              </option>
                              <option value="18">18 Adult
                              </option>
                              <option value="19">19 Adult
                              </option>
                              <option value="20">20 Adult
                              </option>
                              <option value="many">Many
                              </option>  
                            </select>
                          </div>
                        </div>
                        <div class="form-group col-lg-6 col-md-6 icon_arrow">
                          <div class="input-group border-bottom-dark-2">
                            <select class="form-control" name="child" id="child">
                              <option selected="selected" disabled="disabled">0 Child
                              </option>
                              <option value="1">1 Child
                              </option>
                              <option value="2">2 Child
                              </option>
                              <option value="3">3 Child
                              </option>
                              <option value="4">4 Child
                              </option>
                              <option value="5">5 Child
                              </option>
                              <option value="6">6 Child
                              </option>
                              <option value="7">7 Child
                              </option>
                              <option value="8">8 Child
                              </option>
                              <option value="9">9 Child
                              </option>
                              <option value="10">10 Child
                              </option>
                              <option value="11">11 Child
                              </option>
                              <option value="12">12 Child
                              </option>
                              <option value="13">13 Child
                              </option>
                              <option value="14">14 Child
                              </option>
                              <option value="15">15 Child
                              </option>
                              <option value="16">16 Child
                              </option>
                              <option value="17">17 Child
                              </option>
                              <option value="18">18 Child
                              </option>
                              <option value="19">19 Child
                              </option>
                              <option value="20">20 Child
                              </option>
                              <option value="many">Many
                              </option>
                            </select>               
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-12 col-md-12">
                      <input type="submit" name="submit" value="Search" class="btn btn-warning btn-md floatright" >
                    </div>
                  </form>
                </div>
              </div>
            </div>
            <script>
              function searchfun(id){
                var url="<?php echo base_url('front/getname');?>";
                $.ajax({
                  type: 'post',
                  dataType : 'json',
                  url: url,
                  data: "id="+id,
                  success: function (data) {
                    document.getElementById('clubname').value=data;
                  }
                }
                      );
                //alert(id);
              }
            </script>   
            <!-- end hotel booking -->
            <!-- start client says slider -->
            <div class="col-lg-12 col-md-12 col-sm-4">
              <div class="customer_says margin-top-65">
                <div class="section_title margin-bottom-30">
                  <h5>Customer Review
                  </h5>
                </div>
                <div class="section_description">
                  <div id="customer_says_slider" class="carousel slide" data-ride="carousel" data-pause="none">
                    <!-- Wrapper for slides -->
                    <div class="carousel-inner" role="listbox">
                      
                       <?php 
                 $resa= $this->App->getRecordByLimit('tbl_reviews', 'PublishStatus', '1', '0', '3');
                 if(!empty($resa)){ $j=1;
                     foreach($resa as $rts){
                         $cmt = substr($rts['Reviewscomment'], 0, 200);
                         $Review = $rts['Review'];
                         
                          if($Review=='5'){
                                                              $s='<span class="str"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><span>';
                                                          }elseif($Review=='4'){
                                                              $s='<span class="str"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-o"></i><span>';
                                                          }elseif($Review=='3'){
                                                              $s='<span class="str"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><span>';
                                                          }elseif($Review=='2'){
                                                              $s='<span class="str"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><span>';
                                                          }elseif($Review=='1'){
                                                              $s='<span class="str"><i class="fa fa-star"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><span>';
                                                          }else{
                                                              $s='<span class="str"><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><span>';
                                                          }
                         $BookingId = $rts['BookingId'];
                         $Created=$rts['Created'];
                           $bookingdetails= $this->App->getPerticularRecord('tbl_booking', 'Id', $BookingId);
                           $name=$bookingdetails[0]['FirstName'].' '.$bookingdetails[0]['LastName'];
                           $userid=$bookingdetails[0]['CustomerId'];
                            $clubid=$bookingdetails[0]['ClubId'];
                            
                            $clubdetails= $this->App->getPerticularRecord('tbl_vendor', 'Id', $clubid);
                           $clubname=$clubdetails[0]['ClubName'];
                           $customerdetails= $this->App->getPerticularRecord('tbl_customer', 'Id', $userid);
                           $ProfileImage=$customerdetails[0]['ProfileImage'];
                           
                           if($ProfileImage!=''){
                               if (file_exists(FCPATH.'assets/customerprofile/'.$ProfileImage)){
                                $i=base_url('assets/customerprofile/'.$ProfileImage);
                               }else{
                                   $i=base_url('assets/fronttheme/customcss/dummy.png');
                               }
                            }else{
                                $i=base_url('assets/fronttheme/customcss/dummy.png');
                            }
                  ?>
                <div class="item  <?php if($j==1){ echo 'active';}?>">
                  <div class="single_says">
                    <div class="customer_comment">
                        <h6 class="mkq"><?php echo $clubname; ?></h6>
                      <p><?php echo $s;?></p>
                        
                         <p><?php echo $cmt;?></p>
                      
                     
                    </div>
                    <div class="customer_detail clearfix">
                      <div class="customer_pic alignleft-20">
                        <a href="#">
                          <img src="<?php echo $i;?>" alt="" class="imgc">
                          
                        </a>
                      </div>
                      <div class="customer_identity floatleft">
                        <h6><?php echo $name;?> 
                        </h6>
                          
                      </div>
                    </div>
                  </div>
                </div>
                  
                  <?php $j++; }
                  } ?>
                    </div>
                    <!-- Controls -->
                    <a class="slider_says left" href="#customer_says_slider" role="button" data-slide="prev">
                      <i class="fa fa-angle-left">
                      </i>
                      <span class="sr-only">Previous
                      </span>
                    </a>
                    <a class="slider_says right" href="#customer_says_slider" role="button" data-slide="next">
                      <i class="fa fa-angle-right">
                      </i>
                      <span class="sr-only">Next
                      </span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
            <!-- end client says slider -->
          </div>                  
        </div>
      </div>
    </div>
    <!----------------------------------------------------------------------------------------------->
    <!----------------------------------------------------------------------------------------------->
    <!-- start single room details -->
  </div>
  </div>
</div>
</section>
<!-- end other detect room section -->
<!-- start contact us area -->
<!-- end contact us area -->
<style>
     i.fa.fa-star-o {
    padding: 1px;color: coral;
}
i.fa.fa-star {
    padding: 1px;
    color: coral;
}
    .mkq {
    color: #000;
    font-size: 21px;
    line-height: 30px;
    }
   .boxo {
    background: yellowgreen;
    color: #fff;
    font-size: 20px;
    text-align: center;
    width: 26%;
    float: right;
    border-radius: 3px;
    margin: 2px;
    font-family: serif;
}img.imgc {
    width: 25%;
    border-radius: 30px;
}span.io {
    background: yellowgreen;
    padding: 2px 10px;
    font-size: 24px;
    color: #fff;
    font-family: serif;
    border-radius: 4px;    float: right;
}
label.pol {
    font-size: 14px;
    color: #000;
    line-height: normal;
}
a.btn.bmp {
    padding: 6px 11px;
    margin: 4px 0px;
}a.btn.bmp.mo {
    font-size: 15px;
}.col label {
    
      font-size: 14px !important;
    font-weight: 300;
    margin-top: 11px;
}
p.col {
    padding: 6px 0px;
}
  body#room_detail_page .hotel_booking_area {
    background: #313a45 none repeat scroll 0 0;
    padding: 5px 5px 0px;
    position: relative;
  }
  img.ew {
    width: 100%;
    border-radius: 6px;
  }
  .border-dark-1 a {
    text-decoration: none;
  }
  body#accomodation_page .single_wrapper_details .single_room_cost .btn,
  body#accomodation_page .single_wrapper_details .single_room_cost .floatright .btn {
    margin-bottom: -36px !important;
  }
  body#accomodation_page .single_wrapper_details .single_wrapper_details_pad,
  body#accomodation_page .single_wrapper_details .single_wrapper_details_pad {
    height: auto;
    width: 100%;
  }
  img.eightimg {
    height: 412px;
  }
  img.rm {
    height: 150px;
  }
  img.uo {
    height: 188px;
  }
  .room_media {
    margin-bottom: 28px;
    text-align: center;
  }
  .padding-22 {
    padding: 27px 22px;
    text-align: justify;
  }
  img.ew {
    height: 150px;
  }
  .boxclx {
    border: 1px solid #ccc;
    display: inline-block;
    background: whitesmoke;
    padding: 12px;
    border-radius: 8px;
    margin: 1%;
    width:98%
  }
  h3.titlecls {
    padding-top: 10px;
  }
  .mg {
    border-top: 1px dotted;
    padding: 7px;
    margin-top: 15px;
  }
  .col-md-3.col-lg-3.col-sm-12.mds {
    background: #313a45;
  }
  input#clubname ,input#bookdate {
    background: transparent;
    border: none;
    color:#fff; font-size: 10px;
  }
  img.imgsearch {
    width: 34%;
  }
  .mop {
    border: 1px solid #ccc;
    background: #fff;
    padding: 2px;
    margin: 8px;
  }
 span.njk {
    font-size: 19px;
    text-align: center;
    color: #fff;
    background: yellowgreen;
    font-family: serif;
    float: right;
    border-radius: 3px;
    font-weight: bold;
    margin-right: 2%;
    
    width: 18%;    margin: 6px;

}
</style>
