<?php $this->load->view('front/include/bootstraptable/header');?>

<section class="breadcrumb_main_area margin-bottom-80">
  <div class="container-fluid">
    <div class="row">
      <div class="breadcrumb_main nice_title">
        <h2> Confirmed Booking
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
           
          </div>
        </div>         
        <!-- end offer start -->
      </div>
    </div>
  </div>            
</section>
<section class="contact_mail_area margin-bottom-90">
  <div class="container">
      <div class="row"> 
                  <div class="col-md-12  col-lg-12 col-sm-12 mnk">
                   <a class="btn  margin3 " href="<?php echo base_url('booking-request');?>" >
                        <i class="fa fa-thumbs-o-up">  </i>  Requested Booking  
                    </a>
                    <a class="btn  margin3 bluebtn" href="<?php echo base_url('booking-confirm');?>" >
                        <i class="fa fa-thumbs-up">  </i>  Confirmed Booking  
                    </a>
                    <a class="btn  margin3 " href="<?php echo base_url('booking-reject');?>" >
                        <i class="fa fa-remove">  </i>  Rejected Booking  
                    </a>
                    <a class="btn  margin3 " href="<?php echo base_url('booking-cancel');?>" >
                        <i class="fa fa-thumbs-down"> </i>  Cancelled  Booking  
                    </a>
                    <a class="btn  margin3 " href="<?php echo base_url('booking-complete');?>" >
                        <i class="fa fa-check">  </i>  Completed  Booking  
                    </a>
                  </div>
         
              </div>  
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2 style="font-size:20px ">Confirmed Booking
            </h2>
           
            <!------------------------------------>
            <!------------------------------------------->
                             <div class="row">
                       <div class="col-md-12 col-sm-12 col-xs-12">
                           
                       <form action="<?php echo base_url('booking-confirm');?>" method="post">
                       <div class="boxborder"><h5 class="f5">Search By - </h5>
                        
							<div class="col-md-2 col-sm-6 col-xs-12 p5">
                                                            <input value="<?php echo $username;?>" type="text" name="username" id="username"  class="form-control" placeholder="Enter Name">
							  
							</div>
                           <div class="col-md-2 col-sm-6 col-xs-12 p5">
                                                            <input value="<?php echo $phone;?>" type="text" name="phone" id="phone"  onkeypress="return ValidatePhoneNo()" maxlength="10"  class="form-control" placeholder=" Phone number">
							  
							</div>
                           <div class="col-md-2 col-sm-6 col-xs-12 p5">
                                                            <input value="<?php echo $bookingno;?>" type="text" name="bookingno" id="bookingno"  class="form-control" placeholder=" Booking No.">
							  
							</div>
                         <script>
                        function ValidatePhoneNo() {
                          if ((event.keyCode > 47 && event.keyCode < 58) || event.keyCode == 43 || event.keyCode == 32)
                            return event.returnValue;
                          return event.returnValue = '';
                          
                        }
                      </script>
                         
							
							
                            <div class="col-md-4 col-sm-6 col-xs-12 p5">
                            <div class="controls">
                                <div class="input-prepend input-group">
                                  <span class="add-on input-group-addon"><i class="glyphicon glyphicon-calendar fa fa-calendar"></i></span>
                                  <input type="text"  name="reservation" id="reservation" class="form-control"  />
                                </div>
                              </div>
                                   </div>
							<div class="col-md-2 col-sm-3 col-xs-3 p5">
							  <input type="submit" name="submit" value="Search" class="btn btn-info">
							</div>
							
							</div>
							</form>
                           
                       </div>
                     </div>
                     <!--------------------------------------------->
            
          </div>
          <!------------------------------------------->
        </div>
        <div class="x_content">
        	
          <table id="datatable-buttons" style="overflow-x: scroll;" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
              <tr>
                <th>Action</th> 
                <th>Booking No.</th>
                <th>Name</th>
                <th>Booking Date</th>
                <th>Booking Time</th>
                <th>No. of Pax</th>  
                <th>Phone</th>  
                <th>Email</th>                            
                <th>Date</th>  
                <th>Dining Preferences</th>
              </tr>
            </thead>
            <tbody>
            <?php  
                if(!empty($listbooking)){
                foreach($listbooking as $cat){ 
                if($cat['Status']=='1'){ $s='Active';}else{ $s='Inactive';}
                if($cat['BookingStatus']=='1'){
                ?>
              <tr>
                <td> 
<?php $ct = date('Y-m-d');
 $bkdt=$cat['BookingDate'];

if (strtotime($bkdt) > strtotime($ct) ) { ?>
 <a  class="btn btn-warning pad-30" style="margin:3px 0px;" data-toggle="tooltip" title="Reject" onclick="rejectreq('<?php echo $cat['Id']?>')">
                    <i class="fa fa-times-circle"> 
                    </i>  
                  </a> 
                  <a  class="btn btn-dark pad-30" style="margin:3px 0px;padding: 7px 9px;background: #2A3F54; color: #fff;  border: 1px;" data-toggle="tooltip" title="Cancel" onclick="cancelreq('<?php echo $cat['Id']?>')">
                    <i class="fa fa-remove"> 
                    </i>  
                  </a> 
  
<?php  }else{
?>                   
         <a class="btn pad-30" style="margin:3px 0px" data-toggle="tooltip" title="Complete"  onclick="completeprocess('<?php echo $cat['Id']?>')">
                    <i class="fa fa-check"> 
                    </i>  
                  </a>            
<?php }?>         
       
                </td>
                 <td><?php echo  'B00'.$cat['BookingNo'];?></td>
                <td><?php echo  $cat['FirstName'].' '.$cat['LastName'];?></td>
                <td><?php echo  $cat['BookingDate'];?></td>
                <td><?php echo  $cat['BookingTime'];?></td>
                <td><?php echo  $cat['NoofPax'];?></td>                
                <td><?php echo  $cat['Phone'];?></td>
                <td><?php echo  $cat['Email'];?></td>                
                <td><?php echo  $cat['Created'];?></td>
                <td><?php echo  $cat['DiningPreferences'];?></td>
               
              </tr>
                <?php } } } ?>
            </tbody>
          </table>
         
          <script>
            function cancelreq(id){
              var r = confirm("Are You sure want to Cancel this Request?");
              var url="<?php echo base_url('booking/cancelrequest');?>";
              if (r == true) {
                $.ajax({
                  type: 'post',
                  url: url,
                  data: "id="+id,
                  success: function () {
                    alert('Canceled Request Successfully');
                    location.reload();
                  }
                }
                      );
              }
            }
            function completeprocess(id){
              var r = confirm("Are You sure want to Complete this Request?");
              var url="<?php echo base_url('booking/completerequest');?>";
              if (r == true) {
                $.ajax({
                  type: 'post',
                  url: url,
                  data: "id="+id,
                  success: function () {
                    alert('Complete Request Successfully');
                    location.reload();
                  }
                }
                      );
              }
            }

 function rejectreq(id){
              var r = confirm("Are You sure want to Reject this Request?");
              var url="<?php echo base_url('booking/rejectrequest');?>";
              if (r == true) {
                $.ajax({
                  type: 'post',
                  url: url,
                  data: "id="+id,
                  success: function () {
                    alert('Rejected Request Successfully');
                    location.reload();
                  }
                }
                      );
              }
            }
          </script>	
        </div>
      </div>
    </div>
  </div>
  </div>
</div>
</section>
<div id="updatediv">
</div>
<script>
  function editcategory(){
    var s=$("#cattitle1 option:selected").val();
    var itemtitle1=$("#itemtitle1").val();
    var itemid=$("#itemid").val();
    var price1=$("#price1").val();
    var catstatus=$().val("#catstatus option:selected");
    var url="<?php echo base_url('food/edititem');?>";
    if(s=='' || itemtitle1=='' || price1==''){
      $("#err3").html("Please item title required");
    }
    else{
      $.ajax({
        type: 'post',
        dataType : 'json',
        url: url,
        data: "category="+s+"&itemtitle1="+itemtitle1+"&price1="+price1+"&itemid="+itemid+"&catstatus="+catstatus,
        success: function (data) {
          if(data=='1'){
            alert('Item successfully Update.');
            location.reload();
          }
          if(data=='2'){
            $('#err2').html('Item already Exist.');
          }
        }
      }
            );
    }
  }
</script>

<?php $this->load->view('front/include/bootstraptable/footer');?>
