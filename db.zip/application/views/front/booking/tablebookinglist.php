<?php $this->load->view('front/include/bootstraptable/header');?>
<section class="breadcrumb_main_area margin-bottom-80">
  <div class="container-fluid">
    <div class="row">
      <div class="breadcrumb_main nice_title">
        <h2> Booking Calender
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
            
          </div>
        </div>         
        <!-- end offer start -->
      </div>
    </div>
  </div>            
</section>
<section class="contact_mail_area margin-bottom-90">
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
           <?php echo 'Total Table : '.$totaltable;?>
        </div>
        <div class="x_content">
        	
          <table id="datatable-buttons" style="overflow-x: scroll;" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
              <tr>
                <th>Action
                </th> 
                <th>Date 
                </th>
                
                <th>Booking Table
                </th>
                <th>Available table
                </th> 
                 
              </tr>
            </thead>
            <tbody>
              <?php if(!empty($listbook)){
foreach($listbook as $cat){ 
$CategoryId=$cat['BookingDate'];
$ava =  $totaltable-$cat['NobTable'];?>
              <tr>
                <td>
                  <a  class="btn pad-30" style="margin:3px 0px" data-toggle="tooltip" title="Update"  onclick="viewpopup('<?php echo $cat['NobTable'];?>','<?php echo $ava;?>','<?php echo $cat['Id']?>')">
                    <i class="fa fa-eye"> 
                    </i>  
                  </a> 
                 
                </td>
                <td>
                  <?php echo  $cat['BookingDate'];?>
                </td>
                <td>
                  <?php echo $cat['NobTable'];?>
                </td>
                <td>
                  <?php echo $totaltable-$cat['NobTable'];?>
                </td>
                
              </tr>
              
               <!-- Modal content -->
				  <div id="myModal1-<?php echo $cat['Id']?>" class="modal" style="display:none">			 
				  <div class="modal-content">	
				  <div class="row">
				  <div class="col-md-12">
				  <div class="boxcircle">
				   <?php $book =$cat['NobTable'];
				    for($i=0;$i<$book;$i++){
					   echo '<span class="roundbook">B</span>';	
					}
					for($i=0;$i<$ava;$i++){
					   echo '<span class="roundavailabel">A</span>';	
					}
				    
				   ?>			
					</div></div></div>
					<hr>
					<center><a onclick="closemodel('<?php echo $cat['Id']?>')" class="btn pad-30 ">Close</a></center>
				  </div>
				</div>
			  <!-- Closed Modal content -->
              <?php }
} ?>
            </tbody>
          </table>
         
          <script>
            function viewpopup(booked,available,unic){
				$("#myModal1-"+unic).show();
            }
            function closemodel(id){
              $("#myModal1-"+id).hide();
            }
          </script>	
        </div>
      </div>
    </div>
  </div>
  </div>
</div>
</section>

<style>
.boxcircle {	
      width: 100% !important;
    display: inline-block;
	}
span.roundbook {
    background: #f14;
    padding: 5px 10px;
    margin: 4px;
    color: #fff;
    font-size: 18px;
    font-weight: bold;
    border-radius: 21px;    
    display: inline-table;
}
span.roundavailabel {
       background: #ccc;
    padding: 5px 10px;
    margin: 4px;
    color: #fff;
    font-size: 16px;
    font-weight: bold;
    border-radius: 21px;
    display: inline-table;
}
/* The Modal (background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
    background-color: #fefefe;
    margin: auto;
    padding: 20px;
    border: 1px solid #888;
    width: 50%;
}

/* The Close Button */
.close {
    color: #aaaaaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}
</style>

<?php $this->load->view('front/include/bootstraptable/footer');?>
