<!-- start breadcrumb -->
<section class="breadcrumb_main_area margin-bottom-80">
   <div class="container-fluid">
      <div class="row">
         <?php $vid=$vendordetails[0]['Id'];
            $layout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$vid);
            $img=$layout[0]['MainImage'];
            
                $PerAdultPrice11=$layout[0]['PerAdultPrice'];
            
            $Description=$layout[0]['Description'];
            if($img!=''){
            $i=base_url('assets/clubimage/'.$img);
            }else{
            $i=base_url('assets/fronttheme/banner/TableFast-Banner-2.jpg');
            } ?>
         <style>
            .march {
            background:url(<?php echo $i;?>);
            background-repeat: no-repeat;
            background-size:     cover;
            }
         </style>
         <div class="breadcrumb_main nice_title march">
            <h2>
               <?php echo $vendordetails[0]['ClubName'];?>
            </h2>
            <!-- special offer start -->
            <div class="special_offer_main">
               <div class="container">
                  <div class="special_offer_sub">
                     <?php $vid=$vendordetails[0]['Id'];
                        $layout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$vid);
                        $img=$layout[0]['MainImage'];
                            $Description=$layout[0]['Description'];
                            $Cuisines=$layout[0]['Cuisines'];
                            $PerAdultPrice=$layout[0]['PerAdultPrice'];
                        if($img!=''){
                        $i=base_url('assets/clubimage/'.$img);
                        }else{
                        $i=base_url('assets/fronttheme/banner/TableFast-Banner-2.jpg');
                        } ?>
                  </div>
               </div>
            </div>
            <!-- end offer start -->
         </div>
      </div>
   </div>
</section>
<!-- end breadcrunb -->
<div class="room_detail_main margin-bottom-55">
   <div class="container">
      <div class="row">
         <div class="col-lg-12 col-md-12">
            <?php  $this->load->view('front/include/tab');?>
         </div>
         <div class="col-lg-9 col-md-9">
            <div class="deluxe_room_detail">
               <div class="section_title content-left margin-bottom-5">
                  <h5>
                     <?php echo $vendordetails[0]['ClubName'];?> Detail 
                     <span class="price floatright"><?php echo $PerAdultPrice.' QR';?>
                     </span> 
                     <br> 
                     <span class="day floatright">
                     </span>
                  </h5>
               </div>
               <div class="section_content">
                  <p>Checkout the latest deal
                  </p>
                  <div class="showcase">
                     <div class="section_description">
                        <div class="row">
                           <div class="col-lg-12 col-md-12">
                              <div class="clearfix" style="">
                                 <ul id="image-gallery" class="gallery list-unstyled cS-hidden">
                                    <!-- <ul id="vertical" class="gallery list-unstyled"> -->
                                    <?php  $vid=$vendordetails[0]['Id'];
                                       $layout=$this->App->getPerticularRecord('tbl_clubgallery','VendorId',$vid);
                                       
                                       $imsg=$layout[0]['Image'];
                                       if(!empty($layout)){
                                       foreach($layout as $lay){  ?>
                                    <li data-thumb="<?php echo base_url('assets/clubgallery/'.$lay['Image']);?>">
                                       <img class="mslider" src="<?php echo base_url('assets/clubgallery/'.$lay['Image']);?>" style="width:100%"/>
                                    </li>
                                    <?php }
                                       }
                                       ?>
                                 </ul>
                              </div>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-lg-12 col-md-12">
                              <div class="room_facilities_des padding-top-50 padding-bottom-50 border-bottom-whitesmoke border-top-whitesmoke">
                                 <p>
                                    <label style="color: #000;    font-size: 24px;">Cost For Two : 
                                    <span style="    font-size: 13px;
                                       color: navy;
                                       font-family: sans-serif;
                                       }">
                                    <?php echo $PerAdultPrice.' QR';?>
                                    </span>
                                    </label> 
                                    <label style="color: #000;    font-size: 24px;">Cuisines : 
                                    <span style="    font-size: 13px;
                                       color: navy;
                                       font-family: sans-serif;
                                       }">
                                    <?php echo $Cuisines;?>
                                    </span>
                                    </label> 
                                 </p>
                                 <p>
                                    <?php echo $Description;?> 
                                 </p>
                                 <p>
                                    <?php $vid=$vendordetails[0]['Id'];
                                       $layout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$vid);
                                       echo 'Available Parking : </span>'.$layout[0]['AvailableParking'];
                                       if($layout[0]['AvailableParking']=='paid'){
                                       echo '<br>Parking Price (Per hrs) : </span> Rs '.$layout[0]['PriceParkingPerhrs'];
                                       }?> 
                                 </p>
                              </div>
                           </div>
                        </div>
                        <div class="row">
                           <!-- start welcome section -->
                           <!-- end welcome section -->
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-lg-3 col-md-3">
            <!-- start hotel booking -->
            <div class="col-lg-12 col-md-12 col-sm-4 myclspo">
               <div class="hotel_booking_area clearfix myclspo1">
                  <div class="hotel_booking">
                     <form id="form1" role="form" action="#" class="">
                        <div class="col-lg-12 col-md-12">
                           <div class="room_book">
                              <h6>Vendor Details
                              </h6>
                              <p>Club
                              </p>
                           </div>
                        </div>
                        <?php $vid=$vendordetails[0]['Id'];
                           $vendordetails=$this->App->getPerticularRecord('tbl_vendor','Id',$vid);?>
                        <div class="form-group col-lg-12 col-md-12">
                           <div class="input-group border-bottom-dark-2">
                              <br>
                              <label style="    font-size: 20px;    color: whitesmoke;">
                              <?php echo $vendordetails[0]['FirstName'].' '.$vendordetails[0]['LastName'];?>
                              </label>
                              <br>
                              <label>
                              <i class="fa fa-envelope">
                              </i> 
                              <?php echo $vendordetails[0]['Email'];?>
                              </label>
                              <label>
                              <i class="fa fa-phone">
                              </i> 
                              <?php echo $vendordetails[0]['Phone'] .' , '.$vendordetails[0]['AlternativePhone'];?>
                              </label>
                              <br>
                              <label>
                              <i class="fa fa-map-marker">
                              </i> 
                              <?php echo $vendordetails[0]['Address'].' <br> '.$vendordetails[0]['City'].'-'.$vendordetails[0]['PostCode'].' ,'.$vendordetails[0]['Country']; ?>
                              </label>
                              <br>
                              <label>
                              <?php $AddressIfram=$vendordetails[0]['AddressIfram'];
                                 if($AddressIfram!=''){ ?>
                              <iframe width="100%" height="250" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAyhF2cCWevFm_T8iog0GqV3utCrfAbWYw&q='<?php echo $AddressIfram;?>'">
                              </iframe>
                              <?php } ?>
                              </label> 
                           </div>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
            <!-- end hotel booking -->
            <!-- start client says slider -->
            <!-- end client says slider -->
         </div>
      </div>
      <div class="row">
         <p class="vencls">Opening hours :  
            <?php  
               $vid=$vendordetails[0]['Id'];
               $layout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$vid);
               $SundayFrom=$layout[0]['SundayFrom'];
               $SundayTo=$layout[0]['SundayTo'];
               $SundayFromClose=$layout[0]['SundayFromClose'];
               $SundayToClose=$layout[0]['SundayToClose'];
               $MondayFrom=$layout[0]['MondayFrom'];
               $MondayTo=$layout[0]['MondayTo'];
               $MondayFromClose=$layout[0]['MondayFromClose'];
               $MondayToClose=$layout[0]['MondayToClose'];
               $TuesdayFrom=$layout[0]['TuesdayFrom'];
               $TuesdayTo=$layout[0]['TuesdayTo'];
               $TuesdayToClose=$layout[0]['TuesdayToClose'];
               $WednesdayFrom=$layout[0]['WednesdayFrom'];
               $WednesdayTo=$layout[0]['WednesdayTo'];
               $WednesdayFromClose=$layout[0]['WednesdayFromClose'];
               $WednesdayToClose=$layout[0]['WednesdayToClose'];
               $ThursdayFrom=$layout[0]['ThursdayFrom'];
               $ThursdayTo=$layout[0]['ThursdayTo'];
               $ThursdayFromClose=$layout[0]['ThursdayFromClose'];
               $ThursdayToClose=$layout[0]['ThursdayToClose'];
               $FridayFrom=$layout[0]['FridayFrom'];
               $FridayTo=$layout[0]['FridayTo'];
               $FridayFromClose=$layout[0]['FridayFromClose'];
               $FridayToClose=$layout[0]['FridayToClose'];
               $SaturdayFrom=$layout[0]['SaturdayFrom'];
               $SaturdayTo=$layout[0]['SaturdayTo'];
               $SaturdayFromClose=$layout[0]['SaturdayFromClose'];
               $SaturdayToClose=$layout[0]['SaturdayToClose'];
               ?>
            <?php 
               $currentday= date('l');
               if($currentday =='Monday'){
               echo $MondayFrom.' - '.$MondayTo;
               } elseif($currentday =='Tuesday'){
               echo $TuesdayFrom.' - '.$TuesdayTo;
               }
               elseif($currentday =='Wednesday'){
               echo $WednesdayFrom.' - '.$WednesdayTo;
               }
               elseif($currentday =='Thursday'){
               echo $ThursdayFrom.' - '.$ThursdayTo;
               }
               elseif($currentday =='Friday'){
               echo $FridayFrom.' - '.$FridayTo;
               }
               elseif($currentday =='Saturday'){
               echo $SaturdayFrom.' - '.$SaturdayTo;
               }
               elseif($currentday =='Sunday'){
               echo $SundayFrom.' - '.$SundayTo;
               }
               else{
               echo $SundayFrom.' - '.$SundayTo;
               }?>
            <span style="float:right" class="tooltip4">See More
            <span class="tooltiptext">
            <label> Monday : 
            <?php echo $MondayFrom; ?> To 
            <?php echo $MondayTo;?>
            <label>Thuesday : 
            <?php echo $TuesdayFrom;?> To 
            <?php echo $TuesdayTo; ?>
            </label>
            <label>Wednesday :
            <?php echo $WednesdayFrom; ?> To 
            <?php echo $WednesdayTo; ?>
            </label>
            <label>Thursday : 
            <?php echo $ThursdayFrom; ?> To 
            <?php echo $ThursdayTo; ?>
            </label>
            <label>Friday : 
            <?php echo $FridayFrom; ?> To 
            <?php echo $FridayTo; ?>
            </label>
            <label>Saturday : 
            <?php echo $SaturdayFrom; ?> To
            <?php echo $SaturdayTo; ?>
            </label>
            <label>Sunday : 
            <?php echo $SundayFrom; ?> To 
            <?php echo $SundayTo; ?>
            </label>
            </span>
            </span>  
         </p>
      </div>
   </div>
</div>
</div>
<style>
   .tooltip4 {
   position: relative;
   display: inline-block;
   border-bottom: 1px dotted black;
   }
   .tooltip4 .tooltiptext {
   visibility: hidden;
   width: 220px;
   background-color: #555;
   color: #fff;
   text-align: center;
   border-radius: 6px;
   padding: 5px 5px;
   position: absolute;
   z-index: 1;
   bottom: 125%;
   left: -10%;
   margin-left: -140px;
   opacity: 0;
   transition: opacity 0.3s;
   }
   .tooltip4 .tooltiptext::after {
   content: "";
   position: absolute;
   top: 100%;
   left: 50%;
   margin-left: -5px;
   border-width: 5px;
   border-style: solid;
   border-color: #555 transparent transparent transparent;
   }
   .tooltip4:hover .tooltiptext {
   visibility: visible;
   opacity: 1;
   }
</style>
<!-- start contact us area -->
<!-- end contact us area -->
<style>
   .myclspo1 {
   background: #313a45;
   }
   p {
   color: #666666;
   /* font-weight: normal; */
   font-size: 14px;
   font-family: inherit;
   font-weight: normal;
   }
   label {
   font-family: serif;
   }
   span.a {
   COLOR: slategray;
   }
   p.vencls {
   color: navy;
   font-weight: bold;
   font-size: 18px;
   }
   label {
   display: table-row;
   color: #ccc;
   font-size: 13px;
   margin: 2px !important;
   }
</style>
