<!-- start breadcrumb -->
  <?php $metsetting=$this->App->passwordChecking('tbl_information','Id','Status','3','1');
        
    ?>
<section class="breadcrumb_main_area margin-bottom-80">
  <div class="container-fluid">
    <div class="row">
      <div class="breadcrumb_main nice_title">
        <h2>Privacy Policy
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
           
          </div>
        </div>         
        <!-- end offer start -->
      </div>
    </div>
  </div>            
</section>
<!-- end breadcrunb -->
<!-- start our room facilities -->
<section class="our_room_facilities_area">
  <div class="container">
    <div class="our_room_facilities margin-bottom-70">
      <div class="facilities_top_para">
      <h3><?php echo $metsetting[0]['Subtitle'];?></h3>
        <p>
        <?php echo $metsetting[0]['Description'];?>
        
        </p>
      </div>
      </div>
  </div>
</section>
<!-- end our room facilities -->
<!-- start contact us area -->

