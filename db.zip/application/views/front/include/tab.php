 <div class="">
     <a  href="<?php echo base_url('front/detail/'.$vendordetails[0]['Slug']);?>" class="btn menucls <?php if(current_url()==base_url('front/clubdetails/'.$vendordetails[0]['Slug']) || current_url()==base_url('front/detail/'.$vendordetails[0]['Slug'])){ echo 'act';}?>">Overview
          </a>
      <a  href="<?php echo base_url('front/menu/'.$vendordetails[0]['Slug']);?>" class="btn menucls <?php if(current_url()==base_url('front/menu/'.$vendordetails[0]['Slug'])){ echo 'act';}?>">Menu
          </a>
          <a  href="<?php echo base_url('front/events/'.$vendordetails[0]['Slug']);?>" class="btn menucls <?php if(current_url()==base_url('front/events/'.$vendordetails[0]['Slug'])){ echo 'act';}?>">Evens
          </a>
         
          <a href="<?php echo base_url('front/detail/'.$vendordetails[0]['Slug']);?>" class="btn menucls">Book a Table
          </a>
          <a href="<?php echo base_url('front/detail/'.$vendordetails[0]['Slug']);?>" class="btn menucls">Reviews
          </a>
             <a  href="<?php echo base_url('front/gallery/'.$vendordetails[0]['Slug']);?>" class="btn menucls">Photos
          </a>
        </div>
<style>
    a.btn.menucls {
    margin: 11px 2px;
    padding: 11px 30px;
}
.act {
    border: 2px solid #63c2ea;
     background: #63c2ea;
    color: #FFF;
}
.act:hover {
    background: #fff;
    color: #63c2ea;
    border: 2px solid #fff;
}
</style>