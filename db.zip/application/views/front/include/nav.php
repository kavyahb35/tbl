<?php $setting = $this->App->getRecord('tbl_setting');
           $logo = $setting[0]['HeaderLogo'];
       
            if($logo!=''){
                if (file_exists(FCPATH.'assets/logo/'.$logo)){
                 $logoimg=$logo;
                }else{
                    $logoimg='header.png';
                }
            }else{
                $logoimg='header.png';
            }
          $settingContactNumber = $setting[0]['ContactNumber'];
          $settingEmail = $setting[0]['Email'];
          $settingFacebook = $setting[0]['Facebook'];
          $settingAddress = $setting[0]['Address'];
          $settingGoogle = $setting[0]['Google'];
          $settingLinked = $setting[0]['Linked'];
          $settingTwitter = $setting[0]['Twitter'];
          $settingFooterLogo = $setting[0]['FooterLogo'];
           
 ?>
<header class="header_area"><meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
  
  <!-- start header top -->
  <div class="header_top_area">
    <div class="container">
      <div class="row">
        <div class="header_top clearfix">
          <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <div class="left_header_top">
              <!--<ul>
<li><a href="#"><img src="<?php echo base_url('assets/fronttheme/')?>/img/temp-icon.png" alt="temp-icon">India dc, GR 37°C</a></li>
</ul>-->
            </div>
          </div>
          <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 floatright">
            <div class="right_header_top clearfix floatright">
              <ul class="nav navbar-nav">
 <li role="presentation" >
                <?php 
$vendorid=$this->session->userdata['vendorauth']['Id'];
$customerid=$this->session->userdata['customerauth']['Id'];
if($vendorid==''){  if($customerid==''){
  ?>
   
                  <a id="drop1" href="<?php echo base_url('vendor-signin');?>" role="button" >
                   Vendor Sign In
                   
                  </a> 
<?php } } if($customerid==''){ if($vendorid==''){?>

<li role="presentation" >
                  <a id="drop1" href="<?php echo base_url('sign-in');?>" role="button" >
                   Customer Sign In
                   
                  </a>
             
  <?php } } ?>
   </li>
         
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end header top  -->
  <!-- start main header -->
  <div class="main_header_area">
    <div class="container">
      <!-- start mainmenu & logo -->
      <div class="mainmenu">
        <div id="nav">
          <nav class="navbar navbar-default">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header logocls">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation
                </span>
                <span class="icon-bar">
                </span>
                <span class="icon-bar">
                </span>
                <span class="icon-bar">
                </span>
              </button>
              <div class="site_logo fix ">
                <a id="brand" class="clearfix navbar-brand" href="<?php echo base_url();?>">
                  <img src="<?php echo base_url('assets/logo/'.$logoimg);?>" alt="Trips" class="logocls1">
                </a>
              </div>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
              <ul class="nav navbar-nav">
                <li role="presentation" >
                  <a id="drop-one" href="<?php echo base_url();?>"  aria-haspopup="true" role="button" aria-expanded="false">
                    Home
                  </a>
                </li>        
                <li>
                  <a href="<?php echo base_url('club-list')?>">Clubs
                  </a>
                </li>
                <li>
                  <a href="<?php echo base_url('about-us')?>">About Us
                  </a>
                </li>
                <li>
                  <a href="<?php echo base_url('contact-us');?>">Contact Us
                  </a>
                </li>
                <?php 
                
                
                
					
	$custid=$this->session->userdata['customerauth']['Id']; 
	$vendorid=$this->session->userdata['vendorauth']['Id'];   
	$teko=$this->App->getPerticularRecord('tbl_vendor','Id',$vendorid); 
	$ststatus=$teko[0]['Status'];   


                                
if($vendorid!=''){ ?>
                 <li role="presentation" class="dropdown">
                  <a id="drop2" href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" role="button" aria-expanded="false">
                    <?php echo $this->session->userdata['vendorauth']['author'];


?>
                  </a>
                  <ul id="menu2" class="dropdown-menu" role="menu">
<?php if($ststatus=='2'){?>
                    <li role="presentation">
                      <a role="menuitem" tabindex="-1" href="<?php echo base_url('vendor-dashboard');?>">Dashboard
                      </a>
                    </li><?php }?>
                    <li role="presentation">
                      <a role="menuitem" tabindex="-1" href="<?php echo base_url('update-step1');?>">Update Club Profile
                      </a>
                    </li>
                    <li role="presentation">
                      <a role="menuitem" target="_blank" tabindex="-1" href="<?php echo base_url('food/foodcategory');?>">List Menu Category
                      </a>
                    </li>
                    <li role="presentation">
                      <a role="menuitem" target="_blank" tabindex="-1" href="<?php echo base_url('food/fooditem');?>">List Menu Item
                      </a>
                    </li>

<li role="presentation">
                      <a role="menuitem" target="_blank" tabindex="-1" href="<?php echo base_url('package/combolist');?>">List Combo Packages
                      </a>
                    </li>
                    <li role="presentation">
                      <a role="menuitem" target="_blank" tabindex="-1" href="<?php echo base_url('events');?>">List Events
                      </a>
                    </li>
                    <li role="presentation">
                      <a role="menuitem" target="_blank" tabindex="-1" href="<?php echo base_url('events/types');?>">List Events Types
                      </a>
                    </li>
                    <li role="presentation">
                      <a role="menuitem" target="_blank" tabindex="-1" href="<?php echo base_url('club/facility');?>">List Facility
                      </a>
                    </li>
                     <li role="presentation">
                      <a role="menuitem"  tabindex="-1" href="<?php echo base_url('booking/tablebookingview');?>">Table Available List
                      </a>
                    </li>
                     <li role="presentation">
                      <a role="menuitem"  tabindex="-1" href="<?php echo base_url('events/completedtransaction');?>">Event parched ticket
                      </a>
                    </li>
                    <?php if($ststatus=='2'){?>
                    <li role="presentation">
                      <a role="menuitem" tabindex="-1" href="<?php echo base_url('vendor-change-password');?>">Change Password
                      </a>
                    </li>
 <li role="presentation">
                      <a role="menuitem"  tabindex="-1" href="<?php echo base_url('vendor/transactions');?>">List Transaction
                      </a>
                    </li>
<?php } ?>
                    <li role="presentation">
                      <a role="menuitem" tabindex="-1" href="<?php echo base_url('vendor-logout');?>">Sign Out
                      </a>
                    </li>
                  </ul>
                </li>
                <?php } elseif($custid!='') { ?>
                <li role="presentation" class="dropdown">
                  <a id="drop2" href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" role="button" aria-expanded="false">
                    <?php echo $this->session->userdata['customerauth']['Name'];?>
                  </a>
                  <ul id="menu2" class="dropdown-menu" role="menu">
                    <li role="presentation">
                      <a role="menuitem" tabindex="-1" href="<?php echo base_url('dashboard');?>">Dashboard
                      </a>
                    </li>
                    <li role="presentation">
                      <a role="menuitem" tabindex="-1" href="<?php echo base_url('profile');?>">Profile
                      </a>
                    </li>
                    <li role="presentation">
                      <a role="menuitem"  tabindex="-1" href="<?php echo base_url('customer/completedtransaction');?>">Event parched ticket
                      </a>
                    </li>
                    <li role="presentation">
                      <a role="menuitem" tabindex="-1" href="<?php echo base_url('change-password');?>">Change Password
                      </a>
                    </li>
                   
                    <li role="presentation">
                      <a role="menuitem" tabindex="-1" href="<?php echo base_url('logout');?>">Sign Out
                      </a>
                    </li>
                  </ul>
                </li>
                <?php }else{} ?>
                
                
                
              </ul>
             
            </div>
            <!-- /.navbar-collapse -->
          </nav>
        </div>
      </div>
      <!-- end mainmenu and logo -->
    </div>
  </div>
  <!-- end main header -->
</header>
<style>
  .mainmenu .nav.navbar-nav li.dropdown > a {
    background: url(img/dropdown_bg.png) no-repeat scroll 95% 90%;
  }
</style>
