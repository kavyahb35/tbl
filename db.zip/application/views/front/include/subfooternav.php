<?php $setting = $this->App->getRecord('tbl_setting');
          $logo = $setting[0]['HeaderLogo'];
          
            if($logo!=''){
               if (file_exists(FCPATH.'assets/logo/'.$logo)){
                 $logoimg=$logo;
                }else{
                    $logoimg='header.png';
                }
            }else{
                $logoimg='header.png';
            }
          
          
          $settingContactNumber = $setting[0]['ContactNumber'];
          $settingEmail = $setting[0]['Email'];
          $settingFacebook = $setting[0]['Facebook'];
          $settingAddress = $setting[0]['Address'];
          $settingGoogle = $setting[0]['Google'];
          $settingLinked = $setting[0]['Linked'];
          $settingTwitter = $setting[0]['Twitter'];
          $settingFooterLogo = $setting[0]['FooterLogo'];
            if($settingFooterLogo!=''){
                if (file_exists(FCPATH.'assets/logo/'.$settingFooterLogo)){
                 $logoimgfooter=$settingFooterLogo;
                }else{
                    $logoimgfooter='footer.png';
                }
            }else{
                $logoimgfooter='footer.png';
            }
 ?>
<section class="contact_us_area content-left">
   <div class="container">
      <div class="contact_us clearfix">
         <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
            <div class="call clearfix">
               <h6>Call Us
               </h6>
               <p><?php echo $settingContactNumber;?>
               </p>
            </div>
         </div>
         <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <div class="email_us clearfix">
               <h6>Email us
               </h6>
               <p><?php echo $settingEmail;?>
               </p>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
            <div class="news_letter clearfix">
               <input type="email" placeholder="Enter ID  for Newsletter" id="newsemail" id="newsemail" style="text-transform:none">
               <a onclick="newsletterfrom()" class="btn btn-blue">Subscribe
               </a>
            </div>
            <div class="errnews" style="font-size: 13px;margin-top: 0px;color: mediumvioletred;  font-weight: bold;"></div>
            <div class="successnews" style="font-size: 13px;margin-top: 0px;color: yellow;  font-weight: bold;"></div>
            <style>
               .errnews > p {
               font-size: 13px;margin-top: 0px;color: mediumvioletred;  font-weight: bold;
               }
            </style>
         </div>
         <script>
            function newsletterfrom(){
              var eml=$("#newsemail").val();
              var url="<?php echo base_url('front/newsletter');?>";
               if(eml!=''){
               $.ajax({
                              type: 'post',
                              dataType : 'json',
                              url: url,
                              data: "email="+eml,
                              success: function (data) {
                                if(data=='1'){
                                  $('.successnews').html('Thank you for subscribe our newsletter.').delay(3000).fadeOut();
                                   document.getElementById("newsemail").value = "";
                                 
                                }
                                if(data.err=='2'){
                                  $('.errnews').html(data.error).delay(3000).fadeOut();
                                }
                              }
                            });
               }else{
alert('Please Enter Valid Email Id');
                  /* $('.errnews').html('Please Enter Valid Email Id').delay(3000).fadeOut();*/
               }
              
            }
         </script>
         <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <div class="social_icons clearfix">
               <ul>
                  <!--<li>
                     <a href="<?php echo $settingFacebook;?>">
                     <i class="fa fa-facebook">
                     </i>
                     </a>
                  </li>
                  <li>
                     <a href="<?php echo $settingTwitter;?>">
                     <i class="fa fa-twitter">
                     </i>
                     </a>
                  </li>-->
                  <li>
                     <a href="<?php echo $settingGoogle;?>">
                     <i class="fa fa-google-plus">
                     </i>
                     </a>
                  </li>
                  <li>
                     <a href="<?php echo $settingLinked;?>">
                     <i class="fa fa-linkedin">
                     </i>
                     </a>
                  </li>
               </ul>
            </div>
         </div>
      </div>
   </div>
</section>
