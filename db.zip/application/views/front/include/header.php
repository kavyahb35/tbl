<?php header("Cache-Control: max-age=300, must-revalidate");?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <?php $this->load->view('front/meta/metapage');?>
   
     
     
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('assets/favicon/');?>favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- fonts -->
    <link href='https://fonts.googleapis.com/css?family=Playfair+Display:400,700,900' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Karla:700,400' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Lora:400,700' rel='stylesheet' type='text/css'>
    <!-- fontawesome -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/font-awesome.css" />
    <!-- bootstrap -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/bootstrap.min.css" />
    <!-- uikit -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/uikit.min.css" />
    <!-- animate -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/animate.css" />
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/datepicker.css" />
    <!-- Owl carousel 2 css -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/owl.carousel.css">
    <!-- rev slider -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/rev-slider/settings.css" />
    <!-- lightslider -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/lightslider.css">
    <!-- Theme -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/reset.css">
    <!-- custom css -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/style.css" />
    <!-- responsive -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/responsive.css" />
   
    <?php $s = $this->uri->segment(3);$e= $this->uri->segment(4);?>
  </head>
  <body 
        <?php 
        if(current_url()==base_url()){ echo 'id="home_two"';} 
         elseif(current_url() == base_url('booking/'.$s)){ echo 'id="about_us_page"';}
        elseif(current_url()==base_url('about')){ echo 'id="about_us_page"';}
        elseif(current_url()==base_url('contact')){ echo 'id="contact_us_page"';}
        elseif(current_url()==base_url('vendor-dashboard')){ echo 'id="booking_page"';}
        elseif(current_url()==base_url('step2')){ echo 'id="booking_page"';}
        elseif(current_url()==base_url('update-step1')){ echo 'id="booking_page"';}
        elseif(current_url()==base_url('step1')){ echo 'id="booking_page"';}
        elseif(current_url()==base_url('step6')){ echo 'id="booking_page"';}
        elseif(current_url()==base_url('step4')){ echo 'id="booking_page"';}
        elseif(current_url()==base_url('step3')){ echo 'id="booking_page"';}
        elseif(current_url()==base_url('step5')){ echo 'id="booking_page"';}
        elseif(current_url()==base_url('completed')){ echo 'id="booking_page"';}
        elseif(current_url()==base_url('preview-club')){ echo 'id="room_detail_page"';}
        elseif(current_url()==base_url('club-list')){ echo 'id="accomodation_page"';}
        elseif(current_url()==base_url('front/allclub/'.$s)){ echo 'id="accomodation_page"';}
        elseif(current_url()==base_url('food/foodcategory')){ echo 'id="accomodation_page"';}
        elseif(current_url()==base_url('food/fooditem')){ echo 'id="accomodation_page"';}
        elseif(current_url()==base_url('search')){ echo 'id="room_detail_page"';}
        elseif(current_url()==base_url('detail/'.$s)){ echo 'id="gallery_page"';}
        elseif(current_url()==base_url('front/menu/'.$s)){ echo 'id="gallery_page"';}
        elseif(current_url()==base_url('food/foodcategory/'.$s)){ echo 'id="accomodation_page"';}
        elseif(current_url()==base_url('food/fooditem/'.$s)){ echo 'id="accomodation_page"';}
        elseif(current_url()==base_url('events/index/'.$s)){ echo 'id="accomodation_page"';}
        elseif(current_url()==base_url('events')){ echo 'id="accomodation_page"';}
        elseif(current_url()==base_url('events/editevent/'.$s)){ echo 'id="accomodation_page"';}
        elseif(current_url()==base_url('event-detail/'.$s)){ echo 'id="accomodation_page"';}

        elseif(current_url()==base_url('detail/'.$s)){ echo 'id="gallery_page"';}
        elseif(current_url()==base_url('create-step1')){ echo 'id="booking_page"';}
  
        else if(current_url()==base_url('booking/'.$s)){ echo 'id="booking_page"';}
        else if(current_url()==base_url('booking-success/'.$s)){ echo 'id="booking_page"';}
        elseif(current_url()==base_url('dashboard')){ echo 'id="booking_page"';}
        elseif(current_url()==base_url('profile')){ echo 'id="booking_page"';}
        elseif(current_url()==base_url('request-booking')){ echo 'id="booking_page"';}
        elseif(current_url()==base_url('confirm-booking')){ echo 'id="booking_page"';}
        elseif(current_url()==base_url('canceled')){ echo 'id="booking_page"';}
        elseif(current_url()==base_url('complete-booking')){ echo 'id="booking_page"';}
        elseif(current_url()==base_url('reject-booking')){ echo 'id="booking_page"';}
        elseif(current_url()==base_url('update-booking/'.$s)){ echo 'id="booking_page"';}
        elseif(current_url()==base_url('success-booking/'.$s)){ echo 'id="booking_page"';}   
        elseif(current_url()==base_url('cancel-booking/'.$s)){ echo 'id="booking_page"';}
     
        elseif(current_url()==base_url('customer/reviewrating/'.$s)){ echo 'id="booking_page"';}
        elseif(current_url()==base_url('payment-cancelled')){ echo 'id="booking_page"';}
   
        elseif(current_url()==base_url('customer-verification')){ echo 'id="booking_page"';}
        
        elseif(current_url()==base_url('customer/verification/'.$s.'/'.$e)){ echo 'id="booking_page"';}
        elseif(current_url()==base_url('event-detail/'.$s)){ echo 'id="booking_page"';}
        else {
          echo 'id="booking_page"';  
        }
   
   
   ?>>
  <!-- start preloader -->
  <div id="loader-wrapper">
    <!--<div class="logo">
      <a href="<?php echo base_url();?>">
        <span>Table</span> - Fast
      </a>
    </div>
    <div id="loader">   
    </div>-->
  </div>
  <?php $this->load->view('front/include/nav');?>
