<?php header("Cache-Control: max-age=300, must-revalidate");?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Tablefast.com
    </title>
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('assets/favicon/');?>favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- fonts -->
    <link href='https://fonts.googleapis.com/css?family=Playfair+Display:400,700,900' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Karla:700,400' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Lora:400,700' rel='stylesheet' type='text/css'>
    <!-- fontawesome -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/font-awesome.css" />
    <!-- bootstrap -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/bootstrap.min.css" />
    <!-- uikit -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/uikit.min.css" />
    <!-- animate -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/animate.css" />
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/datepicker.css" />
    <!-- Owl carousel 2 css -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/owl.carousel.css">
    <!-- rev slider -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/rev-slider/settings.css" />
    <!-- lightslider -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/lightslider.css">
    <!-- Theme -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/reset.css">
    <!-- custom css -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/style.css" />
    <!-- responsive -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/responsive.css" />
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/customcss/bookingcss.css')?>" />
    <link href="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">

    <link href="<?php echo base_url('assets/admintheme');?>/build/css/custom.minfront.css" rel="stylesheet">
    
<link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/customcss/customerbookingcss.css');?>">
 <!-- bootstrap-daterangepicker -->
    <link href="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
    <!-- bootstrap-datetimepicker -->
    <link href="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.css" rel="stylesheet">
   
   
    <?php $s= $this->uri->segment(3);?>

  </head>
  <body  id="accomodation_page">
  <!-- start preloader -->
 <!-- <div id="loader-wrapper">
    <div class="logo">
      <a href="<?php echo base_url();?>">
         <span>Table</span> - Fast
      </a>
    </div>
    <div id="loader">   
    </div>
  </div>-->
  <?php $this->load->view('front/include/nav');?> 
