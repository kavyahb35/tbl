<?php //$this->load->view('front/include/subfooternav');?>
<?php $setting = $this->App->getRecord('tbl_setting');
          $logo = $setting[0]['HeaderLogo'];
          $settingContactNumber = $setting[0]['ContactNumber'];
          $settingEmail = $setting[0]['Email'];
          $settingFacebook = $setting[0]['Facebook'];
          $settingAddress = $setting[0]['Address'];
          $settingGoogle = $setting[0]['Google'];
          $settingLinked = $setting[0]['Linked'];
          $settingTwitter = $setting[0]['Twitter'];
          $settingFooterLogo = $setting[0]['FooterLogo'];
            if($settingFooterLogo!=''){
               if (file_exists(FCPATH.'assets/logo/'.$settingFooterLogo)){
                 $logoimgfooter=$settingFooterLogo;
                }else{
                    $logoimgfooter='footer.png';
                }
            }else{
                $logoimgfooter='footer.png';
            }
 ?>
<footer class="footer_area">
  <div class="container">
    <div class="footer">
      <div class="footer_top padding-top-80 clearfix">
        <div class="col-lg-4 col-md-4 col-sm-4">
          <div class="footer_widget">
            <div class="footer_logo">
              <a href="<?php echo base_url();?>">
                <img src="<?php echo base_url('assets/logo/'.$logoimgfooter)?>" alt="">
              </a>
            </div>
            <p>We intend to give accessible table reservation with pleasant surroundings, superb food and admirable services to make your stay definitely repayable and satisfaction guarantee.
            </p>
            <ul>
              <li>
                <P>
                  <i class="fa fa-map-marker">
                  </i><?php echo $settingAddress;?>
                </P>
              </li>
            </ul>
          </div>
        </div>
       <div class="col-lg-4 col-md-4 col-sm-4">
         <div class="footer_widget">
            <h5 class="quick klq">Quick Links
            </h5>
            <ul class="quickli">
                  
                 <!-- <li>
                    <a href="<?php echo base_url('club-list');?>">Clubs
                    </a>
                  </li>-->
                  <li>
                    <a href="<?php echo base_url('about-us');?>">About Us
                    </a>
                  </li>
                  <li>
                    <a href="<?php echo base_url('contact-us');?>">Contact
                    </a>
                  </li>

 <?php $metsetting=$this->App->passwordChecking('tbl_information','Id','Status','2','1');
                if(!empty($metsetting)){ ?>
				 <li>
                    <a href="<?php echo base_url('terms-and-conditions');?>">Terms & Conditions
                    </a>
                  </li>	
			<?php	}
                ?>
                  <?php $metsetting=$this->App->passwordChecking('tbl_information','Id','Status','3','1');
                if(!empty($metsetting)){ ?>
				 <li>
                    <a href="<?php echo base_url('privacy-policy');?>">Privacy Policy
                    </a>
                  </li>	
			<?php	}
			$vendorid=$this->session->userdata['vendorauth']['Id'];  
        $customerid=$this->session->userdata['customerauth']['Id'];  
        
        if($vendorid=='' && $customerid==''){
                ?>
<!--<li class="">
                  <a  href="<?php echo base_url('vendor-signup');?>">Vendor Sign up
                  </a>
                </li>-->
                <?php } ?>
                </ul>  
         </div>
         </div>
        



         <div class="col-lg-4 col-md-4 col-sm-4 ">
          <div class="footer_widget">
            <h5>We Are Global
            </h5>
            <div class="footer_map">
              <a href="#">
                <img src="<?php echo base_url('assets/fronttheme/')?>/img/footer-map-two.jpg" alt="">
              </a>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="container">
          <div class="footer_copyright margin-tb-50 content-center">
            <p>© 2018 
              <a href="#">Tablefast.com 
              </a>. All rights reserved
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>
<!-- end footer -->
<!-- jquery library -->
<script src="<?php echo base_url('assets/fronttheme/')?>/js/vendor/jquery-1.11.2.min.js"></script>
<!-- bootstrap -->
<script src="<?php echo base_url('assets/fronttheme/')?>/js/bootstrap.min.js"></script>


    <script src="<?php echo base_url('assets/admintheme');?>/vendors/moment/min/moment.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap-datetimepicker -->    
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>
    

<!-- uikit -->
<script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/jszip/dist/jszip.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/pdfmake/build/vfs_fonts.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url('assets/admintheme');?>/build/js/custom.min.js"></script>



<!--Activating WOW Animation only for modern browser-->
<!--[if !IE]><!-->
<script type="text/javascript">new WOW().init();</script>
<script src="<?php echo base_url('assets/fronttheme/')?>/js/main.js"></script>

</body>
</html>
