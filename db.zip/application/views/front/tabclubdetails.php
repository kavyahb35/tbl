<!-- start breadcrumb -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">  
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>    
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script> </head>
    

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>

<section class="breadcrumb_main_area margin-bottom-80">
   <div class="container-fluid">
      <div class="row">
         <?php $vid=$vendordetails[0]['Id'];
            $layout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$vid);
            $img=$layout[0]['MainImage'];
            $PerAdultPrice11=$layout[0]['PerAdultPrice'];
            $Description=$layout[0]['Description'];
            if($img!=''){
                if (file_exists(FCPATH.'assets/clubimage/'.$img)){
                $i=base_url('assets/clubimage/'.$img);
                }else{
                $i=base_url('assets/fronttheme/banner/TableFast-Banner-2.jpg');
                }
            }else{
            $i=base_url('assets/fronttheme/banner/TableFast-Banner-2.jpg');
            } ?>
         <style>
            .march {
            background:url(<?php echo $i;?>);
            background-repeat: no-repeat;
            background-size:     cover;
            }
         </style>
         <div class="breadcrumb_main nice_title march">
            <h2>
               <?php echo $vendordetails[0]['ClubName'];?>
            </h2>
            <!-- special offer start -->
            <div class="special_offer_main">
               <div class="container">
                  <div class="special_offer_sub">
                     <?php $vid=$vendordetails[0]['Id'];
                        $layout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$vid);
                        $img=$layout[0]['MainImage'];
                            $Description=$layout[0]['Description'];
                            $Cuisines=$layout[0]['Cuisines'];
                            $PerAdultPrice=$layout[0]['PerAdultPrice'];
                        if($img!=''){
                            if (file_exists(FCPATH.'assets/clubimage/'.$img)){
                                $i=base_url('assets/clubimage/'.$img);
                            }else{
                            $i=base_url('assets/fronttheme/customcss/dummyimg.jpg');
                            }
                        }else{
                        $i=base_url('assets/fronttheme/customcss/dummyimg.jpg');
                        } ?>
                  </div>
               </div>
            </div>
            <!-- end offer start -->
         </div>
      </div>
   </div>
</section>
<!-- end breadcrunb -->
<!-- start other detect room section -->
<div class="other_room_area">
   <div class="container">
      <div class="row">
         <div class="col-md-12 col-sm-12 col-xs-12 col-lg-12">
            <div class="col-md-3 col-sm-12 col-lg-3 col-xs-12">
               <!----------- booking form start code ------------------------------------------>
               <h5 class="quick clsff">Reserve with Table</h5>
               <?php 
                  $vid=$vendordetails[0]['Id'];
                  $layout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$vid);
                  $SundayFrom=$layout[0]['SundayFrom'];
                  $SundayTo=$layout[0]['SundayTo'];
                  $SundayFromClose=$layout[0]['SundayFromClose'];
                  $SundayToClose=$layout[0]['SundayToClose'];
                  $MondayFrom=$layout[0]['MondayFrom'];
                  $MondayTo=$layout[0]['MondayTo'];
                  $MondayFromClose=$layout[0]['MondayFromClose'];
                  $MondayToClose=$layout[0]['MondayToClose'];
                  $TuesdayFrom=$layout[0]['TuesdayFrom'];
                  $TuesdayTo=$layout[0]['TuesdayTo'];
                  $TuesdayToClose=$layout[0]['TuesdayToClose'];
                  $WednesdayFrom=$layout[0]['WednesdayFrom'];
                  $WednesdayTo=$layout[0]['WednesdayTo'];
                  $WednesdayFromClose=$layout[0]['WednesdayFromClose'];
                  $WednesdayToClose=$layout[0]['WednesdayToClose'];
                  $ThursdayFrom=$layout[0]['ThursdayFrom'];
                  $ThursdayTo=$layout[0]['ThursdayTo'];
                  $ThursdayFromClose=$layout[0]['ThursdayFromClose'];
                  $ThursdayToClose=$layout[0]['ThursdayToClose'];
                  $FridayFrom=$layout[0]['FridayFrom'];
                  $FridayTo=$layout[0]['FridayTo'];
                  $FridayFromClose=$layout[0]['FridayFromClose'];
                  $FridayToClose=$layout[0]['FridayToClose'];
                  $SaturdayFrom=$layout[0]['SaturdayFrom'];
                  $SaturdayTo=$layout[0]['SaturdayTo'];
                  $SaturdayFromClose=$layout[0]['SaturdayFromClose'];
                  $SaturdayToClose=$layout[0]['SaturdayToClose'];
                  $NoofPax=$layout[0]['NoofPax'];
                  
                  $facebook=$layout[0]['facebook'];
                  $googleplus=$layout[0]['googleplus'];
                  $twitter=$layout[0]['twitter'];
                  $linked=$layout[0]['linked'];
                  $youtube=$layout[0]['youtube'];
                  $vimeo=$layout[0]['vimeo'];
                  $instagram=$layout[0]['instagram'];
                  
                  ?>
                  
               <div class="reserved_box">
                     <div class="row boxp">
					  <div class="col-md-12 pql">
						1. Please select your booking details - <span style="color:navy;">Today Open Timing : <?php
                                    $currentday= date('l');
                                    if($currentday =='Monday'){
                                    echo $MondayFrom.' - '.$MondayTo;
                                    } elseif($currentday =='Tuesday'){
                                    echo $TuesdayFrom.' - '.$TuesdayTo;
                                    }
                                    elseif($currentday =='Wednesday'){
                                    echo $WednesdayFrom.' - '.$WednesdayTo;
                                    }
                                    elseif($currentday =='Thursday'){
                                    echo $ThursdayFrom.' - '.$ThursdayTo;
                                    }
                                    elseif($currentday =='Friday'){
                                    echo $FridayFrom.' - '.$FridayTo;
                                    }
                                    elseif($currentday =='Saturday'){
                                    echo $SaturdayFrom.' - '.$SaturdayTo;
                                    }
                                    elseif($currentday =='Sunday'){
                                    echo $SundayFrom.' - '.$SundayTo;
                                    }
                                    else{
                                    echo $SundayFrom.' - '.$SundayTo;
                                    } ?></span> <p style="color:#F14;">Available Table : <?php 
                                    
                                      $vendetails = $this->App->getPerticularRecord('tbl_vendor','Id',$vendordetails[0]['Id']);
                                      $venid = $vendetails[0]['Id'];
                                      $bookdet = $this->App->getPerticularRecord('tbl_clublayout', 'VendorId', $venid);
									  $totbooking = $bookdet[0]['NumTable'];
									  $sdatet = date('Y-m-d');
										$querycal= $this->db->query("select * from tbl_booking_calender where VendorId='".$venid."' and BookingDate='".$sdatet."' limit 1");
										$calendor = $querycal->result_array();
										$numrow = $querycal->num_rows();
										
										if($numrow > 0){
											$r = $calendor[0]['NobTable'];											
										}else{ $r ='0';}
										
										$tos = $totbooking-$r;
                                                                              if($tos > 0){ echo $tos;}else{ echo '0';}
                                    
                                    ?>
					  </div>
                     </div>
               
					 <div class="col-md-12">
					 <input id="date" class=" form-control col-md-12 col-xs-12 l1" placeholder="Booking Date *" type="text" name="date" value="<?php echo $bookingdate;?>" >
                                       <label class="errtag"><?php echo form_error('date'); ?></label>
                                   
					  <script>
							$.noConflict();   
								$('#date').datepicker({
									format: "yyyy-mm-dd",
									 startDate: new Date() 
								}); 
							
						</script>
					 </div>
					  <script>
                                       function myFunction(){
                                       var v=$("#date").val();
                                       var cid="<?php echo $vendordetails[0]['Id'];?>";
                                       var url="<?php echo base_url('booking/gettime');?>";
                                       $.ajax({
                                       type: 'post',
                                       url: url,
                                       data: "date="+v+"&cid="+cid,
                                       success: function () {
                                       }
                                       });
                                       }
                                    </script>
					 <div class="col-md-12" id="timedisp1">
					 <input type="text" id="myDatepicker1" class="form-control l1" type="text" name="myDatepicker1" placeholder="Booking Time *"  value="<?php echo $myDatepicker1;?>">
                                    <label class="errtag"><?php echo form_error('myDatepicker1'); ?></label>
					 </div>
					 
					 <div class="col-md-12" >
					 <select class="form-control col-md-12 col-xs-12 l1" id="noofmember" name="noofmember" value="<?php echo $noofmember;?>">
                                       <option>--Select No. of Pax--</option>
                                          <?php for($i=1;$i<20;$i++){ ?>
                                          <option value="<?php echo $i;?>"><?php echo $i;?></option>
                                          <?php } ?>
                                       </select>
					  
					 </div>
					 <div class="form-group">
                              <center> <div class="col-md-12 col-sm-12 col-xs-12 ">
                               <a class="btn btn-warning btnwrm" style="text-transform: capitalize;" onclick="updatebookingform('<?php echo $vendordetails[0]['Id'];?>')">Update</a>
                                 </div>
                                 <div class="errormsgbooking" style="color:#f14"></div><br>
                                 <a href="" style="display:none" id="check">Find Available Times on OpenTable</a>
                                 </center>
                             </div>
               
               
               </div>
               <script>
                function updatebookingform(vid)
                {
					
						var date = $("#date").val();
						var time = $("#myDatepicker1").val();
						var noofmember = $("#noofmember option:selected").val();
						var url="<?php echo base_url('booking/checkbooingupdates');?>";
						var club="<?php echo $vendordetails[0]['ClubName'];;?>";
						
						var senddata = "data="+date+"&time="+time+"&noofmember="+noofmember+"&vid="+vid;
						
						var rurl = "<?php echo base_url('booking-club/'.$vendordetails[0]['Slug']);?>";
						
						if(date != '' && time !=''){
							  $.ajax({
							   type: 'post',
							   dataType : 'Json',
							   url: url,
							   data: senddata,
							   success: function (data) {
								   if(data.succ=='1'){
									   $("#check").show(); 
									   window.location.href=rurl;  
									}
									if(data.err=='2'){
									   $("#check").hide();  
									   $(".errormsgbooking").html(club+" is not available for your requested time. Choose another time, or search club with availability.").delay(3000).fadeOut();; 
									}
							   }
						 });
						}else{
							alert("All Fields required");
						}
				}
               </script>
               <!----------- booking form end code ------------------------------------------>
               <!-----start code facebook feed -------------->
               <h5 class="quick clsff">Facebook Feed
               </h5>
               <div class="facebookfeedcls1">
                  <div id="fb-root"></div>
                  <script>(function(d, s, id) {
                     var js, fjs = d.getElementsByTagName(s)[0];
                     if (d.getElementById(id)) return;
                     js = d.createElement(s); js.id = id;
                     js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId={APP_ID}";
                     fjs.parentNode.insertBefore(js, fjs);
                     }(document, 'script', 'facebook-jssdk'));
                  </script>
                  <div class="fb-page" 
                     data-href="https://www.facebook.com/Cueserve/" 
                     data-tabs="timeline" 
                     data-small-header="false" 
                     data-adapt-container-width="true" 
                     data-hide-cover="false" 
                     data-show-facepile="true">
                     <div class="fb-xfbml-parse-ignore">
                        <blockquote cite="https://www.facebook.com/facebook">
                           <a href="https://www.facebook.com/facebook">Facebook</a>
                        </blockquote>
                     </div>
                  </div>
               </div>
               <!----------- facebook feed end code ------------------------------------------>
            </div>
            <div class="col-md-9 col-sm-12 col-lg-9 col-xs-12">
               <div class="other_room">
                  <div role="tabpanel">
                     <!-- <div class="section_title content-center"> -->
                     <!-- Nav tabs -->
                     <div class="container">
                        <div class="section_title">
                           <ul class="nav nav-tabs margin-bottom-60" role="tablist">
                              <li role="presentation" class="active"><a href="#all" aria-controls="all" role="tab" data-toggle="tab">Overview</a></li>
                              <li role="presentation"><a href="#deluxe_room" aria-controls="deluxe_room" role="tab" data-toggle="tab">Menu</a></li>
                              <li role="presentation"><a href="#royal_room" aria-controls="royal_room" role="tab" data-toggle="tab">Package</a></li>
                              <li role="presentation"><a href="#single_bedroom" aria-controls="single_bedroom" role="tab" data-toggle="tab">Events</a></li>
                             <!-- <li role="presentation"><a href="#double_bedroom" aria-controls="double_bedroom" role="tab" data-toggle="tab">Photos</a></li>-->
                              <?php $vendorid=$this->session->userdata['vendorauth']['Id'];                                        
                                 if($vendorid==''){ ?>
                              <li role="presentation"><a href="<?php echo base_url('booking-club/'.$vendordetails[0]['Slug']);?>">Table Booking</a></li>
                              <?php }else{ ?>
                              <li role="presentation"><a href="">Table Booking</a></li>
                              <?php } ?>
                              <!--href="#classic_room" aria-controls="classic_room" role="tab" data-toggle="tab"-->
                              <li role="presentation"><a href="#exe_room" aria-controls="exe_room" role="tab" data-toggle="tab">Reviews</a></li>
                           </ul>
                        </div>
                     </div>
                     <!-- Tab panes -->
                     <div class="tab-content">
                        <!-- <div class="section_content"> -->
                        <div role="tabpanel" class="tab-pane active" id="all">
                           <!-- start single room details -->
                           <div class="room_detail_main margin-bottom-55">
                              <div class="container">
                                 <div class="row">
                                    <div class="col-lg-6 col-md-6">
                                       <div class="deluxe_room_detail">
                                          <div class="section_title content-left margin-bottom-5" >
                                             <h5>
                                                <?php echo $vendordetails[0]['ClubName'];?> Detail 
                                                <!--<span class="price floatright"><?php echo $PerAdultPrice.' QAR';?>
                                                   </span>--> 
                                                <?php $que=$this->db->query("SELECT ROUND(AVG(Review),1) as totalcal FROM `tbl_reviews` WHERE ClubId='".$vid."'");
                                                   $res=$que->result_array();
                                                   $tto=$res[0]['totalcal'];?>
                                                <span class="day floatright rev leftrev">
                                                <?php echo $tto;?>
                                                </span>
                                             </h5>
                                          </div>
                                          <div class="section_content">
                                             <div class="showcase">
                                                <div class="section_description">
                                                   <div class="row">
                                                      <div class="col-lg-12 col-md-12">
                                                         <div class="clearfix" style="">
                                                            <ul id="image-gallery" class="gallery list-unstyled cS-hidden">
                                                               <!-- <ul id="vertical" class="gallery list-unstyled"> -->
                                                               <?php  $vid=$vendordetails[0]['Id'];
                                                                  $layout=$this->App->getPerticularRecord('tbl_clubgallery','VendorId',$vid);
                                                                  
                                                                  $imsg=$layout[0]['Image'];
                                                                  if(!empty($layout)){
                                                                  foreach($layout as $lay){  ?>
                                                               <li data-thumb="<?php echo base_url('assets/clubgallery/'.$lay['Image']);?>">
                                                                  <img class="mslider" src="<?php echo base_url('assets/clubgallery/'.$lay['Image']);?>" style="width:100%"/>
                                                               </li>
                                                               <?php }
                                                                  }
                                                                  ?>
                                                            </ul>
                                                         </div>
                                                      </div>
                                                   </div>
                                                   <div class="row">
                                                      <div class="col-lg-12 col-md-12">
                                                         <div class="room_facilities_des padding-top-50 padding-bottom-50 border-bottom-whitesmoke border-top-whitesmoke">
                                                            <p>
                                                               <label style="color: #000;    font-size: 18px;">Cost For Two : 
                                                               <span style="    font-size: 13px;
                                                                  color: navy;
                                                                  font-family: sans-serif;
                                                                  }">
                                                               <?php echo $PerAdultPrice.' QAR';?>
                                                               </span>
                                                               </label> 
                                                               <label style="color: #000;    font-size: 18px;">Cuisines : 
                                                               <span style="    font-size: 13px;
                                                                  color: navy;
                                                                  font-family: sans-serif;
                                                                  }">
                                                               <?php echo $Cuisines;?>
                                                               </span>
                                                               </label> 
                                                            </p>
                                                            <p>
                                                               <label style="color: #000;    font-size: 18px;">
                                                                  Facilities : 
                                                                  <span style="    font-size: 13px;
                                                                     color: navy;
                                                                     font-family: sans-serif;
                                                                     }">
                                                            <ul>
                                                            <?php 
                                                               $vid=$vendordetails[0]['Id'];
                                                               $facility=$this->App->getPerticularRecord('tbl_facility','ClubId',$vid);
                                                               if(!empty($facility)){
                                                               foreach($facility as $fac){
                                                               if($fac['Status']=='1'){
                                                               ?>
                                                            <li><?php echo $fac['Title'];?></li>
                                                            <?php } }
                                                               } ?>
                                                            </ul>
                                                            </span>
                                                            </label>
                                                            </p>
                                                            <p>
                                                               <label style="color: #000;    font-size: 18px;">Description : </label>
                                                               <?php echo $Description;?> 
                                                            </p>
                                                            <!---social media -------------------->
                                                             <div class="social_icons clearfix">
															  <ul class="clearul" style="display: inline-flex;">
															   <li style="padding: 3px;">
																  <a href="<?php echo $facebook;?>">
																	<i class="fa fa-facebook">
																	</i>
																  </a>
																</li>
																<li style="padding: 3px 6px;">
																  <a href="<?php echo $googleplus;?>">
																	<i class="fa fa-twitter">
																	</i>
																  </a>
																</li>
																<li style="padding: 3px 6px;">
																  <a href="<?php echo $twitter;?>">
																	<i class="fa fa-google-plus">
																	</i>
																  </a>
																</li>
																<li style="padding: 3px 6px;">
																  <a href="<?php echo $linked;?>">
																	<i class="fa fa-linkedin">
																	</i>
																  </a>
																</li>
																<li style="padding: 3px 6px;">
																  <a href="<?php echo $youtube;?>">
																	<i class="fa fa-youtube-play">
																	</i>
																  </a>
																</li>
																<li style="padding: 3px 6px;">
																  <a href="<?php echo $vimeo;?>">
																	<i class="fa fa-instagram">
																	</i>
																  </a>
																</li>
																<li style="padding: 3px 6px;">
																  <a href="<?php echo $instagram;?>">
																	<i class="fa fa-vimeo-square">
																	</i>
																  </a>
																</li>
															  </ul>
															</div>
                                                            <!----end social media ----------------->
                                                            
                                                            <p>
                                                               <?php $vid=$vendordetails[0]['Id'];
                                                                  $layout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$vid);
                                                                  echo 'Available Parking : </span> <span style="text-transform: capitalize;">'.$layout[0]['AvailableParking'].'</span>';
                                                                  if($layout[0]['AvailableParking']=='paid'){
                                                                  echo '<br>Parking Price (Per hrs) : </span>  '.$layout[0]['PriceParkingPerhrs'].' QAR';
                                                                  }?> 
                                                            </p>
                                                         </div>
                                                      </div>
                                                   </div>
                                                   <div class="row">
                                                      <!-- start welcome section -->
                                                      <!-- end welcome section -->
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-12 myclspo">
                                       <!-- start hotel booking -->
                                       <div class="col-lg-12 col-md-12 col-sm-12 myclspo">
                                          <div class="hotel_booking_area clearfix areaclas">
                                             <div class="hotel_booking">
                                                <form id="form1" role="form" action="#" class="">
                                                   <div class="col-lg-12 col-md-12">
                                                      <div class="room_book">
                                                         <h6><?php echo $vendordetails[0]['ClubName']?>
                                                         </h6>
                                                      </div>
                                                   </div>
                                                   <?php $vid=$vendordetails[0]['Id'];
                                                      $vendordetails=$this->App->getPerticularRecord('tbl_vendor','Id',$vid);?>
                                                   <div class="form-group col-lg-12 col-md-12">
                                                      <div class="input-group border-bottom-dark-2">
                                                         <br>
                                                         <label style="    font-size: 20px;    color: whitesmoke;">
                                                         <?php echo $vendordetails[0]['FirstName'].' '.$vendordetails[0]['LastName'];?>
                                                         </label>
                                                         <br>
                                                         <label>
                                                         <i class="fa fa-envelope">
                                                         </i> 
                                                         <?php echo $vendordetails[0]['Email'];?>
                                                         </label>
                                                         <label>
                                                         <i class="fa fa-phone">
                                                         </i> 
                                                         <?php echo $vendordetails[0]['Phone'] .' , '.$vendordetails[0]['AlternativePhone'];?>
                                                         </label>
                                                         <br>
                                                         <label>
                                                         <i class="fa fa-map-marker">
                                                         </i> 
                                                         <?php echo $vendordetails[0]['Address'].' <br> '.$vendordetails[0]['City'].'-'.$vendordetails[0]['PostCode'].' ,'.$vendordetails[0]['Country']; ?>
                                                         </label>
                                                         <br>
                                                         <label>
                                                         <?php $AddressIfram=$vendordetails[0]['AddressIfram'];
                                                            if($AddressIfram!=''){ ?>
                                                         <iframe width="100%" height="200" frameborder="0" style="margin-bottom:10px;border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAyhF2cCWevFm_T8iog0GqV3utCrfAbWYw&q='<?php echo $AddressIfram;?>'">
                                                         </iframe>
                                                         <?php } ?>
                                                         </label> 
                                                      </div>
                                                   </div>
                                                </form>
                                             </div>
                                          </div>
                                       </div>
                                       <!-- end hotel booking -->
                                       <!-- start client says slider -->
                                       <!-- end client says slider -->
                                    </div>
                                 </div>
                                 <div class="row">
                                    <p class="vencls">
                                       <?php  
                                          $vid=$vendordetails[0]['Id'];
                                          $layout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$vid);
                                          $SundayFrom=$layout[0]['SundayFrom'];
                                          $SundayTo=$layout[0]['SundayTo'];
                                          $SundayFromClose=$layout[0]['SundayFromClose'];
                                          $SundayToClose=$layout[0]['SundayToClose'];
                                          $MondayFrom=$layout[0]['MondayFrom'];
                                          $MondayTo=$layout[0]['MondayTo'];
                                          $MondayFromClose=$layout[0]['MondayFromClose'];
                                          $MondayToClose=$layout[0]['MondayToClose'];
                                          $TuesdayFrom=$layout[0]['TuesdayFrom'];
                                          $TuesdayTo=$layout[0]['TuesdayTo'];
                                          $TuesdayToClose=$layout[0]['TuesdayToClose'];
                                          $WednesdayFrom=$layout[0]['WednesdayFrom'];
                                          $WednesdayTo=$layout[0]['WednesdayTo'];
                                          $WednesdayFromClose=$layout[0]['WednesdayFromClose'];
                                          $WednesdayToClose=$layout[0]['WednesdayToClose'];
                                          $ThursdayFrom=$layout[0]['ThursdayFrom'];
                                          $ThursdayTo=$layout[0]['ThursdayTo'];
                                          $ThursdayFromClose=$layout[0]['ThursdayFromClose'];
                                          $ThursdayToClose=$layout[0]['ThursdayToClose'];
                                          $FridayFrom=$layout[0]['FridayFrom'];
                                          $FridayTo=$layout[0]['FridayTo'];
                                          $FridayFromClose=$layout[0]['FridayFromClose'];
                                          $FridayToClose=$layout[0]['FridayToClose'];
                                          $SaturdayFrom=$layout[0]['SaturdayFrom'];
                                          $SaturdayTo=$layout[0]['SaturdayTo'];
                                          $SaturdayFromClose=$layout[0]['SaturdayFromClose'];
                                          $SaturdayToClose=$layout[0]['SaturdayToClose'];
                                          ?>
                                      
                                       <span style="
    float:left" class="tooltip4">See More
                                       <span class="tooltiptext">
                                       <label> Monday : 
                                       <?php echo $MondayFrom; ?> To 
                                       <?php echo $MondayTo;?>
                                       <label>Thuesday : 
                                       <?php echo $TuesdayFrom;?> To 
                                       <?php echo $TuesdayTo; ?>
                                       </label>
                                       <label>Wednesday :
                                       <?php echo $WednesdayFrom; ?> To 
                                       <?php echo $WednesdayTo; ?>
                                       </label>
                                       <label>Thursday : 
                                       <?php echo $ThursdayFrom; ?> To 
                                       <?php echo $ThursdayTo; ?>
                                       </label>
                                       <label>Friday : 
                                       <?php echo $FridayFrom; ?> To 
                                       <?php echo $FridayTo; ?>
                                       </label>
                                       <label>Saturday : 
                                       <?php echo $SaturdayFrom; ?> To
                                       <?php echo $SaturdayTo; ?>
                                       </label>
                                       <label>Sunday : 
                                       <?php echo $SundayFrom; ?> To 
                                       <?php echo $SundayTo; ?>
                                       </label>
                                       </span>
                                       </span>  
                                    </p>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div role="tabpanel" class="tab-pane" id="deluxe_room">
                           <!-- start single room details -->
                           <div class="room_detail_main margin-bottom-55">
                              <div class="container">
                                 <div class="row">
                                    <div class="col-lg-6 col-md-6">
                                       <div class="deluxe_room_detail">
                                          <div class="section_title content-left margin-bottom-5">
                                             <h5 style="margin-left: 12px;">
                                                <?php echo $vendordetails[0]['ClubName'];?> Menu 
                                                <br> 
                                                <span class="day floatright">
                                                </span>
                                             </h5>
                                          </div>
                                          <?php $clubid=$vendordetails[0]['Id'];
                                             $menucategory =$this->App->passwordChecking('tbl_foodcategory','ClubId','Status',$clubid,'1');
                                             if(!empty($menucategory)){
                                             ?>
                                          <div class="bocxcsla">
                                             <h1 class="menutitle">Menu
                                             </h1>
                                             <?php 
                                                $menucategory =$this->App->passwordChecking('tbl_foodcategory','ClubId','Status',$clubid,'1');
                                                if(!empty($menucategory)){
                                                foreach($menucategory as $category){
                                                $cattit= $category['Title'];
                                                $cid= $category['Id'];
                                                echo '<h4 class="titmenu">'.$cattit.'</h4>';
                                                $menucategory =$this->App->passwordChecking('tbl_fooditem','ClubId','CategoryId',$clubid,$cid);
                                                
                                                if(!empty($menucategory)){
                                                echo '<div class="ulc"><ul>';
                                                foreach($menucategory as $menu){
                                                if($menu['Status']=='1'){
                                                 $menutit=$menu['Title'];
                                                $price=$menu['Price'];
                                                  echo '<li class="mlkdetail">'.$menutit.' <span class="priceclsdetail">    '.$price.' QAR'.'</span></li>';
                                                //echo '<tr ><td class="mlk">'.$menutit.' </td><td class="pricecls">    '.$price.' QAR'.'</td></tr>';
                                                }
                                                }
                                                echo '</ul></div>';
                                                }
                                                }
                                                }
                                                ?>
                                          </div>
                                          <?php }else { echo '<div style="font-size:20px;text-align:center;padding-top: 26px;">No Menu found.</div>';} ?> <br>
                                       </div>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-12 ">
                                       <!-- start hotel booking -->
                                       <div class="col-lg-12 col-md-12 col-sm-12 myclspo">
                                          <div class="hotel_booking_area clearfix areaclas">
                                             <div class="hotel_booking">
                                                <form id="form1" role="form" action="#" class="">
                                                   <div class="col-lg-12 col-md-12">
                                                      <div class="room_book">
                                                         <h6><?php echo $vendordetails[0]['ClubName']?>
                                                         </h6>
                                                      </div>
                                                   </div>
                                                   <?php $vid=$vendordetails[0]['Id'];
                                                      $vendordetails=$this->App->getPerticularRecord('tbl_vendor','Id',$vid);?>
                                                   <div class="form-group col-lg-12 col-md-12">
                                                      <div class="input-group border-bottom-dark-2">
                                                         <br>
                                                         <label style="    font-size: 20px;    color: whitesmoke;">
                                                         <?php echo $vendordetails[0]['FirstName'].' '.$vendordetails[0]['LastName'];?>
                                                         </label>
                                                         <br>
                                                         <label>
                                                         <i class="fa fa-envelope">
                                                         </i> 
                                                         <?php echo $vendordetails[0]['Email'];?>
                                                         </label>
                                                         <label>
                                                         <i class="fa fa-phone">
                                                         </i> 
                                                         <?php echo $vendordetails[0]['Phone'] .' , '.$vendordetails[0]['AlternativePhone'];?>
                                                         </label>
                                                         <br>
                                                         <label>
                                                         <i class="fa fa-map-marker">
                                                         </i> 
                                                         <?php echo $vendordetails[0]['Address'].' <br> '.$vendordetails[0]['City'].'-'.$vendordetails[0]['PostCode'].' ,'.$vendordetails[0]['Country']; ?>
                                                         </label>
                                                         <br>
                                                         <label>
                                                         <?php $AddressIfram=$vendordetails[0]['AddressIfram'];
                                                            if($AddressIfram!=''){ ?>
                                                         <iframe width="100%" height="200" frameborder="0" style="margin-bottom:10px;border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAyhF2cCWevFm_T8iog0GqV3utCrfAbWYw&q='<?php echo $AddressIfram;?>'">
                                                         </iframe>
                                                         <?php } ?>
                                                         </label> 
                                                      </div>
                                                   </div>
                                                </form>
                                             </div>
                                          </div>
                                       </div>
                                       <!-- end hotel booking -->
                                       <!-- start client says slider -->
                                       <!-- end client says slider -->
                                    </div>
                                 </div>
                              </div>
                              <style>
                                 .bocxcsla {
                                 background: url(https://www.tablefast.com/assets/menu/menu2.jpg) no-repeat 13px 19%;
                                 padding: 24px;
                                 color: #fff;
                                 text-transform: capitalize;
                                 font-size: 13px;
                                 list-style: none;
                                 }
                                 h1.menutitle {
                                 font-size: 35px;
                                 color: #fff;
                                 padding: 8px 0px;
                                 /* border-bottom: 1px solid; */
                                 font-family: cursive;
                                 }
                                 h4.titmenu {
                                 font-size: 15px;
                                 color: orange;
                                 font-weight: bold;
                                 margin-top: 17px;
                                 }
                                 /*  .mlk {
                                 list-style: none;
                                 width: 26%;
                                 position: relative;    font-size: 12px;
                                 }
                                 .priceclsdetail {
                                 color: yellow;
                                 position: absolute;
                                 left: 130px;    width: 100%;
                                 } */
                                 .room_book h6 {
                                 color: #fff;
                                 font-size: 23px;
                                 line-height: 25px;
                                 }
                                 p {
                                 color: #666666;
                                 /* font-weight: normal; */
                                 font-size: 14px;
                                 font-family: inherit;
                                 font-weight: normal;
                                 }
                                 label {
                                 font-family: serif;
                                 color: #ccc;
                                 }
                                 span.a {
                                 COLOR: slategray;
                                 }
                              </style>
                           </div>
                           <!-- end single room details -->
                        </div>
                        <div role="tabpanel" class="tab-pane" id="single_bedroom">
                           <!-- start single room details -->
                           <div class="room_detail_main margin-bottom-55">
                              <div class="container">
                                 <div class="row">
                                    <div class="col-lg-6 col-md-6">
                                       <div class="deluxe_room_detail">
                                          <div class="section_title content-left margin-bottom-5">
                                             <h5 style="    margin-left: 14px;">
                                                <?php echo $vendordetails[0]['ClubName'];?> Detail 
                                                <!--<span class="price floatright"><?php echo $PerAdultPrice.' QAR';?>
                                                   </span> -->
                                                <br> 
                                                <span class="day floatright">
                                                </span>
                                             </h5>
                                          </div>
                                          <!-------------------------------------------------------------------->
                                          <?php 
                                             $clubid=$vendordetails[0]['Id'];
                                             $eventsdetails=$this->App->getPerticularRecord('tbl_events', 'ClubId', $clubid);
                                             $currentdt = date('Y-m-d',strtotime("-1 days"));
                                             $query=$this->db->query("SELECT * FROM `tbl_events` WHERE ClubId='".$clubid."' and (`FromDate` > '".$currentdt."' or `ToDate` > '".$currentdt."' or `OneDate` > '".$currentdt."')");
                                             $eventsdetails=$query->result_array();
                                             if(!empty($eventsdetails)){ $k=0;
                                                 foreach($eventsdetails as $clb){
                                                      $img=$clb['Image'];
                                                      
                                                      $fromdate=$clb['FromDate'];
                                                      $todate=$clb['ToDate'];
                                                      $specialdate=$clb['OneDate'];
                                                      $NoofDays=$clb['NoofDays'];
                                                      if($NoofDays=='1')
                                                      {
                                                         if(strtotime($currentdt) < strtotime($specialdate))
                                                         { ?>
                                          <div class="boxclx">
                                             <div clas=" row">
                                                <div class="col-lg-4 col-md-4 col-sm-12">
                                                   <div class="mk">
                                                      <a href="<?php echo base_url('event-detail/'.$clb['Slug']);?>">
                                                      <?php if($img!=''){ 
                                                         if (file_exists(FCPATH.'assets/events/'.$img)){?>
                                                      <img src="<?php echo base_url('assets/events/'.$img);?>" alt="" class="ew">
                                                      <?php }else{?>
                                                      <img src="<?php echo base_url('assets/fronttheme/customcss/dummyimg.jpg')?>" alt="" class="ew">
                                                      <?php  } } else{ ?>
                                                      <img src="<?php echo base_url('assets/fronttheme/customcss/dummyimg.jpg')?>" alt="" class="ew">
                                                      <?php } ?>
                                                      </a>
                                                   </div>
                                                </div>
                                                <div class="col-lg-8 col-md-8 col-sm-12">
                                                   <div class="col-md-12">
                                                      <a href="<?php echo base_url('event-detail/'.$clb['Slug']);?>">
                                                         <h3 class="titlecls">
                                                            <?php echo $clb['Title'];?>
                                                         </h3>
                                                      </a>
                                                   </div>
                                                   <div class="col-md-12">
                                                      <div class="col-md-8 col-lg-8 col-sm-8 col-xs-12">
                                                         <p class="col"> 
                                                            <label style="    font-family: serif;    color: #222;    font-weight: 300;">
                                                            <i class="fa fa-timer"></i>
                                                            <?php 
                                                               if($clb['NoofDays']=='1'){
                                                               
                                                                $dt=date("d-m-Y", strtotime($clb['OneDate']));
                                                               }else{
                                                                   $f=date("d-m-Y", strtotime($clb['FromDate']));
                                                                   $l=date("d-m-Y", strtotime($clb['ToDate']));
                                                                   $dt=$f.' To '.$l;}
                                                               echo '<br>Date : '.$dt.'<br>'; echo 'Time '.$clb['TimeFrom'].' To '.$clb['TimeTo'];
                                                              ?>
                                                            </label>
                                                         </p>
                                                      </div>
                                                      <div class="col-md-4 col-lg-4 col-sm-4 col-xs-12">
                                                         <a style="padding: 6px 7px;" href="<?php echo base_url('event-detail/'.$clb['Slug']);?>" class="btn ">Read More
                                                         </a>
                                                      </div>
                                                   </div>
                                                   <div class="col-md-12">
                                                      <div class="col-md-12">
                                                         <p class="col"> 
                                                            <label style="    font-family: serif;    color: #000;    font-weight: 300;">
                                                            <?php  $big=$clb['Description'];
                                                               $small = substr($big, 0, 110);
                                                               echo  $small.'...'; ?>
                                                            </label>
                                                         </p>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <?php  }
                                             }
                                             else if($NoofDays > '1'){
                                                  if((strtotime($currentdt) < strtotime($fromdate) && strtotime($currentdt) < strtotime($todate)) ||  strtotime($currentdt) < strtotime($todate))
                                                { ?>
                                          <div class="boxclx">
                                             <div clas=" row">
                                                <div class="col-lg-4 col-md-4 col-sm-12">
                                                   <div class="mk">
                                                      <a href="<?php echo base_url('event-detail/'.$clb['Slug']);?>">
                                                      <?php if($img!=''){
                                                         if (file_exists(FCPATH.'assets/events/'.$img)){?>
                                                      <img src="<?php echo base_url('assets/events/'.$img);?>" alt="" class="ew">
                                                      <?php } else {?>
                                                      <img src="<?php echo base_url('assets/fronttheme/customcss/dummyimg.jpg')?>" alt="" class="ew">
                                                      <?php  } }else{ ?>
                                                      <img src="<?php echo base_url('assets/fronttheme/customcss/dummyimg.jpg')?>" alt="" class="ew">
                                                      <?php } ?>
                                                      </a>
                                                   </div>
                                                </div>
                                                <div class="col-lg-8 col-md-8 col-sm-12">
                                                   <div class="col-md-12">
                                                      <a href="<?php echo base_url('event-detail/'.$clb['Slug']);?>">
                                                         <h3 class="titlecls">
                                                            <?php echo $clb['Title'];?>
                                                         </h3>
                                                      </a>
                                                   </div>
                                                   <div class="col-md-12">
                                                      <div class="col-md-8 col-lg-8 col-sm-8 col-xs-12">
                                                         <p class="col"> 
                                                            <label style="    font-family: serif;    color: #222;    font-weight: 300;">
                                                            <i class="fa fa-timer"></i>
                                                            <?php 
                                                               if($clb['NoofDays']=='1'){
                                                               
                                                                $dt=date("d-m-Y", strtotime($clb['OneDate']));
                                                               }else{
                                                                   $f=date("d-m-Y", strtotime($clb['FromDate']));
                                                                   $l=date("d-m-Y", strtotime($clb['ToDate']));
                                                                   $dt=$f.' To '.$l;}
                                                               echo '<br>Date : '.$dt.'<br>'; echo 'Time '.$clb['TimeFrom'].' To '.$clb['TimeTo'];
                                                               echo '<br>Price :  '.$clb['Price'].' QAR';?>
                                                            </label>
                                                         </p>
                                                      </div>
                                                      <div class="col-md-4 col-lg-4 col-sm-4 col-xs-12">
                                                         <a style="padding: 6px 7px;" href="<?php echo base_url('event-detail/'.$clb['Slug']);?>" class="btn ">Read More
                                                         </a>
                                                      </div>
                                                   </div>
                                                   <div class="col-md-12">
                                                      <div class="col-md-12">
                                                         <p class="col"> 
                                                            <label style="    font-family: serif;    color: #000;    font-weight: 300;">
                                                            <?php  $big=$clb['Description'];
                                                               $small = substr($big, 0, 110);
                                                               echo  $small.'...'; ?>
                                                            </label>
                                                         </p>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <?php   }
                                             }
                                             else{                                                    
                                             }  
                                             ?>
                                          <?php   $k++;}
                                             }else { echo '<div style="font-size:20px;text-align:center;padding-top: 26px;">No event found.</div>';} ?> 
                                          <!-------------------------------------------------------------------->
                                       </div>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-12 ">
                                       <!-- start hotel booking -->
                                       <div class="col-lg-12 col-md-12 col-sm-12 ">
                                          <div class="hotel_booking_area clearfix areaclas">
                                             <div class="hotel_booking">
                                                <form id="form1" role="form" action="#" class="">
                                                   <div class="col-lg-12 col-md-12">
                                                      <div class="room_book">
                                                         <h6><?php echo $vendordetails[0]['ClubName']?>
                                                         </h6>
                                                      </div>
                                                   </div>
                                                   <?php $vid=$vendordetails[0]['Id'];
                                                      $vendordetails=$this->App->getPerticularRecord('tbl_vendor','Id',$vid);?>
                                                   <div class="form-group col-lg-12 col-md-12">
                                                      <div class="input-group border-bottom-dark-2">
                                                         <br>
                                                         <label style="    font-size: 20px;    color: whitesmoke;">
                                                         <?php echo $vendordetails[0]['FirstName'].' '.$vendordetails[0]['LastName'];?>
                                                         </label>
                                                         <br>
                                                         <label>
                                                         <i class="fa fa-envelope">
                                                         </i> 
                                                         <?php echo $vendordetails[0]['Email'];?>
                                                         </label>
                                                         <label>
                                                         <i class="fa fa-phone">
                                                         </i> 
                                                         <?php echo $vendordetails[0]['Phone'] .' , '.$vendordetails[0]['AlternativePhone'];?>
                                                         </label>
                                                         <br>
                                                         <label>
                                                         <i class="fa fa-map-marker">
                                                         </i> 
                                                         <?php echo $vendordetails[0]['Address'].' <br> '.$vendordetails[0]['City'].'-'.$vendordetails[0]['PostCode'].' ,'.$vendordetails[0]['Country']; ?>
                                                         </label>
                                                         <br>
                                                         <label>
                                                         <?php $AddressIfram=$vendordetails[0]['AddressIfram'];
                                                            if($AddressIfram!=''){ ?>
                                                         <iframe width="100%" height="200" frameborder="0" style="margin-bottom:10px;border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAyhF2cCWevFm_T8iog0GqV3utCrfAbWYw&q='<?php echo $AddressIfram;?>'">
                                                         </iframe>
                                                         <?php } ?>
                                                         </label> 
                                                      </div>
                                                   </div>
                                                </form>
                                             </div>
                                          </div>
                                       </div>
                                       <!-- end hotel booking -->
                                       <!-- start client says slider -->
                                       <!-- end client says slider -->
                                    </div>
                                 </div>
                                 <style>
                                    .boxclx {
                                    border: 1px solid #ccc;
                                    display: inline-block;
                                    background: whitesmoke;
                                    padding: 12px;
                                    border-radius: 8px;
                                    margin: 2%;
                                    width:95%
                                    }
                                    p.col {
                                    margin: 0px;
                                    padding: 0px;
                                    }
                                    h3.titlecls {
                                    padding-top: 3px;
                                    font-size:18px;    margin-left: 13px;
                                    }
                                    .mg {
                                    border-top: 1px dotted;
                                    padding: 7px;
                                    margin-top: 15px;
                                    }
                                    .col-md-3.col-lg-3.col-sm-12.mds {
                                    background: #313a45;
                                    }
                                    input#clubname ,input#bookdate {
                                    background: transparent;
                                    border: none;
                                    color:#fff; font-size: 10px;
                                    }
                                    img.imgsearch {
                                    width: 34%;
                                    }
                                    .mop {
                                    border: 1px solid #ccc;
                                    background: #fff;
                                    padding: 2px;
                                    margin: 8px;
                                    }
                                 </style>
                              </div>
                           </div>
                           <!-- end single room details -->
                        </div>
                        <div role="tabpanel" class="tab-pane" id="double_bedroom">
                           <!-- start single room details -->
                           <div class="room_detail_main margin-bottom-55">
                              <div class="container">
                                 <div class="row">
                                    <style> img.imgopwn {
                                       height: 150px;width:100%
                                       }
                                    </style>
                                    <div class="col-lg-6 col-md-6 col-xs-12 col-sm-12">
                                       <h5 style="margin-left: 14px;">
                                          <?php echo $vendordetails[0]['ClubName'];?> Gallery 
                                       </h5>
                                       <?php $clubid =$vendordetails[0]['Id'];
                                          $clubgallery= $this->App->getPerticularRecord('tbl_clubgallery', 'VendorId', $clubid);
                                          if(!empty($clubgallery)){
                                              foreach($clubgallery as $gallery){
                                                 
                                              
                                          ?>
                                       <div class="col-lg-4 col-md-4 col-sm-4">
                                          <div class="single_room_wrapper clearfix" style="padding: 12px 0px;">
                                             <div class="room_wrapper">
                                                <div class="room_media" style="width:100%">
                                                   <?php if($gallery['Image']!=''){
                                                      if (file_exists(FCPATH.'assets/clubgallery/'.$gallery['Image'])){?>
                                                   <img alt="img" class="imgopwn" src="<?php echo base_url('assets/clubgallery/'.$gallery['Image']);?>" >      
                                                   <?php    }
                                                      }
                                                      ?>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <?php }
                                          } else { echo '<div style="font-size:20px;text-align:center;padding-top: 26px;">No gallery image found.</div>';} ?>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 ">
                                       <!-- start hotel booking -->
                                       <div class="col-lg-12 col-md-12 col-sm-12 ">
                                          <div class="hotel_booking_area clearfix areaclas">
                                             <div class="hotel_booking">
                                                <form id="form1" role="form" action="#" class="">
                                                   <div class="col-lg-12 col-md-12">
                                                      <div class="room_book">
                                                         <h6><?php echo $vendordetails[0]['ClubName']?>
                                                         </h6>
                                                      </div>
                                                   </div>
                                                   <?php $vid=$vendordetails[0]['Id'];
                                                      $vendordetails=$this->App->getPerticularRecord('tbl_vendor','Id',$vid);?>
                                                   <div class="form-group col-lg-12 col-md-12">
                                                      <div class="input-group border-bottom-dark-2">
                                                         <br>
                                                         <label style="    font-size: 20px;    color: whitesmoke;">
                                                         <?php echo $vendordetails[0]['FirstName'].' '.$vendordetails[0]['LastName'];?>
                                                         </label>
                                                         <br>
                                                         <label>
                                                         <i class="fa fa-envelope">
                                                         </i> 
                                                         <?php echo $vendordetails[0]['Email'];?>
                                                         </label>
                                                         <label>
                                                         <i class="fa fa-phone">
                                                         </i> 
                                                         <?php echo $vendordetails[0]['Phone'] .' , '.$vendordetails[0]['AlternativePhone'];?>
                                                         </label>
                                                         <br>
                                                         <label>
                                                         <i class="fa fa-map-marker">
                                                         </i> 
                                                         <?php echo $vendordetails[0]['Address'].' <br> '.$vendordetails[0]['City'].'-'.$vendordetails[0]['PostCode'].' ,'.$vendordetails[0]['Country']; ?>
                                                         </label>
                                                         <br>
                                                         <label>
                                                         <?php $AddressIfram=$vendordetails[0]['AddressIfram'];
                                                            if($AddressIfram!=''){ ?>
                                                         <iframe width="100%" height="200" frameborder="0" style="margin-bottom:10px;border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAyhF2cCWevFm_T8iog0GqV3utCrfAbWYw&q='<?php echo $AddressIfram;?>'">
                                                         </iframe>
                                                         <?php } ?>
                                                         </label> 
                                                      </div>
                                                   </div>
                                                </form>
                                             </div>
                                          </div>
                                       </div>
                                       <!-- end hotel booking -->
                                       <!-- start client says slider -->
                                       <!-- end client says slider -->
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <!-- end single room details -->
                        </div>
                        <style> img.imgopwn {
                           height: 150px;width:100%
                           }
                        </style>
                        <div role="tabpanel" class="tab-pane" id="classic_room">
                           <!-- start single room details -->
                           <div class="room_detail_main margin-bottom-55">
                              <div class="container">
                                 <div class="row">
                                    <div class="col-lg-6 col-md-6">
                                       <div class="deluxe_room_detail">
                                          <div class="section_title content-left margin-bottom-5">
                                             <h5>
                                                <?php echo $vendordetails[0]['ClubName'];?> 
                                             </h5>
                                          </div>
                                          <div class="section_content">
                                             <!---------------------------------------------------------->
                                             <div class="accomodation_single_room">
                                                <div class="container">
                                                   <div class="row">
                                                      <div class="col-lg-9 col-md-9 col-sm-9 col-sm-12">
                                                         Booking Form
                                                      </div>
                                                      <div class="col-lg-3 col-md-3 col-sm-12 ">
                                                         <!-- start hotel booking -->
                                                         <div class="col-lg-12 col-md-12 col-sm-12 ">
                                                            <div class="hotel_booking_area clearfix areaclas">
                                                               <div class="hotel_booking">
                                                                  <form id="form1" role="form" action="#" class="">
                                                                     <div class="col-lg-12 col-md-12">
                                                                        <div class="room_book">
                                                                           <h6><?php echo $vendordetails[0]['ClubName']?>
                                                                           </h6>
                                                                        </div>
                                                                     </div>
                                                                     <?php $vid=$vendordetails[0]['Id'];
                                                                        $vendordetails=$this->App->getPerticularRecord('tbl_vendor','Id',$vid);?>
                                                                     <div class="form-group col-lg-12 col-md-12">
                                                                        <div class="input-group border-bottom-dark-2">
                                                                           <br>
                                                                           <label style="    font-size: 20px;    color: whitesmoke;">
                                                                           <?php echo $vendordetails[0]['FirstName'].' '.$vendordetails[0]['LastName'];?>
                                                                           </label>
                                                                           <br>
                                                                           <label>
                                                                           <i class="fa fa-envelope">
                                                                           </i> 
                                                                           <?php echo $vendordetails[0]['Email'];?>
                                                                           </label>
                                                                           <label>
                                                                           <i class="fa fa-phone">
                                                                           </i> 
                                                                           <?php echo $vendordetails[0]['Phone'] .' , '.$vendordetails[0]['AlternativePhone'];?>
                                                                           </label>
                                                                           <br>
                                                                           <label>
                                                                           <i class="fa fa-map-marker">
                                                                           </i> 
                                                                           <?php echo $vendordetails[0]['Address'].' <br> '.$vendordetails[0]['City'].'-'.$vendordetails[0]['PostCode'].' ,'.$vendordetails[0]['Country']; ?>
                                                                           </label>
                                                                           <br>
                                                                           <label>
                                                                           <?php $AddressIfram=$vendordetails[0]['AddressIfram'];
                                                                              if($AddressIfram!=''){ ?>
                                                                           <iframe width="100%" height="200" frameborder="0" style="margin-bottom:10px;border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAyhF2cCWevFm_T8iog0GqV3utCrfAbWYw&q='<?php echo $AddressIfram;?>'">
                                                                           </iframe>
                                                                           <?php } ?>
                                                                           </label> 
                                                                        </div>
                                                                     </div>
                                                                  </form>
                                                               </div>
                                                            </div>
                                                         </div>
                                                         <!-- end hotel booking -->
                                                         <!-- start client says slider -->
                                                         <!-- end client says slider -->
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <!------------------------------------------------------------->
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <!-- end single room details -->
                        </div>
                        <div role="tabpanel" class="tab-pane" id="exe_room">
                           <!-- start single room details -->
                           <div class="room_detail_main margin-bottom-55">
                              <div class="container">
                                 <div class="row">
                                    <div class="col-lg-6 col-md-6">
                                       <div class="deluxe_room_detail">
                                          <div class="section_content">
                                             <!---------------------------------------------------------->
                                             <div class="accomodation_single_room">
                                                <div class="container">
                                                   <div class="row">
                                                      <div class="col-lg-6 col-md-96 col-sm-6 col-sm-12">
                                                         <h5 style="    margin-left: 0px;">
                                                            <?php echo $vendordetails[0]['ClubName'];?> Reviews
                                                         </h5>
                                                         <?php $clbid=$vendordetails[0]['Id'];
                                                            $review=$this->App->getPerticularRecord('tbl_reviews','ClubId',$clbid);
                                                            
                                                            if(!empty($review)){
                                                            echo '<div class="row">';
                                                            echo '<div class="col-md-12">';
                                                            
                                                            foreach($review as $rev){
                                                                $clubid=$rev['ClubId'];
                                                                $BookingId=$rev['BookingId'];
                                                                $Review=$rev['Review'];
                                                                
                                                                if($Review=='5'){
                                                                    $s='<span class="str"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><span>';
                                                                }elseif($Review=='4'){
                                                                    $s='<span class="str"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-o"></i><span>';
                                                                }elseif($Review=='3'){
                                                                    $s='<span class="str"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><span>';
                                                                }elseif($Review=='2'){
                                                                    $s='<span class="str"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><span>';
                                                                }elseif($Review=='1'){
                                                                    $s='<span class="str"><i class="fa fa-star"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><span>';
                                                                }else{
                                                                    $s='<span class="str"><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><span>';
                                                                }
                                                                
                                                                
                                                                $comment=$rev['Reviewscomment'];
                                                                $Created=$rev['Created'];
                                                                $Created = date("d-m-Y", strtotime($Created));
                                                                
                                                                $bookingdetails=$this->App->getPerticularRecord('tbl_booking','Id',$BookingId);
                                                                $customerid=$bookingdetails[0]['CustomerId'];
                                                                $cname=$bookingdetails[0]['FirstName'].' '.$bookingdetails[0]['LastName'];
                                                                
                                                                
                                                                $customerdetails=$this->App->getPerticularRecord('tbl_customer','Id',$customerid);
                                                                
                                                                $ProfileImage=$customerdetails[0]['ProfileImage'];
                                                                
                                                                if($ProfileImage!=''){
                                                                    $i=base_url('assets/customerprofile/'.$ProfileImage);
                                                                }else{
                                                                    $i=base_url('assets/fronttheme/customcss/dummy.png');
                                                                }
                                                                
                                                                $cimagedetails=$this->App->getPerticularRecord('tbl_reviewsimages','ReviewId',$BookingId);
                                                                
                                                            echo '<div class="containbox">';
                                                            echo '<div class="row">';
                                                            echo '<div class="col-md-3 col-sm-3 col-xs-3 col-lg-3">';
                                                            echo '<div class="img-responsive imgcls"><img src="'.$i.'"></div>';
                                                            echo '</div>';
                                                            echo '<div class="col-md-7 col-sm-7 col-xs-7 col-lg-7">';
                                                            echo '<div class="contitname">'.$cname.'</div>';
                                                            echo '<div class="contit stars">'.$s.'</div>';
                                                             echo '<div class="condate"> Date : '.$Created.'</div>';
                                                            echo '</div>';
                                                             echo '<div class="col-md-2 col-sm-2 col-xs-2 col-lg-2">';
                                                              echo '<div class="rev leftrev">'.$Review.'</div>';
                                                            echo '</div>';
                                                            
                                                             echo '<div class="col-md-12 col-sm-12 col-xs-12 ">';
                                                            echo '<div class="commernt">'.$comment.'</div>';
                                                            echo '</div>';
                                                             echo '<div class="row">';
                                                             echo '<div class="col-md-12 col-sm-12 col-xs-12 ">';
                                                            if(!empty($cimagedetails)){
                                                            foreach($cimagedetails as $tesd){
                                                            $imh=$tesd['Image'];
                                                            if($imh!=''){
                                                            $revimg=base_url('assets/reviewimg/'.$imh);
                                                            
                                                            if (file_exists(FCPATH.'assets/reviewimg/'.$imh)){
                                                            echo '<div class="col-md-2 col-sm-3 col-lg-2 col-xs-3">';
                                                            echo '<div class="nki">';
                                                            echo '<img src="'.$revimg.'" class="img-responsive big">';
                                                            echo '</div>';
                                                            echo '</div>';
                                                            
                                                            }
                                                            }  
                                                            }
                                                            }
                                                            
                                                            echo '</div>';
                                                            echo '</div>';
                                                            echo '</div>';
                                                            echo '</div>';
                                                            
                                                            
                                                            }
                                                            echo '</div>';
                                                            echo '</div>';
                                                            
                                                            }else { echo '<div style="font-size:20px;text-align:center;padding-top: 26px;">No review found.</div>';} ?>
                                                      </div>
                                                      <div class="col-lg-3 col-md-3 col-sm-12 ">
                                                         <!-- start hotel booking -->
                                                         <div class="col-lg-12 col-md-12 col-sm-12 ">
                                                            <div class="hotel_booking_area clearfix areaclas">
                                                               <div class="hotel_booking">
                                                                  <form id="form1" role="form" action="#" class="">
                                                                     <div class="col-lg-12 col-md-12">
                                                                        <div class="room_book">
                                                                           <h6><?php echo $vendordetails[0]['ClubName']?>
                                                                           </h6>
                                                                        </div>
                                                                     </div>
                                                                     <?php $vid=$vendordetails[0]['Id'];
                                                                        $vendordetails=$this->App->getPerticularRecord('tbl_vendor','Id',$vid);?>
                                                                     <div class="form-group col-lg-12 col-md-12">
                                                                        <div class="input-group border-bottom-dark-2">
                                                                           <br>
                                                                           <label style="    font-size: 20px;    color: whitesmoke;">
                                                                           <?php echo $vendordetails[0]['FirstName'].' '.$vendordetails[0]['LastName'];?>
                                                                           </label>
                                                                           <br>
                                                                           <label>
                                                                           <i class="fa fa-envelope">
                                                                           </i> 
                                                                           <?php echo $vendordetails[0]['Email'];?>
                                                                           </label>
                                                                           <label>
                                                                           <i class="fa fa-phone">
                                                                           </i> 
                                                                           <?php echo $vendordetails[0]['Phone'] .' , '.$vendordetails[0]['AlternativePhone'];?>
                                                                           </label>
                                                                           <br>
                                                                           <label>
                                                                           <i class="fa fa-map-marker">
                                                                           </i> 
                                                                           <?php echo $vendordetails[0]['Address'].' <br> '.$vendordetails[0]['City'].'-'.$vendordetails[0]['PostCode'].' ,'.$vendordetails[0]['Country']; ?>
                                                                           </label>
                                                                           <br>
                                                                           <label>
                                                                           <?php $AddressIfram=$vendordetails[0]['AddressIfram'];
                                                                              if($AddressIfram!=''){ ?>
                                                                           <iframe width="100%" height="200" frameborder="0" style="margin-bottom:10px;border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAyhF2cCWevFm_T8iog0GqV3utCrfAbWYw&q='<?php echo $AddressIfram;?>'">
                                                                           </iframe>
                                                                           <?php } ?>
                                                                           </label> 
                                                                        </div>
                                                                     </div>
                                                                  </form>
                                                               </div>
                                                            </div>
                                                         </div>
                                                         <!-- end hotel booking -->
                                                         <!-- start client says slider -->
                                                         <!-- end client says slider -->
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <!------------------------------------------------------------->
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <!-- end single room details -->
                        </div>
                        <div role="tabpanel" class="tab-pane" id="royal_room">
                           <div class="room_detail_main margin-bottom-55">
                              <div class="container">
                                 <div class="row">
                                    <div class="col-lg-6 col-md-6">
                                       <div class="deluxe_room_detail">
                                          <div class="section_title content-left margin-bottom-5">
                                             <h5 style="    margin-left: 14px;">
                                                <?php echo $vendordetails[0]['ClubName'];?> Detail 
                                                <!--<span class="price floatright"><?php echo $PerAdultPrice.' QAR';?>
                                                   </span> -->
                                                <br> 
                                                <span class="day floatright">
                                                </span>
                                             </h5>
                                          </div>
                                          <!-------------------------------------------------------------------->
                                          <?php  $vid = $vendordetails[0]['Id'];
                                             $package= $this->App->getPerticularRecord('tbl_packages', 'ClubId',$vid);
                                             
                                             if(!empty($package)){
                                             foreach($package as $pack){
                                             $img=$pack['Image'];
                                              ?>
                                          <div class="col-lg-6 col-md-6 col-sm-6 yellowbox">
                                             <div class="single_room_wrapper clearfix padding-bottom-30">
                                                <figure class="uk-overlay1 uk-overlay-hover1">
                                                   <div class="room_media mk">
                                                      <a  href="<?php echo base_url('package/viewpackage/'.$pack['Id']);?>" >
                                                         <?php if($img!=''){ 
                                                            if (file_exists(FCPATH.'assets/package/'.$img)){?>
                                                         <img src="<?php echo base_url('assets/package/'.$img);?>" alt="" class="ew">
                                                         <?php }else{ ?>
                                                         <img src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="" class="ew">
                                                         <?php } } else{ ?>
                                                         <img src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="" class="ew">
                                                         <?php } ?> 
                                                   </div>
                                                   <div  class="room_title border-bottom-whitesmoke clearfix">
                                                   <div class="left_room_title floatleft">
                                                   <a href="<?php echo base_url('package/viewpackage/'.$pack['Id']);?>">
                                                   <h6 class="claimedRight" maxlength="50" >
                                                   <?php 
                                                      echo $r=trim($clb['Title']);
                                                      ?>
                                                   </h6>
                                                   <style>
                                                   img.ew {
                                                   height: 150px; width: 100%;
                                                   }
                                                   .claimedRight {
                                                   margin-top:10px;
                                                   display: block;
                                                   width: 190px;
                                                   overflow: hidden;
                                                   white-space: nowrap;
                                                   text-overflow: ellipsis;
                                                   }
                                                   figure.uk-overlay1.uk-overlay-hover1 {
                                                   width: 100%;
                                                   }</style>
                                                   </a>
                                                   <p><?php echo $pack['ActPrice'].' QAR';?>
                                                   <span>
                                                   </span>
                                                   </p>
                                                   </div>
                                                   <div class="left_room_title floatright">
                                                   <a href="<?php echo base_url('package/viewpackage/'.$pack['Id']);?>" style="
                                                      margin: 0px 0px 8px 1px;" class="btn ">Read More..
                                                   </a>
                                                   </div>
                                                   </div>
                                                </figure>
                                             </div>
                                          </div>
                                          <?php }
                                             }else {
                                             echo '<div style="font-size:20px;text-align:center;padding-top: 26px;">No package found.</div>';
                                             } ?>          
                                          <!-------------------------------------------------------------------->
                                       </div>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-12 ">
                                       <!-- start hotel booking -->
                                       <div class="col-lg-12 col-md-12 col-sm-12 ">
                                          <div class="hotel_booking_area clearfix areaclas">
                                             <div class="hotel_booking">
                                                <form id="form1" role="form" action="#" class="">
                                                   <div class="col-lg-12 col-md-12">
                                                      <div class="room_book">
                                                         <h6><?php echo $vendordetails[0]['ClubName']?>
                                                         </h6>
                                                      </div>
                                                   </div>
                                                   <?php $vid=$vendordetails[0]['Id'];
                                                      $vendordetails=$this->App->getPerticularRecord('tbl_vendor','Id',$vid);?>
                                                   <div class="form-group col-lg-12 col-md-12">
                                                      <div class="input-group border-bottom-dark-2">
                                                         <br>
                                                         <label style="    font-size: 20px;    color: whitesmoke;">
                                                         <?php echo $vendordetails[0]['FirstName'].' '.$vendordetails[0]['LastName'];?>
                                                         </label>
                                                         <br>
                                                         <label>
                                                         <i class="fa fa-envelope">
                                                         </i> 
                                                         <?php echo $vendordetails[0]['Email'];?>
                                                         </label>
                                                         <label>
                                                         <i class="fa fa-phone">
                                                         </i> 
                                                         <?php echo $vendordetails[0]['Phone'] .' , '.$vendordetails[0]['AlternativePhone'];?>
                                                         </label>
                                                         <br>
                                                         <label>
                                                         <i class="fa fa-map-marker">
                                                         </i> 
                                                         <?php echo $vendordetails[0]['Address'].' <br> '.$vendordetails[0]['City'].'-'.$vendordetails[0]['PostCode'].' ,'.$vendordetails[0]['Country']; ?>
                                                         </label>
                                                         <br>
                                                         <label>
                                                         <?php $AddressIfram=$vendordetails[0]['AddressIfram'];
                                                            if($AddressIfram!=''){ ?>
                                                         <iframe width="100%" height="200" frameborder="0" style="margin-bottom:10px;border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAyhF2cCWevFm_T8iog0GqV3utCrfAbWYw&q='<?php echo $AddressIfram;?>'">
                                                         </iframe>
                                                         <?php } ?>
                                                         </label> 
                                                      </div>
                                                   </div>
                                                </form>
                                             </div>
                                          </div>
                                       </div>
                                       <!-- end hotel booking -->
                                       <!-- start client says slider -->
                                       <!-- end client says slider -->
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- end other detect room section -->
<style>
   img.img-responsive.big {
   height: 71px;
   border-radius: 5px;
   width: 100%;
   padding: 0px;
   margin: 5px;
   }
   i.fa.fa-star-o {
   padding: 1px;color:coral;
   }
   .tooltip4 {
   position: relative;
   display: inline-block;
   border-bottom: 1px dotted black;
   }
   .tooltip4 .tooltiptext {
   visibility: hidden;
   width: 220px;
   background-color: #555;
   color: #fff;
   text-align: center;
   border-radius: 6px;
   padding: 5px 5px;
   position: absolute;
   z-index: 1;
   bottom: 125%;
   left: 0%;
   margin-left: -37px;
   opacity: 0;
   transition: opacity 0.3s;
   }
   .tooltip4 .tooltiptext::after {
   content: "";
   position: absolute;
   top: 100%;
   left: 50%;
   margin-left: -5px;
   border-width: 5px;
   border-style: solid;
   border-color: #555 transparent transparent transparent;
   }
   .tooltip4:hover .tooltiptext {
   visibility: visible;
   opacity: 1;
   }
</style>
<!-- start contact us area -->
<!-- end contact us area -->
<style>
td.day.disabled {
    background: #eaeaea !important;
}
   span.day.floatright.rev.leftrev {
   width: 10%;
   margin: 0px 10px;
   }
   .floatright {
   float: right;
   font-family: serif;
   }
   /*.active a {
   font-weight: bold;
   background: #3ac4fa !important;
   color: #fff !important;
   }*/
   .myclspo1 {
   background: #313a45;
   }
   p {
   color: #666666;
   /* font-weight: normal; */
   font-size: 14px;
   font-family: inherit;
   font-weight: normal;
   }
   label {
   font-family: serif;
   }
   span.a {
   COLOR: slategray;
   }
   p.vencls {
   color: navy;
   font-weight: bold;
   font-size: 18px;
   }
   label {
   display: table-row;
   color: #ccc;
   font-size: 12px;
   margin: 2px !important;
   }body#gallery_page .other_room .nav-tabs {
   border-bottom: op !important;
   }
   .containbox {
   border: 1px solid #ccc;
   margin: 3% 0%;
   padding: 3%;
   background: snow;
   }.img-responsive.imgcls img {
   border-radius: 91px;
   height: auto;
   }
   .commernt {
   padding: 7px;
   text-align: justify;
   font-size: 12px;
   color: #000;
   }
   .contitname {
   font-size: 25px;
   color: #000;
   text-transform: capitalize;
   line-height: 31px;
   }i.fa.fa-star {
   color: coral;
   padding: 1px;
   }
   button.btn.btn-warning.btnwrm {
    padding: 7px 15px;
    text-align: center;
}
   .l1 {
		margin: 6px 0px;
	}
	.reserved_box {
    border: 1px solid #ccc;
    padding: 13px 12px;
    height: 400px;
    margin: 20px 0px;
}	
a.btn.btn-warning.btnwrm {
    padding: 7px 20px;
}
</style>
<script src="<?php echo base_url('assets');?>/vendors/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap -->
<!--<script src="<?php echo base_url('assets');?>/vendors/bootstrap/dist/js/bootstrap.min.js"></script>-->
<!-- FastClick -->
<script src="<?php echo base_url('assets');?>/vendors/fastclick/lib/fastclick.js"></script>
<!-- NProgress -->
<!-- bootstrap-daterangepicker -->
<script src="<?php echo base_url('assets');?>/vendors/moment/min/moment.min.js"></script>
<script src="<?php echo base_url('assets');?>/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- bootstrap-datetimepicker -->    
<script src="<?php echo base_url('assets');?>/vendors/bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>
<!-- Ion.RangeSlider -->
<script src="<?php echo base_url('assets');?>/vendors/jquery.inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
<script>
   $('#myDatepicker1').datetimepicker({    format: 'hh:mm A' }  );
</script>
