<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript">
</script>
<section class="breadcrumb_main_area ">
  <div class="container-fluid">
    <div class="row">
      <div class="breadcrumb_main nice_title">
        <h2>Payment Options
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
           
          </div>
        </div>         
        <!-- end offer start -->
      </div>
    </div>
  </div>            
</section>
<section class="booking_area nobito">
<div class="container"> 
<div class="row">
<div class="col-md-12 col-sm-12 col-xs-12 col-lg-12">
<div style="     border: 1px solid #ccc;    text-align: left;    padding: 3%;">
  <label>Select Payment Options </label><br>
  <input type="radio" name="chk" value="bypaypal" onclick="selectbox()"> Payment By Paypal Account <br>
  <input type="radio" name="chk" value="bycard" onclick="selectbox()"> Payment By Card <br>
 
 <script>
   function selectbox()
   {
	var c= $( 'input[name=chk]:checked' ).val(); 
	 if(c=='bypaypal'){
		$("#bypaypal").show();
		$("#bycard").hide();
	 }
	 else if(c=='bycard'){
		 $("#bypaypal").hide();
		$("#bycard").show();
		 }
		 else {
			 $("#bypaypal").hide();
		$("#bycard").hide();
			}
	}
 </script>
 <div id="bycard" style="display:none">
	<form class="form-horizontal" target="paypal" action="{$paypalUrl}" method="post" target="paypal" id="paypal_form" class="hidden">
  <fieldset id="payment">
    <legend><br><?php echo $text_credit_card; ?></legend>
    <div class="form-group required">
      <label class="col-md-6 col-sm-12  col-xs-12 col-lg-6 control-label" for="input-cc-type"><?php echo $entry_cc_type; ?></label>
      <div class="col-md-6 col-sm-12  col-xs-12 col-lg-6">
        <select name="cc_type" id="input-cc-type" class="form-control">
          <?php foreach ($cards as $card) { ?>
            <option value="<?php echo $card['value']; ?>"><?php echo $card['text']; ?></option>
          <?php } ?>
        </select>
      </div>
    </div>
    <div class="form-group required">
      <label class="col-md-6 col-sm-12  col-xs-12 col-lg-6 control-label" for="input-cc-number"><?php echo $entry_cc_number; ?></label>
      <div class="col-md-6 col-sm-12  col-xs-12 col-lg-6">
        <input type="text" name="cc_number" value="" placeholder="<?php echo $entry_cc_number; ?>" id="input-cc-number" class="form-control" />
      </div>
    </div>
    <div class="form-group">
      <label class="col-md-6 col-sm-12  col-xs-12 col-lg-6 control-label" for="input-cc-start-date"><span data-toggle="tooltip" title="<?php echo $help_start_date; ?>"><?php echo $entry_cc_start_date; ?></span></label>
      <div class="col-md-3 col-sm-6  col-xs-6 col-lg-3">
        <select name="cc_start_date_month" id="input-cc-start-date" class="form-control">
          <?php foreach ($months as $month) { ?>
          <option value="<?php echo $month['value']; ?>"><?php echo $month['text']; ?></option>
          <?php } ?>
        </select>
      </div>
      <div class="col-md-3 col-sm-6  col-xs-6 col-lg-3">
        <select name="cc_start_date_year" class="form-control">
          <?php foreach ($year_valid as $year) { ?>
          <option value="<?php echo $year['value']; ?>"><?php echo $year['text']; ?></option>
          <?php } ?>
        </select>
      </div>
    </div>
    <div class="form-group required">
      <label class="col-md-6 col-sm-12  col-xs-12 col-lg-6 control-label" for="input-cc-expire-date"><?php echo $entry_cc_expire_date; ?></label>
      <div class="col-md-3 col-sm-6  col-xs-6 col-lg-3">
        <select name="cc_expire_date_month" id="input-cc-expire-date" class="form-control">
          <?php foreach ($months as $month) { ?>
          <option value="<?php echo $month['value']; ?>"><?php echo $month['text']; ?></option>
          <?php } ?>
        </select>
      </div>
      <div class="col-md-3 col-sm-6  col-xs-6 col-lg-3">
        <select name="cc_expire_date_year" class="form-control">
          <?php foreach ($year_expire as $year) { ?>
          <option value="<?php echo $year['value']; ?>"><?php echo $year['text']; ?></option>
          <?php } ?>
        </select>
      </div>
    </div>
    <div class="form-group required">
      <label class="col-md-6 col-sm-12  col-xs-12 col-lg-6 control-label" for="input-cc-cvv2"><?php echo $entry_cc_cvv2; ?></label>
      <div class="col-md-6 col-sm-12  col-xs-12 col-lg-6">
        <input type="text" name="cc_cvv2" value="" placeholder="<?php echo $entry_cc_cvv2; ?>" id="input-cc-cvv2" class="form-control" />
      </div>
    </div>
    <div class="form-group">
      <label class="col-md-6 col-sm-12  col-xs-12 col-lg-6 control-label" for="input-cc-issue"><span data-toggle="tooltip" title="<?php echo $help_issue; ?>"><?php echo $entry_cc_issue; ?></span></label>
      <div class="col-md-6 col-sm-12  col-xs-12 col-lg-6">
        <input type="text" name="cc_issue" value="" placeholder="<?php echo $entry_cc_issue; ?>" id="input-cc-issue" class="form-control" />
      </div>
    </div>
  
  <div class="buttons">
  <div class="pull-right">
     <input type="button" value="submit" id="button-confirm" class="btn btn-default" />
  
  </div>
</div>


  </fieldset>
  

</form>

 </div>
 <div id="bypaypal" style="display:none">
 <br>
          <a class="btn btn-default " href="<?php echo base_url('vendor/expresscheckout');?>">PayPal Account</a>
 </div>

</div>
</div>


</div>





 </div>
          
</section>

<script type="text/javascript">
 $('#button-confirm').bind('click', function() {
	$.ajax({
		url: "<?php echo base_url('vendor/sendrecurring');?>",
		dataType: 'json',
		type: 'post',
		data: $('#payment :input'),
				
		beforeSend: function() {
			$('#button-confirm').attr('disabled', true);
			$('#payment').before('<div class="attention" style="color:orange;text-align:center"><img src="catalog/view/theme/default/image/loading.gif" alt="" /> <?php echo $text_wait; ?></div>');
		},
		complete: function() {
			$('#button-confirm').attr('disabled', false);
			$('.attention').remove();
		},				
		success: function(json) {
			if(json.success=='1'){
			 window.location.href="<?php echo base_url('vendor/payment_successfulpaypalpro');?>";	
			}if(json.err=='2'){
				alert(json.error);
			}

			
		}
	});
});
</script> 
