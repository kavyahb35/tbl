<!-- start breadcrumb -->
<section class="breadcrumb_main_area margin-bottom-80">
   <div class="container-fluid">
      <div class="row">
         <?php $vid=$eventdetails[0]['Id'];
            $img=$eventdetails[0]['Image'];
            $Description=$eventdetails[0]['Description'];
            if($img!=''){
                if (file_exists(FCPATH.'assets/clubimage/'.$img)){
            $i=base_url('assets/events/'.$img);
                }
                else{
            $i=base_url('assets/fronttheme/banner/TableFast-Banner-2.jpg');
            }
            }else{
            $i=base_url('assets/fronttheme/banner/TableFast-Banner-2.jpg');
            } ?>
         <style>
            .march {
            background:url(<?php echo $i;?>);
            background-repeat: no-repeat;
            background-size:     cover;
            }
         </style>
         <div class="breadcrumb_main nice_title march">
            <h2>
               <?php echo $eventdetails[0]['Title'];?>
            </h2>
            <!-- special offer start -->
            <div class="special_offer_main">
               <div class="container">
                  <div class="special_offer_sub">
                     <?php $vid=$eventdetails[0]['Id'];
                        $img=$eventdetails[0]['Image'];
                        $Description=$layout[0]['Description'];
                        if($img!=''){
                        $i=base_url('assets/events/'.$img);
                        }else{
                        $i=base_url('assets/fronttheme/banner/TableFast-Banner-2.jpg');
                        } ?>
                  </div>
               </div>
            </div>
            <!-- end offer start -->
         </div>
      </div>
   </div>
</section>
<!-- end breadcrunb -->
<div class="room_detail_main margin-bottom-55">
   <div class="container">
      <div class="row">
         <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
            <div class="deluxe_room_detail">
               <div class="section_title content-left margin-bottom-5">
                  <h5>
                     <?php echo $eventdetails[0]['Title'];?> Detail 
                   <!--  <span class="price floatright"><?php echo $eventdetails[0]['Price'].' QAR';?>
                     </span> -->
                     <br> 
                  </h5>
                  <p class="col"> 
                     <label style="    font-family: serif;    color: #222;    font-weight: 300;">
                     <i class="fa fa-timer"></i>
                     <?php 
                        if($eventdetails[0]['NoofDays']=='1'){
                        
                        $dt=date("d-m-Y", strtotime($eventdetails[0]['OneDate']));
                        }else{
                        $f=date("d-m-Y", strtotime($eventdetails[0]['FromDate']));
                        $l=date("d-m-Y", strtotime($eventdetails[0]['ToDate']));
                        $dt=$f.' To '.$l;
                        
                        }
                        echo '<br>Date : '.$dt.'<br>'; echo 'Time '.$eventdetails[0]['TimeFrom'].' To '.$eventdetails[0]['TimeTo'];
                      //  echo '<br>Price : ₹ '.$eventdetails[0]['Price'];?>
                     </label>
                  </p>
                  <p class="col"> 
                     <label style="    font-family: serif;    color: #000;    font-weight: 300;">
                     <?php  echo $eventdetails[0]['Description'];
                        ?>
                     </label>
                  </p>
                  
                  
           <?php $eventtype = $eventdetails[0]['eventtype'];
                 if($eventtype!=''){ echo '<div class="typediv">';
                 $type = explode(',',$eventtype);
                 $c = count($type); 
                 for($i=0;$i<$c;$i++){ 
					 $res = $this->App->getPerticularRecord('tbl_event_type', 'Id', $type[$i]);
					 if(!empty($res)){
						 $big = $res[0]['ShortDescription'];
						 $small = substr($big, 0, 200);
						 
						 $vendorClubId=$res[0]['ClubId'];
						 $typeId=$res[0]['Id'];
						 $eventid=$eventdetails[0]['Id'];
						 
						 
						 
						 
                ?>
                  <div class="boxevent">
                  <ul class="ulc">
                  <li class="ulctit"><?php echo $res[0]['Title']?></li>
                    <li class="ulcdesc"><?php echo $small.'...'?></li>
                      <li class="ulcamt"><?php echo 'Amount : '.$res[0]['Amount'].' QAR';?></li>
                      <?php
                      $r = $this->db->query("select * from tbl_event_ticket_update where ClubId='".$vendorClubId."' and EventId='".$eventid."' and EventTypeId='".$typeId."'");
                     
						$noresult = $r->result_array();
						 $tottic = $noresult[0]['NoofTicket'];
						
						 $UsedTicket = $noresult[0]['UsedTicket'];
						$availableticket =  $tottic-$UsedTicket;
						if($availableticket!=''){
						if($availableticket > 0){ ?>
							<center><li class="ulcamtbuton succ"><a href="<?php echo base_url('events/book/'.$vendorClubId.'/'.$eventid.'/'.$typeId);?>" class="ticketcls" >Buy Tickets </a></li></center>
						<?php }else { ?>
						<center><li class="ulcamtbuton err"><a  class="ticketcls err" >Not Available </a></li></center>
						<?php } }else{ ?>
								<center><li class="ulcamtbuton succ"><a href="<?php echo base_url('events/book/'.$vendorClubId.'/'.$eventid.'/'.$typeId);?>" class="ticketcls" >Buy Tickets </a></li></center>
							<?php }
                       ?>
                      
                  </ul>
                  </div>
          <?php } } echo '</div>'; } ?>
                  
                  
               </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
            <div class="customer_says">
               <div class="section_title margin-bottom-50">
                  <h5>Latest Events
                  </h5>
               </div>
               <?php  $ClubId=$eventdetails[0]['ClubId'];$currentdt = date('Y-m-d',strtotime("-1 days"));
                  $query=$this->db->query("SELECT * FROM `tbl_events` WHERE ClubId='".$ClubId."' and (`FromDate` > '".$currentdt."' or `ToDate` > '".$currentdt."' or `OneDate` > '".$currentdt."') ORDER BY `Id` DESC");
                  $latest=$query->result_array();
                 
                  ?>
               <div class="section_description">
                  <div id="customer_says_slider" class="carousel slide" data-ride="carousel" data-pause="none">
                     <!-- Wrapper for slides -->
                     <div class="carousel-inner" role="listbox">
                        <?php if(!empty($latest)){ $i=1;
                           foreach($latest as $lst){ 
                               if($lst['Status']=='1'){
                                   
                                $currentdt = date('Y-m-d',strtotime("-1 days"));
                                 $fromdate=$lst['FromDate'];
                                                $todate=$lst['ToDate'];
                                                $specialdate=$lst['OneDate'];
                                                $NoofDays=$lst['NoofDays'];
                                                if($NoofDays=='1')
                                                {
                                                   if(strtotime($currentdt) < strtotime($specialdate))
                                                   {  ?>
                                                        <div class="item <?php if($i=='1'){ echo 'active';} ?>">
                           <div class="single_says">
                              <div class="customer_comment">
                                 <p>
                                    <?php $big=$lst['Description'];
                                       $small = substr($big, 0, 110);
                                       echo  $small.'...'; ?>  
                                 </p>
                              </div>
                              <div class="customer_detail clearfix">
                                 <div class="customer_pic alignleft-20">
                                    <a href="<?php echo base_url('front/eventdetail/'.$lst['Slug']);?>">
                                    <img src="<?php echo base_url('assets/events/'.$lst['Image'])?>" alt="" class="smlcls">
                                    </a>
                                 </div>
                                 <div class="customer_identity floatleft">
                                    <a href="<?php echo base_url('front/eventdetail/'.$lst['Slug']);?>">
                                       <h6><?php echo $lst['Title'];?>
                                       </h6>
                                    </a>
                                    <p><?php  if($lst['NoofDays']=='1'){
                                       $f=date("d-m-Y", strtotime($lst['OneDate']));
                                       }else{ 
                                       $f=date("d-m-Y", strtotime($lst['FromDate']));
                                                                                          $l=date("d-m-Y", strtotime($lst['ToDate']));
                                                                                          $dt=$f.' To '.$l;
                                       }
                                                           echo 'Date : '.$dt.'<br>'; echo 'Time '.$lst['TimeFrom'].' To '.$lst['TimeTo'];
                                                           echo '<br>Price : ₹ '.$lst['Price'];?>
                                    </p>
                                 </div>
                              </div>
                           </div>
                        </div>
                                                  <?php }
                                                }
                                                elseif($NoofDays > '1')
                                                {
                                                   if(strtotime($currentdt) < strtotime($fromdate) && strtotime($currentdt) < strtotime($todate))
                                                   { ?>
                                                       <div class="item <?php if($i=='1'){ echo 'active';} ?>">
                           <div class="single_says">
                              <div class="customer_comment">
                                 <p>
                                    <?php $big=$lst['Description'];
                                       $small = substr($big, 0, 110);
                                       echo  $small.'...'; ?>  
                                 </p>
                              </div>
                              <div class="customer_detail clearfix">
                                 <div class="customer_pic alignleft-20">
                                    <a href="<?php echo base_url('front/eventdetail/'.$lst['Slug']);?>">
                                    <img src="<?php echo base_url('assets/events/'.$lst['Image'])?>" alt="" class="smlcls">
                                    </a>
                                 </div>
                                 <div class="customer_identity floatleft">
                                    <a href="<?php echo base_url('front/eventdetail/'.$lst['Slug']);?>">
                                       <h6><?php echo $lst['Title'];?>
                                       </h6>
                                    </a>
                                    <p><?php  if($lst['NoofDays']=='1'){
                                       $f=date("d-m-Y", strtotime($lst['OneDate']));
                                       }else{ 
                                       $f=date("d-m-Y", strtotime($lst['FromDate']));
                                                                                          $l=date("d-m-Y", strtotime($lst['ToDate']));
                                                                                          $dt=$f.' To '.$l;
                                       }
                                                           echo 'Date : '.$dt.'<br>'; echo 'Time '.$lst['TimeFrom'].' To '.$lst['TimeTo'];
                                                           echo '<br>Price : ₹ '.$lst['Price'];?>
                                    </p>
                                 </div>
                              </div>
                           </div>
                        </div> 
                                                  <?php }
                                                }else{}       
                                                
                               ?>
                        
                        <?php } $i++; }
                           } ?>
                     </div>
                     <!-- Controls -->
                     <a class="slider_says left" href="#customer_says_slider" role="button" data-slide="prev">
                     <i class="fa fa-angle-left">
                     </i>
                     <span class="sr-only">Previous
                     </span>
                     </a>
                     <a class="slider_says right" href="#customer_says_slider" role="button" data-slide="next">
                     <i class="fa fa-angle-right">
                     </i>
                     <span class="sr-only">Next
                     </span>
                     </a>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- start contact us area -->
<!-- end contact us area -->
<style>
a.ticketcls.err {
    font-size: 16px;
}
a.ticketcls {
    color: #fff;
    font-size: 16px;
    font-weight: 700;
}
li.ulcamtbuton.succ {
    background: yellowgreen;
}
li.ulcamtbuton.err {
    background: #fe5d5d;
}
li.ulcamtbuton {
    text-align: center;
    color: #fff;
    padding: 9px;
    margin: 11px 0px;
    border-radius: 21px;
    width: 78%;
}
li.ulcamt {
    border-bottom: 3px solid;
}
.ulcamt {
    font-size: 17px;
    font-weight: 600;
    color: #000;
    text-align: center;
}
li.ulcdesc {
    border-bottom: 3px solid;height: 210px;    text-align: left;
}
.typediv {
    width: 100%;
    display: block;
}
li.ulctit {
   border-bottom: 2px solid;
    font-size: 19px;
    text-align: center;
    font-weight: 600;
    text-transform: capitalize;
    color: #000;

}
ul.ulc {    
      list-style: none;
    padding: 9px 11px;
    text-align: justify;
}
.boxevent {
    width: 30%;
    display: inline-table;
    border: 2px solid #ccc;
    padding: 6px;
    margin: 5px 9px;;
}
   img.smlcls {
   width: 27%;
   padding: 4px;
   height: 76px;
   border-radius: 49px;
   }
</style>
