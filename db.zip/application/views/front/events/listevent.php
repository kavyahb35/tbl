<?php $this->load->view('front/include/bootstraptable/header'); ?>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">  
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>    
	   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script> 
			

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<?php if(!empty($error)){ ?>
<script type="text/javascript">
   $(window).on('load',function(){
       $('#myModal').modal('show');
   });
</script>
<?php } ?>
<section class="breadcrumb_main_area margin-bottom-80">
   <div class="container-fluid">
      <div class="row">
         <div class="breadcrumb_main nice_title">
            <h2> Events
            </h2>
            <!-- special offer start -->
            <div class="special_offer_main">
               <div class="container">
                 
               </div>
            </div>
            <!-- end offer start -->
         </div>
      </div>
   </div>
</section>
<section class="contact_mail_area margin-bottom-90">
   <div class="container">
      <div class="row">
         <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
               <div class="x_title">
                  <h2 style="font-size:20px "> Events
                  </h2>
                  <button type="button" class="btn "  style="float:right;margin-bottom:10px;color:#63c2ea !important" data-toggle="modal" data-target="#myModal" >
                  <i class="fa fa-plus"> 
                  </i> Add Event  
                  </button>
                  <br>
                  <br>
                  <!------------------------------------>
                  <!-- Modal -->
                  <div class="modal fade" id="myModal" role="dialog">
                     <div class="modal-dialog">
                        <div class="modal-content">
                           <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal">&times;
                              </button>
                              <h4 class="modal-title" >Add Events
                              </h4>
                           </div>
                           <div class="modal-body">
                              <form name="eventfrm" id="eventfrm" method="post" action="<?php echo base_url("events/addevent");?>" class="form-horizontal form-label-left" novalidate enctype="multipart/form-data">
                                 <?php    if(!empty($error)){?>
                                 <div class="alert alert-danger  alert-dismissible">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                                    </a>
                                    <?php  echo $error;?>
                                 </div>
                                 <?php } ?>
                                 <div id="err" style="color:red">
                                 </div>
                                 <div id="err1" style="color:red">
                                 </div>
                                 
                                 
                                 
                                 <div class="form-group">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                       <input id="eventtitle" class="form-control col-md-12 col-xs-12" placeholder="Title" required="required" type="text" name="eventtitle" >
                                    </div>
                                 </div>
                                 
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                    <label>Event Type</label><br>
                                    <div class="m1">
                                   <?php if(!empty($listtypeevent)){
									       foreach($listtypeevent as $listevnt){
											      $title = $listevnt['Title']; ?>
											      <p class="m12">
											       <input required="required" type="checkbox" name="eventtype[]" value="<?php echo $listevnt['Id']?>" > <?php echo $title;?>
											       </p>
											  <?php }
									   } ?>
                                     </div>
                                    </div>
                                 </div>
                                 <div class="form-group">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                       <textarea class="form-control col-md-12 col-xs-12" placeholder="Description" name="description" id="description"></textarea>
                                    </div>
                                 </div>
                                 <div class="form-group">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                       <select class="form-control col-md-12 col-xs-12" id="days" name="days" onchange="divopenclose()">
                                          <option value="">--Select No. of Days--</option>
                                          <option value="1">1</option>
                                          <option value="many">Many</option>
                                       </select>
                                    </div>
                                 </div>
                                 <script>
                                    function divopenclose(){
                                      
                                        var c=$("#days option:selected").val();
                                        if(c=='1'){
                                            $("#maydays").hide();
                                             $("#onedays").show();
                                        }
                                        if(c=='many'){
                                            $("#maydays").show();
                                             $("#onedays").hide();
                                        }
                                    }
                                 </script>
                                 <div id="maydays" style="display:none">
                                    <div class="form-group">
                                       <div class="col-md-12 col-sm-12 col-xs-12">
                                          <input id="nooddays" class=" form-control col-md-12 col-xs-12" placeholder="No. of Days " required="required" type="text" name="nooddays" >
                                       </div>
                                    </div>
                                    <div class="form-froup">
                                       <div class="col-md-12 col-sm-12 col-sm-12">
                                          <div class="form-group col-lg-6 col-md-6 col-sm-6 xdisplay_inputx form-group has-feedback "> 
                                             <input type="text" class="form-control has-feedback-left" id="date"  placeholder="From Date" required="required" type="text" name="fromdate">
                                             <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
                                          </div>
                                          <div class="form-group col-lg-6 col-md-6 col-sm-6 icon_arrow2">
                                             <input type="text" class="form-control has-feedback-left" id="date1"  placeholder="To Date" required="required" type="text" name="todate">
                                             <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div id="onedays" style="display:none">
                                    <div class="form-group">
                                       <div class="col-md-12 col-sm-12 col-xs-12">
                                          <input type="text" class="form-control has-feedback-left" id="date2"   placeholder="Special Date" required="required" type="text" name="specialdate">
                                       </div>
                                    </div>
                                 </div>
                                 <div class="form-group">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                       <input type="file" name="uploadsfl" id="uploadsfl"  >
                                    </div>
                                 </div>
                                 <div class="form-froup">
                                    <div class="col-md-12 col-sm-12 col-sm-12">
                                       <div class="form-group col-lg-6 col-md-6 col-sm-6 icon_arrow1 ">
                                          <lable>From Time</lable>
                                          <input type="time" id="fromtime" class="form-control" type="text" name="fromtime" placeholder="Time From" required="required" >
                                       </div>
                                       <div class="form-group col-lg-6 col-md-6 col-sm-6 icon_arrow2">
                                          <lable>To Time</lable>
                                          <input type="time" id="totime" class="form-control" type="text" name="totime" placeholder="Time To" required="required" >
                                       </div>
                                    </div>
                                 </div>
                                 <!--<div class="form-group">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                       <input id="price" class="form-control col-md-12 col-xs-12" placeholder="Price" required="required" type="text" name="price" >
                                    </div>
                                 </div>-->
                                 <div class="ln_solid">
                                 </div>
                                 <div class="form-group">
                                    <div class="col-md-12 col-sm-12 col-xs-12 ">
                                       <button  class="btn btn-default" >Submit
                                       </button>
                                    </div>
                                 </div>
                              </form>
                              <script>
                                 $("#eventfrm").validate({
                                   rules: {
                                     eventtitle: "required",
                                     description: "required",
                                     price: "required",
                                   }
                                   ,
                                   messages: {
                                     eventtitle: "Please enter Title ",
                                     description: "Please enter description",
                                     price: "Please enter First Name",
                                   }
                                   ,
                                   submitHandler: function(form) {
                                     form.submit();
                                   }
                                 }
                                                            );
                              </script>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>  
         <script>
            $.noConflict();   
                $('#date').datepicker({
                    format: "yyyy-mm-dd",
                     startDate: new Date() 
                }); 
                 $('#date1').datepicker({
                    format: "yyyy-mm-dd",
                     startDate: new Date() 
                }); 
                 $('#date2').datepicker({
                    format: "yyyy-mm-dd",
                     startDate: new Date() 
                }); 
            
        </script> 
               <!------------------------------------------->
            </div>
            <div id="updatediv"></div>
            <div class="x_content">
               <table id="datatable-buttons"  class="table table-striped table-bordered" cellspacing="0" width="100%">
                  <thead>
                     <tr>
                        <th>Action                </th>
                        <th>Events              </th>
                        <th>Image                </th>
                        <th>No. of Days                </th>
                        <th>Date                </th>
                        <th>Time                 </th>
                       <!-- <th>Price                </th>-->
                     </tr>
                  </thead>
                  <tbody>
                     <?php if(!empty($listcategory)){
                        foreach($listcategory as $cat){ 
                        if($cat['Status']=='1'){ $s='Active';}else{ $s='Inactive';}
                        if($cat['NoofDays']=='1'){
                            $dt=$cat['OneDate'];
                        }else{ 
                        if($cat['FromDate']==$cat['ToDate']){
                        $dt=$cat['ToDate'];
                        }
                        elseif($cat['FromDate']!='' && $cat['ToDate']!=''){
                        $dt=$cat['FromDate'].' To '.$cat['ToDate'];
                        }
                        elseif($cat['FromDate']!='' && $cat['ToDate']==''){
                        $dt=$cat['FromDate'];
                        }elseif($cat['FromDate']=='' && $cat['ToDate']!=''){
                        $dt=$cat['ToDate'];
                        }
                        
                        elseif($cat['FromDate']=='' && $cat['ToDate']==''){
                        $dt='';
                        }
                        }
                        $img = $cat['Image'];
                        if($img!=''){
                            $b=base_url('assets/events/'.$img);
                            $sdq="<img src='".$b."' width='100%' >";
                        }else{
                             $b=base_url('assets/fronttheme/customcss/dummyimg.jpg');
                        $sdq="<img src='".$b."' width='100%' >";
                        }
                        ?>
                     <tr>
                        <td>
                         <a  class="btn btn-success pad-30" style="margin:3px 0px" data-toggle="tooltip" title="View Tickets"  href="<?php echo base_url('events/viewticketsevent/'.$cat['Slug'])?>">
                           <i class="fa fa-eye"> 
                           </i>  
                           </a> 
                           <a  class="btn pad-30" style="margin:3px 0px" data-toggle="tooltip" title="Edit"  href="<?php echo base_url('events/editevent/'.$cat['Slug'])?>">
                           <i class="fa fa-edit"> 
                           </i>  
                           </a> 
                           <a  class="btn btn-warning pad-30" style="margin:3px 0px;" data-toggle="tooltip" title="Delete" onclick="deletecategory('<?php echo $cat['Id']?>')">
                           <i class="fa fa-trash"> 
                           </i>  
                           </a> 
                        </td>
                        <td>
                           <?php echo  $cat['Title'];?>
                        </td>
                        <td>
                           <?php echo  $sdq;?>
                        </td>
                        <td>
                           <?php echo $cat['NoofDays'];?>
                        </td>
                        <td>
                           <?php echo $dt;?>
                        </td>
                        <td>
                           <?php
                              if($cat['TimeFrom']==$cat['TimeTo']){
                              echo $dt=$cat['TimeFrom'];
                              }
                              elseif($cat['TimeFrom']!='' && $cat['TimeTo']!=''){
                              echo $dt=$cat['TimeFrom'].' To '.$cat['TimeTo'];
                              }
                              elseif($cat['TimeFrom']!='' && $cat['TimeTo']==''){
                              echo $dt=$cat['TimeFrom'];
                              }elseif($cat['TimeFrom']=='' && $cat['TimeTo']!=''){
                              echo $dt=$cat['TimeTo'];
                              }elseif($cat['TimeFrom']=='' && $cat['TimeTo']==''){
                              echo $dt='';
                              }
                              
                              // echo $cat['TimeFrom'].' To '.$cat['TimeTo'];?>
                        </td>
                        <!--<td>
                           <?php //echo $cat['Price'].' QAR';?>
                        </td>-->
                     </tr>
                     <?php }
                        } ?>
                  </tbody>
               </table>
               <div class="row">
                  <nav class="text-center margin-top-65 margin-bottom-75">
                     <ul class="pagination">
                        <?php echo $links; ?>
                     </ul>
                  </nav>
               </div>
               <script>
                  function deletecategory(id){
                    var r = confirm("Are You sure want to Delete this Record?");
                    var url="<?php echo base_url('events/deleteevent');?>";
                    if (r == true) {
                      $.ajax({
                        type: 'post',
                        url: url,
                        data: "id="+id,
                        success: function () {
                          alert('Delete Event Successfully');
                          location.reload();
                        }
                      }
                            );
                    }
                  }
                  function updatecategory(id){
                    var url="<?php echo base_url('events/updateeventfrom');?>";
                    $.ajax({
                      type: 'post',
                      dataType : 'json',
                      url: url,
                      data: "id="+id,
                      success: function (data) {
                          alert(data);
                        $("#updatediv").html(data);
                        $('#myModal2').modal('show');
                      }
                    }
                          );
                  }
               </script>	
            </div>
         </div>
      </div>
   </div>
   </div>
   </div>
</section>
<script>
   function editcategory(){
     var s=$("#cattitle1 option:selected").val();
     var itemtitle1=$("#itemtitle1").val();
     var itemid=$("#itemid").val();
     var price1=$("#price1").val();
     var catstatus=$().val("#catstatus option:selected");
     var url="<?php echo base_url('food/edititem');?>";
     if(s=='' || itemtitle1=='' || price1==''){
       $("#err3").html("Please item title required");
     }
     else{
       $.ajax({
         type: 'post',
         dataType : 'json',
         url: url,
         data: "category="+s+"&itemtitle1="+itemtitle1+"&price1="+price1+"&itemid="+itemid+"&catstatus="+catstatus,
         success: function (data) {
           if(data=='1'){
             alert('Item successfully Update.');
             location.reload();
           }
           if(data=='2'){
             $('#err2').html('Item already Exist.');
           }
         }
       }
             );
     }
   }
</script>
<style>
td.day.disabled {
    background: #eaeaea !important;
}
.m12 {
    width: 31% !important;
    display: inline-block;
}
.m1 {
    width: 100%;
    display: block;
}
   .alert-danger p {
   color: #a94442;
   }
</style>
<?php $this->load->view('front/include/bootstraptable/footer');?>
