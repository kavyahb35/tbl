 <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">  
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>    
	   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script> 
			

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<!-- start breadcrumb -->
<section class="breadcrumb_main_area margin-bottom-80">
  <div class="container-fluid">
    <div class="row">
      <div class="breadcrumb_main nice_title">
        <h2>Event Edit
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
           
          </div>
        </div>         
        <!-- end offer start -->
      </div>
    </div>
  </div>            
</section>
<!-- end breadcrunb -->
<!-- start other detect room section -->
<section class="booking_area">
  <div class="container">
    <div class="booking">
      <div role="tabpanel">
        <!-- Nav tabs -->
       
        <!-- Tab panes -->
        <div class="row">
          <!-------------------------------------------->
           <div class="col-md-2"></div>
          <div class="col-md-8" >
            <div class="facilities_name clearfix">
              <div class="row">
                <?php    if(!empty($error)){?>
                <div class="alert alert-danger  alert-dismissible">
                  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                  </a>
                  <?php  echo $error;?>
                </div>
                <?php } ?>
                <form name="eventfrm" id="eventfrm" method="post" action="<?php echo base_url("events/editevent/".$eventdetails[0]['Slug']);?>" class="form-horizontal form-label-left" novalidate enctype="multipart/form-data">
                      <div id="err" style="color:red">
                      </div>
                      <div id="err1" style="color:red">
                      </div>
                   
                        <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                          <input id="eventtitle" class="form-control col-md-12 col-xs-12" placeholder="Title" required="required" type="text" name="eventtitle" value="<?php echo $eventdetails[0]['Title']?>">
                        </div>
                      </div>
                         <div class="form-group">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                    <label>Event Type</label><br>
                                    <div class="m1"><?php $evntyp = $eventdetails[0]['eventtype'];
                                    $ty = explode(',',$evntyp);
                                    ?>
                                   <?php if(!empty($listtypeevent)){
									       foreach($listtypeevent as $listevnt){
											      $title = $listevnt['Title']; ?>
											      <p class="m12">
											       <input required="required" type="checkbox" name="eventtype[]" value="<?php echo $listevnt['Id']?>" <?php if(in_array($listevnt['Id'],$ty)){ echo 'checked';}?> > <?php echo $title;?>
											       </p>
											  <?php }
									   } ?>
                                     </div>
                                    </div>
                                 </div>
                        <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                          <textarea class="form-control col-md-12 col-xs-12" placeholder="Description" name="description" id="description"><?php echo $eventdetails[0]['Description']?></textarea>
                        </div>
                      </div>
                         <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <select class="form-control col-md-12 col-xs-12" id="days" name="days" onchange="divopenclose()">
                                <option value="1" <?php if($eventdetails[0]['NoofDays']=='1'){ echo 'selected=selected';}?>>1</option>
                                <option value="many" <?php if($eventdetails[0]['NoofDays']!='1'){ echo 'selected=selected';}?>>Many</option>
                                
                            </select> 
                        </div>
                         </div>
                      <script>
                          function divopenclose(){
                            
                              var c=$("#days option:selected").val();
                              if(c=='1'){
                                  $("#maydays").hide();
                                   $("#onedays").show();
                              }
                              if(c=='many'){
                                  $("#maydays").show();
                                   $("#onedays").hide();
                              }
                          }
                      </script>
                        
                        <div id="maydays" <?php if($eventdetails[0]['OneDate'] ==''){ echo 'style="display:block"'; }else{ echo 'style="display:none"'; }?>   >
                            <div class="form-group">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                   <input id="nooddays" class=" form-control col-md-12 col-xs-12" placeholder="No. of Days "  type="text" name="nooddays" value="<?php echo $eventdetails[0]['NoofDays']?>">
                                </div>
                            </div>
                             <div class="form-froup">
                            <div class="col-md-12 col-sm-12 col-sm-12">
                                <div class="form-group col-lg-6 col-md-6 col-sm-6  ">                            
                                    <input id="date" class=" form-control col-md-12 col-xs-12" placeholder="From Date" type="text" name="fromdate" value="<?php echo $eventdetails[0]['FromDate']?>">
                               </div> 
                          <div class="form-group col-lg-6 col-md-6 col-sm-6 ">
                               <input id="date1" class=" form-control col-md-12 col-xs-12" placeholder="To Date"  type="text" name="todate" value="<?php echo $eventdetails[0]['ToDate']?>">
                              </div>
                            </div>
                        </div>
                           
                        </div>
                        
                        <div id="onedays" <?php if($eventdetails[0]['OneDate'] ==''){ echo 'style="display:none"'; }?>  >
                             <div class="form-group">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <input id="date2" class=" form-control col-md-12 col-xs-12" placeholder="Special Date" type="text" name="specialdate" value="<?php echo $eventdetails[0]['OneDate']?>">
                                </div>
                              </div>
                        </div>
                        
                        
                         <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <input type="file" name="uploadsfl" id="uploadsfl"  >
                            <?php if($eventdetails[0]['Image']!=''){ ?>
                            <img src="<?php echo base_url('assets/events/'.$eventdetails[0]['Image']);?>" width="30%">
                            <input type="hidden" name="oldimg" value="<?php echo $eventdetails[0]['Image'];?>">
                            <?php }?>
                        </div>
                      </div>
                        <div class="form-froup">
                            <div class="col-md-12 col-sm-12 col-sm-12">
                                <div class="form-group col-lg-6 col-md-6 col-sm-6 icon_arrow1 ">  
                                    <lable>From Time</lable>
                                    <input type="time" id="fromtime" class="form-control" type="text" name="fromtime" placeholder="Time From" required="required" value="<?php echo $eventdetails[0]['TimeFrom']?>">
                                </div> 
                          <div class="form-group col-lg-6 col-md-6 col-sm-6 icon_arrow2"><lable>To Time</lable>
                                <input type="time" id="totime" class="form-control" type="text" name="totime" placeholder="Time To" required="required" value="<?php echo $eventdetails[0]['TimeTo']?>">
                           </div>
                            </div>
                        </div>
                      
                      <!--<div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                          <input id="price" class="form-control col-md-12 col-xs-12" placeholder="Price" required="required" type="text" name="price" value="<?php echo $eventdetails[0]['Price']?>">
                        </div>
                      </div>-->
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <select class="form-control" name="status" >
                                <option value="1" <?php if($eventdetails[0]['Status']=='1'){ echo 'selected=selected';}?>>Active</option>
                                <option value="0" <?php if($eventdetails[0]['Status']=='0'){ echo 'selected=selected';}?>>Inactive</option>
                            </select>
                        </div>
                      </div>
                      <div class="ln_solid">
                      </div>
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12 ">
                          <button  class="btn btn-info" >Submit
                          </button>
                            
                        </div>
                      </div>
                    </form>
              </div>
                <div class="col-md-2"></div>
                
                
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<script>
            $.noConflict();   
                $('#date').datepicker({
                    format: "yyyy-mm-dd",
                     startDate: new Date() 
                }); 
                 $('#date1').datepicker({
                    format: "yyyy-mm-dd",
                     startDate: new Date() 
                }); 
                 $('#date2').datepicker({
                    format: "yyyy-mm-dd",
                     startDate: new Date() 
                }); 
            
        </script> 
<!-- end other detect room section -->
<!-- start contact us area -->
<!-- end contact us area -->
<style>

.m12 {
    width: 31% !important;
    display: inline-block;
}
.m1 {
    width: 100%;
    display: block;
}
	td.day.disabled {
		background: #eaeaea !important;
	}
		 .form-group.col-lg-6.col-md-6.col-sm-6.icon_arrow1 {
		margin-right: 33px;
	}
    .input-group {
  position: static;
  display: unset;
  border-collapse: separate;
  }
  label.error {
    color: red;
    font-size: 12px;
    font-weight: 300;
  }
  .alert {
    text-align: left;
    padding-left: 26px;
  }
  a.close {
    padding-right: 14px;
  }
  .cls {
    font-size: 53px;
    color: steelblue;
    text-align: center;
  }
  .titclub {
    font-size: 21px;
    color: red;
    text-align: center;
  }
  div#nmp {
    border: 1px solid steelblue;
    border-radius: 6px;
    margin: 1%;
    padding: 15px;
  }
</style>
