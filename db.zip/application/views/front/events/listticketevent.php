<?php $this->load->view('front/include/bootstraptable/header'); ?>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">  
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>    
	   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script> 
			

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<?php if(!empty($error)){ ?>
<script type="text/javascript">
   $(window).on('load',function(){
       $('#myModal').modal('show');
   });
</script>
<?php } ?>
<section class="breadcrumb_main_area margin-bottom-80">
   <div class="container-fluid">
      <div class="row">
         <div class="breadcrumb_main nice_title">
            <h2> Event Tickets Manage
            </h2>
            <!-- special offer start -->
            <div class="special_offer_main">
               <div class="container">
                 
               </div>
            </div>
            <!-- end offer start -->
         </div>
      </div>
   </div>
</section>
<section class="contact_mail_area margin-bottom-90">
   <div class="container">
      <div class="row">
         <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
               <div class="x_title">
                  <h2 style="font-size:20px ">Event Tickets Manage  
                  </h2>
                 
                 
            </div>
            <div id="updatediv"></div>
            <div class="x_content">
               <table id="datatable-buttons"  class="table table-striped table-bordered" cellspacing="0" width="100%">
                  <thead>
                     <tr>
                      
                        <th>Events Name              </th>
                        <th>Event Type                </th>
                        <th>Ticket Price               </th>
                        <th>No. of Ticket                </th>
                        <th>Available Ticket                </th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php if(!empty($listcompleteticket)){
                        foreach($listcompleteticket as $cat){ 
						 $eventdetails = $this->App->getPerticularRecord('tbl_events', 'Id', $cat['EventId']);   
							 $eventtitle = $eventdetails[0]['Title'];   
							 $eventtypedetails = $this->App->getPerticularRecord('tbl_event_type', 'Id', $cat['EventTypeId']);   
							 $eventtypetitle = $eventtypedetails[0]['Title'];   
							$eventtypeamt = $eventtypedetails[0]['Amount'];  
                        
                        ?>
                     <tr>
                        
                        <td>
                           <?php echo  $eventtitle;?>
                        </td>
                        <td>
                           <?php echo  $eventtypetitle;?>
                        </td>
                        <td>
                           <?php echo $eventtypeamt.' QAR';?>
                        </td>
                         <td>
                           <?php echo  $cat['NoofTicket'];?>
                        </td>
                         <td>
                           <?php $t =$cat['NoofTicket']-$cat['UsedTicket'];
                           if($t > 0 ){ echo $t;}else{ echo '0';}
                           ?>
                        </td>
                        
                        <!--<td>
                           <?php //echo $cat['Price'].' QAR';?>
                        </td>-->
                     </tr>
                     <?php }
                        } ?>
                  </tbody>
               </table>
               <div class="row">
                  <nav class="text-center margin-top-65 margin-bottom-75">
                     <ul class="pagination">
                        <?php echo $links; ?>
                     </ul>
                  </nav>
               </div>
               <script>
                  function deletecategory(id){
                    var r = confirm("Are You sure want to Delete this Record?");
                    var url="<?php echo base_url('events/deleteevent');?>";
                    if (r == true) {
                      $.ajax({
                        type: 'post',
                        url: url,
                        data: "id="+id,
                        success: function () {
                          alert('Delete Event Successfully');
                          location.reload();
                        }
                      }
                            );
                    }
                  }
                  function updatecategory(id){
                    var url="<?php echo base_url('events/updateeventfrom');?>";
                    $.ajax({
                      type: 'post',
                      dataType : 'json',
                      url: url,
                      data: "id="+id,
                      success: function (data) {
                          alert(data);
                        $("#updatediv").html(data);
                        $('#myModal2').modal('show');
                      }
                    }
                          );
                  }
               </script>	
            </div>
         </div>
      </div>
   </div>
   </div>
   </div>
</section>
<script>
   function editcategory(){
     var s=$("#cattitle1 option:selected").val();
     var itemtitle1=$("#itemtitle1").val();
     var itemid=$("#itemid").val();
     var price1=$("#price1").val();
     var catstatus=$().val("#catstatus option:selected");
     var url="<?php echo base_url('food/edititem');?>";
     if(s=='' || itemtitle1=='' || price1==''){
       $("#err3").html("Please item title required");
     }
     else{
       $.ajax({
         type: 'post',
         dataType : 'json',
         url: url,
         data: "category="+s+"&itemtitle1="+itemtitle1+"&price1="+price1+"&itemid="+itemid+"&catstatus="+catstatus,
         success: function (data) {
           if(data=='1'){
             alert('Item successfully Update.');
             location.reload();
           }
           if(data=='2'){
             $('#err2').html('Item already Exist.');
           }
         }
       }
             );
     }
   }
</script>
<style>
td.day.disabled {
    background: #eaeaea !important;
}
.m12 {
    width: 31% !important;
    display: inline-block;
}
.m1 {
    width: 100%;
    display: block;
}
   .alert-danger p {
   color: #a94442;
   }
</style>
<?php $this->load->view('front/include/bootstraptable/footer');?>
