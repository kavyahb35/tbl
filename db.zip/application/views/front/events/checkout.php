<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript">
</script>
<section class="breadcrumb_main_area ">
  <div class="container-fluid">
    <div class="row">
      <div class="breadcrumb_main nice_title">
        <h2>Check out
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
           
          </div>
        </div>         
        <!-- end offer start -->
      </div>
    </div>
  </div>            
</section>
<section class="booking_area nobito">
<div class="container"> 
<div class="row">

	<diV class="col-md-6 col-sm-12 col-xs-12 col-lg-6 boc"> 
		 <div class="col-md-12 col-sm-12 col-xs-12 col-lg-12 bocx">
			<?php $eventdetails= $this->App->getPerticularRecord('tbl_events', 'Id', $evnetid);
			 $img=$eventdetails[0]['Image'];
                        $Description=$layout[0]['Description'];
                        if($img!=''){
                        $i=base_url('assets/events/'.$img);
                        }else{
                        $i=base_url('assets/fronttheme/banner/TableFast-Banner-2.jpg');
					}
                         if($eventdetails[0]['NoofDays']=='1'){
                        
                        $dt=date("d-m-Y", strtotime($eventdetails[0]['OneDate']));
                        }else{
                        $f=date("d-m-Y", strtotime($eventdetails[0]['FromDate']));
                        $l=date("d-m-Y", strtotime($eventdetails[0]['ToDate']));
                        $dt=$f.' To '.$l;
                        
                        }
                        echo '<h5>'.$eventdetails[0]['Title'].'</h5>';
                        echo '<div class="burger">';
                        echo '<p><img src="'.$i.'" width="20%"></p>';
                        echo '<p>Date : '.$dt.' '; echo $eventdetails[0]['TimeFrom'].' To '.$eventdetails[0]['TimeTo'].'</p>';
                        echo '</div>';
                        $eventtypedetails= $this->App->getPerticularRecord('tbl_event_type', 'Id', $typeid);
                        echo '<p>'.$eventtypedetails[0]['Title'].'</p>';
                         echo '<p>'.$eventtypedetails[0]['Amount'].' QAR </p>';
                        
                        
                        
                         ?>
		 </div>
	</diV>



	<diV class="col-md-6 col-sm-12 col-xs-12 col-lg-6 ">
	<div class="row"><?php 
	$r = $this->db->query("select * from tbl_event_ticket_update where ClubId='".$vendorid."' and EventId='".$evnetid."' and EventTypeId='".$typeid."'");
	
		$noresult = $r->result_array();
		$tottic = $noresult[0]['NoofTicket'];
		$UsedTicket = $noresult[0]['UsedTicket'];
		$availableticket =  $tottic-$UsedTicket;
		if($availableticket > 0){
			$ava = $availableticket;
		}else {
			$ava = '0';
		}
		
	?>
	
	</div>
	<div class="row bkl">
	    <div class="col-md-12 col-sm-12 col-xs-12 col-lg-12 "><p class="totticket"> No. of Available Tickets : <?php echo $ava;?></p></div>
		<div class="col-md-6 col-sm-12 col-xs-12 col-lg-6 ">
			<div id="totamt">Total Amount : <?php echo $eventtypedetails[0]['Amount'].' QAR '; ?></div>
		</div>
		<div class="col-md-6 col-sm-12 col-xs-12 col-lg-6">
			<a class="btn btn-detault" onclick="openform()" id="formids"> Buy Now</a>
		</div>
	</div>
	
	<div class="row">
	
	<div class="col-md-4 col-sm-12 col-xs-12 col-lg-4">
	<label>Amount</label>
	<p><?php 	   echo '<p style="      margin-top: -8%;">'.$eventtypedetails[0]['Amount'].' QAR </p>';?></p>
	</div>
	    <div class="col-md-4 col-sm-12 col-xs-12 col-lg-4">
	    
	    
	    <label> Qty</label>
	       <select name="noofticker" id="noofticker" class="form-control">
          <?php for($i=1;$i<50;$i++) { ?>
            <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
          <?php } ?>
        </select>
	    </div>
	
	<div class="col-md-4 col-sm-12 col-xs-12 col-lg-4">
	    <a class="btn btn-detault" onclick="updatefunction('<?php echo $eventtypedetails[0]['Amount'];?>')" style="    margin-top: 17%;"> Update</a>
	</div>
	
	</div>
	
	</diV>
</div>


<div class="row">
 <div id="bycard" style="display:none">
	<form class="form-horizontal" target="paypal" action="" method="post" target="paypal" id="paypal_form" class="hidden">
	
	
  <fieldset id="payment">
  <input type="hidden" value="<?php echo $vendorid; ?>" name="vendorid">
	<input type="hidden" value="<?php echo $typeid; ?>" name="typeid">
	<input type="hidden" value="<?php echo $evnetid; ?>" name="evnetid">
	<input type="hidden" value="<?php echo $eventtypedetails[0]['Amount'];?>" name="defaultamt">
	<div id="totamtinput"></div>
    <legend><br><?php echo $text_credit_card; ?></legend>
    <div class="form-group required">
      <label class="col-md-6 col-sm-12  col-xs-12 col-lg-6 control-label" for="input-cc-type"><?php echo $entry_cc_type; ?></label>
      <div class="col-md-6 col-sm-12  col-xs-12 col-lg-6">
        <select name="cc_type" id="input-cc-type" class="form-control">
          <?php foreach ($cards as $card) { ?>
            <option value="<?php echo $card['value']; ?>"><?php echo $card['text']; ?></option>
          <?php } ?>
        </select>
      </div>
    </div>
    <div class="form-group required">
      <label class="col-md-6 col-sm-12  col-xs-12 col-lg-6 control-label" for="input-cc-number"><?php echo $entry_cc_number; ?></label>
      <div class="col-md-6 col-sm-12  col-xs-12 col-lg-6">
        <input type="text" name="cc_number" value="" placeholder="<?php echo $entry_cc_number; ?>" id="input-cc-number" class="form-control" />
      </div>
    </div>
    <div class="form-group">
      <label class="col-md-6 col-sm-12  col-xs-12 col-lg-6 control-label" for="input-cc-start-date"><span data-toggle="tooltip" title="<?php echo $help_start_date; ?>"><?php echo $entry_cc_start_date; ?></span></label>
      <div class="col-md-3 col-sm-6  col-xs-6 col-lg-3">
        <select name="cc_start_date_month" id="input-cc-start-date" class="form-control">
          <?php foreach ($months as $month) { ?>
          <option value="<?php echo $month['value']; ?>"><?php echo $month['text']; ?></option>
          <?php } ?>
        </select>
      </div>
      <div class="col-md-3 col-sm-6  col-xs-6 col-lg-3">
        <select name="cc_start_date_year" class="form-control">
          <?php foreach ($year_valid as $year) { ?>
          <option value="<?php echo $year['value']; ?>"><?php echo $year['text']; ?></option>
          <?php } ?>
        </select>
      </div>
    </div>
    <div class="form-group required">
      <label class="col-md-6 col-sm-12  col-xs-12 col-lg-6 control-label" for="input-cc-expire-date"><?php echo $entry_cc_expire_date; ?></label>
      <div class="col-md-3 col-sm-6  col-xs-6 col-lg-3">
        <select name="cc_expire_date_month" id="input-cc-expire-date" class="form-control">
          <?php foreach ($months as $month) { ?>
          <option value="<?php echo $month['value']; ?>"><?php echo $month['text']; ?></option>
          <?php } ?>
        </select>
      </div>
      <div class="col-md-3 col-sm-6  col-xs-6 col-lg-3">
        <select name="cc_expire_date_year" class="form-control">
          <?php foreach ($year_expire as $year) { ?>
          <option value="<?php echo $year['value']; ?>"><?php echo $year['text']; ?></option>
          <?php } ?>
        </select>
      </div>
    </div>
    <div class="form-group required">
      <label class="col-md-6 col-sm-12  col-xs-12 col-lg-6 control-label" for="input-cc-cvv2"><?php echo $entry_cc_cvv2; ?></label>
      <div class="col-md-6 col-sm-12  col-xs-12 col-lg-6">
        <input type="text" name="cc_cvv2" value="" placeholder="<?php echo $entry_cc_cvv2; ?>" id="input-cc-cvv2" class="form-control" />
      </div>
    </div>
    <div class="form-group">
      <label class="col-md-6 col-sm-12  col-xs-12 col-lg-6 control-label" for="input-cc-issue"><span data-toggle="tooltip" title="<?php echo $help_issue; ?>"><?php echo $entry_cc_issue; ?></span></label>
      <div class="col-md-6 col-sm-12  col-xs-12 col-lg-6">
        <input type="text" name="cc_issue" value="" placeholder="<?php echo $entry_cc_issue; ?>" id="input-cc-issue" class="form-control" />
      </div>
    </div>
  
  <div class="buttons">
  <div class="pull-right">
     <input type="button" value="submit" id="button-confirm" class="btn btn-default" />
  
  </div>
</div>


  </fieldset>
  

</form>

 </div>
 
	
</div>

<script type="text/javascript">
 $('#button-confirm').bind('click', function() {
	$.ajax({
		url: "<?php echo base_url('events/sendrecurring');?>",
		dataType: 'json',
		type: 'post',
		data: $('#payment :input'),
				
		beforeSend: function() {
			$('#button-confirm').attr('disabled', true);
			$('#payment').before('<div class="attention" style="color:orange;text-align:center"><img src="catalog/view/theme/default/image/loading.gif" alt="" /> <?php echo $text_wait; ?></div>');
		},
		complete: function() {
			$('#button-confirm').attr('disabled', false);
			$('.attention').remove();
		},				
		success: function(json) {
			if(json.succ=='1'){
				
			 window.location.href="<?php echo base_url('events/successPayment/');?>"+json.success;	
			}if(json.err=='2'){
				alert(json.error);
			}

			
		}
	});
});
</script> 
  <script>
     function updatefunction(amt)
     {
		 var v = $("#noofticker option:selected").val();
		 var n = v * amt;
		 $("#totamt").html('Total Amount : '+n +' QAR');
		 $("#totamtinput").html('<input type="hidden" name="totamt" value="'+n+'">');
	 }
	 function openform()
	 {
		 $("#formids").hide();
		 $("#bycard").show();
	  }
	 
  </script>




 </div>
          
</section>
<style>
.row.bkl {
    margin: 0% 0% 0% 0%;
    border: 1px solid #ccc;
    padding: 3%;
}
.col-md-6.col-sm-12.col-xs-12.col-lg-6.boc {
    border: 1px solid #ccc;
    padding: 14px;
}</style> 
