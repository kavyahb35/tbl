<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript">
</script>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js">
</script>
<!-- start breadcrumb -->
<section class="breadcrumb_main_area margin-bottom-80">
  <div class="container-fluid">
    <div class="row">
      <div class="breadcrumb_main nice_title">
        <h2>Event Edit Type
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
           
          </div>
        </div>         
        <!-- end offer start -->
      </div>
    </div>
  </div>            
</section>
<!-- end breadcrunb -->
<!-- start other detect room section -->
<section class="booking_area">
  <div class="container">
    <div class="booking">
      <div role="tabpanel">
        <!-- Nav tabs -->
       
        <!-- Tab panes -->
        <div class="row">
          <!-------------------------------------------->
           <div class="col-md-2"></div>
          <div class="col-md-8" >
            <div class="facilities_name clearfix">
              <div class="row">
                <?php    if(!empty($error)){?>
                <div class="alert alert-danger  alert-dismissible">
                  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                  </a>
                  <?php  echo $error;?>
                </div>
                <?php } ?>
                <form name="eventfrm" id="eventfrm" method="post" action="<?php echo base_url("events/editeventtype/".$eventdetails[0]['Id']);?>" class="form-horizontal form-label-left" novalidate >
                      <div id="err" style="color:red">
                      </div>
                      <div id="err1" style="color:red">
                      </div>
                        <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                          <input id="eventtitle" class="form-control col-md-12 col-xs-12" placeholder="Title" required="required" type="text" name="eventtitle" value="<?php echo $eventdetails[0]['Title']?>">
                        </div>
                      </div>
                        <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                          <textarea class="form-control col-md-12 col-xs-12" placeholder="Description" name="description" id="description"><?php echo $eventdetails[0]['ShortDescription']?></textarea>
                        </div>
                      </div>
                         
                         <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                          <input id="price" class="form-control col-md-12 col-xs-12" placeholder="Price" required="required" type="text" name="price" value="<?php echo $eventdetails[0]['Amount']?>">
                        </div>
                      </div>
                         <div class="form-group">
							<div class="col-md-12 col-sm-12 col-xs-12">
							   <input id="price" class="form-control col-md-12 col-xs-12" placeholder="No. of Event Tickets" required="required" type="text" name="notickets" value="<?php echo $eventdetails[0]['NoofTickets'];?>" >
							</div>
						 </div>
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <select class="form-control" name="status" >
                                <option value="1" <?php if($eventdetails[0]['Status']=='1'){ echo 'selected=selected';}?>>Active</option>
                                <option value="0" <?php if($eventdetails[0]['Status']=='0'){ echo 'selected=selected';}?>>Inactive</option>
                            </select>
                        </div>
                      </div>
                      <div class="ln_solid">
                      </div>
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12 ">
                          <button  class="btn btn-info" >Submit
                          </button>
                            
                        </div>
                      </div>
                    </form>
              </div>
                <div class="col-md-2"></div>
                
                
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- end other detect room section -->
<!-- start contact us area -->
<!-- end contact us area -->
<style>
     .form-group.col-lg-6.col-md-6.col-sm-6.icon_arrow1 {
    margin-right: 33px;
}
    .input-group {
  position: static;
  display: unset;
  border-collapse: separate;
  }
  label.error {
    color: red;
    font-size: 12px;
    font-weight: 300;
  }
  .alert {
    text-align: left;
    padding-left: 26px;
  }
  a.close {
    padding-right: 14px;
  }
  .cls {
    font-size: 53px;
    color: steelblue;
    text-align: center;
  }
  .titclub {
    font-size: 21px;
    color: red;
    text-align: center;
  }
  div#nmp {
    border: 1px solid steelblue;
    border-radius: 6px;
    margin: 1%;
    padding: 15px;
  }
</style>
