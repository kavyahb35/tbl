<!-- end header -->
<link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>     
<style></style>
<!-- start main slider -->
<div class="main_slider_area">
   <div class="container-fluid">
      <div class="row">
         <div class="main_slider" id="slider_rev">
            <!-- special offer start -->
            
            <!-- end offer start -->
            <div class="fullwidthbanner-container" >
               <div class="fullwidth_home_two_banner">
                  <ul>
                     
                     <?php if(!empty($Allbanner)){ 
                        foreach($Allbanner as $banner){ ?>
                     <?php if($banner['BannerImage']!=''){
                        if (file_exists(FCPATH.'assets/fronttheme/banner/'.$banner['BannerImage'])){ ?>
                     <li data-transition="random" data-slotamount="7" data-masterspeed="1000">
                        <img src="<?php echo base_url('assets/fronttheme/banner/'.$banner['BannerImage'])?>" alt="slide" >
                       
                     </li>
                     <?php   }
                        } ?>
                     <?php } }else{ ?>
                     <li data-transition="random" data-slotamount="7" data-masterspeed="1000">
                        <img src="<?php echo base_url('assets/fronttheme/banner')?>/TableFast-Banner-1.jpg" alt="slide" >
                        
                     </li>
                     <?php } ?>
                  </ul>
               </div>
            </div>
            <!-- start hotel booking -->
            <!---Search functionality----------------->
            <div class="hotel_booking_area">
               <div class="container">
                  <div class="hotel_booking">
                     <form id="form1" role="form" action="<?php echo base_url('search');?>" method="post">
                        <div class="col-lg-2 col-md-2 col-sm-2">
                           <div class="room_book border-right-dark-1">
                              <h6>Book Your
                              </h6>
                              <p>Tables
                              </p>
                           </div>
                        </div>
                        <div class="form-group col-lg-4 col-md-4 col-sm-4">
                           <div class="input-group border-bottom-dark-2">
                              <input class="form-control" type="text" name="clubname" id="clubname" required placeholder="ClubName or Address" onkeyup="showResult(this.value)"/>
                              <div class="input-group-addon">
                                 <i class="fa fa-map-marker">
                                 </i>
                              </div>
                           </div>
                           <div id="kpl">
                           </div>
                        </div>
                        <script>
                           function showResult(val){
                             var url="<?php echo base_url('front/autosearch');?>";
                             $.ajax({
                               type: 'post',
                               dataType : 'json',
                               url: url,
                               data: "category="+val,
                               success: function (data) {
                                 $("#kpl").html(data);
                               }
                             }
                                   );
                           }
                        </script>
                        <div class="form-group col-lg-2 col-md-2 col-sm-2">
                           <div class="input-group border-bottom-dark-2">
                              <input class="date-picker" id="datepicker" name="bookdata" placeholder="Arrival" type="text">
                              <div class="input-group-addon">
                                 <i class="fa fa-calendar">
                                 </i>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4">
                           <div class="row">
                              <div class="form-group col-lg-4 col-md-4 col-sm-4 icon_arrow">
                                 <div class="input-group border-bottom-dark-2">
                                    <select class="form-control" name="adult" id="adult">
                                       <option selected="selected" disabled="disabled">1 Adult
                                       </option>
                                       <option value="1">1 Adult
                                       </option>
                                       <option value="2">2 Adult
                                       </option>
                                       <option value="3">3 Adult
                                       </option>
                                       <option value="4">4 Adult
                                       </option>
                                       <option value="5">5 Adult
                                       </option>
                                       <option value="6">6 Adult
                                       </option>
                                       <option value="7">7 Adult
                                       </option>
                                       <option value="8">8 Adult
                                       </option>
                                       <option value="9">9 Adult
                                       </option>
                                       <option value="10">10 Adult
                                       </option>
                                       <option value="11">11 Adult
                                       </option>
                                       <option value="12">12 Adult
                                       </option>
                                       <option value="13">13 Adult
                                       </option>
                                       <option value="14">14 Adult
                                       </option>
                                       <option value="15">15 Adult
                                       </option>
                                       <option value="16">16 Adult
                                       </option>
                                       <option value="17">17 Adult
                                       </option>
                                       <option value="18">18 Adult
                                       </option>
                                       <option value="19">19 Adult
                                       </option>
                                       <option value="20">20 Adult
                                       </option>
                                       <option value="many">Many
                                       </option>
                                    </select>
                                 </div>
                              </div>
                              <div class="form-group col-lg-4 col-md-4 col-sm-4 icon_arrow">
                                 <div class="input-group border-bottom-dark-2">
                                    <select class="form-control" name="child" id="child">
                                       <option selected="selected" disabled="disabled">0 Child
                                       </option>
                                       <option value="1">1 Child
                                       </option>
                                       <option value="2">2 Child
                                       </option>
                                       <option value="3">3 Child
                                       </option>
                                       <option value="4">4 Child
                                       </option>
                                       <option value="5">5 Child
                                       </option>
                                       <option value="6">6 Child
                                       </option>
                                       <option value="7">7 Child
                                       </option>
                                       <option value="8">8 Child
                                       </option>
                                       <option value="9">9 Child
                                       </option>
                                       <option value="10">10 Child
                                       </option>
                                       
                                       <option value="many">Many
                                       </option>
                                    </select>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-md-4 col-sm-4">
                                 <input type="submit" class="btn btn-warning btn-md floatright" name="submit" value="Book">
                              </div>
                           </div>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
            <!----------end serach functionality--------------------------------------------->
            <!-- end hotel booking -->
         </div>
      </div>
   </div>
</div>
<!-- end main slider -->
<!-- start welcome section -->
<!--<section class="another_facitilies_area">
   <div class="container">
      <div class="another_facitilies clearfix padding-bottom-100">
         <div class="col-lg-3 col-md-3 col-sm-3">
            <div class="single_facities">
               <a href="#">
               <img src="<?php echo base_url('assets/fronttheme/')?>/img/home-facilities-icon-eleven.png" alt="">
               </a>
               <h6>Restaurant
               </h6>
               <p>Semper ac dolor vitae accumsan. Cras interdum hendrerit lacinia.  vitae molestie interdum.
               </p>
            </div>
         </div>
         <div class="col-lg-3 col-md-3 col-sm-3">
            <div class="single_facities">
               <a href="#">
               <img src="<?php echo base_url('assets/fronttheme/')?>/img/home-facilities-icon-seven.png" alt="">
               </a>
               <h6>Sports Club
               </h6>
               <p>Semper ac dolor vitae accumsan. Cras interdum hendrerit lacinia.  vitae molestie interdum.
               </p>
            </div>
         </div>
         <div class="col-lg-3 col-md-3 col-sm-3">
            <div class="single_facities">
               <a href="#">
               <img src="<?php echo base_url('assets/fronttheme/')?>/img/home-facilities-icon-eight.png" alt="">
               </a>
               <h6>Pick up
               </h6>
               <p>Semper ac dolor vitae accumsan. Cras interdum hendrerit lacinia.  vitae molestie interdum.
               </p>
            </div>
         </div>
         <div class="col-lg-3 col-md-3 col-sm-3">
            <div class="single_facities">
               <a href="#">
               <img src="<?php echo base_url('assets/fronttheme/')?>/img/home-facilities-icon-nine.png" alt="">
               </a>
               <h6>BAR
               </h6>
               <p>Semper ac dolor vitae accumsan. Cras interdum hendrerit lacinia.  vitae molestie interdum.
               </p>
            </div>
         </div>
      </div>
   </div>
</section>-->
<!-- end welcome section -->
<!-- start Hotel Facilities section -->
<section class="select_room_area padding-top-90">
   <div class="container">
      <div class="row">
         <div class="select_room clearfix">
            <div class="section_title nice_title content-center">
               <h3>Select Your Table
               </h3>
            </div>
            <div class="select_room_content clearfix">
               <?php if(!empty($clubs)){
                  foreach($clubs as $clb){
                  $cid=$clb['Id'];
                  $clublayout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$cid);
                  $img=$clublayout[0]['MainImage'];
                  $PerAdultPrice=$clublayout[0]['PerAdultPrice'];
                  ?>
               <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 eightcls">
                  <div class="room_thumb eightroom">
                     <a href="<?php echo base_url('detail/'.$clb['Slug']);?>">
                     <?php if($img!=''){ 
                        if (file_exists(FCPATH.'assets/clubimage/1920X600/'.$img)){
                        ?>
                     <img class="eightimg" src="<?php echo base_url('assets/clubimage/1920X600/'.$img);?>" alt="">
                     <?php }  else{ ?>
                     <img class="eightimg" src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="">
                     <?php } } else{ ?>
                     <img class="eightimg" src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="">
                     <?php } ?>
                     </a>
                     <div class="room_details">
                        <div class="about_room floatleft">
                           <div class="room_quality floatleft">
                              <a href="<?php echo base_url('detail/'.$clb['Slug']);?>">
                                 <h5 class="claimedRight" maxlength="50">
                                    <?php echo $clb['ClubName'];?>
                                 </h5>
                              </a>
                           </div>
                           <div class="room_rent floatleft">
                              <p class="pricefnt"><?php echo $PerAdultPrice.' QAR';?>
                              </p>
                           </div>
                        </div>
                        <div class="room_block floatright">
<?php $vendorid=$this->session->userdata['vendorauth']['Id'];                                        
if($vendorid==''){ ?>
                           <a href="<?php echo base_url('detail/'.$clb['Slug']);?>" class="btn btn-black">See More Clubs
                           </a> <?php } ?>
                        </div>
                     </div>
                  </div>
               </div>
               <?php } } ?>
               <div class="col-lg-4 col-md-4 col-sm-4 col-sx-12 fourcls">
                  <?php if(!empty($clubs1)){
                     foreach($clubs1 as $clb1){
                     $cid=$clb1['Id'];
                     $clublayout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$cid);
                     $img=$clublayout[0]['MainImage'];
                     $PerAdultPrice=$clublayout[0]['PerAdultPrice'];
                     ?>
                  <div class="room_thumb small_room_thumb margin-bottom-35 fourroom1">
                     <a href="<?php echo base_url('detail/'.$clb1['Slug']);?>">
                     <?php if($img!=''){
                        if (file_exists(FCPATH.'assets/clubimage/455X300/'.$img)){?>
                     <img src="<?php echo base_url('assets/clubimage/455X300/'.$img);?>" alt="" class="uo">
                     <?php }else{ ?>
                     <img class="uo" src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="">
                     <?php } }else{ ?>
                     <img class="uo" src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="">
                     <?php } ?>
                     </a> 
                     <div class="room_details">
                        <div class="about_room floatleft">
                           <div class="room_quality floatleft">
                              <a href="<?php echo base_url('detail/'.$clb1['Slug']);?>">
                                 <h5 class="claimedRight1" maxlength="50">
                                    <?php echo $clb1['ClubName'];?>
                                 </h5>
                              </a>
                           </div>
                           <div class="room_rent floatleft">
                              <p class="pricefnt1"><?php echo $PerAdultPrice.' QAR';?>
                              </p>
                           </div>
                        </div>
                        <div class="room_block floatright"><?php $vendorid=$this->session->userdata['vendorauth']['Id'];                                        
if($vendorid==''){ ?>
                      
                           <a href="<?php echo base_url('detail/'.$clb1['Slug']);?>" class="btn btn-black">See More Clubs
                           </a><?php } ?>
                        </div>
                     </div>
                  </div>
                  <?php } } 
                     if(!empty($clubs2)){
                     foreach($clubs2 as $clb2){
                     $cid=$clb2['Id'];
                     $clublayout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$cid);
                     $img=$clublayout[0]['MainImage'];
                     $PerAdultPrice=$clublayout[0]['PerAdultPrice'];
                     ?>
                  <div class="room_thumb small_room_thumb fourroom1">
                     <a href="<?php echo base_url('detail/'.$clb2['Slug']);?>">
                     <?php if($img!=''){ 
                        if (file_exists(FCPATH.'assets/clubimage/455X300/'.$img)){?>
                     <img src="<?php echo base_url('assets/clubimage/455X300/'.$img);?>" alt=""  class="uo tr" >
                     <?php } else{ ?>
                     <img class="uo tr"  src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="">
                     <?php }}else{ ?>
                     <img class="uo tr"  src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="">
                     <?php } ?>
                     </a> 
                     <div class="room_details">
                        <div class="about_room floatleft">
                           <div class="room_quality floatleft">
                              <a href="<?php echo base_url('detail/'.$clb2['Slug']);?>">
                                 <h5 class="claimedRight1" maxlength="50">
                                    <?php echo $clb2['ClubName'];?>
                                 </h5>
                              </a>
                           </div>
                           <div class="room_rent floatleft">
                              <p class="pricefnt1"><?php echo $PerAdultPrice.' QAR';?>
                              </p>
                           </div>
                        </div>
                        <div class="room_block floatright">
<?php $vendorid=$this->session->userdata['vendorauth']['Id'];                                        
if($vendorid==''){ ?>
                      
                           <a href="<?php echo base_url('detail/'.$clb2['Slug']);?>" class="btn btn-black">See More Clubs
                           </a><?php }?>
                        </div>
                     </div>
                  </div>
                  <?php } } ?>
               </div>
               <div class="col-lg-12 col-md-12 col-sm-12 col-sx-12">
                  <div class="view_all_rooms text-center  padding-bottom-90  padding-top-90">
                     <a href="<?php echo base_url('front/allclub'); ?>" class="btn btn-warning">See more tables
                     </a>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- end Hotel Facilities section -->
<!-- start About Us section -->
<section class="about_us_area margin-bottom-128">
   <div class="container">
      <div class="about_us clearfix"><br><br>
         <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 padding-left-0">
            <div class="news">
               <div class="section_title margin-bottom-50">
                  <h5>Top Rated Club
                  </h5>
               </div>
               <div class="section_description">
                  <div class="row">
                     <div class="col-md-12">
                        <?php if(!empty($clubs3rec)){
                           foreach($clubs3rec as $clb3){
                           $cid=$clb3['Id'];
                           
                           $que=$this->db->query("SELECT ROUND(AVG(Review),1) as totalcal FROM `tbl_reviews` WHERE ClubId='".$cid."'");
                           $res=$que->result_array();
                           $tto=$res[0]['totalcal'];
                           
                           
                           $clublayout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$cid);
                           $img=$clublayout[0]['MainImage'];
                           ?> 
                        <div class="single_content clearfix border-bottom-whitesmoke">
                           <div class="col-lg-4 col-md-4 col-sm-12 col-xs-4 padding-left-0">
                              <div class="post_media">
                                 <a href="<?php echo base_url('detail/'.$clb3['Slug']);?>">
                                 <?php if($img!=''){ 
                                    if (file_exists(FCPATH.'assets/clubimage/210X150/'.$img)){
                                    ?>
                                 <img class="smcl" src="<?php echo base_url('assets/clubimage/210X150/'.$img);?>" alt="">
                                 <?php }else{ ?>
                                 <img class="smcl" src="<?php echo base_url('assets/fronttheme/customcss/dummyimg.jpg')?>" alt="">
                                 <?php } }else{ ?>
                                 <img class="smcl" src="<?php echo base_url('assets/fronttheme/customcss/dummyimg.jpg')?>" alt="">
                                 <?php } ?>
                                 </a>
                              </div>
                           </div>
                           <div class="col-lg-8 col-md-8 col-sm-12 col-xs-8 padding-left-0">
                              <div class="post_title clearfix">
                                 <a href="<?php echo base_url('detail/'.$clb3['Slug']);?>">
                                    <h6>
                                       <?php echo $clb3['ClubName'];?>
                                       <?php echo '<span class="boxo">'.$tto.'</span>';?>
                                    </h6>
                                 </a>
                              </div>
                              <div class="post_content  margin-bottom-35 " style="color: deepskyblue;" >
                                 <?php echo 'By '.$clb3['FirstName'].' '.$clb3['LastName'];?>
                              </div>
                           </div>
                        </div>
                        <?php } } ?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <div class="showcase">
               <div class="section_title margin-bottom-50">
                  <h5 class="aboutcl">About  TableFast
                  </h5>
               </div>
               <div class="section_description">
                  <div class="about_hotel" style="">
                     <div class="hotel_thumb">
                        <img src="<?php echo base_url('assets/logo')?>/banner.jpeg" alt="img">
                     </div>
                     <div class="about_details">
                        <p>
                           <?php  $metsetting=$this->App->passwordChecking('tbl_information','Id','Status','1','1');
$desabt  = $metsetting[0]['Description'];
$sed = substr($desabt, 0, 334);
echo $sed.'..';
?>
                        </p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <div class="customer_says">
               <div class="section_title margin-bottom-50">
                  <h5>Reviews
                  </h5>
               </div>
               <div class="section_description">
                  <div id="customer_says_slider" class="carousel slide" data-ride="carousel" data-pause="none">
                     <!-- Wrapper for slides -->
                     <div class="carousel-inner" role="listbox">
                        <?php 
                           $resa= $this->App->getRecordByLimit('tbl_reviews', 'PublishStatus', '1', '0', '3');
                           if(!empty($resa)){ $j=1;
                               foreach($resa as $rts){
                                   $cmt = substr($rts['Reviewscomment'], 0, 200);
                                   $Review = $rts['Review'];
                                   
                                    if($Review=='5'){
                                                                        $s='<span class="str"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><span>';
                                                                    }elseif($Review=='4'){
                                                                        $s='<span class="str"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-o"></i><span>';
                                                                    }elseif($Review=='3'){
                                                                        $s='<span class="str"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><span>';
                                                                    }elseif($Review=='2'){
                                                                        $s='<span class="str"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><span>';
                                                                    }elseif($Review=='1'){
                                                                        $s='<span class="str"><i class="fa fa-star"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><span>';
                                                                    }else{
                                                                        $s='<span class="str"><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><span>';
                                                                    }
                                   $BookingId = $rts['BookingId'];
                                   $Created=$rts['Created'];
                                     $bookingdetails= $this->App->getPerticularRecord('tbl_booking', 'Id', $BookingId);
                                     $name=$bookingdetails[0]['FirstName'].' '.$bookingdetails[0]['LastName'];
                                     $userid=$bookingdetails[0]['CustomerId'];
                                      $clubid=$bookingdetails[0]['ClubId'];
                                      
                                      $clubdetails= $this->App->getPerticularRecord('tbl_vendor', 'Id', $clubid);
                                     $clubname=$clubdetails[0]['ClubName'];
                                     $customerdetails= $this->App->getPerticularRecord('tbl_customer', 'Id', $userid);
                                     $ProfileImage=$customerdetails[0]['ProfileImage'];
                                     
                                     if($ProfileImage!=''){
                                         
                                       if (file_exists(FCPATH.'assets/customerprofile/'.$ProfileImage)){
                                          $i=base_url('assets/customerprofile/'.$ProfileImage);
                                       }else{
                                          $i=base_url('assets/fronttheme/customcss/dummy.png');
                                      }
                                      }else{
                                          $i=base_url('assets/fronttheme/customcss/dummy.png');
                                      }
                            ?>
                        <div class="item  <?php if($j==1){ echo 'active';}?>">
                           <div class="single_says">
                              <div class="customer_comment">
                                 <h6 class="mkq"><?php echo $clubname; ?></h6>
                                 <p><?php echo $s;?></p>
                                 <p><?php echo $cmt;?></p>
                              </div>
                              <div class="customer_detail clearfix">
                                 <div class="customer_pic alignleft-20">
                                    <a href="#">
                                    <img src="<?php echo $i;?>" alt="" class="imgc">
                                    </a>
                                 </div>
                                 <div class="customer_identity floatleft">
                                    <h6><?php echo $name;?> 
                                    </h6>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <?php $j++; }
                           } ?>
                     </div>
                     <!-- Controls -->
                     <a class="slider_says left" href="#customer_says_slider" role="button" data-slide="prev">
                     <i class="fa fa-angle-left">
                     </i>
                     <span class="sr-only">Previous
                     </span>
                     </a>
                     <a class="slider_says right" href="#customer_says_slider" role="button" data-slide="next">
                     <i class="fa fa-angle-right">
                     </i>
                     <span class="sr-only">Next
                     </span>
                     </a>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- end About Us section -->






<section class="welcome_area">
   <div class="container">
      <div class="about_us clearfix">
         <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding-left-0">
            <div class="news">
               <div class="section_title margin-bottom-50">
                  <h5>You may Also like
                  </h5>
               </div>
               <div class="section_description">
                  <div class="row">
                     <?php if(!empty($clubs4rec)){
                        foreach($clubs4rec as $clb4){
                        $cid=$clb4['Id'];
                        $clublayout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$cid);
                        $img=$clublayout[0]['MainImage'];
                        $PerAdultPrice=$clublayout[0]['PerAdultPrice'];
                        ?>           
                     <div class="col-lg-3 col-md-3 col-sm-3">
                        <div class="single_room_wrapper clearfix">
                           <div class="room_wrapper">
                              <div class="room_media">
                                 <a href="<?php echo base_url('detail/'.$clb4['Slug']);?>">
                                 <?php if($img!=''){
                                    if (file_exists(FCPATH.'assets/clubimage/455X300/'.$img)){
                                    ?>
                                 <img src="<?php echo base_url('assets/clubimage/455X300/'.$img);?>" alt="" class="rm">
                                 <?php }else{ ?>
                                 <img src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="">
                                 <?php } }else{ ?>
                                 <img src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="">
                                 <?php } ?>
                                 </a>
                              </div>
                              <div class="room_title clearfix">
                                 <div class="left_room_title floatleft">
                                    <a href="<?php echo base_url('detail/'.$clb4['Slug']);?>">
                                       <h6 class="claimedRight" maxlength="50">
                                          <?php echo $clb4['ClubName'];?>
                                       </h6>
                                       <style>.claimedRight {
                                          display: block;
                                          width: 160px;
                                          overflow: hidden;
                                          white-space: nowrap;
                                          text-overflow: ellipsis;
                                          }
                                          figure.uk-overlay1.uk-overlay-hover1 {
                                          width: 100%;
                                          }
                                       </style>
                                    </a>
                                    <p><?php echo $PerAdultPrice.' QAR';?> 
                                       <span>
                                       </span>
                                    </p>
                                 </div>
                                 <div class="left_room_title floatright">
<?php $vendorid=$this->session->userdata['vendorauth']['Id'];                                        
if($vendorid==''){ 
	if($PerAdultPrice > 99 && $PerAdultPrice < 300){
		$cls = 'btn btn-black';
		}
	else if($PerAdultPrice > 299 && $PerAdultPrice < 600){
		$cls = 'btn btn-red';
		}
	else if($PerAdultPrice > 600 && $PerAdultPrice < 900){
		$cls = 'btn btn-blues';
		}
	else if($PerAdultPrice > 899 && $PerAdultPrice < 1201){
		$cls = 'btn btn-violet';
		}
	else {
		$cls = 'btn btn-black';
		}
	?>
                      
                                    <a href="<?php echo base_url('detail/'.$clb4['Slug']);?>" class="<?php echo $cls;?>">See More Clubs
                                    </a><?php } ?>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <?php } } ?> 
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>








<section class="welcome_area">
   <div class="container">
   <div class="container-fluid">
      <div class="row">
         <div class="hotel_showcase">
            <div class="section_title nice_title content-center"><br />
               <h3>Latest Events
               </h3>
            </div>
            <div class="section_content">
               <div class="showcase_slider">
                     <?php if(!empty($allevents)){
                        foreach($allevents as $clb){
							
							$img = $clb['Image'];
                        ?>           
                     <div class="col-lg-12 col-md-12 col-sm-12 eve1">
                        <div class="single_room_wrapper clearfix">
                           <div class="room_wrapper">
                              <div class="room_media evn1s">
                                 <a href="<?php echo base_url('event-detail/'.$clb['Slug']);?>">
                                 <?php if($img!=''){
                                    if (file_exists(FCPATH.'assets/events/'.$img)){
                                    ?>
                                 <img src="<?php echo base_url('assets/events/'.$img);?>" alt="" class="rm">
                                 <?php }else{ ?>
                                 <img src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="" class="rm">
                                 <?php } }else{ ?>
                                 <img src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="" class="rm">
                                 <?php } ?>
                                 </a>
                              </div>
                              <div class="room_title clearfix">
                                <Center> <div class="left_room_title floatleft">
                                 
                                    <a href="<?php echo base_url('event-detail/'.$clb['Slug']);?>">
                                       <h6 class="claimedRight mp0" maxlength="50">
                                          <?php echo $clb['Title'];?>
                                       </h6>
                                       <style>.claimedRight {
                                          display: block;
                                          width: 160px;
                                          overflow: hidden;
                                          white-space: nowrap;
                                          text-overflow: ellipsis;
                                          }
                                          figure.uk-overlay1.uk-overlay-hover1 {
                                          width: 100%;
                                          }
                                       </style>
                                    </a>
                                 </div>
                               </Center> 
                               </div>
                               <Center> <div class=" evn12s">
								
                      
                                    <a href="<?php echo base_url('event-detail/'.$clb['Slug']);?>" class="btn">Read More
                                    </a>
                                 </div></Center>
                              </div>
                           
                        </div>
                     </div>
                     <?php } } ?> 
                     </div>
            </div>
         </div>
      </div>
   </div>
   </div>
</section>


























<script>
   function searchfun(id){
     var url="<?php echo base_url('front/getname');?>";
     $.ajax({
       type: 'post',
       dataType : 'json',
       url: url,
       data: "id="+id,
       success: function (data) {
         document.getElementById('clubname').value=data;
       }
     }
           );
   }
</script>
<!-- end contact us area -->
<style>
a.btn.btn-red:hover {
    background: red;
    color: #fff;
    border:1px solid red;
}
a.btn.btn-red {
    color: red;
    border:2px solid red;
}

a.btn.btn-blues:hover {
    background: blue;
    color: #fff;
    border:1px solid blue;
}
a.btn.btn-blues {
    color: blue;
    border:2px solid blue;
}

a.btn.btn-violet:hover {
    background: violet;
    color: #fff;
    border:1px solid violet;
}
a.btn.btn-violet {
    color: violet;
    border:2px solid violet;
}

.evn12s {
    width: 74%;
    padding: 5px;
}
h6.claimedRight.mp0 {
    padding: 0px 0px 13px 0px;
}
.room_media.evn1s {
    height: 150px;
}
   i.fa.fa-star-o {
   padding: 1px;color: coral;
   }
   i.fa.fa-star {
   padding: 1px;
   color: coral;
   }
   .mkq {
   color: #000;
   font-size: 21px;
   line-height: 30px;
   }
   .mop {
   width: 100%;
   border: 1px solid #ccc;
   padding: 4px;
   margin: 7px;
   }
   img.imgsearch {
   width: 15%;
   }
   input#clubname ,input#bookdate {
   background: transparent;
   border: none;
   color:#fff
   }
   img.eightimg {
   height: 412px; width: 100%;
   }
   img.smcl {
   height: 55px;    width: 100%;
   }
   img.iop {
   height: 137px;
   }
   .room_wrapper {
   margin-bottom: 20px;
   }
   img.rm {
   height: 150px;    width: 100%;
   }
   img.uo {
   height: 188px;
   width: 360px;
   max-width: 100%;
   }
   .room_media {
   margin-bottom: 28px;
   text-align: center;
   }
   div#kpl {
   margin-top: 13%;
   }
   .boxo {
   background: yellowgreen;
   color: #fff;
   font-size: 20px;
   text-align: center;
   width: 26%;
   float: right;
   border-radius: 3px;
   margin: 2px;
   font-family: serif;
   }
   img.imgc {
   width: 25%;
   border-radius: 30px;
   }
   span.io {
   background: yellowgreen;
   padding: 2px 10px;
   font-size: 24px;
   color: #fff;
   font-family: serif;
   border-radius: 4px;    float: right;
   }
</style>
<!-- start footer -->
