  <?php $this->load->view('front/include/bootstraptable/header');?> 
<section class="breadcrumb_main_area margin-bottom-80">
  <div class="container-fluid">
    <div class="row">
      <div class="breadcrumb_main nice_title">
        <h2> Categories
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
           
          </div>
        </div>         
        <!-- end offer start -->
      </div>
    </div>
  </div>            
</section>
<!-- start contact mail area -->
<section class="contact_mail_area margin-bottom-90">
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2 style="font-size:20px "> Categories
            </h2>
            <button type="button" class="btn btn-info categorybtn"  style="float:right;margin-bottom:10px;color:#63c2ea !important" data-toggle="modal" data-target="#myModal" >
              <i class="fa fa-plus"> 
              </i> Add   
            </button>
            <br>
            <br>
            <!------------------------------------>
            <!-- Modal -->
            <div class="modal fade" id="myModal" role="dialog">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;
                    </button>
                    <h4 class="modal-title" >Add Category
                    </h4>
                  </div>
                  <div class="modal-body">
                    <form id="demo-form2" method="post" class="form-horizontal form-label-left">
                      <div id="err" style="color:red">
                      </div>
                      <div id="err1" style="color:red">
                      </div>
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                          <input id="cattitle" class="form-control col-md-12 col-xs-12" placeholder="Title" required="required" type="text" name="cattitle" >
                        </div>
                      </div>
<button type="button" class="btn btn-default" onclick="addcategory()">Submit
                          </button>
                   
                   
                  </div>
                 
                   </form>
                </div>
                
                 <script>
                      function addcategory(){
                        var s=$("#cattitle").val();
                        var url="<?php echo base_url('food/addcategory');?>";
                        if(s==''){
                          $("#err").html("Please category title required");
                        }
                        else{
                          $.ajax({
                            type: 'post',
                            dataType : 'json',
                            url: url,
                            data: "category="+s,
                            success: function (data) {
                              if(data=='1'){
                                alert('Category successfully added.');
                                location.reload();
                              }
                              if(data=='2'){
                                $('#err1').html('Category already Exist.');
                              }
                            }
                          });
                        }
                      }
                    </script>
              </div>
            </div>
          </div>
          <!------------------------------------------->
        </div>
        <div class="x_content">
        	
          <table id="datatable-buttons" style="overflow-x: scroll;" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
              <tr>
                <th>Action
                </th> 
                <th>Category
                </th>
                <th>Status
                </th> 
                <th>Created
                </th>  
              </tr>
            </thead>
            <tbody>
              <?php if(!empty($listcategory)){
foreach($listcategory as $cat){ 
if($cat['Status']=='1'){ $s='Active';}else{ $s='Inactive';}?>
              <tr>
                <td>
                  <a  class="btn pad-30" style="margin:3px 0px" data-toggle="tooltip" title="Update"  onclick="updatecategory('<?php echo $cat['Id']?>')">
                    <i class="fa fa-edit"> 
                    </i>  
                  </a> 
                  <a  class="btn btn-warning pad-30" style="margin:3px 0px;" data-toggle="tooltip" title="Delete" onclick="deletecategory('<?php echo $cat['Id']?>')">
                    <i class="fa fa-trash"> 
                    </i>  
                  </a> 
                </td>
                <td>
                  <?php echo $cat['Title'];?>
                </td>
                <td>
                  <?php echo $s;?>
                </td>
                <td>
                  <?php echo $cat['Created'];?>
                </td>
              </tr>
              <?php }
} ?>
            </tbody>
          </table>
          <div class="row">
            <nav class="text-center margin-top-65 margin-bottom-75">
              <ul class="pagination">
                <?php echo $links; ?>
              </ul>
            </nav> 
          </div>
          <script>
            function deletecategory(id){
              var r = confirm("Are You sure want to Trash this Record?");
              var url="<?php echo base_url('food/deleteCategory');?>";
              if (r == true) {
                $.ajax({
                  type: 'post',
                  url: url,
                  data: "id="+id,
                  success: function () {
                    alert('Delete Category Successfully');
                    location.reload();
                  }
                }
                      );
              }
            }
            function updatecategory(id){
              var url="<?php echo base_url('food/updatefrom');?>";
              $.ajax({
                type: 'post',
                dataType : 'json',
                url: url,
                data: "id="+id,
                success: function (data) {
                  $("#updatediv").html(data);
                  $('#myModal2').modal('show');
                }
              }
                    );
            }
          </script>	
        </div>
      </div>
    </div>
  </div>
  </div>
</div>
</section>
<div id="updatediv">
</div>
<script>
  function editcategory(){
    var s=$("#cattitle1").val();
    var catstatus=$("#catstatus option:selected").val();
    var catid=$("#catid").val();
    var url="<?php echo base_url('food/editcategory');?>";
    if(s==''){
      $("#err3").html("Please category title required");
    }
    else{
      $.ajax({
        type: 'post',
        dataType : 'json',
        url: url,
        data: "category="+s+"&id="+catid+"&catstatus="+catstatus,
        success: function (data) {
          if(data=='1'){
            alert('Category successfully Update.');
            location.reload();
          }
          if(data=='2'){
            $('#err2').html('Category already Exist.');
          }
        }
      }
            );
    }
  }
</script>
<?php $this->load->view('front/include/bootstraptable/footer');?> 
