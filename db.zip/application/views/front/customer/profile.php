<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript">
</script>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js">
</script>
<!-- start breadcrumb -->
<section class="breadcrumb_main_area margin-bottom-80">
  <div class="container-fluid">
    <div class="row">
      <div class="breadcrumb_main nice_title">
        <h2>Profile
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
            
          </div>
        </div>         
        <!-- end offer start -->
      </div>
    </div>
  </div>            
</section>
<!-- end breadcrunb -->
<!-- start other detect room section -->
<section class="booking_area">
  <div class="container">
    <div class="booking">
      <div role="tabpanel">
        <!-- Nav tabs -->
       
        <!-- Tab panes -->
        <div class="row">  <h5 style="text-align: center;">Profile Information</h5><br>
             <form method="post" action="<?php echo base_url("profile");?>" class="form-horizontal form-label-left" novalidate enctype="multipart/form-data" name="registration" id="registration">
               
          <!-------------------------------------------->
          <div class="col-md-4 col-sm-4 col-xs-4  col-lg-4">
              <div class="row">
                  <div class="col-md-12 col-sm-12 col-xs-12  col-lg-12">
                      <?php
                        $img=$profiles[0]['ProfileImage'];
                        if(!empty($img)){
                            $i=base_url('assets/customerprofile/'.$img);
                        }else{
                            $i=base_url('assets/fronttheme/customcss/dummy.png');
                        }
                      ?>
                   <img class="img-responsive avatar-view" src="<?php echo $i;?>" alt="Customer Profile" title="Change the Customer Profile">
                   <input type="hidden" name="oldimg" id="oldimg" value="<?php echo $img;?>">
                    <div class="file-upload">
                        <label for="upload" class="file-upload__label">Edit Profile Image</label>
                        <input id="upload" class="file-upload__input" type="file" name="image" >
                    </div>
                  </div>
              </div>
          </div>
          <div class="col-md-8 col-sm-8 col-xs-8  col-lg-8 boxborder" >
            <div class="facilities_name clearfix">
              <div class="">
              
                <div class="res">
                 
                <?php    if(!empty($error)){?>
                <div class="alert alert-danger  alert-dismissible">
                  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                  </a>
                  <?php  echo $error;?>
                </div>
                <?php }  if(!empty($success)){?><div class="alert alert-success  alert-dismissible">
                  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                  </a>
                  <?php  echo $success;?>
                </div><?php } ?>
                      <div id="err" style="color:red">
                      </div>
                      <div id="err1" style="color:red">
                      </div>
                        <div class="">
                            <div class="form-group">
                                <div class="col-md-6 col-sm-6 col-xs-6"> 
                                     <label>First Name*</label>
                                  <input id="firstname" class="form-control col-md-12 col-xs-12" placeholder="First Name"  type="text" name="firstname" value="<?php echo $profiles[0]['FirstName']?>">
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-6">         
                                     <label>Last Name*</label>
                                   <input id="lastname" class="form-control col-md-12 col-xs-12" placeholder="First Name"  type="text" name="lastname" value="<?php echo $profiles[0]['LastName']?>">
                                </div>
                            </div>
                        </div>
                         <div class="">
                            <div class="form-group">
                                <div class="col-md-12 col-sm-12 col-xs-12">    
                                    
                                <label>Where do you live?*</label>
                                  <input id="address" class="form-control col-md-12 col-xs-12" placeholder="Address"  type="text" name="address" value="<?php echo $profiles[0]['Address']?>">
                                </div>
                                <br><br>
                                <div class="col-md-12 col-sm-12 col-xs-12">    
                                <label>A little bit about yourself </label>                        
                                   <input id="yourself" class="form-control col-md-12 col-xs-12"  required="required" type="text" name="yourself" value="<?php echo $profiles[0]['Yourself']?>">
                                </div>
                            </div>
                        </div>
                     <script>
                                        function ValidatePhoneNo() {
                                                    if ((event.keyCode > 47 && event.keyCode < 58) || event.keyCode == 43 || event.keyCode == 32)
                                                            return event.returnValue;
                                                    return event.returnValue = '';
                                        }
                                    </script>
                                   
                         <div class="">
                            <div class="form-group">
                                <div class="col-md-6 col-sm-6 col-xs-6">     
                                    <label>Your mobile number</label>
                                  <input id="phone" onkeypress="return ValidatePhoneNo()" class="form-control col-md-12 col-xs-12" placeholder="Mobile Number" required="required" type="text" name="phone" value="<?php echo $profiles[0]['Phone']?>">
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-6">
                                    <label>Your email address</label>
                                   <input id="email" class="form-control col-md-12 col-xs-12" placeholder="Email Id" required="required" type="email" name="email" value="<?php echo $profiles[0]['Email']?>">
                                </div>
                            </div>
                        </div>
                    
                        
                        
                         
                      <div class="ln_solid">
                      </div>
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12 ">
                        
                            <input type="submit" name="submit" class="btn" value="Save">
                            
                        </div>
                      </div>
                </div>
                <br><br>
              </div></form>
                 <script>
       
            //form validation rules
            $("#registration").validate({
                rules: {
                    lastname: "required",
                     firstname: "required",
                    phone: "required",
                    address: "required",
                   
                    email: "required",
                    yourself: "required",
                    },
                messages: {
                    firstname: "Please enter First Name",
                    lastname: "Please enter Last Name",
                    yourself:  {
                            required :"Please enter Yourself "
                                     }, 
                    address:  {
                            required :"Please enter Address "
                                     }, 
                    phone:  {
                            required :"Please enter Phone Number",
                            minlength:"minimum length is 10",
                                     }, 
                    email: "Please enter Email",
                    

                },
                submitHandler: function(form) {
                   form.submit();
                }
            }); </script>
                
            </div>
          </div>
                              

        </div>
        <div class="row" style="    margin-bottom: 2%;"></div>
      </div>
    </div>
  </div>
</section>
<!-- end other detect room section -->
<!-- start contact us area -->
<!-- end contact us area -->
<style>
    .boxborder {
    border: 1px solid #eaeaea;
    padding: 2%;
    background: snow;
    border-radius: 3px;
    /* margin: 1% 0%; */
}
   .file-upload {
    text-align: center;
    margin: 4% 5%;display: inline-block;
} 
                      

.file-upload__label {
    display: block;
    padding: 5px 8px;
    color: #fff;
    background: #222;
    border-radius: 4px;
    transition: background .3s;
}
    
.file-upload__input {
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    bottom: 0;
    font-size: 1;
    width:0;
    height: 100%;
    opacity: 0;
}     
     .form-group.col-lg-6.col-md-6.col-sm-6.icon_arrow1 {
    margin-right: 33px;
}
    .input-group {
  position: static;
  display: unset;
  border-collapse: separate;
  }
  label.error {
    color: red;
    font-size: 12px;
    font-weight: 300;
    display: table;
  }
  .alert {
    text-align: left;
    padding-left: 26px;
  }
  a.close {
    padding-right: 14px;
  }
  .cls {
    font-size: 53px;
    color: steelblue;
    text-align: center;
  }
  .titclub {
    font-size: 21px;
    color: red;
    text-align: center;
  }
  div#nmp {
    border: 1px solid steelblue;
    border-radius: 6px;
    margin: 1%;
    padding: 15px;
  }
</style>
