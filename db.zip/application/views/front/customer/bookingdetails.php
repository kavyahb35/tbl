<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
 <?php if(!empty($success)){ ?>
<script type="text/javascript">
    $(window).on('load',function(){
        $('#myModal').modal('show');
    });
</script>
 <?php } ?>
<!-- start breadcrumb -->
<section class="breadcrumb_main_area margin-bottom-80">
   <div class="container-fluid">
      <div class="row">
         <div class="breadcrumb_main nice_title">
            <h2> <?php echo $clubdetails[0]['ClubName'];?>
            </h2>
            <!-- special offer start -->
            <div class="special_offer_main">
               <div class="container">
                 
               </div>
            </div>
            <!-- end offer start -->
         </div>
      </div>
   </div>
</section>
<!-- end breadcrunb -->
<!-- start other detect room section -->
<section class="booking_area">
   <div class="container">
      <div class="booking">
         <div role="tabpanel" style="margin:2% 0px">
            <!-- Nav tabs -->
            <!-- Tab panes -->
            <div class="row">
               <!-------------------------------------------->
                <div class="col-md-8 frmbox col-lg-8 col-sm-8 col-sm-12" >
                  <div class="facilities_name clearfix boxm">
                     <div class="row"><div class="centercls">
                        <h5 style="font-size: 30px;"><?php echo $clubdetails[0]['ClubName'];?> </h5>
                        <div class="contcls">
                            <h5 style=" font-size: 22px;text-transform: capitalize;padding-top: 5%;">Processing Request </h5>
                            <p> Tablefast.com is processing your request.</p>
                        </div>
                        <div class="contclss">
                            <h5 style="
     border-top: 1px solid #ccc; font-size: 16px;text-transform: capitalize;    padding: 4% 0px 0px 0px;">Need Help? </h5>
                            <a href="<?php echo base_url('contact')?>"> Contact Us</a>
                        </div>
                        
                     </div>
                     <br><br>
                    </div>
                  </div>
               </div>
            
            <div class="col-md-4 col-lg-4 col-sm-4 col-sm-12">
                   <div class="categorymenu">
                    <?php $vid=$clubdetails[0]['Id'];
                    $layout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$vid);
                    $img=$layout[0]['MainImage'];

                        $PerAdultPrice11=$layout[0]['PerAdultPrice'];

                    $Description=$layout[0]['Description'];
                    if($img!=''){
                    $i=base_url('assets/clubimage/'.$img);
                    }else{
                    $i=base_url('assets/fronttheme/banner/TableFast-Banner-2.jpg');
                    } ?>
                       <h5 style="font-size: 20px;text-transform: capitalize;padding: 3% 5%;">Booking At</h5>
                       <div class="col-md-12 col-lg-12 col-sm-12 col-sm-12">
                           <div class="boxvc">
                            <p class="resimg"><img src="<?php echo $i;?>"></p>
                            <h6 class="h6c"><?php echo $clubdetails[0]['ClubName'];?></h6>
                            <p class="add"><i class="fa fa-map-marker"></i> <?php echo $clubdetails[0]['Address'].' , <br>'.$clubdetails[0]['City'].' - '.$clubdetails[0]['PostCode'].' , '.$clubdetails[0]['Country'];?></p>
                           
                             <p class="add"><i class="fa fa-phone"></i> <?php echo $clubdetails[0]['Phone'].' , '.$clubdetails[0]['AlternativePhone'];?></p>
                          
                             <h5 style="font-size: 20px;text-transform: capitalize">Booking Details</h5>
<p class="add"><label>Booking No.: </label> <?php echo 'B00'.$bookingdetail[0]['BookingNo'];?></p>
                        <p class="add"><label>DATE : </label> <?php echo $bookingdetail[0]['BookingDate'];?></p>
                         <p class="add"><label>GUESTS : </label> <?php echo $bookingdetail[0]['NoofPax'];?></p>
                          <p class="add"><label>TIME : </label> <?php echo $bookingdetail[0]['BookingTime'];?></p>
                       
                          <h5 style="font-size: 20px;text-transform: capitalize">Guest Details</h5>
                        <p class="add"><label>NAME : </label> <?php echo $bookingdetail[0]['FirstName'].' '.$bookingdetail[0]['LastName'];?></p>
                         <p class="add"><label>PHONE NUMBER : </label> <?php echo $bookingdetail[0]['Phone'];?></p>
                          <p class="add"><label>Email : </label> <?php echo $bookingdetail[0]['Email'];?></p>
                       
                           
                           </div>
                       </div>
                       
                        
                   </div>
               </div>
              
            
            </div>
        
         </div>
      </div>
   </div>
</section>
<style>
    .add label {
    padding: 0px;
    color: #3d5a77;
    text-transform: capitalize !important;
}
  .centercls { text-align: center}
   .categorymenu {
      
   }.facilities_name.clearfix.boxm {
    border: 1px solid #ccc;
    margin: 1% 0%;
    padding: 6%;
    border-radius: 5px;
    background: snow;
}
.categorymenu {
    border: 1px solid #ccc;
    display: inline-block;
    padding: 9px;
     background: snow;
}
p.resimg img {
    width: 100%;
    border-radius: 4px;
}h6.h6c {
    color: #000;
    font-size: 22px;
}p.add {
    font-size: 13px;
}
</style>
