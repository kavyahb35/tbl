
<!-- start breadcrumb -->
<section class="breadcrumb_main_area ">
  <div class="container-fluid">
    <div class="row">
      <div class="breadcrumb_main nice_title">
        <h2>Verify Successfully.
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
           
          </div>
        </div>         
        <!-- end offer start -->
      </div>
    </div>
  </div>            
</section>
<!-- end breadcrunb -->
<!-- start other detect room section -->
<section class="booking_area nobito">
  <div class="container">
    <div class="booking" style="text-align:center">
    <p ><img src="<?php echo base_url('assets/fronttheme/customcss/success.png');?>" class="dfs"></p>
    <p>Thank you for register your verification is successfully Please Sign In.</p>
    <br>
    <a href="<?php echo base_url('customer');?>" class="btn btn-default">Sign In</a>
     
    </div>
  </div>
  </div>
</section>
<!-- end other detect room section -->
<!-- start contact us area -->
<!-- end contact us area -->
