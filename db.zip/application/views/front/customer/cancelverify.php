<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript">
</script>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js">
</script>
<!-- start breadcrumb -->
<section class="breadcrumb_main_area">
  <div class="container-fluid">
    <div class="row">
      <div class="breadcrumb_main nice_title">
        <h2>Verification Expired
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
            
          </div>
        </div>         
        <!-- end offer start -->
      </div>
    </div>
  </div>            
</section>
<!-- end breadcrunb -->
<!-- start other detect room section -->
<section class="booking_area nobito">
  <div class="container">
    <div class="booking" style="text-align:center">
    <p ><img src="<?php echo base_url('assets/fronttheme/customcss/cancel.png');?>" class="dfs"></p>
    <p>Sorry,Your verification url Expire.</p>
     
      
    </div>
  </div>
  </div>
</section>
<!-- end other detect room section -->
<!-- start contact us area -->
<!-- end contact us area -->

