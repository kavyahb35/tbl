<?php $this->load->view('front/include/bootstraptable/header'); ?>

<section class="breadcrumb_main_area margin-bottom-80">
   <div class="container-fluid">
      <div class="row">
         <div class="breadcrumb_main nice_title">
            <h2>  Event parched ticket
            </h2>
            <!-- special offer start -->
            <div class="special_offer_main">
               <div class="container">
                
               </div>
            </div>
            <!-- end offer start -->
         </div>
      </div>
   </div>
</section>
<section class="contact_mail_area margin-bottom-90">
   <div class="container">
      <div class="row">
         <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
               <div class="x_title">
                  <h2 style="font-size:20px "> Completed Transaction 
                  </h2>
                  <a class="btn "  style="float:right;margin-bottom:10px;color:#63c2ea !important" href="<?php echo base_url('customer/pendingtransaction')?>">
                  <i class="fa fa-plus"> 
                  </i> Pending Transaction
                  </a>
                  <br>
                  <br>
                 
            </div>
            <div id="updatediv"></div>
            <div class="x_content">
               <table id="datatable-buttons"  class="table table-striped table-bordered" cellspacing="0" width="100%">
                  <thead>
                     <tr>
                     <th>Parched Id</th>
                      <th>Club Name        </th>
                        <th>Events        </th>
					   <th>Image   </th>
					   <th>Event Type </th>
					   <th>Event Date                 </th>
					   <th>Price                </th>
					   <th>Comment</th>
					   <th>Payment Date</th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php if(!empty($listcompleteticket)){
                        foreach($listcompleteticket as $cat){ 
                         $cd = $cat['ClubId'];
										   $CustomerId = $cat['CustomerId'];
										   $EventId = $cat['EventId'];
										   $EventType = $cat['EventType'];
										   $Amount = $cat['Amount'];
										   $Comment = $cat['Comment'];
										   $Created = $cat['Created'];
										   
                                           if($cat['Status']=='1'){ $s='Active';}else{ $s='Inactive';}
                                           
                                           
										   $cd=$cat['ClubId'];
                                           $clubnamede=$this->App->getPerticularRecord('tbl_vendor', 'Id', $cd);
                                           $clubname = $clubnamede[0]['ClubName'];
                                           $evnetdetails=$this->App->getPerticularRecord('tbl_events', 'Id', $EventId);
                                           
                                           if($evnetdetails[0]['NoofDays']=='1'){
                                               $dt=$evnetdetails[0]['OneDate'];
                                           }else{ $dt=$evnetdetails[0]['FromDate'].' To '.$eventdetails[0]['ToDate'];}
                                           $img=$evnetdetails[0]['Image'];
                                           if($img!=''){
                                               $b=base_url('assets/events/'.$img);
                                               $sdq="<img src='".$b."' width='100%' >";
                                           } 
                                           
										   $evnettypedetails=$this->App->getPerticularRecord('tbl_event_type', 'Id', $EventType);
										   $typename = $evnettypedetails[0]['Title'];
                                             
                                           $customerdetails=$this->App->getPerticularRecord('tbl_customer', 'Id', $CustomerId);
                                           $customername = $customerdetails[0]['FirstName'].' '.$customerdetails[0]['LastName'];
                                           $Email = $customerdetails[0]['Email'];
                                           $Phone = $customerdetails[0]['Phone'];
                        if($cat['Status']=='1'){ 
                        
                       
                        ?>
                     <tr>
                                    <td>
                                          <?php echo  'P00'.$cat['Id'];?>
                                       </td>
                                       <td><?php echo $clubname;?></td>
                                       <td>
                                          <?php echo  $evnetdetails[0]['Title'];?>
                                       </td>
                                       <td  width="7%">
                                          <?php echo  $sdq;?>
                                       </td>
                                       <td>
                                          <?php echo $typename;?>
                                       </td>
                                       
                                       <td>
                                          <?php echo $dt.' Time: '.$evnetdetails[0]['TimeFrom'].' To '.$evnetdetails[0]['TimeTo'];?>
                                       </td>
                                       <td>
                                          <?php echo $Amount.' QAR';?>
                                       </td>
                                       <td>
                                          <?php echo $Comment;?>
                                       </td>
                                       <td>
                                          <?php echo $Created;?>
                                       </td>
                                    </tr>
                     <?php } }
                        } ?>
                  </tbody>
               </table>
               <div class="row">
                  <nav class="text-center margin-top-65 margin-bottom-75">
                     <ul class="pagination">
                        <?php echo $links; ?>
                     </ul>
                  </nav>
               </div>
               <script>
                  function deletecategory(id){
                    var r = confirm("Are You sure want to Delete this Record?");
                    var url="<?php echo base_url('events/deleteeventtype');?>";
                    if (r == true) {
                      $.ajax({
                        type: 'post',
                        url: url,
                        data: "id="+id,
                        success: function () {
                          alert('Delete Event type Successfully');
                          location.reload();
                        }
                      }
                            );
                    }
                  }
                  function updatecategory(id){
                    var url="<?php echo base_url('events/updateeventfrom');?>";
                    $.ajax({
                      type: 'post',
                      dataType : 'json',
                      url: url,
                      data: "id="+id,
                      success: function (data) {
                          alert(data);
                        $("#updatediv").html(data);
                        $('#myModal2').modal('show');
                      }
                    }
                          );
                  }
               </script>	
            </div>
         </div>
      </div>
   </div>
   </div>
   </div>
</section>
<script>
   function editcategory(){
     var s=$("#cattitle1 option:selected").val();
     var itemtitle1=$("#itemtitle1").val();
     var itemid=$("#itemid").val();
     var price1=$("#price1").val();
     var catstatus=$().val("#catstatus option:selected");
     var url="<?php echo base_url('food/edititem');?>";
     if(s=='' || itemtitle1=='' || price1==''){
       $("#err3").html("Please item title required");
     }
     else{
       $.ajax({
         type: 'post',
         dataType : 'json',
         url: url,
         data: "category="+s+"&itemtitle1="+itemtitle1+"&price1="+price1+"&itemid="+itemid+"&catstatus="+catstatus,
         success: function (data) {
           if(data=='1'){
             alert('Item successfully Update.');
             location.reload();
           }
           if(data=='2'){
             $('#err2').html('Item already Exist.');
           }
         }
       }
             );
     }
   }
</script>
<style>
   .alert-danger p {
   color: #a94442;
   }
</style>
<?php $this->load->view('front/include/bootstraptable/footer');?>
