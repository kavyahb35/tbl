<!-- start breadcrumb -->

    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/customcss/customerbookingcss.css');?>">
<section class="breadcrumb_main_area margin-bottom-80">
  <div class="container-fluid">
    <div class="row">
      <div class="breadcrumb_main nice_title">
        <h2>Rejected Booking 
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
           
          </div>
        </div>
        <!-- end offer start -->
      </div>
    </div>
  </div>
</section>
<!-- end breadcrunb -->
<!-- start other detect room section -->
<section class="other_room_area">
  <div class="container">
    <div class="row">
      <div class="other_room">
        <div class="section_title nice_title content-center">
          <!--  <h3>Other Decent Table</h3>-->
        </div>
        <!----------------------------------------------------------------------------------------------->
        <div class="accomodation_single_room">
          <div class="container">
              <div class="row"> 
                  <div class="col-md-12  col-lg-12 col-sm-12 mnk">
                    <a class="btn margin3 l1"  href="<?php echo base_url('customer/requestBooking');?>" >
                        <i class="fa fa-thumbs-o-up">  </i>  Requested Booking  
                    </a>
                    <a class="btn margin3 l1" href="<?php echo base_url('customer/confirmBooking');?>" >
                        <i class="fa fa-thumbs-up">  </i>  Confirmed Booking  
                    </a>
                    <a class="btn margin3 bluebtn l1" href="<?php echo base_url('customer/rejectBooking');?>" >
                        <i class="fa fa-remove">  </i>  Rejected Booking  
                    </a>
                    <a class="btn margin3 l1" href="<?php echo base_url('customer/cancelBooking');?>" >
                        <i class="fa fa-thumbs-down"> </i>  Cancelled Booking  
                    </a>
                    <a class="btn margin3 l1" href="<?php echo base_url('customer/completeBooking');?>" >
                        <i class="fa fa-check">  </i>  Completed Booking  
                    </a>
                  </div>
                  
              </div>  
            <div class="row">
              <div class="col-md-12  col-lg-12 col-sm-12">
                <?php if(!empty($listbooking)){ 
                        foreach($listbooking as $clb) {
                        $cid=$clb['ClubId'];
                         $clubdetails=$this->App->getPerticularRecord('tbl_vendor','Id',$cid);
                        
                        $clublayout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$cid);
                        $img=$clublayout[0]['MainImage'];
                        $NoofPax=$clublayout[0]['PerAdultPrice'];
                        $Cuisines=$clublayout[0]['Cuisines'];
                        $currentday= date('l');
                        $SundayFrom=$clublayout[0]['SundayFrom'];
                        $SundayTo=$clublayout[0]['SundayTo'];
                        $SundayFromClose=$clublayout[0]['SundayFromClose'];
                        $SundayToClose=$clublayout[0]['SundayToClose'];
                        $MondayFrom=$clublayout[0]['MondayFrom'];
                        $MondayTo=$clublayout[0]['MondayTo'];
                        $MondayFromClose=$clublayout[0]['MondayFromClose'];
                        $MondayToClose=$clublayout[0]['MondayToClose'];
                        $TuesdayFrom=$clublayout[0]['TuesdayFrom'];
                        $TuesdayTo=$clublayout[0]['TuesdayTo'];
                        $TuesdayToClose=$clublayout[0]['TuesdayToClose'];
                        $WednesdayFrom=$clublayout[0]['WednesdayFrom'];
                        $WednesdayTo=$clublayout[0]['WednesdayTo'];
                        $WednesdayFromClose=$clublayout[0]['WednesdayFromClose'];
                        $WednesdayToClose=$clublayout[0]['WednesdayToClose'];
                        $ThursdayFrom=$clublayout[0]['ThursdayFrom'];
                        $ThursdayTo=$clublayout[0]['ThursdayTo'];
                        $ThursdayFromClose=$clublayout[0]['ThursdayFromClose'];
                        $ThursdayToClose=$clublayout[0]['ThursdayToClose'];
                        $FridayFrom=$clublayout[0]['FridayFrom'];
                        $FridayTo=$clublayout[0]['FridayTo'];
                        $FridayFromClose=$clublayout[0]['FridayFromClose'];
                        $FridayToClose=$clublayout[0]['FridayToClose'];
                        $SaturdayFrom=$clublayout[0]['SaturdayFrom'];
                        $SaturdayTo=$clublayout[0]['SaturdayTo'];
                        $SaturdayFromClose=$clublayout[0]['SaturdayFromClose'];
                        $SaturdayToClose=$clublayout[0]['SaturdayToClose'];
                        if($currentday =='Monday'){
                        $dt= $MondayFrom.' - '.$MondayTo;
                        } elseif($currentday =='Tuesday'){
                        $dt= $TuesdayFrom.' - '.$TuesdayTo;
                        }
                        elseif($currentday =='Wednesday'){
                        $dt= $WednesdayFrom.' - '.$WednesdayTo;
                        }
                        elseif($currentday =='Thursday'){
                        $dt= $ThursdayFrom.' - '.$ThursdayTo;
                        }
                        elseif($currentday =='Friday'){
                        $dt= $FridayFrom.' - '.$FridayTo;
                        }
                        elseif($currentday =='Saturday'){
                        $dt= $SaturdayFrom.' - '.$SaturdayTo;
                        }
                        elseif($currentday =='Sunday'){
                        $dt= $SundayFrom.' - '.$SundayTo;
                        }
                        else{
                        $dt= $SundayFrom.' - '.$SundayTo;
                        }
                        if(($clb['BookingStatus']=='2') && ($clb['Status']=='1')){
                        
                ?>
                <div class="boxclx">
                  <div clas=" row">
                    <div class="col-lg-3 col-md-3 col-sm-12">
                      <div class="mk">
                        <a href="<?php echo base_url('front/detail/'.$clubdetails[0]['Slug']);?>">
                          <?php if($img!=''){ ?>
                          <img src="<?php echo base_url('assets/clubimage/'.$img);?>" alt="" class="ew">
                          <?php }else{ ?>
                          <img src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="" class="ew">
                          <?php } ?>
                        </a>
                      </div>
                    </div>
                    <div class="col-lg-9 col-md-9 col-sm-12">
                      <div class="col-md-12">
                        <a href="<?php echo base_url('front/detail/'.$clubdetails[0]['Slug']);?>">
                          <h3 class="titlecls">
                            <?php echo $clubdetails[0]['ClubName'];?>
                          </h3>
                        </a>
                         </div>
                          <div class="col-md-12">
                          <div class="col-md-4">
                        <p class="col"> 
                         
                          <h6 style="font-size: 16px;font-family: serif;text-transform: capitalize; font-weight: bold;color: navy;">Club Details :</h6>
                        <label class="ms">
                            <i class="fa fa-map-marker">
                            </i> 
                            
                             <?php echo $clubdetails[0]['Address']; ?>
                             <?php echo '<br>'.$clubdetails[0]['City'].'-'.$clubdetails[0]['PostCode'].' ,'.$clubdetails[0]['Country']; ?>
                          </label>
                          
                          <label class="ms">
                            <i class="fa fa-phone">
                            </i>                             
                             <?php echo $clubdetails[0]['Phone'];?> </label>
                      
                        </p>
                         
                        </div>
                             
                            <!----------------------------------------------->  
                              <div class="col-md-5">
                        <p class="col"> 
                         
                         
                       <h6 style="font-size: 16px;font-family: serif;text-transform: capitalize; font-weight: bold;color: navy;margin-top: 9px;">Booking Details :</h6>
                        <label class="ms">
                            <i class="fa fa-list">
                            </i> 
                            Booking No. :
                             <?php echo 'B00'.$clb['BookingNo']; ?>
                               </label>
                               
                          <label class="ms">
                            <i class="fa fa-clock-o">
                            </i> 
                            Date :
                             <?php echo $clb['BookingDate'] .' '.$clb['BookingTime']; ?>
                               </label>
                       
                          <label class="ms">
                            <i class="fa fa-user">
                            </i> 
                           No. of PAX :
                             <?php echo $clb['NoofPax']; ?>
                               </label>
                      
                          <label class="ms">
                             
                           Dining Preferences:
                             <?php echo $clb['DiningPreferences']; ?>
                               </label>
                        </p>
                         
                        </div>
                        <div class="col-md-3">
                            <a title="View" tooltip="View" href="<?php echo base_url('front/detail/'.$clubdetails[0]['Slug']);?>" class="btn bmp view"> <i class="fa fa-eye"></i> View Menu
                        </a>
                            
                         <a  title="Delete" tooltip="Delete"  onclick="deletecategory('<?php echo $clb['Id'];?>')" class="btn btn-warning cancle"><i class="fa fa-trash"></i> Delete Booking
                        </a>
                             <script>
                                 function deletecategory(id) {
                                   var r = confirm("Are You sure want to Delete this Request?");
                                   var url = "<?php echo base_url('customer/deletebooking/'.$clb['Id']);?>";
                                   if (r == true) {
                                       $.ajax({
                                           type: 'post',
                                           url: url,
                                           data: "id=" + id,
                                           success: function() {
                                               alert('Delete record Successfully');
                                               location.reload();
                                           }
                                       });
                                   }
                                 }
                              </script>
                          
                        
                        </div>
                        </div>
                  </div>
                </div>
                
              </div>
                        <?php } }
}else {
     echo '<div style="text-align:center;
     font-size: 24px;
    border: 1px solid #ccc;
    margin: 2% 0px;
    padding: 1%;
    width: 100%;">Booking Records not found.</div>';
}?>
              </div>
          </div>
      </div>
    </div>
    <!----------------------------------------------------------------------------------------------->
    <!----------------------------------------------------------------------------------------------->
    <!-- start single room details -->
  </div>
  </div>
</div>
</section>
<!-- end other detect room section -->
<!-- start contact us area -->
<!-- end contact us area -->
