	<?php  $sesdate = $this->session->userdata['bookingnewsession']['sesdates'];
			$sestime = $this->session->userdata['bookingnewsession']['sestime'];	
			$sesnoofmember = $this->session->userdata['bookingnewsession']['sesnoofmember'];?>

<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">  
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script> </head>
    

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>


 <?php /*if(!empty($success)){ ?>
<script type="text/javascript">
    $(window).on('load',function(){
        $('#myModal').modal('show');
    });
</script>
 <?php } */?>
 
 <?php 
 
$customerid=$this->session->userdata['customerauth']['Id']; 
if($customerid!=''){
	$customerdetil=$this->App->getPerticularRecord('tbl_customer','Id',$customerid);
	$cfname=$customerdetil[0]['FirstName'];
	$clname=$customerdetil[0]['LastName'];
	$cEmail=$customerdetil[0]['Email'];
	$cPhone=$customerdetil[0]['Phone'];
	
	}
 ?>
 
<!-- start breadcrumb -->
<section class="breadcrumb_main_area margin-bottom-80">
   <div class="container-fluid">
      <div class="row">
         <div class="breadcrumb_main nice_title">
            <h2> <?php echo $clubdetails[0]['ClubName'];?>
            </h2>
            <!-- special offer start -->
            <div class="special_offer_main">
               <div class="container">
                  
               </div>
            </div>
            <!-- end offer start -->
         </div>
      </div>
   </div>
</section>
<!-- end breadcrunb -->
<!-- start other detect room section -->
<section class="booking_area">
   <div class="container">
      <div class="booking">
         <div role="tabpanel" style="margin:2% 0px">
            <!-- Nav tabs -->
            <!-- Tab panes -->
            <div class="row">
               <!-------------------------------------------->
               <div class="col-md-4 col-lg-4 col-sm-4 col-sm-12">
                   <?php  $clubid=$clubdetails[0]['Id'];
                            $menucategory =$this->App->passwordChecking('tbl_foodcategory','ClubId','Status',$clubid,'1');
                           ?>
                   <div <?php if(!empty($menucategory)){ echo 'class="categorymenu"';}?> >
                        <?php if(!empty($menucategory)){
                            ?>
                                      <div class="bocxcsla">
                                        <h4 class="menutitlebook">Menu
                                        </h4>
                                        <?php 
                            $menucategory =$this->App->passwordChecking('tbl_foodcategory','ClubId','Status',$clubid,'1');
                            if(!empty($menucategory)){
                            foreach($menucategory as $category){
                            $cattit= $category['Title'];
                            $cid= $category['Id'];
                            echo '<h4 class="titmenu">'.$cattit.'</h4>';
                            $menucategory =$this->App->passwordChecking('tbl_fooditem','ClubId','CategoryId',$clubid,$cid);
                            if(!empty($menucategory)){
                            echo '<div class="ulc"><ul>';
                            foreach($menucategory as $menu){
                            if($menu['Status']=='1'){
                            $menutit=$menu['Title'];
                            $price=$menu['Price'];
                              echo '<li class="mlkbook">'.$menutit.' <span class="priceclsbook">    '.$price.' QAR</span></li>';
                            //echo '<tr ><td class="mlk">'.$menutit.' </td><td class="pricecls">    '.$price.' QAR</td></tr>';
                            }
                            }
                            echo '</ul></div>';
                            }
                            }
                            }
                            ?>
                                      </div>
                            <?php } ?> <br>
                       
                   </div>
                   
                   
                   
                   
                  
                   <h5 class="quick clsff" style="margin:10px 0px">Facebook Feed
            </h5>
           
       <div class="facebookfeedcls1">
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId={APP_ID}";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<div class="fb-page" 
     data-href="https://www.facebook.com/Cueserve/" 
     data-tabs="timeline" 
     data-small-header="false" 
     data-adapt-container-width="true" 
     data-hide-cover="false" 
     data-show-facepile="true">
  <div class="fb-xfbml-parse-ignore">
    <blockquote cite="https://www.facebook.com/facebook">
      <a href="https://www.facebook.com/facebook">Facebook</a>
    </blockquote>
  </div>
</div>
</div>

          
                   
               </div>
               <div class="col-md-8 frmbox col-lg-8 col-sm-8 col-sm-12" >
                  <div class="facilities_name clearfix boxm">
                     <div class="row">
                        <h5>Booking Table </h5>
                        <br>
                        <?php 
                           $vid=$clubdetails[0]['Id'];
                           $layout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$vid);
                           $SundayFrom=$layout[0]['SundayFrom'];
                           $SundayTo=$layout[0]['SundayTo'];
                           $SundayFromClose=$layout[0]['SundayFromClose'];
                           $SundayToClose=$layout[0]['SundayToClose'];
                           $MondayFrom=$layout[0]['MondayFrom'];
                           $MondayTo=$layout[0]['MondayTo'];
                           $MondayFromClose=$layout[0]['MondayFromClose'];
                           $MondayToClose=$layout[0]['MondayToClose'];
                           $TuesdayFrom=$layout[0]['TuesdayFrom'];
                           $TuesdayTo=$layout[0]['TuesdayTo'];
                           $TuesdayToClose=$layout[0]['TuesdayToClose'];
                           $WednesdayFrom=$layout[0]['WednesdayFrom'];
                           $WednesdayTo=$layout[0]['WednesdayTo'];
                           $WednesdayFromClose=$layout[0]['WednesdayFromClose'];
                           $WednesdayToClose=$layout[0]['WednesdayToClose'];
                           $ThursdayFrom=$layout[0]['ThursdayFrom'];
                           $ThursdayTo=$layout[0]['ThursdayTo'];
                           $ThursdayFromClose=$layout[0]['ThursdayFromClose'];
                           $ThursdayToClose=$layout[0]['ThursdayToClose'];
                           $FridayFrom=$layout[0]['FridayFrom'];
                           $FridayTo=$layout[0]['FridayTo'];
                           $FridayFromClose=$layout[0]['FridayFromClose'];
                           $FridayToClose=$layout[0]['FridayToClose'];
                           $SaturdayFrom=$layout[0]['SaturdayFrom'];
                           $SaturdayTo=$layout[0]['SaturdayTo'];
                           $SaturdayFromClose=$layout[0]['SaturdayFromClose'];
                           $SaturdayToClose=$layout[0]['SaturdayToClose'];
                           $NoofPax=$layout[0]['NoofPax'];
                           
                           ?>
                        <?php    if(!empty($error)){?>
                        <div class="alert alert-danger  alert-dismissible">
                           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                           </a>
                           <?php  echo $error;?>
                        </div>
                        <?php } ?>
                         <?php    if(!empty($success)){?>
                        <div class="alert alert-success  alert-dismissible">
                           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                           </a>
                           <?php  echo $success;?>
                        </div>
                        <?php } ?>
                        <form action="<?php echo base_url('booking-club/'.$clubdetails[0]['Slug']); ?>" class="account_form" method="post" name="bookingfrm" id="bookingfrm">
                           <div id="err" style="color:red">
                           </div>
                           <div id="err1" style="color:red">
                           </div>
                           <div class="row">
                              <div class="col-md-12">
                                 <p class="tag">1. Please select your booking details - <span style="color:navy;">Today Open Timing : <?php
                                    $currentday= date('l');
                                    if($currentday =='Monday'){
                                    echo $MondayFrom.' - '.$MondayTo;
                                    } elseif($currentday =='Tuesday'){
                                    echo $TuesdayFrom.' - '.$TuesdayTo;
                                    }
                                    elseif($currentday =='Wednesday'){
                                    echo $WednesdayFrom.' - '.$WednesdayTo;
                                    }
                                    elseif($currentday =='Thursday'){
                                    echo $ThursdayFrom.' - '.$ThursdayTo;
                                    }
                                    elseif($currentday =='Friday'){
                                    echo $FridayFrom.' - '.$FridayTo;
                                    }
                                    elseif($currentday =='Saturday'){
                                    echo $SaturdayFrom.' - '.$SaturdayTo;
                                    }
                                    elseif($currentday =='Sunday'){
                                    echo $SundayFrom.' - '.$SundayTo;
                                    }
                                    else{
                                    echo $SundayFrom.' - '.$SundayTo;
                                    } ?></span> <p style="color:#F14;">Available Table : <?php 
                                    
                                      $vendetails = $this->App->getPerticularRecord('tbl_vendor','Slug',$clubdetails[0]['Slug']);
                                      $venid = $vendetails[0]['Id'];
                                      $bookdet = $this->App->getPerticularRecord('tbl_clublayout', 'VendorId', $venid);
									  $totbooking = $bookdet[0]['NumTable'];
									  $sdatet = date('Y-m-d');
										$querycal= $this->db->query("select * from tbl_booking_calender where VendorId='".$venid."' and BookingDate='".$sdatet."' limit 1");
										$calendor = $querycal->result_array();
										$numrow = $querycal->num_rows();
										
										if($numrow > 0){
											$r = $calendor[0]['NobTable'];											
										}else{ $r ='0';}
										
										echo $totbooking-$r;
                                    
                                    ?></p>
                                 <div class="row">
                                    <div class="col-md-4"> 
                                       <input id="date" class=" form-control col-md-12 col-xs-12" placeholder="Booking Date *" type="text" name="date" value="<?php if($bookingdate!=''){ echo $bookingdate;}else{ echo $sesdate;} ?>" >
                                       <label class="errtag"><?php echo form_error('date'); ?></label>
                                   
      <script>
            $.noConflict();   
                $('#date').datepicker({
                    format: "yyyy-mm-dd",
                     startDate: new Date() 
                }); 
            
        </script> 
                                   
                                    </div>
                                    <script>
                                       function myFunction(){
                                       var v=$("#date").val();
                                       var cid="<?php echo $clubdetails[0]['Id'];?>";
                                       var url="<?php echo base_url('booking/gettime');?>";
                                       $.ajax({
                                       type: 'post',
                                       url: url,
                                       data: "date="+v+"&cid="+cid,
                                       success: function () {
                                       }
                                       });
                                       }
                                    </script>
                                    <div class="col-md-4"  id="timedisp1">
                                       <input type="text" id="myDatepicker1" class="form-control" type="text" name="myDatepicker1" placeholder="Booking Time *"  value="<?php if($myDatepicker1!=''){ echo $myDatepicker1; }else { echo $sestime;}?>">
                                    <label class="errtag"><?php echo form_error('myDatepicker1'); ?></label>
                                    </div>
                                    <div class="col-md-4">
                                       <select class="form-control col-md-12 col-xs-12" id="noofmember" name="noofmember" value="<?php if($noofmember!=''){ echo $noofmember; } else{ echo $sesnoofmember;} ?>">
                                       <option>--Select No. of Pax--</option>
                                          <?php for($i=1;$i<20;$i++){ ?>
                                          <option value="<?php echo $i;?>"><?php echo $i;?></option>
                                          <?php } ?>
                                       </select>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-12">
                                 <p class="tag">2. Enter guest details</p>
                                 <div class="row">
                                    <div class="col-md-6">                               
                                       <input id="firstname" class="form-control col-md-12 col-xs-12" placeholder="First Name *"  type="text" name="firstname" value="<?php if($firstname!=''){ echo $firstname;}else{ echo $cfname;}?>">
                                    <label class="errtag"><?php echo form_error('firstname'); ?></label>
                                    </div>
                                    <div class="col-md-6">
                                       <input id="lastname" class="form-control col-md-12 col-xs-12" placeholder="Last Name "  type="text" name="lastname" value="<?php if($lastname!=''){ echo $lastname;}else{ echo $clname;}?>">
                                    <label class="errtag"><?php echo form_error('lastname'); ?></label>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <script>
                                       function ValidatePhoneNo() {
                                         if ((event.keyCode > 47 && event.keyCode < 58) || event.keyCode == 43 || event.keyCode == 32)
                                           return event.returnValue;
                                         return event.returnValue = '';
                                       }
                                    </script>
                                    <div class="col-md-6">                               
                                       <input id="email" class="form-control col-md-12 col-xs-12" placeholder="Email ID *"  type="email" name="email" value="<?php if($email!=''){ echo $email;}else{ echo $cEmail; }?>">
                                    <label class="errtag"><?php echo form_error('email'); ?></label>
                                    </div>
                                    <div class="col-md-6">
                                        <input id="phone"   class="form-control col-md-12 col-xs-12" onkeypress="return ValidatePhoneNo()" placeholder="Phone Number *" type="text" name="phone" value="<?php if($phone!=''){ echo $phone;}else{ echo $cPhone;}?>">
                                   <label class="errtag"><?php echo form_error('phone'); ?></label>
                                    </div>
                                 </div>
                              </div>
                           </div>
                            <?php if($NoofPax=='1') { ?>
                           <div class="row">
                              <div class="col-md-12">
                                 <p class="tag">3. Set your dining preferences</p>
                                 <div class="col-md-6 col-sm-12 col-xs-12 col-lg-6">                               
                                    <label>Where would you like to be seated?</label>
                                 </div>
                                 <div class="col-md-6 col-sm-12 col-xs-12 col-lg-6">
                                    <input type="radio" name="diningprefer" id="diningprefer" checked value="indoor"> Indoor
                                    <input type="radio" name="diningprefer" id="diningprefer" checked value="outdoor"> Outdoor
                                 </div>
                              </div>
                           </div>
                            <?php } ?>
                           <div class="ln_solid">
                           </div>
                           <div class="form-group">
                              <div class="col-md-12 col-sm-12 col-xs-12 ">
                                 <button  class="btn btn-warning" style="text-transform: capitalize;" >Submit
                                 </button>
                                 <a href="<?php echo base_url('detail/'.$clubdetails[0]['Slug'])?>" class="btn btn-default"> Cancel</a>
                              </div>
                           </div>
                        </form>
                     </div>
                     <br><br>
                     <script>
                        //form validation rules
                        $("#bookingfrm").validate({
                          rules: {
                            date: "required",
                            myDatepicker1: "required",
                            noofmember: "required",
                            firstname: "required",
                           // lastname: "required",
                            phone: "required",
                            email: "required",
                          }
                          ,
                          messages: {
                            date: "Please enter Booking Date",
                            myDatepicker1: "Please enter Time",
                            noofmember: "Please enter No.of Pax",              
                            firstname: "Please enter First Name",
                           // lastname: "Please enter Last Name",
                            phone: "Please enter Phone",
                            email: "Please enter Email",
                          }
                          ,
                          submitHandler: function(form) {
                            form.submit();
                          }
                        }
                                                   );
                     </script>
                     
                     
                  </div>
               </div>
            </div>
        
         </div>
      </div>
   </div>
</section>
<script src="<?php echo base_url('assets');?>/vendors/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap -->

<!--<script src="<?php echo base_url('assets');?>/vendors/bootstrap/dist/js/bootstrap.min.js"></script>-->
<!-- FastClick -->
<script src="<?php echo base_url('assets');?>/vendors/fastclick/lib/fastclick.js"></script>
<!-- NProgress -->
<!-- bootstrap-daterangepicker -->
<script src="<?php echo base_url('assets');?>/vendors/moment/min/moment.min.js"></script>
<script src="<?php echo base_url('assets');?>/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- bootstrap-datetimepicker -->    
<script src="<?php echo base_url('assets');?>/vendors/bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>
<!-- Ion.RangeSlider -->
<script src="<?php echo base_url('assets');?>/vendors/jquery.inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
<!-- jQuery Knob -->
<!-- end other detect room section -->
<!-- start contact us area -->
<!-- end contact us area -->

<script>
   $('#myDatepicker1').datetimepicker({    format: 'hh:mm A' }  );
</script>
<style>
    td.day.disabled {
    color: steelblue;
    background: whitesmoke !important;
}
    label.errtag p {
    font-size: 14px;
    color: red;
}
.alert-danger p {
    color: #a94442;

}
   input, select {
   margin: 6px 0px;
   }label.error {
   color: red;
   font-size: 13px;
   }h6.titmenu {
    color: palegreen;    border-bottom: 1px solid;
    font-weight: bold;
    }h4.titmenu {
    font-size: 15px;
    color: orange;
    font-weight: bold;
    margin-top: 17px;
  }
  
   .categorymenu {
       background: url("<?php echo base_url('assets/menu/menu.jpg');?>") 90% 0%;
          /* padding: 15px;*/
    color: #fff;
   }
   .bocxcsla {
    background: rgba(0,0,0,0.5);
    padding: 9px;
    margin-top: 7px;
}


.col-md-12.mkl {
    display: inline-flex;
}.btn.btn-warning {
    height: 40px;
    padding: 10px 12px 9px 12px;
}button.btn.btn-default {
    height: 40px;
}
</style>

<!--------------------------------------------------->
<div class="modal fade" id="myModal" role="dialog">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;
                    </button>
                    <h4 class="modal-title" >OTP Verification for Booking Process
                    </h4>
                  </div>
                  <div class="modal-body">
                    <form id="demo-form2" method="post" class="form-horizontal form-label-left">
                      
                      <div id="errotp" style="color:red"></div>
                      <div id="sucresend" style="color:green"></div>
                      <div id="errresend" style="color:red"></div>
                      
                      <div class="form-group">
                        <div class="col-md-4 col-sm-6 col-xs-6 col-lg-4">
                          <input id="otpnum" class="form-control col-md-12 col-xs-12" placeholder="OTP Number" required="required" type="text" name="otpnum" >
<div class="row"><div class="col-md-12 mkl">
                       <button type="button" style="margin:0px 4px" class="btn btn-default" onclick="otpverify('<?php echo $bookingid;?>')">Verify
                          </button>
                          
                          <button type="button" class="btn btn-warning" onclick="resendotp('<?php echo $bookingid;?>')">Resend OTP
                          </button></div></div>
                        </div>
                      </div>
                      <div class="ln_solid">
                      </div>
                    </form>                
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close
                    </button>
                  </div>
                </div>
              </div>
            </div>
<script>
    function otpverify(id){
        var otp = $("#otpnum").val();
        if(otp!=''){
         var url="<?php echo base_url('booking/otpverify');?>";
         var rurl="<?php echo base_url('booking/bookingsuccess');?>"+'/'+id;
              $.ajax({
                type: 'post',
                dataType : 'json',
                url: url,
                data: "bookid="+id+"&otp="+otp,
                success: function (data) {
                 if(data=='1'){
                    //redirect success page
                    window.location.href=rurl;
                 }
                 if(data=='2'){
                    $('#errotp').html('Please enter OTP number').delay(3000).fadeOut();
                           
                }if(data=='3'){
                    $('#errotp').html('OTP Number not valid').delay(3000).fadeOut();
                           
                    
                }
              }
          });
        }else{
             $('#errotp').html('Please enter OTP number').delay(3000).fadeOut();
        }
    }
    
    function resendotp(id){
         var url="<?php echo base_url('booking/resendotp');?>";
              $.ajax({
                type: 'post',
                dataType : 'json',
                url: url,
                data: "bookid="+id,
                success: function (data) {
                 if(data=='1'){
                    //redirect success page
                   $('#sucresend').html('Send OTP Successfully.Please check your OTP.').delay(3000).fadeOut();
                 }
                 if(data=='2'){
                    $('#errresend').html('Booking details in correct.').delay(3000).fadeOut();
                           
                }
              }
          });
        
    
    }
</script>
