<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>

<!-- start breadcrumb -->
<section class="breadcrumb_main_area margin-bottom-80">
   <div class="container-fluid">
      <div class="row">
         <div class="breadcrumb_main nice_title">
            <h2> <?php echo $clubdetails[0]['ClubName'];?>
            </h2>
            <!-- special offer start -->
            <div class="special_offer_main">
               <div class="container">
                 
               </div>
            </div>
            <!-- end offer start -->
         </div>
      </div>
   </div>
</section>
<!-- end breadcrunb -->
<!-- start other detect room section -->
<section class="booking_area">
   <div class="container">
      <div class="booking">
         <div role="tabpanel" style="margin:2% 0px">
            <!-- Nav tabs -->
            <!-- Tab panes -->
            <div class="row">
               <!-------------------------------------------->
               <div class="col-md-4 col-lg-4 col-sm-4 col-sm-12">
                   <?php $clubid=$clubdetails[0]['Id'];
                            $menucategory =$this->App->passwordChecking('tbl_foodcategory','ClubId','Status',$clubid,'1');
                         ?>
                   <div <?php if(!empty($menucategory)){ echo 'class="categorymenu"';}?> >
                        <?php $clubid=$clubdetails[0]['Id'];
                            $menucategory =$this->App->passwordChecking('tbl_foodcategory','ClubId','Status',$clubid,'1');
                            if(!empty($menucategory)){
                            ?>
                                      <div class="bocxcsla">
                                        <h4 class="menutitle">Menu
                                        </h4>
                                        <?php 
                            $menucategory =$this->App->passwordChecking('tbl_foodcategory','ClubId','Status',$clubid,'1');
                            if(!empty($menucategory)){
                            foreach($menucategory as $category){
                            $cattit= $category['Title'];
                            $cid= $category['Id'];
                          echo '<h4 class="titmenu">'.$cattit.'</h4>';
                            $menucategory =$this->App->passwordChecking('tbl_fooditem','ClubId','CategoryId',$clubid,$cid);
                            if(!empty($menucategory)){
                             echo '<div class="ulc"><ul>';
                            foreach($menucategory as $menu){
                            if($menu['Status']=='1'){
                            $menutit=$menu['Title'];
                            $price=$menu['Price'];
                              echo '<li class="mlk">'.$menutit.' <span class="pricecls">   ₹ '.$price.'</span></li>';
                           // echo '<tr ><td class="mlk">'.$menutit.' </td><td class="pricecls">   ₹ '.$price.'</td></tr>';
                            }
                            }
                            echo '</ul></div>';
                            }
                            }
                            }
                            ?>
                                      </div>
                            <?php } ?> <br>
                       
                   </div>
               </div>
               <div class="col-md-8 frmbox col-lg-8 col-sm-8 col-sm-12" >
                  <div class="facilities_name clearfix boxm">
                     <div class="row">
                        <h5>Cancel Booking  </h5>
                        <br>
                        <?php 
                           $vid=$clubdetails[0]['Id'];
                           $layout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$vid);
                         
                           ?>
                        <?php    if(!empty($error)){?>
                        <div class="alert alert-danger  alert-dismissible">
                           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                           </a>
                           <?php  echo $error;?>
                        </div>
                        <?php } ?>
                         <?php    if(!empty($success)){?>
                        <div class="alert alert-success  alert-dismissible">
                           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                           </a>
                           <?php  echo $success;?>
                        </div>
                        <?php } ?>
                        <form action="<?php echo base_url('cancel-booking/'.$modify[0]['Id']); ?>" class="account_form" method="post" name="bookingfrm" id="bookingfrm">
                           <div id="err" style="color:red">
                           </div>
                           <div id="err1" style="color:red">
                           </div>
                           
                           <div class="row">
                              <div class="col-md-12">
                                 <p class="tag">Cancel booking Reason *</p>
                                 <div class="">
                                    <div class="col-md-12">                               
                                       <textarea id="cancelreason" class="form-control col-md-12 col-xs-12" placeholder="Cancel Reason"  name="cancelreason" ></textarea>
                                    </div>                                   
                                 </div>
                                
                              </div>
                           </div>
                            <br>
                           <div class="form-group">
                              <div class="col-md-12 col-sm-12 col-xs-12 ">
                                 <button  class="btn btn-warning" >Submit
                                 </button>
                                  <a  class="btn" href="<?php echo base_url('dashboard');?>">Cancel
                                 </a>
                              </div>
                           </div>
                        </form>
                     </div>
                     <br><br>
                     <script>
                        //form validation rules
                        $("#bookingfrm").validate({
                          rules: {
                            date: "required",
                            myDatepicker1: "required",
                            noofmember: "required",
                            firstname: "required",
                            lastname: "required",
                            phone: "required",
                            email: "required",
                          }
                          ,
                          messages: {
                            date: "Please enter Booking Date",
                            myDatepicker1: "Please enter Time",
                            noofmember: "Please enter No.of Pax",              
                            firstname: "Please enter First Name",
                            lastname: "Please enter Last Name",
                            phone: "Please enter Phone",
                            email: "Please enter Email",
                          }
                          ,
                          submitHandler: function(form) {
                            form.submit();
                          }
                        }
                                                   );
                     </script>
                    
                  </div>
               </div>
            </div>
        
         </div>
      </div>
   </div>
</section>
<script src="<?php echo base_url('assets');?>/vendors/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap -->
<!--<script src="<?php echo base_url('assets');?>/vendors/bootstrap/dist/js/bootstrap.min.js"></script>-->
<!-- FastClick -->
<script src="<?php echo base_url('assets');?>/vendors/fastclick/lib/fastclick.js"></script>
<!-- NProgress -->
<!-- bootstrap-daterangepicker -->
<script src="<?php echo base_url('assets');?>/vendors/moment/min/moment.min.js"></script>
<script src="<?php echo base_url('assets');?>/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- bootstrap-datetimepicker -->    
<script src="<?php echo base_url('assets');?>/vendors/bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>
<!-- Ion.RangeSlider -->
<script src="<?php echo base_url('assets');?>/vendors/jquery.inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
<!-- jQuery Knob -->
<!-- end other detect room section -->
<!-- start contact us area -->
<!-- end contact us area -->
<script>
   $('#myDatepicker1').datetimepicker({    format: 'hh:mm A' }  );
</script>
<style>
   input, select {
   margin: 6px 0px;
   }label.error {
   color: red;
   font-size: 13px;
   }
   
   .mlk {
    list-style: none;
    width: 26%;
    position: relative;
    font-size: 14px;
    text-transform: CAPITALIZE;
}
  .pricecls {
    color: yellow;
    position: absolute;
    left: 130px;    width: 100%;
  }
  h4.menutitle {
    color: #fff;
}
  
   .categorymenu {
       background: url("<?php echo base_url('assets/menu/menu.jpg');?>") 90% 0%;
           padding: 15px;
    color: #fff;
   }
   .bocxcsla {
    background: rgba(0,0,0,0.5);
    padding: 9px;
    margin: 0px;
}.facilities_name.clearfix.boxm {
    border: 1px solid #ccc;
    margin: 1% 0%;
    padding: 6%;
    border-radius: 5px;
    background: snow;
}


.col-md-12.mkl {
    display: inline-flex;
}.btn.btn-warning {
    height: 40px;
    padding: 10px 12px 9px 12px;
}button.btn.btn-default {
    height: 40px;
}
</style>

<!--------------------------------------------------->
<div class="modal fade" id="myModal" role="dialog">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;
                    </button>
                    <h4 class="modal-title" >OTP Verification for Booking Process
                    </h4>
                  </div>
                  <div class="modal-body">
                    <form id="demo-form2" method="post" class="form-horizontal form-label-left">
                      
                      <div id="errotp" style="color:red"></div>
                      <div id="sucresend" style="color:green"></div>
                      <div id="errresend" style="color:red"></div>
                      
                      <div class="form-group">
                        <div class="col-md-4 col-sm-6 col-xs-6 col-lg-4">
                          <input id="otpnum" class="form-control col-md-12 col-xs-12" placeholder="OTP Number" required="required" type="text" name="otpnum" >
<div class="row"><div class="col-md-12 mkl">
                       <button type="button" style="margin:0px 4px" class="btn btn-default" onclick="otpverify('<?php echo $bookingid;?>')">Verify
                          </button>
                          
                          <button type="button" class="btn btn-warning" onclick="resendotp('<?php echo $bookingid;?>')">Resend OTP
                          </button></div></div>
                        </div>
                      </div>
                      <div class="ln_solid">
                      </div>
                    </form>                
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close
                    </button>
                  </div>
                </div>
              </div>
            </div>
<script>
    function otpverify(id){
        var otp = $("#otpnum").val();
        if(otp!=''){
         var url="<?php echo base_url('customer/otpverify');?>";
         var rurl="<?php echo base_url('customer/bookingsuccess');?>"+'/'+id;
              $.ajax({
                type: 'post',
                dataType : 'json',
                url: url,
                data: "bookid="+id+"&otp="+otp,
                success: function (data) {
                 if(data=='1'){
                    //redirect success page
                    window.location.href=rurl;
                 }
                 if(data=='2'){
                    $('#errotp').html('Please enter OTP number').delay(3000).fadeOut();
                           
                }if(data=='3'){
                    $('#errotp').html('OTP Number not valid').delay(3000).fadeOut();
                           
                    
                }
              }
          });
        }else{
             $('#errotp').html('Please enter OTP number').delay(3000).fadeOut();
        }
    }
    
    function resendotp(id){
         var url="<?php echo base_url('booking/resendotp');?>";
              $.ajax({
                type: 'post',
                dataType : 'json',
                url: url,
                data: "bookid="+id,
                success: function (data) {
                 if(data=='1'){
                    //redirect success page
                   $('#sucresend').html('Send OTP Successfully.Please check your OTP.').delay(3000).fadeOut();
                 }
                 if(data=='2'){
                    $('#errresend').html('Booking details in correct.').delay(3000).fadeOut();
                           
                }
              }
          });
        
    
    }
</script>
