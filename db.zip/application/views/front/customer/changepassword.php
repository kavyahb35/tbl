<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript">
</script>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js">
</script>
<link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/custom.css">
<section class="section-account parallax bg-11">
  <div class="awe-overlay">
  </div>
  <div class="container">
    <div class="login-register">
      <div class="text text-center">
        <h2>Change Password
        </h2>
        <form action="<?php echo base_url('change-password');?>" method="post" class="account_form" name="loginfrm" id="loginfrm">
          <?php if(!empty($error)){?>
          <div class="alert alert-danger  alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
            </a>
            <?php  echo $error;?>
          </div>
          <?php } ?>
          <?php if(!empty($success)){?>
          <div class="alert alert-success  alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
            </a>
            <?php  echo $success;?>
          </div>
          <?php } ?>
          <div class="field-form">
            <input type="password" class="field-text" placeholder="Old Password*" name="oldpassword" id="oldpassword">
            <span class="view-pass">
              <i class="lotus-icon-view">
              </i>
            </span>
          </div>
          <div class="field-form">
            <input type="password" class="field-text" placeholder="New Password*" name="password" id="password">
            <span class="view-pass">
              <i class="lotus-icon-view">
              </i>
            </span>
          </div>
          <div class="field-form">
            <input type="password" class="field-text" placeholder="Confirm Password*" name="cpassword" id="cpassword">
            <span class="view-pass">
              <i class="lotus-icon-view">
              </i>
            </span>
          </div>
          <div class="field-form field-submit">
            <button class="btn btn-warning btn-md">Submit
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>
<script>
  //form validation rules
  $("#loginfrm").validate({
    rules: {
      password: "required",
      cpassword: "required",
      oldpassword:"required",
    }
    ,
    messages: {
	  oldpassword: "Please enter Old Password",
      password: "Please enter New Password",
      cpassword: "Please enter Confirm Password",
    }
    ,
    submitHandler: function(form) {
      form.submit();
    }
  }
                         );
</script>
<style>
  .alert.alert-danger p {
    color:#a94442;
  }
  label.error {
    color: red;
    font-size: 16px;
    font-weight: 300;
  }
  .alert {
    text-align: left;
    padding-left: 26px;
  }
  a.close {
    padding-right: 14px;
  }
  .awe-overlay {
    background-color: rgba(0,0,0,0.8);
  }
</style>
