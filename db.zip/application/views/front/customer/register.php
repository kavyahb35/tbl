<?php 

$client_id = '757471865886-5i5rima1m0sb8a9legols2b7fdhu1erp.apps.googleusercontent.com'; 
$client_secret = 'MkA7xF5-d2GBpOp1NmC2quQu';
$redirect_uri = 'https://www.tablefast.com/customer/checkgoogleplus';

 unset($_SESSION['access_token']);

$client = new Google_Client();
$client->setClientId($client_id);
$client->setClientSecret($client_secret);
$client->setRedirectUri($redirect_uri);
$client->addScope("email");
$client->addScope("profile");

$service = new Google_Service_Oauth2($client);


  
if (isset($_GET['code'])) {
  $client->authenticate($_GET['code']);
  $_SESSION['access_token'] = $client->getAccessToken();
  header('Location: ' . filter_var($redirect_uri, FILTER_SANITIZE_URL));
  exit;
}

if (isset($_SESSION['access_token']) && $_SESSION['access_token']) {
  $client->setAccessToken($_SESSION['access_token']);
} else {
  $authUrl = $client->createAuthUrl();
}

?>

     <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
  <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/custom.css">
   <?php if(!empty($success)){ ?>
<script type="text/javascript">
    /*$(window).on('load',function(){
        $('#myModal').modal('show');
    });*/
</script>
 <?php } ?>
        <section class="section-account parallax bg-11">
            <div class="awe-overlay"></div>
            <div class="container">
                <div class="login-register">
                    <div class="text text-center">
                        <h2>REGISTER FORM</h2>
      
                       
                        <form action="<?php echo base_url('sign-up'); ?>" class="account_form" method="post" name="registration" id="registration">
                            <div class="row">
                                                  
<?php if(!empty($error)){?>
  <div class="alert alert-danger  alert-dismissible">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
     <?php  echo $error;?>
  
</div><?php } ?>
<?php if(!empty($success)){?>
  <div class="alert alert-success  alert-dismissible">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
     <?php  echo $success;?>
  
</div><?php } ?>
               
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 ">
                                     <div class="field-form">
                                        <input type="text" class="field-text"  name="firstname" id="firstname" placeholder="First name*">
                                    </div>
                                    <div class="field-form">
                                        <input type="email" class="field-text"  name="email" id="email" placeholder="Email*">
                                    </div>
                                     <div class="field-form">
                                        <input type="password" class="field-text"  name="password" id="password" placeholder="Password*">
                                    </div>
                                      <script>
                                        function ValidatePhoneNo() {
                                                    if ((event.keyCode > 47 && event.keyCode < 58) || event.keyCode == 43 || event.keyCode == 32)
                                                            return event.returnValue;
                                                    return event.returnValue = '';
                                        }
                                    </script>
                                   
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 floatright">
                                    <div class="field-form"><?php //echo form_error('jabatan'); ?>
                                        <input type="text" class="field-text"  name='lastname' id="lastname" placeholder="Last name*">
                                    </div>
                                   <div class="field-form">
                                        <input type="text" onkeypress="return ValidatePhoneNo()" class="field-text"  name="phone" id="phone" placeholder="Phone Number*">
                                    </div>
                                    <div class="field-form">
                                        <input type="password" class="field-text"  name="cpassword" id="cpassword" placeholder="Confirm Password*">
                                    </div>
                                    
                                   
                                    
                                </div>
                                
                            </div>
                            
                            <div class="field-form field-submit">
                                <button class="btn btn-warning btn-md" >Sign up</button>
                                
                            </div>
                        </form>
                         <a href="<?php echo base_url('sign-in');?>" style="color:#fff">Sign In</a><br>
                          <br>
                       <p style="color:#fff">---------- OR ----------</p> <br>
                         <a class="google" title="Login with Google" href="<?php echo $authUrl; ?>"><img class="leftimg" src="https://b.zmtcdn.com/images/new_google_icon.png"> Continue with Google</a>   

   <!---------------------------------------------------------->
<?php $id = $this->session->userdata['customerauth']['Id'];
if($id==''){ ?>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v3.0&appId=343420756183797&autoLogAppEvents=1';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<div class="fb-login-button" data-max-rows="1" data-size="large" data-button-type="continue_with" data-show-faces="false" data-auto-logout-link="false" data-use-continue-as="false"></div>

<script>
  // This is called with the results from from FB.getLoginStatus().
  function statusChangeCallback(response) {
    console.log('statusChangeCallback');
    console.log(response);
    // The response object is returned with a status field that lets the
    // app know the current login status of the person.
    // Full docs on the response object can be found in the documentation
    // for FB.getLoginStatus().
    if (response.status === 'connected') {
      // Logged into your app and Facebook.
      testAPI();
    } else {
      // The person is not logged into your app or we are unable to tell.
      document.getElementById('status').innerHTML = 'Please log ' +
        'into this app.';
    }
  }

  // This function is called when someone finishes with the Login
  // Button.  See the onlogin handler attached to it in the sample
  // code below.
  function checkLoginState() {
    FB.getLoginStatus(function(response) {
      statusChangeCallback(response);
    });
  }

  window.fbAsyncInit = function() {
    FB.init({
      appId      : '{your-app-id}',
      cookie     : true,  // enable cookies to allow the server to access 
                          // the session
      xfbml      : true,  // parse social plugins on this page
      version    : 'v2.8' // use graph api version 2.8
    });

    // Now that we've initialized the JavaScript SDK, we call 
    // FB.getLoginStatus().  This function gets the state of the
    // person visiting this page and can return one of three states to
    // the callback you provide.  They can be:
    //
    // 1. Logged into your app ('connected')
    // 2. Logged into Facebook, but not your app ('not_authorized')
    // 3. Not logged into Facebook and can't tell if they are logged into
    //    your app or not.
    //
    // These three cases are handled in the callback function.

    FB.getLoginStatus(function(response) {
      statusChangeCallback(response);
    });

  };

  // Load the SDK asynchronously
  (function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = "https://connect.facebook.net/en_US/sdk.js";
    fjs.parentNode.insertBefore(js, fjs);
  }(document, 'script', 'facebook-jssdk'));

  // Here we run a very simple test of the Graph API after login is
  // successful.  See statusChangeCallback() for when this call is made.
  function testAPI() {
    console.log('Welcome!  Fetching your information.... ');
    FB.api('/me', function(response) {


 var cname = response.name;
var fbkey= response.id;

var ur="<?php echo base_url('customer/fbcallbk');?>";

   $.ajax({
        url: ur,
        dataType: 'json',
       
        data: "username="+cname +"&fbkey="+fbkey,                         
        type: 'post',
        success: function(data){

if(data==1){
window.location.href="https://www.tablefast.com/customer/fbprofile";
}
if(data=='1'){
window.location.href="https://www.tablefast.com/customer/fbprofile";
}
    
if(data=='2'){
window.location.href="https://www.tablefast.com/sign-in";
location.reload();

}        
   if(data=='3'){
location.reload();
window.location.href="https://www.tablefast.com/customer/fbprofile";
} 
     }
    });
      console.log('Successful login for: ' + response.name);
     /*document.getElementById('status').innerHTML =
        'Thanks for logging in, ' + response.name + '!';*/
    });
  }
</script>

<!--
  Below we include the Login Button social plugin. This button uses
  the JavaScript SDK to present a graphical Login button that triggers
  the FB.login() function when clicked.
-->
<fb:login-button scope="public_profile,email" onlogin="checkLoginState();">
</fb:login-button>

<div id="status">
</div>

<style> .fb-login-button.fb_iframe_widget {
    display: none;
}
.fb_iframe_widget {
    width: 44px;
    margin-top: 24px;
}</style>
<?php } ?>
<!------------------------------------------------------>

               
                        <script>
       
            //form validation rules
            $("#registration").validate({
                rules: {
                    lastname: "required",
                    phone: "required",
                    cpassword: "required",
                    firstname: "required",
                    email: "required",
                    password: "required",
                    },
                messages: {
                    firstname: "Please enter First Name",
                    lastname: "Please enter Last Name",
                    password:  {
                            required :"Please enter Password ",
                            minlength:"minimum length is 8",
                            maxlength:"maximum length is 12"
                                     }, 
                    cpassword:  {
                            required :"Please enter Password ",
                            minlength:"minimum length is 8",
                            maxlength:"maximum length is 12"
                                     }, 
                    phone:  {
                            required :"Please enter Phone Number",
                            minlength:"minimum length is 10",
                                     }, 
                    email: "Please enter Email",
                    

                },
                submitHandler: function(form) {
                   form.submit();
                }
            }); </script>
                        
                    </div>
                </div>
            </div>
        </section>
  <style>

.leftimg {
	    height: 25px;
    width: 25px;
	}
.google {
    color: #fff;
    margin-top: 20px;
    border: 1px solid #fff;
    padding: 16px;
    border-radius: 3px;
}
   .awe-overlay {
    background-color: rgba(0,0,0,0.8);
}
  .alert.alert-danger p { color:#a94442;
	}
    label.error {
    color: red;
    font-size: 16px;
    font-weight: 300;
    }
    .alert {
    text-align: left;
    padding-left: 26px;
    }
    a.close {
        padding-right: 14px;
    }
  </style>

<!--------------------------------------------------->
<div class="modal fade" id="myModal" role="dialog">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;
                    </button>
                    <h4 class="modal-title" >OTP Verification for Register Process
                    </h4>
                  </div>
                  <div class="modal-body">
                    <form id="demo-form2" method="post" class="form-horizontal form-label-left">
                      
                      <div id="errotp" style="color:red"></div>
                      <div id="sucresend" style="color:green"></div>
                      <div id="errresend" style="color:red"></div>
                      
                      <div class="form-group">
                        <div class="col-md-4 col-sm-6 col-xs-6 col-lg-4">
                          <input id="otpnum" class="form-control col-md-12 col-xs-12" placeholder="OTP Number" required="required" type="text" name="otpnum" >
<div class="row"><div class="col-md-12 mkl">
                       <button type="button" style="margin:0px 4px" class="btn btn-default" onclick="otpverify('<?php echo $iid;?>')">Verify
                          </button>
                          
                          <button type="button" class="btn btn-warning" onclick="resendotp('<?php echo $iid;?>')">Resend OTP
                          </button></div></div>
                        </div>
                      </div>
                      <div class="ln_solid">
                      </div>
                    </form>                
                  </div>
                  
                </div>
              </div>
            </div>
<script>
    function otpverify(id){
        var otp = $("#otpnum").val();
        if(otp!=''){
         var url="<?php echo base_url('customer/otpverify');?>";
         var rurl="<?php echo base_url('customer/dashboard');?>";
              $.ajax({
                type: 'post',
                dataType : 'json',
                url: url,
                data: "bookid="+id+"&otp="+otp,
                success: function (data) {
                 if(data=='1'){
                    //redirect success page
                    window.location.href=rurl;
                 }
                 if(data=='2'){
                    $('#errotp').html('Please enter OTP number').delay(3000).fadeOut();
                           
                }if(data=='3'){
                    $('#errotp').html('OTP Number not valid').delay(3000).fadeOut();
                           
                    
                }
              }
          });
        }else{
             $('#errotp').html('Please enter OTP number').delay(3000).fadeOut();
        }
    }
    
    function resendotp(id){
         var url="<?php echo base_url('customer/resendotp');?>";
              $.ajax({
                type: 'post',
                dataType : 'json',
                url: url,
                data: "bookid="+id,
                success: function (data) {
                 if(data=='1'){
                    //redirect success page
                   $('#sucresend').html('Send OTP Successfully.Please check your OTP.').delay(3000).fadeOut();
                 }
                 if(data=='2'){
                    $('#errresend').html('Booking details in correct.').delay(3000).fadeOut();
                           
                }
              }
          });
        
    
    }
</script>
<style>

    .col-md-12.mkl {margin:3px;
    display: inline-flex;
}.btn.btn-warning {
    height: 40px;
    padding: 10px 12px 9px 12px;
}button.btn.btn-default {
    height: 40px;
}
</style>
