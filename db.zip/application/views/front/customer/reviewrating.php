<link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
<!-- start breadcrumb -->
<section class="breadcrumb_main_area margin-bottom-80">
   <div class="container-fluid">
      <div class="row">
         <div class="breadcrumb_main nice_title">
            <h2> <?php echo $clubdetails[0]['ClubName'];?>
            </h2>
            <!-- special offer start -->
            <div class="special_offer_main">
               <div class="container">
                 
               </div>
            </div>
            <!-- end offer start -->
         </div>
      </div>
   </div>
</section>
<!-- end breadcrunb -->
<!-- start other detect room section -->
<section class="booking_area">
   <div class="container">
      <div class="booking">
         <div role="tabpanel" style="margin:2% 0px">
            <!-- Nav tabs -->
            <!-- Tab panes -->
            <div class="row">
               <!-------------------------------------------->
               <div class="col-md-8 frmbox col-lg-8 col-sm-8 col-sm-12" >
                  <div class="facilities_name clearfix boxm">
                     <div class="row">
                        <div class="  ">
                            <h5>My Review</h5><br>
                           <?php    if(!empty($error)){?>
                           <div class="alert alert-danger  alert-dismissible">
                              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                              </a>
                              <?php  echo $error;?>
                           </div>
                           <?php } ?>
                           <?php    if(!empty($success)){?>
                           <div class="alert alert-success  alert-dismissible">
                              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                              </a>
                              <?php  echo $success;?>
                           </div>
                           <?php } ?>
                           <form enctype="multipart/form-data" action="<?php echo base_url('customer/reviewrating/'.$bookingdetail[0]['Id']);?>" method='post' >
                              <div class="stars margin3"> 
                                 <input class="star star-5" id="star-5" type="radio" name="star" value="5" <?php if($reviewsdetails[0]['Review']=='5') { echo 'checked';}?>/>
                                 <label class="star star-5" for="star-5"></label>
                                 <input class="star star-4" id="star-4" type="radio" name="star"  value="4" <?php if($reviewsdetails[0]['Review']=='4') { echo 'checked';}?>/>
                                 <label class="star star-4" for="star-4"></label>
                                 <input class="star star-3" id="star-3" type="radio" name="star"  value="3" <?php if($reviewsdetails[0]['Review']=='3') { echo 'checked';}?>/>
                                 <label class="star star-3" for="star-3"></label>
                                 <input class="star star-2" id="star-2" type="radio" name="star"  value="2" <?php if($reviewsdetails[0]['Review']=='2') { echo 'checked';}?>/>
                                 <label class="star star-2" for="star-2"></label>
                                 <input class="star star-1" id="star-1" type="radio" name="star"  value="1" <?php if($reviewsdetails[0]['Review']=='1') { echo 'checked';}?>/>
                                 <label class="star star-1" for="star-1"></label>
                              </div>
                              <textarea rows='5' Placeholder="Write Your Reviews" required class="form-control col-md-12 col-xs-12" name="reviews" id="reviews" ><?php echo $reviewsdetails[0]['Reviewscomment']?></textarea>
                              <!-- <input type="file" name="userFiles[]" id="userFiles[]" accept="image/*" style="margin:1% 0%;" multiple>
                                 --> 
                              <input type="file" name="userFiles[]" accept="image/*" multiple>
                              <input type ="hidden" name="clubid" value="<?php echo $bookingdetail[0]['ClubId'] ?>" id="clubid">
                              <div class="imgbox">
                                  <div class="row">
                                  <?php $bookingid=$reviewsdetails[0]['BookingId'];
                                       $getimgs=$this->App->getPerticularRecord('tbl_reviewsimages','ReviewId',$bookingid);
                                       if(!empty($getimgs)){
                                           
                                           echo '<div class="boxc">';
                                           foreach($getimgs as $img){
                                               $i=$img['Image'];
                                               $imgid=$img['Id'];
                                               $bas=base_url('assets/reviewimg/'.$i);
                                               echo '<div class="col-md-1 col-sm-2 col-xs-2 col-lg-2" style="padding-right:0px;padding-top:4px">';
                                               echo '<div class="box">';
                                               echo '<p><a style="float: right;" onclick="deleteimg('.$imgid.')"><i class="fa fa-trash"></i></a><p>';
                                               echo '<img src="'.$bas.'" width="100%">';
                                               echo '</div>';
                                               echo '</div>';
                                           }
                                            echo '</div>';
                                       }
                                  ?>
                                  </div>
                              </div>
                              <script>
                              function deleteimg(id){
                                var r = confirm("Are You sure want to delete this Image?");
                                var url="<?php echo base_url('customer/deletegallery/')?>"+id;
                                if (r == true) {
                                  $.ajax({
                                    type: 'get',
                                    url: url,
                                    data: "id="+id,
                                    success: function () {
                                      alert('Delete Successfully');
                                      location.reload();
                                    }
                                  }
                                        );
                                }
                              }
                              </script>
                              <div class="margin3 " >
                                 <input type="submit" style="margin: 2% 0%;" name="submit" class="btn margin3" value="Save">
                              </div>
                           </form>
                        </div>
                        <br><br>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 col-lg-4 col-sm-4 col-sm-12">
                  <div class="categorymenu">
                     <?php $vid=$clubdetails[0]['Id'];
                        $layout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$vid);
                        $img=$layout[0]['MainImage'];
                        
                            $PerAdultPrice11=$layout[0]['PerAdultPrice'];
                        
                        $Description=$layout[0]['Description'];
                        if($img!=''){
                        $i=base_url('assets/clubimage/'.$img);
                        }else{
                        $i=base_url('assets/fronttheme/banner/TableFast-Banner-2.jpg');
                        } ?>
                     <h5 style="font-size: 20px;text-transform: capitalize;padding: 3% 5%;">Booking At</h5>
                     <div class="col-md-12 col-lg-12 col-sm-12 col-sm-12">
                        <div class="boxvc">
                           <p class="resimg"><img src="<?php echo $i;?>"></p>
                           <h6 class="h6c"><?php echo $clubdetails[0]['ClubName'];?></h6>
                           <p class="add"><i class="fa fa-map-marker"></i> <?php echo $clubdetails[0]['Address'].' , <br>'.$clubdetails[0]['City'].' - '.$clubdetails[0]['PostCode'].' , '.$clubdetails[0]['Country'];?></p>
                           <p class="add"><i class="fa fa-phone"></i> <?php echo $clubdetails[0]['Phone'].' , '.$clubdetails[0]['AlternativePhone'];?></p>
                           <h5 style="font-size: 20px;text-transform: capitalize">Booking Details</h5>
                           <p class="add"><label>DATE : </label> <?php echo $bookingdetail[0]['BookingDate'];?></p>
                           <p class="add"><label>GUESTS : </label> <?php echo $bookingdetail[0]['NoofPax'];?></p>
                           <p class="add"><label>TIME : </label> <?php echo $bookingdetail[0]['BookingTime'];?></p>
                           <h5 style="font-size: 20px;text-transform: capitalize">Guest Details</h5>
                           <p class="add"><label>NAME : </label> <?php echo $bookingdetail[0]['FirstName'].' '.$bookingdetail[0]['LastName'];?></p>
                           <p class="add"><label>PHONE NUMBER : </label> <?php echo $bookingdetail[0]['Phone'];?></p>
                           <p class="add"><label>Email : </label> <?php echo $bookingdetail[0]['Email'];?></p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<style>
    .box {
    border: 1px solid #ccc;
    padding: 2px;
     border-radius: 5px;
    border-style: double;
}
   textarea#reviews {
   margin: 2% 0%;
   }    
   div.stars {
   width: 270px;
   display: inline-block;
   }
   input.star { display: none; }
   label.star {
   float: right;
   padding: 5px;
   font-size: 36px;
   color: #444;
   transition: all .2s;
   }
   input.star:checked ~ label.star:before {
   content: '\f005';
   color: #FD4;
   transition: all .25s;
   }
   input.star-5:checked ~ label.star:before {
   color: #FE7;
   text-shadow: 0 0 20px #952;
   }
   input.star-1:checked ~ label.star:before { color: #F62; }
   label.star:hover { transform: rotate(-15deg) scale(1.3); }
   label.star:before {
   content: '\f006';
   font-family: FontAwesome;
   }
   .add label {
   padding: 0px;
   color: #3d5a77;
   text-transform: capitalize !important;
   }
   .centercls { text-align: center}
   .categorymenu {
   }.facilities_name.clearfix.boxm {
   border: 1px solid #ccc;
   margin: 1% 0%;
   padding: 6%;
   border-radius: 5px;
   background: snow;
   }
   .categorymenu {
   border: 1px solid #ccc;
   display: inline-block;
   padding: 9px;
   background: snow;
   }
   p.resimg img {
   width: 100%;
   border-radius: 4px;
   }h6.h6c {
   color: #000;
   font-size: 22px;
   }p.add {
   font-size: 13px;
   }
</style>
