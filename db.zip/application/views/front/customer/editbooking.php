<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">  
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script> </head>
    
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
 <?php /*if(!empty($success)){ ?>
<script type="text/javascript">
    $(window).on('load',function(){
        $('#myModal').modal('show');
    });
</script>
 <?php } */ ?>
<!-- start breadcrumb -->
<section class="breadcrumb_main_area margin-bottom-80">
   <div class="container-fluid">
      <div class="row">
         <div class="breadcrumb_main nice_title">
            <h2> <?php echo $clubdetails[0]['ClubName'];?>
            </h2>
            <!-- special offer start -->
            <div class="special_offer_main">
               <div class="container">
                  
               </div>
            </div>
            <!-- end offer start -->
         </div>
      </div>
   </div>
</section>
<!-- end breadcrunb -->
<!-- start other detect room section -->
<section class="booking_area">
   <div class="container">
      <div class="booking">
         <div role="tabpanel" style="margin:2% 0px">
            <!-- Nav tabs -->
            <!-- Tab panes -->
            <div class="row">
               <!-------------------------------------------->
               <div class="col-md-4 col-lg-4 col-sm-4 col-sm-12">
                    <?php $clubid=$clubdetails[0]['Id'];
                            $menucategory =$this->App->passwordChecking('tbl_foodcategory','ClubId','Status',$clubid,'1');
                         ?>
                   <div <?php if(!empty($menucategory)){ echo 'class="categorymenu"';}?> >
                        <?php $clubid=$clubdetails[0]['Id'];
                            $menucategory =$this->App->passwordChecking('tbl_foodcategory','ClubId','Status',$clubid,'1');
                            if(!empty($menucategory)){
                            ?>
                                      <div class="bocxcsla">
                                        <h4 class="menutitle">Menu
                                        </h4>
                                        <?php 
                            $menucategory =$this->App->passwordChecking('tbl_foodcategory','ClubId','Status',$clubid,'1');
                            if(!empty($menucategory)){
                            foreach($menucategory as $category){
                            $cattit= $category['Title'];
                            $cid= $category['Id'];
                             echo '<h4 class="titmenu">'.$cattit.'</h4>';
                            $menucategory =$this->App->passwordChecking('tbl_fooditem','ClubId','CategoryId',$clubid,$cid);
                            if(!empty($menucategory)){
                           echo '<div class="ulc"><ul>';
                            foreach($menucategory as $menu){
                            if($menu['Status']=='1'){
                            $menutit=$menu['Title'];
                            $price=$menu['Price'];
                              echo '<li class="mlk">'.$menutit.' <span class="pricecls">   ₹ '.$price.'</span></li>';
                           // echo '<tr ><td class="mlk">'.$menutit.' </td><td class="pricecls">   ₹ '.$price.'</td></tr>';
                            }
                            }
                            echo '</ul></div>';
                            }
                            }
                            }
                            ?>
                                      </div>
                            <?php } ?> <br>
                       
                   </div>
                   <h5 class="quick clsff" style="margin:10px 0px">Facebook Feed
            </h5>
           
       <div class="facebookfeedcls1">
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId={APP_ID}";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<div class="fb-page" 
     data-href="https://www.facebook.com/Cueserve/" 
     data-tabs="timeline" 
     data-small-header="false" 
     data-adapt-container-width="true" 
     data-hide-cover="false" 
     data-show-facepile="true">
  <div class="fb-xfbml-parse-ignore">
    <blockquote cite="https://www.facebook.com/facebook">
      <a href="https://www.facebook.com/facebook">Facebook</a>
    </blockquote>
  </div>
</div>
</div>
               </div>
               <div class="col-md-8 frmbox col-lg-8 col-sm-8 col-sm-12" >
                  <div class="facilities_name clearfix boxm">
                     <div class="row">
                        <h5>Booking Table </h5>
                        <br>
                        <?php 
                           $vid=$clubdetails[0]['Id'];
                           $layout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$vid);
                           $SundayFrom=$layout[0]['SundayFrom'];
                           $SundayTo=$layout[0]['SundayTo'];
                           $SundayFromClose=$layout[0]['SundayFromClose'];
                           $SundayToClose=$layout[0]['SundayToClose'];
                           $MondayFrom=$layout[0]['MondayFrom'];
                           $MondayTo=$layout[0]['MondayTo'];
                           $MondayFromClose=$layout[0]['MondayFromClose'];
                           $MondayToClose=$layout[0]['MondayToClose'];
                           $TuesdayFrom=$layout[0]['TuesdayFrom'];
                           $TuesdayTo=$layout[0]['TuesdayTo'];
                           $TuesdayToClose=$layout[0]['TuesdayToClose'];
                           $WednesdayFrom=$layout[0]['WednesdayFrom'];
                           $WednesdayTo=$layout[0]['WednesdayTo'];
                           $WednesdayFromClose=$layout[0]['WednesdayFromClose'];
                           $WednesdayToClose=$layout[0]['WednesdayToClose'];
                           $ThursdayFrom=$layout[0]['ThursdayFrom'];
                           $ThursdayTo=$layout[0]['ThursdayTo'];
                           $ThursdayFromClose=$layout[0]['ThursdayFromClose'];
                           $ThursdayToClose=$layout[0]['ThursdayToClose'];
                           $FridayFrom=$layout[0]['FridayFrom'];
                           $FridayTo=$layout[0]['FridayTo'];
                           $FridayFromClose=$layout[0]['FridayFromClose'];
                           $FridayToClose=$layout[0]['FridayToClose'];
                           $SaturdayFrom=$layout[0]['SaturdayFrom'];
                           $SaturdayTo=$layout[0]['SaturdayTo'];
                           $SaturdayFromClose=$layout[0]['SaturdayFromClose'];
                           $SaturdayToClose=$layout[0]['SaturdayToClose'];
                           $NoofPax=$layout[0]['NoofPax'];
                           
                           ?>
                        <?php    if(!empty($error)){?>
                        <div class="alert alert-danger  alert-dismissible">
                           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                           </a>
                           <?php  echo $error;?>
                        </div>
                        <?php } ?>
                         <?php    if(!empty($success)){?>
                        <div class="alert alert-success  alert-dismissible">
                           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                           </a>
                           <?php  echo $success;?>
                        </div>
                        <?php } ?>
                        <form action="<?php echo base_url('update-booking/'.$modify[0]['Id']); ?>" class="account_form" method="post" name="bookingfrm" id="bookingfrm">
                           <div id="err" style="color:red">
                           </div>
                           <div id="err1" style="color:red">
                           </div>
                           <div class="row">
                              <div class="col-md-12">
                                 <p class="tag">1. Please select your booking details - <span style="color:navy;"> Open Timimg : <?php
                                    $currentday= date('l');
                                    if($currentday =='Monday'){
                                    echo $MondayFrom.' - '.$MondayTo;
                                    } elseif($currentday =='Tuesday'){
                                    echo $TuesdayFrom.' - '.$TuesdayTo;
                                    }
                                    elseif($currentday =='Wednesday'){
                                    echo $WednesdayFrom.' - '.$WednesdayTo;
                                    }
                                    elseif($currentday =='Thursday'){
                                    echo $ThursdayFrom.' - '.$ThursdayTo;
                                    }
                                    elseif($currentday =='Friday'){
                                    echo $FridayFrom.' - '.$FridayTo;
                                    }
                                    elseif($currentday =='Saturday'){
                                    echo $SaturdayFrom.' - '.$SaturdayTo;
                                    }
                                    elseif($currentday =='Sunday'){
                                    echo $SundayFrom.' - '.$SundayTo;
                                    }
                                    else{
                                    echo $SundayFrom.' - '.$SundayTo;
                                    } ?></span>
                                 <div class="row">
                                    <div class="col-md-4"> 
                                       <input id="date" class="form-control col-md-12 col-xs-12" placeholder=" Date" type="text" name="date" value="<?php echo $modify[0]['BookingDate'];?>">
                                      <script>
            $.noConflict();   
                $('#date').datepicker({
                    format: "yyyy-mm-dd",
                     startDate: new Date() 
                }); 
            
        </script> 
                                    </div>
                                    <script>
                                       function myFunction(){
                                       var v=$("#date").val();
                                       var cid="<?php echo $clubdetails[0]['Id'];?>";
                                       var url="<?php echo base_url('booking/gettime');?>";
                                       $.ajax({
                                       type: 'post',
                                       url: url,
                                       data: "date="+v+"&cid="+cid,
                                       success: function () {
                                       }
                                       });
                                       }
                                    </script>
                                    <div class="col-md-4"  id="timedisp1">
                                       <input type="text" id="myDatepicker1" class="form-control" type="text" name="myDatepicker1" placeholder="Time From"  value="<?php echo $modify[0]['BookingTime'];?>">
                                    </div>
                                    <div class="col-md-4">
                                       <select class="form-control col-md-12 col-xs-12" id="noofmember" name="noofmember" >
                                          <?php for($i=2;$i<20;$i++){ ?>
                                          <option value="<?php echo $i;?>" <?php if($modify[0]['NoofPax']==$i){ echo 'selected=selected';} ?>><?php echo $i;?></option>
                                          <?php } ?>
                                       </select>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-12">
                                 <p class="tag">2. Enter guest details</p>
                                 <div class="row">
                                    <div class="col-md-6">                               
                                       <input id="firstname" class="form-control col-md-12 col-xs-12" placeholder="First Name"  type="text" name="firstname" value="<?php echo $modify[0]['FirstName'];?>">
                                    </div>
                                    <div class="col-md-6">
                                       <input id="lastname" class="form-control col-md-12 col-xs-12" placeholder="Last Name"  type="text" name="lastname" value="<?php echo $modify[0]['LastName'];?>">
                                    </div>
                                 </div>
                                 <div class="row">
                                    <script>
                                       function ValidatePhoneNo() {
                                         if ((event.keyCode > 47 && event.keyCode < 58) || event.keyCode == 43 || event.keyCode == 32)
                                           return event.returnValue;
                                         return event.returnValue = '';
                                       }
                                    </script>
                                    <div class="col-md-6">                               
                                       <input id="email" class="form-control col-md-12 col-xs-12" placeholder="Email ID"  type="email" name="email" value="<?php echo $modify[0]['Email'];?>">
                                    </div>
                                    <div class="col-md-6">
                                       <span style="      font-size: 18px;
                                             font-weight: bold;">+91</span> <input id="phone" readonly="" style="width:88%;float:right"onkeypress="return ValidatePhoneNo()" maxlength="10" class="form-control col-md-12 col-xs-12" placeholder="Phone" type="text" name="phone" value="<?php echo $modify[0]['Phone'];?>">
                                    </div>
                                 </div>
                              </div>
                           </div>
                            <?php if($NoofPax=='1') { ?>
                           <div class="row">
                              <div class="col-md-12">
                                 <p class="tag">3. Set your dining preferences</p>
                                 <div class="col-md-6 col-sm-12 col-xs-12 col-lg-6">                               
                                    <label>Where would you like to be seated?</label>
                                 </div>
                                 <div class="col-md-6 col-sm-12 col-xs-12 col-lg-6">
                                    <input type="radio" name="diningprefer" id="diningprefer" checked value="indoor" <?php if($modify[0]['DiningPreferences']=='indoor'){ echo 'checked';} ?> > Indoor
                                    <input type="radio" name="diningprefer" id="diningprefer" checked value="outdoor" <?php if($modify[0]['DiningPreferences']=='outdoor'){ echo 'checked';} ?>> Outdoor
                                 </div>
                              </div>
                           </div>
                            <?php } ?>
                           <div class="ln_solid">
                           </div>
                           <div class="form-group">
                              <div class="col-md-12 col-sm-12 col-xs-12 ">
                                 <button  class="btn btn-warning" >Submit
                                 </button>
                              </div>
                           </div>
                        </form>
                     </div>
                     <br><br>
                     <script>
                        //form validation rules
                        $("#bookingfrm").validate({
                          rules: {
                            date: "required",
                            myDatepicker1: "required",
                            noofmember: "required",
                            firstname: "required",
                          //  lastname: "required",
                            phone: "required",
                            email: "required",
                          }
                          ,
                          messages: {
                            date: "Please enter Booking Date",
                            myDatepicker1: "Please enter Time",
                            noofmember: "Please enter No.of Pax",              
                            firstname: "Please enter First Name",
                           // lastname: "Please enter Last Name",
                            phone: "Please enter Phone",
                            email: "Please enter Email",
                          }
                          ,
                          submitHandler: function(form) {
                            form.submit();
                          }
                        }
                                                   );
                     </script>
                    
                  </div>
               </div>
            </div>
        
         </div>
      </div>
   </div>
</section>
<script src="<?php echo base_url('assets');?>/vendors/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap -->
<!--<script src="<?php echo base_url('assets');?>/vendors/bootstrap/dist/js/bootstrap.min.js"></script>-->
<!-- FastClick -->
<script src="<?php echo base_url('assets');?>/vendors/fastclick/lib/fastclick.js"></script>
<!-- NProgress -->
<!-- bootstrap-daterangepicker -->
<script src="<?php echo base_url('assets');?>/vendors/moment/min/moment.min.js"></script>
<script src="<?php echo base_url('assets');?>/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- bootstrap-datetimepicker -->    
<script src="<?php echo base_url('assets');?>/vendors/bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>
<!-- Ion.RangeSlider -->
<script src="<?php echo base_url('assets');?>/vendors/jquery.inputmask/dist/min/jquery.inputmask.bundle.min.js"></script>
<!-- jQuery Knob -->
<!-- end other detect room section -->
<!-- start contact us area -->
<!-- end contact us area -->
<script>
   $('#myDatepicker1').datetimepicker({    format: 'hh:mm A' }  );
</script>
<style>
     td.day.disabled {
    color: steelblue;
    background: whitesmoke !important;
}
   input, select {
   margin: 6px 0px;
   }label.error {
   color: red;
   font-size: 13px;
   }h6.titmenu {
    color: palegreen;    border-bottom: 1px solid;
    font-weight: bold;
    }.mlk {
    list-style: none;
    width: 26%;
    position: relative;
    font-size: 14px;
    text-transform: CAPITALIZE;
}
  .pricecls {
    color: yellow;
    position: absolute;
    left: 130px;    width: 100%;
  }
  h4.menutitle {
    color: #fff;
}
   .categorymenu {
       background: url("<?php echo base_url('assets/menu/menu.jpg');?>") 90% 0%;
           
    color: #fff;
   }h4.titmenu {    
      font-size: 15px;
    color: orange;
    font-weight: bold;
    margin-top: 17px;
}
   .bocxcsla {
    background: rgba(0,0,0,0.5);
    padding: 9px;
    margin: 0px;
}.facilities_name.clearfix.boxm {
    border: 1px solid #ccc;
    margin: 1% 0%;
    padding: 6%;
    border-radius: 5px;
    background: snow;
}


.col-md-12.mkl {
    display: inline-flex;
}.btn.btn-warning {
    height: 40px;
    padding: 10px 12px 9px 12px;
}button.btn.btn-default {
    height: 40px;
}
</style>
