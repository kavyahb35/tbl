<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript">
</script>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js">
<?php $query= $this->db->query("select * from tbl_paypal_setting");
$resu= $query->result_array();
$rs= $resu[0]['Amt'];
?>
</script>
<!-- start breadcrumb -->
<section class="breadcrumb_main_area ">
  <div class="container-fluid">
    <div class="row">
      <div class="breadcrumb_main nice_title">
        <h2>Verify Successfully Payment
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
           
          </div>
        </div>         
        <!-- end offer start -->
      </div>
    </div>
  </div>            
</section>
<!-- end breadcrunb -->
<!-- start other detect room section -->
<section class="booking_area nobito">
  <div class="container">
    <div class="booking" style="text-align:center">
  
     <?php  if($error!='') { ?> 
      <p ><img src="<?php echo base_url('assets/fronttheme/customcss/cancel.png');?>" class="dfs"></p>
     <div class="alert alert-danger  alert-dismissible">
                           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                           </a>
                           <?php  echo $error;?>
                        </div>
     
    <?php } else {?>
    <div class="container">
<h4>Confirm your informations</h4>

<div class="col-md-3">
</div>
<div class="col-md-6 col-sm-12 col-xs-12 col-lg-12">
 <label style=" font-size:14px;   display: inline;"> <?= $firstName." ".$lastName .'<br>'; ?>
                          
                          </label>
                           <label style=" font-size:14px;   display: inline;"> <?= $email.'<br>'; ?>
                          
                          </label>
                          <label style=" font-size:14px;   display: inline;">You will pay <?php echo $rs;?> every Year.
                          </label>
                            <form action='<?php echo base_url('vendor/orderconfirm');?>' METHOD='POST' class="form-horizontal form-label-left">
<input type="submit" value="Confirm" class="btn btn-info"/>
</form>

</div>
<div class="col-md-3">
</div>


   
   
  
    <?php }?>
    </div>
    
  </div>
  </div>
</section>
<!-- end other detect room section -->
<!-- start contact us area -->
<!-- end contact us area -->
