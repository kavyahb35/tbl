<!-- start breadcrumb -->
<section class="breadcrumb_main_area margin-bottom-80">
   <div class="container-fluid">
      <div class="row">
         <?php $vid=$packages[0]['Id'];
            $img=$packages[0]['Image'];
            $Description=$packages[0]['ShortDetails'];
            if($img!=''){
                if (file_exists(FCPATH.'assets/package/'.$img)){
            $i=base_url('assets/package/'.$img);
                }
                else{
            $i=base_url('assets/fronttheme/banner/TableFast-Banner-2.jpg');
            }
            }else{
            $i=base_url('assets/fronttheme/banner/TableFast-Banner-2.jpg');
            } ?>
         <style>
            .march {
            background:url(<?php echo $i;?>);
            background-repeat: no-repeat;
            background-size:     cover;
            }
         </style>
         <div class="breadcrumb_main nice_title march">
            <h2>
               <?php echo $packages[0]['Title'];?>
            </h2>
            <!-- special offer start -->
            <div class="special_offer_main">
               <div class="container">
                  <div class="special_offer_sub">
                     <?php $vid=$packages[0]['Id'];
                        $img=$packages[0]['Image'];
                        $Description=$packages[0]['Description'];
                        if($img!=''){
                        $i=base_url('assets/package/'.$img);
                        }else{
                        $i=base_url('assets/fronttheme/banner/TableFast-Banner-2.jpg');
                        } ?>
                  </div>
               </div>
            </div>
            <!-- end offer start -->
         </div>
      </div>
   </div>
</section>
<!-- end breadcrunb -->
<div class="room_detail_main margin-bottom-55">
   <div class="container">
      <div class="row">
         <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
            <div class="deluxe_room_detail">
               <div class="section_title content-left margin-bottom-5" >
               <div style="margin-left:12px">
                  <h5 >
                     <?php echo $packages[0]['Title'];?> Detail  
                     <br> 
                     </h5>
                 
                 <p>
                  <?php echo $packages[0]['ShortDetails'];?> 
                 </p>
                 
                 </div>
                 
                 
                 <?php $clubid=$packages[0]['ClubId'];
                                       $menucategory =$this->App->passwordChecking('tbl_foodcategory','ClubId','Status',$clubid,'1');
                                       if(!empty($menucategory)){
                                       ?>
                                    <div class="bocxcsla">
                                       <h1 class="menutitle">Combo Package
                                       </h1>
                                       
                                       <?php
                                         $menucategory =$this->App->getPerticularRecord('tbl_packageitem', 'PackageId',$pid);
                                         if(!empty($menucategory)){
                                          foreach($menucategory as $category){
											 $ItemId= $category['ItemId'];
											  $menucategory =$this->App->getPerticularRecord('tbl_fooditem', 'Id',$ItemId);
											  if(!empty($menucategory)){
                                          echo '<div class="ulc"><ul>';
                                          foreach($menucategory as $menu){
											   $menutit=$menu['Title'];
                                          $price=$menu['Price'];
                                            echo '<li class="mlkdetail">'.$menutit.' <span class="priceclsdetail">    '.$price.' QAR'.'</span></li>';
                                         
										  }
										   echo '</ul></div>';
									  }
                                          
											 
										  }
									  }
                                        ?>
                                         <h1 class="menutitle"><?php echo $packages[0]['ActPrice'].' QAR';?>
                                       </h1>
                                       
                                       
                                       
                                       
                                       
                                       
                                       
                                       
                                       
                                       
                                       
                                       
                                       
                                       
                                       
                                       
                                       
                                       
                                       
                                     
                                    </div>
                                    <?php }?>
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 <style>
                           .bocxcsla {
                           background: url(https://tablefast.com/assets/menu/menu2.jpg) no-repeat 13px 19%;
                           padding: 24px;
                           color: #fff;
                           text-transform: capitalize;
                           font-size: 13px;
                           list-style: none;
                           }
                           h1.menutitle {
                           font-size: 35px;
                           color: #fff;
                           padding: 8px 0px;
                           /* border-bottom: 1px solid; */
                           font-family: cursive;
                           }
                           h4.titmenu {
                           font-size: 15px;
                           color: orange;
                           font-weight: bold;
                           margin-top: 17px;
                           }
                           /*  .mlk {
                           list-style: none;
                           width: 26%;
                           position: relative;    font-size: 12px;
                           }
                           .priceclsdetail {
                           color: yellow;
                           position: absolute;
                           left: 130px;    width: 100%;
                           } */
                           .room_book h6 {
                           color: #fff;
                           font-size: 23px;
                           line-height: 25px;
                           }
                           p {
                           color: #666666;
                           /* font-weight: normal; */
                           font-size: 14px;
                           font-family: inherit;
                           font-weight: normal;
                           }
                           label {
                           font-family: serif;
                           color: #ccc;
                           }
                           span.a {
                           COLOR: slategray;
                           }
                        </style>
                 
                 
                 
                 
                 
                 
                 
                 
                   </div>
            </div>
         </div>
         
         
         <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
           <h5 class="quick clsff">Facebook Feed
            </h5>
           
       <div class="facebookfeedcls1">
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId={APP_ID}";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<div class="fb-page" 
     data-href="https://www.facebook.com/Cueserve/" 
     data-tabs="timeline" 
     data-small-header="false" 
     data-adapt-container-width="true" 
     data-hide-cover="false" 
     data-show-facepile="true">
  <div class="fb-xfbml-parse-ignore">
    <blockquote cite="https://www.facebook.com/facebook">
      <a href="https://www.facebook.com/facebook">Facebook</a>
    </blockquote>
  </div>
</div>
</div>
         </div>
         </div>
   </div>
</div>
<!-- start contact us area -->
<!-- end contact us area -->
<style>
   img.smlcls {
   width: 27%;
   padding: 4px;
   height: 76px;
   border-radius: 49px;
   }
</style>
