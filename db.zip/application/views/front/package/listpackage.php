<?php $this->load->view('front/include/bootstraptable/header'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<?php if(!empty($error)){ ?>
<script type="text/javascript">
   $(window).on('load',function(){
       $('#myModal').modal('show');
   });
</script>
<?php } ?>
<section class="breadcrumb_main_area margin-bottom-80">
   <div class="container-fluid">
      <div class="row">
         <div class="breadcrumb_main nice_title">
            <h2>Combo Packages
            </h2>
            <!-- special offer start -->
            <div class="special_offer_main">
               <div class="container">
                  
               </div>
            </div>
            <!-- end offer start -->
         </div>
      </div>
   </div>
</section>
<section class="contact_mail_area margin-bottom-90">
   <div class="container">
      <div class="row">
         <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
               <div class="x_title">
                  <h2 style="font-size:20px "> Combo Packages
                  </h2>
                  <a  class="btn "  style="float:right;margin-bottom:10px;color:#63c2ea !important" href="<?php echo base_url('package/addpackage');?>" >
                  <i class="fa fa-plus"> 
                  </i> Add Combo Package  
                  </a>
                  <br>
                  <br>
                  <!------------------------------------>
                  <!-- Modal -->
                  </div>
               <!------------------------------------------->
            </div>
            <div id="updatediv"></div>
            <div class="x_content">
               <table id="datatable-buttons"  class="table table-striped table-bordered" cellspacing="0" width="100%">
                  <thead>
                     <tr>
                        <th>Action </th>
                        <th>Package Name  </th>
                        <th>Price  </th>
                        <th>Image    </th>
                        <th>Status </th>
                        <th>Date  </th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php if(!empty($listpackage)){
                        foreach($listpackage as $cat){ 
                        if($cat['Status']=='1'){ $s='Active';}else{ $s='Inactive';}
                        
                        $img=$cat['Image'];
                        if($img!=''){
                            $b=base_url('assets/package/'.$img);
                            $sdq="<img src='".$b."' width='100%' >";
                        }else{
                             $b=base_url('assets/fronttheme/customcss/dummyimg.jpg');
                        $sdq="<img src='".$b."' width='100%' >";
                        }
                        ?>
                     <tr>
                        <td>
                         <a  class="btn btn-dark pad-30" style="margin:3px 0px;background-color:#364B5F	" data-toggle="tooltip" title="View"  href="<?php echo base_url('package/viewpackage/'.$cat['Id'])?>">
                           <i class="fa fa-eye"> 
                           </i>  
                           </a> 
                           <a  class="btn pad-30" style="margin:3px 0px" data-toggle="tooltip" title="Edit"  href="<?php echo base_url('package/editpackage/'.$cat['Id'])?>">
                           <i class="fa fa-edit"> 
                           </i>  
                           </a> 
                           <a  class="btn btn-warning pad-30" style="margin:3px 0px;" data-toggle="tooltip" title="Delete" onclick="deletecategory('<?php echo $cat['Id']?>')">
                           <i class="fa fa-trash"> 
                           </i>  
                           </a> 
                        </td>
                        <td>
                           <?php echo  $cat['Title'];?>
                        </td>
                        <td>
                           <?php echo  $cat['ActPrice'].' QAR';?>
                        </td><td>
                           <?php echo  $sdq;?>
                        </td>
                        <td>
                           <?php echo $s;?>
                        </td>
                        <td>
                           <?php echo $cat['Created'];?>
                        </td>
                        
                     </tr>
                     <?php }
                        } ?>
                  </tbody>
               </table>
               <div class="row">
                  <nav class="text-center margin-top-65 margin-bottom-75">
                     <ul class="pagination">
                        <?php echo $links; ?>
                     </ul>
                  </nav>
               </div>
               <script>
                  function deletecategory(id){
                    var r = confirm("Are You sure want to Delete this Record?");
                    var url="<?php echo base_url('package/deletepackage');?>";
                    if (r == true) {
                      $.ajax({
                        type: 'post',
                        url: url,
                        data: "id="+id,
                        success: function () {
                          alert('Delete Package Successfully');
                          location.reload();
                        }
                      }
                            );
                    }
                  }
                  function updatecategory(id){
                    var url="<?php echo base_url('events/updateeventfrom');?>";
                    $.ajax({
                      type: 'post',
                      dataType : 'json',
                      url: url,
                      data: "id="+id,
                      success: function (data) {
                          alert(data);
                        $("#updatediv").html(data);
                        $('#myModal2').modal('show');
                      }
                    }
                          );
                  }
               </script>	
            </div>
         </div>
      </div>
   </div>
   </div>
   </div>
</section>
<script>
   function editcategory(){
     var s=$("#cattitle1 option:selected").val();
     var itemtitle1=$("#itemtitle1").val();
     var itemid=$("#itemid").val();
     var price1=$("#price1").val();
     var catstatus=$().val("#catstatus option:selected");
     var url="<?php echo base_url('food/edititem');?>";
     if(s=='' || itemtitle1=='' || price1==''){
       $("#err3").html("Please item title required");
     }
     else{
       $.ajax({
         type: 'post',
         dataType : 'json',
         url: url,
         data: "category="+s+"&itemtitle1="+itemtitle1+"&price1="+price1+"&itemid="+itemid+"&catstatus="+catstatus,
         success: function (data) {
           if(data=='1'){
             alert('Item successfully Update.');
             location.reload();
           }
           if(data=='2'){
             $('#err2').html('Item already Exist.');
           }
         }
       }
             );
     }
   }
</script>
<style>
   .alert-danger p {
   color: #a94442;
   }
</style>
<?php $this->load->view('front/include/bootstraptable/footer');?>
