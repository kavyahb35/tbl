<!-- start breadcrumb -->
<section class="breadcrumb_main_area margin-bottom-80">
  <div class="container-fluid">
    <div class="row">
      <div class="breadcrumb_main nice_title">
        <h2>Add Combo Package
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
            
          </div>
        </div>         
        <!-- end offer start -->
      </div>
    </div>
  </div>            
</section>
<!-- end breadcrunb -->
<!-- start other detect room section -->
<section class="booking_area">
  <div class="container">
    <div class="booking">
      <div role="tabpanel">
        <!-- Nav tabs -->
       
        <!-- Tab panes -->
        <div class="row">
          <!-------------------------------------------->
           <div class="col-md-2"></div>
          <div class="col-md-8" >
            <div class="facilities_name clearfix">
              <div class="row">
<h5>Add Combo Package</h5><br>
                <?php    if(!empty($error)){?>
                <div class="alert alert-danger  alert-dismissible">
                  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                  </a>
                  <?php  echo $error;?>
                </div>
                <?php } ?>
                <form name="eventfrm" id="eventfrm" method="post" action="<?php echo base_url("package/addpackage");?>" class="form-horizontal form-label-left" novalidate enctype="multipart/form-data">
                      
                        <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                          <input id="eventtitle" class="form-control col-md-12 col-xs-12" placeholder="Package name " required="required" type="text" name="eventtitle" value="<?php echo $title;?>">
                        </div>
                      </div>
                        <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                          <textarea class="form-control col-md-12 col-xs-12" placeholder="Facilities" name="description" id="description"><?php echo $description;?></textarea>
                        </div>
                      </div>
                       
                       <!---------------------------------------------------->
                       <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                        <label>Menu Information</label><br>
                        <?php if(!empty($listcategory)){
							
							foreach($listcategory as $cat){
								$tit = $cat['Title'];
								$catid = $cat['Id'];
								echo '<div class="col-md-4 col-sm-12 col-xs-12 padingcls">';
								echo '<div class="boxpack">';
								  echo '<h4 class="titmenu">'.$tit.'</h4>';
								    $menucategory =$this->App->passwordChecking('tbl_fooditem','ClubId','CategoryId',$vid,$catid);
                                          
                                          if(!empty($menucategory)){
                                          echo '<div ><ul class="ulc">';
                                          foreach($menucategory as $menu){
                                          if($menu['Status']=='1'){
                                           $menutit=$menu['Title'];
                                          $price=$menu['Price']; ?>
                                          <li><input type="checkbox" name="item[]" class="itemvox" value="<?php echo $menu['Id']; ?>" ><?php echo $menu['Title'] .'<span class="bkrop">  '.$menu['Price'].' QAR </span>'; ?>
                                        </li><?php   }
                                          }
                                          echo '</ul></div>';
                                          }
								echo '</div>';
								echo '</div>';
							}
							
							
							} ?>
                        </div>
                      </div>
                       <!------------------------------------------------------->
                        
                       
                        
                         <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <input type="file" name="uploadsfl" id="uploadsfl"  >
                            
                        </div>
                      </div>
                       
                      
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                          <input id="price" class="form-control col-md-12 col-xs-12" placeholder="Price" required="required" type="text" name="price" value="<?php echo $eventdetails[0]['Price']?>">
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <select class="form-control" name="status" >
                                <option value="1" <?php if($eventdetails[0]['Status']=='1'){ echo 'selected=selected';}?>>Active</option>
                                <option value="0" <?php if($eventdetails[0]['Status']=='0'){ echo 'selected=selected';}?>>Inactive</option>
                            </select>
                        </div>
                      </div>
                      <div class="ln_solid">
                      </div>
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12 ">
                          <button  class="btn btn-info" >Submit
                          </button>
                            
                        </div>
                      </div>
                    </form>
              </div>
                <div class="col-md-2"></div>
                
                
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- end other detect room section -->
<!-- start contact us area -->
<!-- end contact us area -->
<style>
span.bkrop {
    float: right;
    margin-right: 5px;
    color: #000;
    font-weight: bold;
    font-size: 14px;
}
.alert-danger p {
    color: #a94442;
}
ul.ulc {
    width: 100%;
    padding: 0px;
}
.ulc li {
    width: 100%;
    list-style: none;
    padding: 0px;
    margin: 2px;
}
.boxpack {
    border: 1px solid #ccc;margin:7px 0px;
   
}
h4.titmenu {
    font-size: 14px;
    border-bottom: 1px solid;
     background-color: lightgray;
}
</style>
