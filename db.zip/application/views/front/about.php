<!-- start breadcrumb -->
<?php $metsetting=$this->App->passwordChecking('tbl_information','Id','Status','1','1');
        
    ?>
<section class="breadcrumb_main_area margin-bottom-80">
  <div class="container-fluid">
    <div class="row">
      <div class="breadcrumb_main nice_title">
        <h2>About US
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
            
          </div>
        </div>         
        <!-- end offer start -->
      </div>
    </div>
  </div>            
</section>
<!-- end breadcrunb -->
<!-- start our room facilities -->
<section class="our_room_facilities_area">
  <div class="container">
    <div class="our_room_facilities margin-bottom-70">
      <div class="facilities_top_para">
        <p>
        <?php echo $metsetting[0]['Description'];?>
        </p>
      </div>
      
    </div>
  </div>
</section>
<!-- end our room facilities -->
<!-- start contact us area -->
<style>
    figure.uk-overlay1.uk-overlay-hover1 {
    width: 100%;
}
ul.whitel {
    list-style: none;
    display: inline-flex;
}
p.white {
    color: #fff;
}
li {
    padding: 5px;
}
    </style>
