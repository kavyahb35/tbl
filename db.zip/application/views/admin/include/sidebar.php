    <?php $setting=$this->App->getRecord('tbl_setting');
        $logo=$setting[0]['HeaderLogo'];
        $filename=base_url('assets/logo/'.$logo);
        if($logo!=''){
            if (file_exists(FCPATH.'assets/logo/'.$logo)){
             $logoimg=$logo;
            }else{
                $logoimg='header.png';
            }
        }else{
            $logoimg='header.png';
        }
    ?>
<div class="left_col scroll-view">
  
  <div class="clearfix">
  </div>
  <!-- menu profile quick info -->
  <div class="profile clearfix">
    <div class="profile_pic">
      <img src="<?php echo base_url('assets/logo/'.$logoimg);?>" alt="..." class="img-circle profile_img">
      
    </div>
    <div class="profile_info">
      <h2><?php $username = $this->session->userdata['adminauth']['username'];
      if($username!=''){
		echo 'Welcome : '.$username;  
	  }else{
		redirect('Admin');  
	  }
      ?>
      </h2>
     
    </div>
  </div>
  <!-- /menu profile quick info -->
  <br />
  <!-- sidebar menu -->
  <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
    <div class="menu_section">
      <h3>General
      </h3>
      <ul class="nav side-menu">
        <li>
          <a href="<?php echo base_url('admin/dashboard');?>">
            <i class="fa fa-dashboard">
            </i> Dashboard 
          </a>
        </li>
        <li>
          <a href="<?php echo base_url('admin/listClub');?>">
            <i class="fa fa-users">
            </i> Club / Vendor Manage
          </a> 
        </li>
        
        
        
        <li>
          <a href="<?php echo base_url('admin/listcategory');?>">
            <i class="fa fa-list">
            </i> Menu Category Manage
          </a> 
        </li>
        <li>
          <a href="<?php echo base_url('admin/listcategoryitem');?>">
            <i class="fa fa-list-ul">
            </i> Menu Item Manage
          </a> 
        </li>
        
      <li><a><i class="fa fa-calendar"></i>Events Manage <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
					<li><a href="<?php echo base_url('admin/listevents');?>">Manage Events</a></li>
					<li><a href="<?php echo base_url('admin/listeventtype');?>">Manage Event Type</a></li>
					<li><a href="<?php echo base_url('admin/listcompleteticketbook');?>">Completed Ticket Transaction </a></li>
					<li><a href="<?php echo base_url('admin/listpendingticketbook');?>">Pending Ticket Transaction</a></li>
					</ul>
        </li>
        
        
        
          <li>
          <a href="<?php echo base_url('admin/listfacility');?>">
            <i class="fa fa-table">
            </i> Facility Manage
          </a> 
        </li>
        
         <li>
          <a href="<?php echo base_url('admin/listcustomer');?>">
            <i class="fa fa-users">
            </i> Customer Manage
          </a> 
        </li>
        <li>
          <a href="<?php echo base_url('admin/listbooking');?>">
            <i class="fa fa-table">
            </i> Manage Booking
          </a> 
        </li>
        
        
        <li>
          <a href="<?php echo base_url('admin/listtransaction');?>">
            <i class="fa fa-table">
            </i> Manage Transaction
          </a> 
        </li>
        
        
        
        
        
        
        
        
        
        
        
        
             <li><a><i class="fa fa-wrench"></i> Manage Setting <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url('admin/listbanner');?>">Manage Banner</a></li>
                      <li><a href="<?php echo base_url('admin/listsetting');?>">Manage Site Setting </a></li>
 <li><a href="<?php echo base_url('admin/listmetapages');?>">Manage Meta Contents</a></li>

 <li><a href="<?php echo base_url('admin/listcontent');?>">Manage Page Contents</a></li>
 
 <li><a href="<?php echo base_url('admin/paypallistsetting');?>">Manage Paypal Setting Information</a></li>
                     
                    </ul>
        </li>
        <!-- <li>
          <a href="<?php echo base_url('admin/listbanner');?>">
            <i class="fa fa-picture-o">
            </i> Manage Banner
          </a> 
        </li>
        <li>
          <a href="<?php echo base_url('admin/listsetting');?>">
            <i class="fa fa-wrench">
            </i> Manage Setting
          </a> 
        </li>-->
        
        <li>
          <a href="<?php echo base_url('admin/listcontact');?>">
            <i class="fa fa-user">
            </i> Contact Manage
          </a> 
        </li>
        <li>
          <a href="<?php echo base_url('admin/listnewsletter');?>">
            <i class="fa fa-envelope">
            </i> Newsletter Manage
          </a> 
        </li>
        
        <!--<li>
          <a href="<?php echo base_url('admin/logout');?>">
            <i class="fa fa-tasks">
            </i> Customer Manage
          </a> 
        </li>
        <li>
          <a href="<?php echo base_url('admin/logout');?>">
            <i class="fa fa-clock-o">
            </i> booking Manage
          </a>
        </li>
        <li>
          <a href="<?php echo base_url('admin/logout');?>">
            <i class="fa fa-home">
            </i>Contact Manage
          </a>
        </li>-->
      </ul>
    </div>
  </div>
  <!-- /sidebar menu -->
  <!-- /menu footer buttons -->
  <div class="sidebar-footer hidden-small">
    
    <a data-toggle="tooltip" data-placement="top" title="Logout" href="<?php echo base_url('admin/logout');?>">
      <span class="glyphicon glyphicon-off" aria-hidden="true">
      </span>
    </a>
  </div>
  <!-- /menu footer buttons -->
</div>
</div>
<style>
.profile_pic {
    width: 100%;
    float: left;
}
.img-circle.profile_img {
    width: 85%;
    background: #fff;
    margin-left: 4%;
    z-index: 1000;
    position: inherit;
    margin-top: 20px;
    border: 1px solid 
}
.user-profile img {
    width: 68%;
    /* height: 29px; */
     border-radius: 0px;
    /* margin-right: 10px; */
    text-align: right;
    /* float: right; */
}
</style>
