<!DOCTYPE html>
<html lang="en">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <!-- Meta, title, CSS, favicons, etc. -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('assets/favicon/');?>favicon.ico">
      <title>Tablefast.com Admin | Dashboard</title>
      <!-- Bootstrap -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
      <!-- Font Awesome -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
      <!-- NProgress -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/nprogress/nprogress.css" rel="stylesheet">
      <!-- iCheck -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/iCheck/skins/flat/green.css" rel="stylesheet">
      <!-- bootstrap-wysiwyg -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
      <!-- Select2 -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/select2/dist/css/select2.min.css" rel="stylesheet">
      <!-- Switchery -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/switchery/dist/switchery.min.css" rel="stylesheet">
      <!-- starrr -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/starrr/dist/starrr.css" rel="stylesheet">
      <!-- bootstrap-daterangepicker -->
	  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">  
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>    
	   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script> 
			

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
      <!-- Custom Theme Style -->
      <link href="<?php echo base_url('assets/admintheme');?>/build/css/custom.min.css" rel="stylesheet">
   </head>
   <body class="nav-md">
      <div class="container body">
         <div class="main_container">
            <div class="col-md-3 left_col">
               <?php $this->load->view('admin/include/sidebar');?>
            </div>
            <!-- top navigation -->
            <?php $this->load->view('admin/include/header');?>
            <!-- /top navigation -->
            <!-- page content -->
            <div class="right_col" role="main">
               <div class="">
                  <div class="clearfix"></div>
                  <div class="row">
                     <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                           <div class="x_title">
                              <h3><?php if($id==''){ echo 'Add';}else { echo 'Edit';}?> Event Type</h3>
                           </div>
                           <div class="x_content">
                             
                              <form id="demo-form2" method="post" action="<?php echo base_url('admin/addevent');?>" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                                  <center><div class="form-group"> 
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                 
                                   <?php if(!empty($error)){?>
							<div class="alert alert-danger  alert-dismissible">
							  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
							  </a>
							  <?php  echo $error;?>
							</div>
							<?php } ?>
							 <?php if(!empty($success)){?>
							<div class="alert alert-success  alert-dismissible">
							  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
							  </a>
							  <?php  echo $success;?>
							</div>
							<?php } ?>
							</div></div></center>
							      
    
                                
							
                                 <div class="form-group">
                                    <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Club Name *</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                    <select  class="form-control col-md-7 col-xs-12" required="required" name="clubname" id="clubname" onchange="geteventtype()">
										<option>--Select Club Name--</option>
										<?php $clubrecords = $this->App->getRecord('tbl_vendor');
											   if(!empty($clubrecords)){
												  foreach($clubrecords as $clb){
													     $clbname = $clb['ClubName'];
													     $clbid = $clb['Id'];												     
													     ?>
													    <option value="<?php echo $clbid;?>" <?php if($eventtypedetails[0]['ClubId']==$clbid){ echo 'selected=selected';}?>><?php echo $clbname;?></option>													     
													     
													 <?php }   
											   }
										?>
                                    </select>
                                           </div>
                                 </div>
                                 
                                 
                                  <div class="form-group">
                                  <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Event Type *</label>
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                    
                                    <div class="m1" id="eventtypediv"></div>
                                  </div>
                                 </div>
                                 <div class="form-group">
                                    <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Title *</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                       <input id="middle-name" class="form-control col-md-7 col-xs-12" required="required" type="text" name="eventtitle" value="<?php echo $eventtypedetails[0]['Title']; ?>">
                                    </div>
                                 </div>
                                 <div class="form-group">
                                    <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Description *</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                    <textarea class="form-control col-md-7 col-xs-12" required="required" name="description"><?php echo $eventtypedetails[0]['ShortDescription']; ?></textarea>
                                     
                                    </div>
                                 </div>
                                   <div class="form-group">
                                    <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">No. of Days *</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                    <select  class="form-control col-md-7 col-xs-12"  id="days" name="days" onchange="divopenclose()">                                  
                                      <option value="">--Select No. of Days--</option>
                                          <option value="1">1</option>
                                          <option value="many">Many</option>
                                       </select>
                                    </div>
                                 </div>
                                 <script>
                                    function divopenclose(){
                                      
                                        var c = $("#days option:selected").val();
                                        if(c=='1'){
                                            $("#maydays").hide();
                                             $("#onedays").show();
                                        }
                                        if(c=='many'){
                                            $("#maydays").show();
                                             $("#onedays").hide();
                                        }
                                    }
                                 </script>
                                 
                                 <div id="maydays" style="display:none">
									   <div class="form-group" >
										<label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">No. of Days *</label>
										<div class="col-md-6 col-sm-6 col-xs-12">
										  <input id="nooddays" class=" form-control col-md-12 col-xs-12" placeholder="No. of Days " type="text" name="nooddays" >
										 
										</div>
									 </div>
									 <div class="form-group" >
										<label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Date *</label>
										<div class="col-md-3 col-sm-6 col-xs-6 col-lg-3 xdisplay_inputx form-group has-feedback">
										<input type="text" class="form-control has-feedback-left" id="date"  placeholder="From Date"  type="text" name="fromdate">
										<span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span> 
										</div>
										
										<div class="col-md-3 col-sm-6 col-xs-6 col-lg-3 xdisplay_inputx form-group has-feedback">
										 <input type="text" class="form-control has-feedback-left" id="date1"  placeholder="To Date" type="text" name="todate">
										<span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span> 
										</div>
									 </div>
                                </div>
                                 
                                 
                                 <div id="onedays" style="display:none">
                                    <div class="form-group">
                                       <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12"> Date *</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                          <input type="text" class="form-control has-feedback-left" id="date2"   placeholder="Special Date"  type="text" name="specialdate">
                                       </div>
                                    </div>
                                 </div>
                               
                                 
                                 <div class="form-group" >
										<label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Time *</label>
										<div class="col-md-3 col-sm-6 col-xs-6 col-lg-3 icon_arrow1">
									<input type="time" id="fromtime" class="form-control" type="text" name="fromtime" placeholder="Time From" required="required" >
										</div>
										
										<div class="col-md-3 col-sm-6 col-xs-6 col-lg-3 icon_arrow2">
										<input type="time" id="totime" class="form-control" type="text" name="totime" placeholder="Time To" required="required" >
										</div>
									 </div>
                                 
                                  <div class="form-group">
                                    <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Upload Image *</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                     <input type="file" name="uploadsfl" id="uploadsfl" accept="image/*" >  
                                      </div>
                                 </div>
                                 
                                   <script>
            $.noConflict();   
                $('#date').datepicker({
                    format: "yyyy-mm-dd",
                     startDate: new Date() 
                }); 
                 $('#date1').datepicker({
                    format: "yyyy-mm-dd",
                     startDate: new Date() 
                }); 
                 $('#date2').datepicker({
                    format: "yyyy-mm-dd",
                     startDate: new Date() 
                }); 
            
        </script> 
                                 
                                  <div class="form-group ">
                                         <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Status *</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                    <select  class="form-control col-md-7 col-xs-12" required="required" name="status">
										<?php if($id==''){ ?><option value="">--Select Status--</option><?php } ?>
										<option value="1" <?php if($eventtypedetails[0]['Status']=='1'){ echo 'selected=selected';}?>>Active</option>
										<option value="0" <?php if($eventtypedetails[0]['Status']=='0'){ echo 'selected=selected';}?>>Inactive</option>
									</select>
								</div>
                                 </div>
                                 
                                 
                                 
                                  
                                 
                                 <div class="ln_solid"></div>
                                 <div class="form-group">
                                    <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                       <!--  <button class="btn btn-primary" type="button">Cancel</button>
                                          <button class="btn btn-primary" type="reset">Reset</button>-->
                                       <input type="submit" class="btn btn-success" value="Submit" >
                                       <a class="btn btn-primary" href="<?php echo base_url('admin/listeventtype');?>">Cancel</a>
                                    </div>
                                 </div>
                              </form>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- /page content -->
            <!-- footer content -->
            <footer>
               <div class="pull-right">
                  Tabletast.com
               </div>
               <div class="clearfix"></div>
            </footer>
            <!-- /footer content -->
         </div>
      </div>
      <script>
         function geteventtype()
         {
			 var eventid = $("#clubname option:selected").val();
			 var url = "<?php echo base_url('admin/geteventype')?>";
			 $.ajax({
                        type: 'post',
                        dataType: 'json',
                        url: url,
                        data: "id="+eventid,
                        success: function (data) {
                          $("#eventtypediv").html(data);
                        }
                      });
		}
      </script>
<style>
td.day.disabled {
    background: #eaeaea !important;
}
input[type="checkbox"] {
    margin: 4px;
}
.m12 {
    width: 31% !important;
    display: inline-block;
}
.m1 {
    width: 100%;
    display: block;
}
   .alert-danger p {
   color: #a94442;
   }
</style>
      
      <!-- jQuery -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/jquery/dist/jquery.min.js"></script>
      <!-- Bootstrap -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
      <!-- FastClick -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/fastclick/lib/fastclick.js"></script>
      <!-- NProgress -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/nprogress/nprogress.js"></script>
      <!-- bootstrap-progressbar -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
      <!-- iCheck -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/iCheck/icheck.min.js"></script>
      <!-- bootstrap-daterangepicker -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/moment/min/moment.min.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
      <!-- bootstrap-wysiwyg -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/google-code-prettify/src/prettify.js"></script>
      <!-- jQuery Tags Input -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
      <!-- Switchery -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/switchery/dist/switchery.min.js"></script>
      <!-- Select2 -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/select2/dist/js/select2.full.min.js"></script>
      <!-- Parsley -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/parsleyjs/dist/parsley.min.js"></script>
      <!-- Autosize -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/autosize/dist/autosize.min.js"></script>
      <!-- jQuery autocomplete -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
      <!-- starrr -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/starrr/dist/starrr.js"></script>
      <!-- Custom Theme Scripts -->
      <script src="<?php echo base_url('assets/admintheme');?>/build/js/custom.min.js"></script>
   </body>
</html>
