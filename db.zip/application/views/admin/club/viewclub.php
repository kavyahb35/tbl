<!DOCTYPE html>
<html lang="en">
   <head>
      <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('assets/favicon/');?>favicon.ico">
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <!-- Meta, title, CSS, favicons, etc. -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Tablefast.com| Admin | View Club </title>
      <!-- Bootstrap -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
      <!-- Font Awesome -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
      <!-- NProgress -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/nprogress/nprogress.css" rel="stylesheet">
      <!-- iCheck -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/iCheck/skins/flat/green.css" rel="stylesheet">
      <!-- bootstrap-progressbar -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
      <!-- PNotify -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/pnotify/dist/pnotify.css" rel="stylesheet">
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/pnotify/dist/pnotify.buttons.css" rel="stylesheet">
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/pnotify/dist/pnotify.nonblock.css" rel="stylesheet">
      <!-- Custom Theme Style -->
      <link href="<?php echo base_url('assets/admintheme');?>/build/css/custom.min.css" rel="stylesheet">
   </head>
   <body class="nav-md">
      <div class="container body">
         <div class="main_container">
            <div class="col-md-3 left_col">
               <?php $this->load->view('admin/include/sidebar');?>
               <!-- top navigation -->
               <?php $this->load->view('admin/include/header');?>  
               <!-- /top navigation -->
               <!-- page content -->
               <div class="right_col" role="main">
                  <div class="">
                     <div class="clearfix"></div>
                     <div class="">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                           <div class="x_panel">
                              <div class="x_title">
                                 <h3>View Details : <?php echo $vendordetails[0]['ClubName'];?>
                                    <?php $status=$vendordetails[0]['Status']; if($status!='2'){?> 
                                    <a  class="btn btn-success" data-toggle="tooltip" title="Approve"  style="float:right"onclick='approvedclub(<?php echo $vendor['Id'];?>)'>
                                    <i class="fa fa-check"> Approve</i>  
                                    </a>
                                    <?php }?>
                                    <?php  if($status!='3'){?> 
                                    <a  class="btn btn-warning" data-toggle="tooltip" title="Reject"  style="float:right" onclick='rejectclub(<?php echo $vendor['Id'];?>)'>
                                    <i class="fa fa-remove"> Reject</i>  
                                    </a>
                                    <?php } if($status!='2'){?>
                                    <a  class="btn btn-danger" data-toggle="tooltip" title="Trash" style="float:right" onclick='deletetime(<?php echo $vendor['Id'];?>)'>
                                    <i class="fa fa-trash-o"> Trash </i>  
                                    </a>
                                    <?php } ?>
                                 </h3>
                                 <script>
                                    function approvedclub(id){
                                        var r = confirm("Are You sure want to Approve this Record?");
                                         var url="<?php echo base_url('admin/approveClub');?>";
                                        if (r == true) {
                                            $.ajax({
                                            type: 'post',
                                            url: url,
                                            data: "id="+id,
                                            success: function () {
                                              alert('Approved Club Successfully');
                                              location.reload();
                                            }
                                          });
                                        }
                                    }
                                    function rejectclub(id){
                                        var r = confirm("Are You sure want to Reject this Record?");
                                         var url="<?php echo base_url('admin/rejectClub');?>";
                                        if (r == true) {
                                            $.ajax({
                                            type: 'post',
                                            url: url,
                                            data: "id="+id,
                                            success: function () {
                                              alert('Rejected Club Successfully');
                                              location.reload();
                                            }
                                          });
                                        }
                                    }
                                    
                                    function deletetime(id){
                                        var r = confirm("Are You sure want to Trash this Record?");
                                         var url="<?php echo base_url('admin/trashClub');?>";
                                        if (r == true) {
                                            $.ajax({
                                            type: 'post',
                                            url: url,
                                            data: "id="+id,
                                            success: function () {
                                              alert('Trash Club Successfully');
                                              location.reload();
                                            }
                                          });
                                        }
                                    }
                                 </script>
                                 <div class="clearfix"></div>
                              </div>
                              <div class="x_content">
                                 <div class="" role="tabpanel" data-example-id="togglable-tabs">
                                    <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
                                       <li role="presentation" class="active"><a href="#tab_content1" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">Description</a>
                                       </li>
                                       <li role="presentation" class=""><a href="#tab_content2" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Menu</a>
                                       </li>
                                       <li role="presentation" class=""><a href="#tab_content3" role="tab" id="profile-tab2" data-toggle="tab" aria-expanded="false">Evens</a>
                                       </li>
                                       <li role="presentation" class=""><a href="#tab_content4" role="tab" id="profile-tab3" data-toggle="tab" aria-expanded="false">Reviews</a>
                                       </li>
                                       <li role="presentation" class=""><a href="#tab_content5" role="tab" id="profile-tab4" data-toggle="tab" aria-expanded="false">Photos</a>
                                       </li>
                                    </ul>
                                    <div id="myTabContent" class="tab-content">
                                       <div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="home-tab">
                                          <div class="col-md-12 col-sm-12 col-xs-12 profile_left">
                                             <?php  $vid=$vendordetails[0]['Id'];
                                                $layout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$vid);
                                                $img=$layout[0]['MainImage'];
                                                                                                 $Cuisines=$layout[0]['Cuisines'];
                                                                                                 $PerAdultPrice=$layout[0]['PerAdultPrice'];
                                                 $Description=$layout[0]['Description'];
                                                 
                                                 
                                                                                                         if($img!=''){
                                                                                                if (file_exists(FCPATH.'assets/clubimage/'.$img)){
                                                                                                    $i="<a href='".$is."' target='_blank'><img src='".base_url('assets/clubimage/'.$img)."' width='100%'></a>";
                                                                               
                                                                                                  }else{
                                                                                                $i="<img src='".base_url('assets/fronttheme/customcss/Dummyimage.jpg')."' width='100%'>";
                                                                                }
                                                                                            }else{
                                                                                                $i="<img src='".base_url('assets/fronttheme/customcss/Dummyimage.jpg')."' width='100%'>";
                                                                                }
                                                                                                         
                                                                                                         ?>
                                             <div class="row">
                                                <?php echo $i;?>
                                             </div>
                                             <br><br>
                                             <div class="row">
                                                <?php $que=$this->db->query("SELECT ROUND(AVG(Review),1) as totalcal FROM `tbl_reviews` WHERE ClubId='".$vid."'");
                                                   $res=$que->result_array();
                                                   $tto=$res[0]['totalcal'];?>
                                                <div class="rev leftrev"><?php echo $tto;?></div>
                                             </div>
                                             <div class="row">
                                                <div class="col-md-8 col-sm-6 col-xs-6 zemp">
                                                   <p>
                                                      <label style="color: #000;    font-size: 24px;">Cost For Two : 
                                                      <span style="    font-size: 13px;
                                                         color: navy;
                                                         font-family: sans-serif;
                                                         }">
                                                      <?php echo $PerAdultPrice.' QAR';?>
                                                      </span>
                                                      </label> 
                                                      <label style="color: #000;    font-size: 24px;">Cuisines : 
                                                      <span style="    font-size: 13px;
                                                         color: navy;
                                                         font-family: sans-serif;
                                                         }">
                                                      <?php echo $Cuisines;?>
                                                      </span>
                                                      </label> 
                                                   </p>
                                                   <?php echo $Description;?>
                                                   <br><br>
                                                   <label><span class="a"><?php echo 'Available Parking : </span>'.$layout[0]['AvailableParking'];
                                                      if($layout[0]['AvailableParking']=='paid'){
                                                       echo '<br><span class="a">Parking Price (Per hrs) : </span> Rs '.$layout[0]['PriceParkingPerhrs'];
                                                       }?></label>
                                                </div>
                                                <div class="col-md-4 col-sm-6 col-xs-6 wamp">
                                                   <p class="vencls">Vendor Details</p>
                                                   <label><?php echo $vendordetails[0]['FirstName'].' '.$vendordetails[0]['LastName'];?></label>
                                                   <label><i class="fa fa-envelope"></i> <?php echo $vendordetails[0]['Email'];?></label>
                                                   <label><i class="fa fa-phone"></i> <?php echo $vendordetails[0]['Phone'] .' , '.$vendordetails[0]['AlternativePhone'];?></label>
                                                   <br><br><label><i class="fa fa-map"></i> <?php echo $vendordetails[0]['Address'].' <br> '.$vendordetails[0]['City'].'-'.$vendordetails[0]['PostCode'].' ,'.$vendordetails[0]['Country']; ?></label>
                                                   <br><br><label><?php $AddressIfram=$vendordetails[0]['AddressIfram'];
                                                      if($AddressIfram!=''){ ?>
                                                   <iframe width="200" height="250" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAyhF2cCWevFm_T8iog0GqV3utCrfAbWYw&q='<?php echo $AddressIfram;?>'"></iframe>
                                                   <?php } ?>
                                                   </label>
                                                </div>
                                             </div>
                                             <div class="row">
                                                <div class="col-md-12">
                                                   <p class="vencls">Opening hours :  
                                                      <?php  
                                                         $vid=$vendordetails[0]['Id'];
                                                         $layout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$vid);
                                                         $SundayFrom=$layout[0]['SundayFrom'];
                                                         $SundayTo=$layout[0]['SundayTo'];
                                                         $SundayFromClose=$layout[0]['SundayFromClose'];
                                                         $SundayToClose=$layout[0]['SundayToClose'];
                                                         $MondayFrom=$layout[0]['MondayFrom'];
                                                         $MondayTo=$layout[0]['MondayTo'];
                                                         $MondayFromClose=$layout[0]['MondayFromClose'];
                                                         $MondayToClose=$layout[0]['MondayToClose'];
                                                         $TuesdayFrom=$layout[0]['TuesdayFrom'];
                                                         $TuesdayTo=$layout[0]['TuesdayTo'];
                                                         $TuesdayToClose=$layout[0]['TuesdayToClose'];
                                                         $WednesdayFrom=$layout[0]['WednesdayFrom'];
                                                         $WednesdayTo=$layout[0]['WednesdayTo'];
                                                         $WednesdayFromClose=$layout[0]['WednesdayFromClose'];
                                                         $WednesdayToClose=$layout[0]['WednesdayToClose'];
                                                         $ThursdayFrom=$layout[0]['ThursdayFrom'];
                                                         $ThursdayTo=$layout[0]['ThursdayTo'];
                                                         $ThursdayFromClose=$layout[0]['ThursdayFromClose'];
                                                         $ThursdayToClose=$layout[0]['ThursdayToClose'];
                                                         $FridayFrom=$layout[0]['FridayFrom'];
                                                         $FridayTo=$layout[0]['FridayTo'];
                                                         $FridayFromClose=$layout[0]['FridayFromClose'];
                                                         $FridayToClose=$layout[0]['FridayToClose'];
                                                         $SaturdayFrom=$layout[0]['SaturdayFrom'];
                                                         $SaturdayTo=$layout[0]['SaturdayTo'];
                                                         $SaturdayFromClose=$layout[0]['SaturdayFromClose'];
                                                         $SaturdayToClose=$layout[0]['SaturdayToClose'];
                                                         ?>
                                                      <?php 
                                                         $currentday= date('l');
                                                         if($currentday =='Monday'){
                                                         echo $MondayFrom.' - '.$MondayTo;
                                                         } elseif($currentday =='Tuesday'){
                                                         echo $TuesdayFrom.' - '.$TuesdayTo;
                                                         }
                                                         elseif($currentday =='Wednesday'){
                                                         echo $WednesdayFrom.' - '.$WednesdayTo;
                                                         }
                                                         elseif($currentday =='Thursday'){
                                                         echo $ThursdayFrom.' - '.$ThursdayTo;
                                                         }
                                                         elseif($currentday =='Friday'){
                                                         echo $FridayFrom.' - '.$FridayTo;
                                                         }
                                                         elseif($currentday =='Saturday'){
                                                         echo $SaturdayFrom.' - '.$SaturdayTo;
                                                         }
                                                         elseif($currentday =='Sunday'){
                                                         echo $SundayFrom.' - '.$SundayTo;
                                                         }
                                                         else{
                                                         echo $SundayFrom.' - '.$SundayTo;
                                                         }?>
                                                      <span style="float:right" class="tooltip4">See More
                                                      <span class="tooltiptext">
                                                      <label> Monday : 
                                                      <?php echo $MondayFrom; ?> To 
                                                      <?php echo $MondayTo;?>
                                                      <label>Thuesday : 
                                                      <?php echo $TuesdayFrom;?> To 
                                                      <?php echo $TuesdayTo; ?>
                                                      </label>
                                                      <label>Wednesday :
                                                      <?php echo $WednesdayFrom; ?> To 
                                                      <?php echo $WednesdayTo; ?>
                                                      </label>
                                                      <label>Thursday : 
                                                      <?php echo $ThursdayFrom; ?> To 
                                                      <?php echo $ThursdayTo; ?>
                                                      </label>
                                                      <label>Friday : 
                                                      <?php echo $FridayFrom; ?> To 
                                                      <?php echo $FridayTo; ?>
                                                      </label>
                                                      <label>Saturday : 
                                                      <?php echo $SaturdayFrom; ?> To
                                                      <?php echo $SaturdayTo; ?>
                                                      </label>
                                                      <label>Sunday : 
                                                      <?php echo $SundayFrom; ?> To 
                                                      <?php echo $SundayTo; ?>
                                                      </label>
                                                      </span>
                                                      </span>  
                                                   </p>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div role="tabpanel" class="tab-pane fade" id="tab_content2" aria-labelledby="profile-tab">
                                          <p>
                                             <?php 
                                                $menucategory =$this->App->passwordChecking('tbl_foodcategory','ClubId','Status',$clubidget,'1');
                                                if(!empty($menucategory)){
                                                ?>
                                          <div class="bocxcsla">
                                             <h1 class="menutitle">Menu
                                             </h1>
                                             <?php 
                                                $menucategory =$this->App->passwordChecking('tbl_foodcategory','ClubId','Status',$clubidget,'1');
                                                if(!empty($menucategory)){
                                                foreach($menucategory as $category){
                                                $cattit= $category['Title'];
                                                $cid= $category['Id'];echo '<h4 class="titmenu">'.$cattit.'</h4>';
                                                $menucategory =$this->App->passwordChecking('tbl_fooditem','ClubId','CategoryId',$clubidget,$cid);
                                                if(!empty($menucategory)){
                                                 echo '<div class="ulc"><ul>';
                                                foreach($menucategory as $menu){
                                                if($menu['Status']=='1'){
                                                $menutit=$menu['Title'];
                                                $price=$menu['Price'];
                                                  echo '<li class="mlk">'.$menutit.' <span class="pricecls">    '.$price.' QAR</span></li>';
                                                //echo '<tr ><td class="mlk">'.$menutit.' </td><td class="pricecls">    '.$price.' QAR</td></tr>';
                                                }
                                                }
                                                echo '</ul></div>';
                                                }
                                                }
                                                }
                                                ?>
                                          </div>
                                          <?php }else {
											  echo 'Menu items not found.';
											  } ?>
                                          </p>
                                       </div>
                                       <div role="tabpanel" class="tab-pane fade" id="tab_content3" aria-labelledby="profile-tab">
                                          <p>
                                             <?php $vid=$vendordetails[0]['Id'];
                                                $events=$this->App->getPerticularRecord('tbl_events', 'ClubId', $vid);
                                                 if(!empty($events)){
                                                foreach($events as $clb){
                                                 $img=$clb['Image'];
                                                ?>
                                          <div class="boxclx">
                                             <div clas=" row">
                                                <div class="col-lg-4 col-md-4 col-sm-12">
                                                   <div class="mk">
                                                      <a href="<?php echo base_url('front/eventdetail/'.$clb['Slug']);?>">
                                                      <?php if($img!=''){ 
                                                         if (file_exists(FCPATH.'assets/events/'.$img)){
                                                                                      
                                                         ?>
                                                      <img src="<?php echo base_url('assets/events/'.$img);?>" alt="" class="ew">
                                                      <?php }else{ ?>
                                                      <img src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="" class="ew">
                                                      <?php } }else{ ?>
                                                      <img src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="" class="ew">
                                                      <?php } ?>
                                                      </a>
                                                      <p class="col"> 
                                                         <label style="    font-family: serif;    color: #222;    font-weight: 300;">
                                                         <i class="fa fa-timer"></i>
                                                         <?php 
                                                            if($cat['NoofDays']=='1'){
                                                            $dt=$clb['OneDate'];
                                                            }else{ $dt=$clb['FromDate'].' To '.$clb['ToDate'];}
                                                            echo '<br>Date : '.$dt.'<br>'; echo 'Time '.$clb['TimeFrom'].' To '.$clb['TimeTo'];
                                                            echo '<br>Price :  '.$clb['Price'].' QAR';?>
                                                         </label>
                                                      </p>
                                                   </div>
                                                </div>
                                                <div class="col-lg-8 col-md-8 col-sm-12">
                                                   <div class="col-md-12">
                                                      <a href="<?php echo base_url('front/eventdetail/'.$clb['Slug']);?>">
                                                         <h3 class="titlecls">
                                                            <?php echo $clb['Title'];?>
                                                         </h3>
                                                      </a>
                                                      <p class="col"> 
                                                         <label style="    font-family: serif;    color: #000;    font-weight: 300;">
                                                         <?php  $big=$clb['Description'];
                                                            $small = substr($big, 0, 310);
                                                            echo  $small.'...'; ?>
                                                         </label>
                                                      </p>
                                                      <div class="floatright">
                                                         <a style="padding: 12px 31px;" href="<?php echo base_url('admin/eventdetail/'.$clb['Slug']);?>" class="btn btn-info ">Read More..
                                                         </a>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <?php }
                                             } else{
												echo 'Events not found'; 
												 }?>
                                          </p>
                                       </div>
                                       <div role="tabpanel" class="tab-pane fade" id="tab_content4" aria-labelledby="profile-tab">
                                          <p>
                                             <?php $clbid=$vendordetails[0]['Id'];
                                                $review=$this->App->getPerticularRecord('tbl_reviews','ClubId',$clbid);
                                                
                                                if(!empty($review)){
                                                echo '<div class="row">';
                                                echo '<div class="col-md-12">';
                                                
                                                foreach($review as $rev){
                                                    $clubid=$rev['ClubId'];
                                                    $BookingId=$rev['BookingId'];
                                                    $Review=$rev['Review'];
                                                    
                                                    if($Review=='5'){
                                                        $s='<span class="str"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></span>';
                                                    }elseif($Review=='4'){
                                                        $s='<span class="str"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-o"></i></span>';
                                                    }elseif($Review=='3'){
                                                        $s='<span class="str"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i></span>';
                                                    }elseif($Review=='2'){
                                                        $s='<span class="str"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i></span>';
                                                    }elseif($Review=='1'){
                                                        $s='<span class="str"><i class="fa fa-star"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i></span>';
                                                    }else{
                                                        $s='<span class="str"><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i></span>';
                                                    }
                                                    
                                                    
                                                    $comment=$rev['Reviewscomment'];
                                                    
                                                   $comment= substr($comment,0,220);
                                                    
                                                    $Created=$rev['Created'];
                                                    $Created = date("d-m-Y", strtotime($Created));
                                                    
                                                    $bookingdetails=$this->App->getPerticularRecord('tbl_booking','Id',$BookingId);
                                                    $customerid=$bookingdetails[0]['CustomerId'];
                                                    $cname=$bookingdetails[0]['FirstName'].' '.$bookingdetails[0]['LastName'];
                                                    
                                                    
                                                    $customerdetails=$this->App->getPerticularRecord('tbl_customer','Id',$customerid);
                                                    
                                                    $ProfileImage=$customerdetails[0]['ProfileImage'];
                                                    
                                                    if($ProfileImage!=''){
                                                        if (file_exists(FCPATH.'assets/customerprofile/'.$ProfileImage)){
                                                        $i=base_url('assets/customerprofile/'.$ProfileImage);                                                              
                                                        }
                                                        else{
                                                        $i=base_url('assets/fronttheme/customcss/dummy.png');
                                                       }
                                                    }else{
                                                        $i=base_url('assets/fronttheme/customcss/dummy.png');
                                                    }
                                                    
                                                    $cimagedetails=$this->App->getPerticularRecord('reviewsimages','ReviewId',$BookingId);
                                                    
                                                echo '<div class="containbox">';
                                                echo '<div class="row">';
                                                echo '<div class="col-md-12">';
                                                echo '<div class="col-md-2 col-sm-4 col-xs-4 col-lg-2">';
                                                echo '<div class="img-responsive imgcls"><img src="'.$i.'"></div>';
                                                echo '</div>';
                                                echo '<div class="col-md-6 col-sm-12 col-xs-12 col-lg-6">';
                                                echo '<div class="contitname">'.$cname.'</div>';
                                                 echo '<div class="contit stars"> '.$s.'
                                                 <span style="float:right"><i class="fa fa-clock-o"></i> '.$Created.'</span>
                                                 </div>';
                                                
                                                echo '</div>';
                                                 echo '<div class="col-md-4 col-sm-12 col-xs-12 col-lg-4">';
                                                  //echo '<div class="rev leftrev">'.$Review.'</div>';
                                                  ?>
                                          <div style="">
                                             <a  class="btn btn-danger" data-toggle="tooltip" title="Delete" onclick="deletereview('<?php echo $rev['Id']?>')">
                                             <i class="fa fa-trash"> 
                                             </i>  
                                             </a>
                                             <a  class="btn btn-info" data-toggle="tooltip" title="Read More" href="<?php echo base_url('admin/listreview/'.$BookingId);?>">
                                             <i class="fa fa-eye"> Read More
                                             </i>  
                                             </a>
                                          </div>
                                          <?php
                                             echo '</div>';
                                              echo '</div>';
                                              echo '<div class="col-md-12">';
                                             echo '<div class="commernt">'.$comment.'.. </div>';
                                             echo '</div>';
                                             
                                             echo '</div>';
                                             echo '</div>';
                                             
                                             
                                             }
                                             echo '</div>';
                                             echo '</div>';
                                             
                                             }else{
												 
												 echo 'Reviews not found';
												 }
                                             ?>
                                          </p>
                                       </div>
                                       <script>
                                          function deletereview(id) {
                                            var r = confirm("Are You sure want to Delete this Record?");
                                            var url = "<?php echo base_url('admin/deletereviews');?>";
                                            if (r == true) {
                                                $.ajax({
                                                    type: 'post',
                                                    url: url,
                                                    data: "id=" + id,
                                                    success: function() {
                                                        alert('Delete review Successfully');
                                                        location.reload();
                                                    }
                                                });
                                            }
                                          }
                                       </script>
                                       <div role="tabpanel" class="tab-pane fade" id="tab_content5" aria-labelledby="profile-tab">
                                          <p> 
                                          <div class="col-md-12">
                                             <?php  $vid=$vendordetails[0]['Id'];
                                                $layout=$this->App->getPerticularRecord('tbl_clubgallery','VendorId',$vid);
                                                $imsg=$layout[0]['Image'];
                                                if(!empty($layout)){
                                                   foreach($layout as $lay){ ?>
                                             <div class="col-md-3 col-sm-4 col-xs-4">
                                                <div class="sv">
                                                   <?php if($imsg!=''){
                                                      if (file_exists(FCPATH.'assets/clubgallery/'.$lay['Image'])){?>
                                                   <a href="<?php echo base_url('assets/clubgallery/'.$lay['Image']);?>" target="_black"> <img src="<?php echo base_url('assets/clubgallery/'.$lay['Image']);?>" width="100%" height="100px">
                                                   </a><?php } }?>
                                                </div>
                                             </div>
                                             <?php }
                                                }else{
													echo 'Photos not found';
													}
                                                ?>
                                          </div>
                                          </p>
                                       </div>
                                       <div role="tabpanel" class="tab-pane fade" id="tab_content6" aria-labelledby="profile-tab">
                                          <p>Booking History</p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="clearfix"></div>
                           <div class="clearfix"></div>
                        </div>
                        <div class="clearfix"></div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="clearfix"></div>
         </div>
         <!-- /page content -->
         <style>
            img.img-responsive.big {
            height: 60px;
            padding: 4px 0px;
            margin: 3px 3px;
            }
            .rev.leftrev {
            font-size: 15px;
            font-weight: bold;
            color: #fff;
            background: yellowgreen;
            width: 25px;
            text-align: center;
            border-radius: 3px;
            float: right;
            }
            i.fa.fa-star-o {
            color: coral;
            padding: 1px;
            }
            .floatright {
            float: right;
            }
            img.ew {
            height: 100px;width:100%
            }
            .boxclx {
            border: 1px solid #ccc;
            display: inline-block;
            background: whitesmoke;
            padding: 12px;
            border-radius: 8px;
            margin: 1%;
            width:98%
            }
            h3.titlecls {
            }
            .mg {
            border-top: 1px dotted;
            padding: 7px;
            margin-top: 15px;
            }
            .col-md-3.col-lg-3.col-sm-12.mds {
            background: #313a45;
            }
            input#clubname ,input#bookdate {
            background: transparent;
            border: none;
            color:#fff; font-size: 10px;
            }
            img.imgsearch {
            width: 34%;
            }
            .mop {
            border: 1px solid #ccc;
            background: #fff;
            padding: 2px;
            margin: 8px;
            }
            .bocxcsla {
            background: url(http://localhost/00csprojs/Tablefast/assets/menu/menu.jpg) no-repeat;
            padding: 24px;
            color: #fff;
            text-transform: capitalize;
            font-size: 12px;
            list-style: none;
            }
            h4.titmenu {
            font-size: 15px;
            color: blue;
            font-weight: bold;
            margin-top: 17px;
            }
            .mlk {
            list-style: none;
            width: 70%;    color: black;
            position: relative;    font-size: 13px;    font-weight: bold;
            }
            .pricecls {
            color: black;
            
                float: right;
            }
            .tooltip4 {
            position: relative;
            display: inline-block;
            border-bottom: 1px dotted black;
            }
            .tooltip4 .tooltiptext {
            visibility: hidden;
            width: 220px;
            background-color: #555;
            color: #fff;
            text-align: center;
            border-radius: 6px;
            padding: 5px 5px;
            position: absolute;
            z-index: 1;
            bottom: 125%;
            left: -10%;
            margin-left: -140px;
            opacity: 0;
            transition: opacity 0.3s;
            }
            .tooltip4 .tooltiptext::after {
            content: "";
            position: absolute;
            top: 100%;
            left: 50%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: #555 transparent transparent transparent;
            }
            .tooltip4:hover .tooltiptext {
            visibility: visible;
            opacity: 1;
            }
            .sd {
            border: 1px solid #ccc;
            padding: 12px;
            border-radius: 5px;
            }
            .sv {
            height: auto;
            width: 100%;
            border: 1px solid #ccc;
            margin: 6px 2px;
            padding: 5px;
            }.boxxls span {
            font-size: 12px;
            color: #000;
            font-weight: 300;
            text-transform: capitalize;
            }.containbox {
            border: 1px solid #ccc;
            margin: 2% 0%;
            padding: 2%;
            background: snow;
            }.img-responsive.imgcls img {
            border-radius: 65px;
            height: 65px;    width: 62px;
            }
            .commernt {
            padding: 7px;
            text-align: justify;
            font-size: 12px;
            color: #000;
            }
            .contitname {
            font-size: 20px;
            color: #000;
            text-transform: capitalize;
            line-height: 31px;
            }i.fa.fa-star {
            color: coral;
            padding: 1px;
            }
         </style>
         <!-- footer content -->
         <footer>
            <div class="pull-right">
               Tablefast.com
            </div>
            <div class="clearfix"></div>
         </footer>
         <!-- /footer content -->
      </div>
      </div>
      <div id="custom_notifications" class="custom-notifications dsp_none">
         <ul class="list-unstyled notifications clearfix" data-tabbed_notifications="notif-group">
         </ul>
         <div class="clearfix"></div>
         <div id="notif-group" class="tabbed_notifications"></div>
      </div>
      <!-- jQuery -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/jquery/dist/jquery.min.js"></script>
      <!-- Bootstrap -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
      <!-- FastClick -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/fastclick/lib/fastclick.js"></script>
      <!-- NProgress -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/nprogress/nprogress.js"></script>
      <!-- bootstrap-progressbar -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
      <!-- iCheck -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/iCheck/icheck.min.js"></script>
      <!-- PNotify -->
      <!-- Custom Theme Scripts -->
      <script src="<?php echo base_url('assets/admintheme');?>/build/js/custom.min.js"></script>
   </body>
</html>
