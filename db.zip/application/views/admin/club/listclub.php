<!DOCTYPE html>
<html lang="en">
   <head>
      <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('assets/favicon/');?>favicon.ico">
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <!-- Meta, title, CSS, favicons, etc. -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Tablefast | Admin</title>
      <!-- Bootstrap -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
      <!-- Font Awesome -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
      <!-- NProgress -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/nprogress/nprogress.css" rel="stylesheet">
      <!-- iCheck -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/iCheck/skins/flat/green.css" rel="stylesheet">
      <!-- Datatables -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">
      <!-- Custom Theme Style -->
      <link href="<?php echo base_url('assets/admintheme');?>/build/css/custom.min.css" rel="stylesheet">
   </head>
   <body class="nav-md">
      <div class="container body">
         <div class="main_container">
            <div class="col-md-3 left_col">
               <?php $this->load->view('admin/include/sidebar');?>
               <!-- top navigation -->
               <?php $this->load->view('admin/include/header');?>  <!-- /top navigation -->
               <!-- page content -->
               <div class="right_col" role="main">
                  <div class="">
                     <div class="page-title">
                        <div class="title_left">
                        </div>
                     </div>
                     <div class="clearfix"></div>
                     <div class="row">
                     </div>
                     <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                           <div class="x_title">
                              <h2>Manage Vendor / Club </h2>
                              <a class="btn btn-danger" data-toggle="tooltip" title="Trash Club List " style="float:right" href="<?php echo base_url('admin/trashClubList')?>" >
                              <i class="fa fa-trash-o"> </i> Trash Club List  
                              </a>
                              <a class="btn btn-primary" data-toggle="tooltip" title="Add Club " style="float:right" href="<?php echo base_url('admin/addclub')?>" >
                              <i class="fa fa-plus"> </i> Add Club  
                              </a>
                              <div class="clearfix"></div>
                           </div>
                           <div class="x_content">
                              <?php                              
                                 //  $usdetail = DB::select('select * from hrusers where UserId = ?',[$uid]);
                                 //   $uname=$usdetail[0]->Email; 
                                  ?>		
                              <table id="datatable-buttons" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                 <thead>
                                    <tr>
                                       <th>Action</th>
                                       <th>Club Name</th>
                                       <th>Banner Image</th>
                                       <th>Vendor Name</th>
                                       <th>Email Id</th>
                                       <th>Phone Number</th>
                                       <th>Location</th>
                                       <th>Status</th>
                                       <th>Created</th>
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <?php if(!empty($listvendor)){ 
                                       foreach($listvendor as $vendor){
                                        $vid=$vendor['Id'];
                                        $layout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$vid);
                                        $img=$layout[0]['MainImage'];
                                        if($img!=''){
                                       	 $i="<a href='".base_url('assets/clubimage/'.$img)."' target='_blank'><img src='".base_url('assets/clubimage/'.$img)."' width='100%'></a>";
                                        }else{
                                       	 $i="<img src='".base_url('assets/fronttheme/customcss/Dummyimage.jpg')."' width='100%'>";
                                       	 }
                                       	            
                                       	 $status=$vendor['Status'];
                                       	 if($status=='0'){ $s='In Draft';}elseif($status=='1'){ $s='Pending for Approval';}elseif($status=='2'){ $s='Approved';}elseif($status=='3'){ $s='Rejected';}elseif($status=='4'){ $s='In Trash';}else{}
                                        if($status!='4' && $vendor['Status']!='0'){
                                         ?>
                                    <tr>
                                       <td>
                                          <a  class="btn btn-info" data-toggle="tooltip" title="View"  href='<?php echo base_url('admin/viewclub/'.$vendor['Id']);?>'>
                                          <i class="fa fa-eye"> </i>  
                                          </a> 
                                           <a class="btn btn-primary" data-toggle="tooltip" title="Edit"  href='<?php echo base_url('admin/updatestep1/'.$vendor['Id']);?>'>
                                          <i class="fa fa-edit"> </i>  
                                          </a> 
                                          <?php  if($status!='2'){?> 
                                          <a  class="btn btn-success" data-toggle="tooltip" title="Approve"  onclick='approvedclub(<?php echo $vendor['Id'];?>)'>
                                          <i class="fa fa-check"> </i>  
                                          </a>
                                          <?php }?>
                                          <?php  if($status!='3'){?> 
                                          <a  class="btn btn-warning" data-toggle="tooltip" title="Reject"  onclick='rejectclub(<?php echo $vendor['Id'];?>)'>
                                          <i class="fa fa-remove"> </i>  
                                          </a>
                                          <?php } if($status!='2'){?>
                                          <a  class="btn btn-danger" data-toggle="tooltip" title="Trash"  onclick='deletetime(<?php echo $vendor['Id'];?>)'>
                                          <i class="fa fa-trash-o"> </i>  
                                          </a>
                                          <?php } ?>
                                           
                                            <a class="btn btn-dark" data-toggle="tooltip" title="Booking List"  href='<?php echo base_url('admin/perclubbooking/'.$vendor['Id']);?>'>
                                          <i class="fa fa-list"> </i>  
                                          </a> 
                                           <a class="btn btn-danger" data-toggle="tooltip" title="Available Table List"  href='<?php echo base_url('admin/listavailabeltable/'.$vendor['Id']);?>'>
                                          <i class="fa fa-eye"> </i>  
                                          </a> 
                                           
                                           
                                       </td>
                                       <td><?php echo $vendor['ClubName'];?></td>
                                       <td width="10%"><?php echo $i;?></td>
                                       <td><?php echo $vendor['FirstName'].' '.$vendor['LastName'];?></td>
                                       <td><?php echo $vendor['Email'];?></td>
                                       <td><?php echo $vendor['Phone'];?></td>
                                       <td><?php echo $vendor['City'].' ,'.$vendor['Country'];?></td>
                                       <td><?php echo $s;?></td>
                                       <td><?php echo $vendor['Created'];?></td>
                                    </tr>
                                    <?php } } } else { ?>
                                    <tr>
                                       <td colspan='9'>Result not found</td>
                                    </tr>
                                    <?php } ?>
                                 </tbody>
                              </table>
                              <script>
                                 function approvedclub(id){
                                     var r = confirm("Are You sure want to Approve this Record?");
                                      var url="<?php echo base_url('admin/approveClub');?>";
                                     if (r == true) {
                                         $.ajax({
                                         type: 'post',
                                         url: url,
                                         data: "id="+id,
                                         success: function () {
                                           alert('Approved Club Successfully');
                                           location.reload();
                                         }
                                       });
                                     }
                                 }
                                 function rejectclub(id){
                                     var r = confirm("Are You sure want to Reject this Record?");
                                      var url="<?php echo base_url('admin/rejectClub');?>";
                                     if (r == true) {
                                         $.ajax({
                                         type: 'post',
                                         url: url,
                                         data: "id="+id,
                                         success: function () {
                                           alert('Rejected Club Successfully');
                                           location.reload();
                                         }
                                       });
                                     }
                                 }
                                 
                                 function deletetime(id){
                                     var r = confirm("Are You sure want to Trash this Record?");
                                      var url="<?php echo base_url('admin/trashClub');?>";
                                     if (r == true) {
                                         $.ajax({
                                         type: 'post',
                                         url: url,
                                         data: "id="+id,
                                         success: function () {
                                           alert('Trash Club Successfully');
                                           location.reload();
                                         }
                                       });
                                     }
                                 }
                              </script>	
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- /page content -->
            <!-- footer content -->
            <?php $this->load->view('admin/include/footer');?>
            <!-- /footer content -->
         </div>
      </div>

      <style>
         tr.inactivecls {
         background: rgba(0,0,0,0.1);
         }
      </style>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/jquery/dist/jquery.min.js"></script>
      <!-- Bootstrap -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
      <!-- FastClick -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/fastclick/lib/fastclick.js"></script>
      <!-- NProgress -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/nprogress/nprogress.js"></script>
      <!-- iCheck -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/iCheck/icheck.min.js"></script>
      <!-- Datatables -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/jszip/dist/jszip.min.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/pdfmake/build/pdfmake.min.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/pdfmake/build/vfs_fonts.js"></script>
      <!-- Custom Theme Scripts -->
      <script src="<?php echo base_url('assets/admintheme');?>/build/js/custom.min.js"></script>

   </body>
</html>
