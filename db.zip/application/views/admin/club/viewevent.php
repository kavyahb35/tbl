<!DOCTYPE html>
<html lang="en">
   <head>
      <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('assets/favicon/');?>favicon.ico">
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <!-- Meta, title, CSS, favicons, etc. -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Tablefast.com| Admin | View Event </title>
      <!-- Bootstrap -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
      <!-- Font Awesome -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
      <!-- NProgress -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/nprogress/nprogress.css" rel="stylesheet">
      <!-- iCheck -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/iCheck/skins/flat/green.css" rel="stylesheet">
      <!-- bootstrap-progressbar -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
      <!-- PNotify -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/pnotify/dist/pnotify.css" rel="stylesheet">
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/pnotify/dist/pnotify.buttons.css" rel="stylesheet">
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/pnotify/dist/pnotify.nonblock.css" rel="stylesheet">
      <!-- Custom Theme Style -->
      <link href="<?php echo base_url('assets/admintheme');?>/build/css/custom.min.css" rel="stylesheet">
   </head>
   <body class="nav-md">
      <div class="container body">
         <div class="main_container">
            <div class="col-md-3 left_col">
               <?php $this->load->view('admin/include/sidebar');?>
               <!-- top navigation -->
               <?php $this->load->view('admin/include/header');?>  
               <!-- /top navigation -->
               <!-- page content -->
               <div class="right_col" role="main">
                  <div class="">
                     <div class="page-title">
                     </div>
                     <div class="clearfix"></div>
                     <div class="">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                           <div class="x_panel">
                              <div class="x_title">
                                 <h3>View Details : <?php echo $eventdetails[0]['Title'];?>
                                    <a  class="btn btn-danger" data-toggle="tooltip" title="Trash" style="float:right" onclick='deletetime(<?php echo $eventdetails[0]['Id'];?>)'>
                                    <i class="fa fa-trash-o"> Delete </i>  
                                    </a>
                                 </h3>
                                 <script>
                                    function deletetime(id){
                                        var r = confirm("Are You sure want to Trash this Record?");
                                         var url="<?php echo base_url('admin/deleteevent');?>";
                                         var rurl="<?php echo base_url('admin/viewclub/'.$eventdetails[0]['ClubId']);?>";
                                        if (r == true) {
                                            $.ajax({
                                            type: 'post',
                                            url: url,
                                            data: "id="+id,
                                            success: function () {
                                              alert('Delete Event Successfully');
                                             window.location.href=rurl;
                                            }
                                          });
                                        }
                                    }
                                 </script>
                                 <div class="clearfix"></div>
                              </div>
                              <div class="x_content">
                                 <div class="row" >
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                       <div class="deluxe_room_detail">
                                          <div class="section_title content-left margin-bottom-5">
                                             <?php 
                                                $img=$eventdetails[0]['Image'];
                                                if($img!=''){
                                                $i="<img src='".base_url('assets/events/'.$img)."' width='100%'>";
                                                }else{
                                                $i=$img;
                                                }?>
                                             <div class="row">
                                                <?php echo $i;?>
                                             </div>
                                             <h5>
                                                <?php echo $eventdetails[0]['Title'];?> Detail 
                                                <span class="price floatright"><?php echo '₹ '.$eventdetails[0]['Price'];?>
                                                </span> 
                                                <br> 
                                             </h5>
                                             <p class="col"> 
                                                <label style="    font-family: serif;    color: #222;    font-weight: 300;">
                                                <i class="fa fa-timer"></i>
                                                <?php 
                                                   if($eventdetails[0]['NoofDays']=='1'){
                                                   $dt=$eventdetails[0]['OneDate'];
                                                   }else{ $dt=$eventdetails[0]['FromDate'].' To '.$eventdetails[0]['ToDate'];}
                                                   echo '<br>Date : '.$dt.'<br>'; echo 'Time '.$eventdetails[0]['TimeFrom'].' To '.$eventdetails[0]['TimeTo'];
                                                   echo '<br>Price : ₹ '.$eventdetails[0]['Price'];?>
                                                </label>
                                             </p>
                                             <p class="col"> 
                                                <label style="    font-family: serif;    color: #000;    font-weight: 300;">
                                                <?php  echo $eventdetails[0]['Description'];
                                                   ?>
                                                </label>
                                             </p>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="clearfix"></div>
                           <div class="clearfix"></div>
                        </div>
                        <div class="clearfix"></div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="clearfix"></div>
         </div>
         <!-- /page content -->
         <style>
            .floatright {
            float: right;
            }
            img.ew {
            height: 100px;width:100%
            }
            .boxclx {
            border: 1px solid #ccc;
            display: inline-block;
            background: whitesmoke;
            padding: 12px;
            border-radius: 8px;
            margin: 1%;
            width:98%
            }
            h3.titlecls {
            }
            .mg {
            border-top: 1px dotted;
            padding: 7px;
            margin-top: 15px;
            }
            .col-md-3.col-lg-3.col-sm-12.mds {
            background: #313a45;
            }
            input#clubname ,input#bookdate {
            background: transparent;
            border: none;
            color:#fff; font-size: 10px;
            }
            img.imgsearch {
            width: 34%;
            }
            .mop {
            border: 1px solid #ccc;
            background: #fff;
            padding: 2px;
            margin: 8px;
            }
            .bocxcsla {
            background: url(http://localhost/00csprojs/Tablefast/assets/menu/menu2.jpg) no-repeat;
            padding: 24px;
            color: #fff;
            text-transform: capitalize;
            font-size: 12px;
            list-style: none;
            }
            h1.menutitle {
            font-size: 35px;
            color: #fff;
            padding: 8px 0px;
            /* border-bottom: 1px solid; */
            font-family: cursive;
            }
            h4.titmenu {
            font-size: 15px;
            color: orange;
            font-weight: bold;
            margin-top: 17px;
            }
            .mlk {
            list-style: none;
            width: 84%;
            }
            .pricecls {
            color: yellow;
            }
            .tooltip4 {
            position: relative;
            display: inline-block;
            border-bottom: 1px dotted black;
            }
            .tooltip4 .tooltiptext {
            visibility: hidden;
            width: 220px;
            background-color: #555;
            color: #fff;
            text-align: center;
            border-radius: 6px;
            padding: 5px 5px;
            position: absolute;
            z-index: 1;
            bottom: 125%;
            left: -10%;
            margin-left: -140px;
            opacity: 0;
            transition: opacity 0.3s;
            }
            .tooltip4 .tooltiptext::after {
            content: "";
            position: absolute;
            top: 100%;
            left: 50%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: #555 transparent transparent transparent;
            }
            .tooltip4:hover .tooltiptext {
            visibility: visible;
            opacity: 1;
            }
            .sd {
            border: 1px solid #ccc;
            padding: 12px;
            border-radius: 5px;
            }
            .sv {
            height: auto;
            width: 100%;
            border: 1px solid #ccc;
            margin: 6px 2px;
            padding: 5px;
            }.boxxls span {
            font-size: 12px;
            color: #000;
            font-weight: 300;
            text-transform: capitalize;
            }
         </style>
         <!-- footer content -->
         <footer>
            <div class="pull-right">
               Tablefast.com
            </div>
            <div class="clearfix"></div>
         </footer>
         <!-- /footer content -->
      </div>
      </div>
      <div id="custom_notifications" class="custom-notifications dsp_none">
         <ul class="list-unstyled notifications clearfix" data-tabbed_notifications="notif-group">
         </ul>
         <div class="clearfix"></div>
         <div id="notif-group" class="tabbed_notifications"></div>
      </div>
      <!-- jQuery -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/jquery/dist/jquery.min.js"></script>
      <!-- Bootstrap -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
      <!-- FastClick -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/fastclick/lib/fastclick.js"></script>
      <!-- NProgress -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/nprogress/nprogress.js"></script>
      <!-- bootstrap-progressbar -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
      <!-- iCheck -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/iCheck/icheck.min.js"></script>
      <!-- PNotify -->
      <!-- Custom Theme Scripts -->
      <script src="<?php echo base_url('assets/admintheme');?>/build/js/custom.min.js"></script>
   </body>
</html>
