<?php if(!empty($paymentdetails)){
		foreach($paymentdetails as $payment){
			$order_history_id = $payment['order_history_id'];
			$order_id = $payment['order_id'];
			$order_status_id = $payment['order_status_id'];
			$notify = $payment['notify'];
			$comment = $payment['comment'];
			$date_added = $payment['date_added'];
			
			$vendordetail =$this->App->getPerticularRecord('tbl_vendor', 'Id', $order_id);
			$name = $vendordetail[0]['FirstName'].' '.$vendordetail[0]['LastName'];
			$clubname = $vendordetail[0]['ClubName'];
			$City = $vendordetail[0]['City'];
			$Country = $vendordetail[0]['Country'];
			$Phone = $vendordetail[0]['Phone'];
			$Address = $vendordetail[0]['Address'];
			$clubname = $vendordetail[0]['ClubName'];
			$clubname = $vendordetail[0]['ClubName'];
			
			$rec =  $this->App->getRecord('tbl_paypal_setting');
			$amt =  $rec[0]['Amt'];
			
		}
	}?>

<!DOCTYPE html>
<html lang="en">
   <head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<!-- Meta, title, CSS, favicons, etc. -->
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('assets/favicon/');?>favicon.ico">
		<title>Tablefast.com | Invoice</title>
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap/dist/css/bootstrap.css">
		<!-- Bootstrap -->
		<link href="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
		<!-- Font Awesome -->
		<link href="<?php echo base_url('assets/admintheme');?>/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
		<link href="<?php echo base_url('assets/admintheme');?>/build/css/custom.min.css" rel="stylesheet">
		<script src="<?php echo base_url('assets/admintheme');?>/vendors/jquery/dist/jquery.min.js"></script>      <!-- Bootstrap -->
		<script src="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
		<style>
			body {
				color: #000;
				background: #fff;
				font-family: "Helvetica Neue",Roboto,Arial,"Droid Sans",sans-serif;
				font-size: 13px;
				font-weight: 400;
				line-height: 1.471;
				width: 800px;
				margin: 0 auto;
			}
		</style>
	</head>
	<body>
		<div class="container">
			<div style="page-break-after: always;">
			<h1>Invoice #<?php echo $order_status_id;?></h1>
			<table class="table table-bordered">
			  <thead>
				<tr>
				  <td colspan="2">Order Details</td>
				</tr>
			  </thead>
			  <tbody>
				<tr>
				  <td style="width: 50%;">
					<address>
						<strong>Tablefast</strong><br />
								Edinburgh, UK 
								12 Simpson Loan<br />     
					</address>
					<b>E-Mail</b> info@tablefast.com<br /></td>
				  <td style="width: 50%;"><b>Date Added</b> <?php echo $date_added;?><br />
								<b>Invoice No.:</b> INV-<?php echo '00'.$order_status_id;?><br />
								<b>Order ID:</b> <?php echo $order_status_id;?><br />
					</td>
				</tr>
			  </tbody>
			</table>
			<table class="table table-bordered">
			  <thead>
				<tr>
				  <td style="width: 50%;"><b>Payment Address</b></td>
				</tr>
			  </thead>
			  <tbody>
				<tr>
				  <td><address>
					<?php echo $name; ?><br /><?php echo $clubname; ?><br /><?php echo $Address; ?><br /><?php echo $City; ?><br /><?php echo $Country; ?><br />
					<?php echo $Phone; ?>            </address></td>
				  
				</tr>
			  </tbody>
			</table>
			<table class="table table-bordered">
			  
			  <tbody>
				
						<tr>
				  <td class="text-right" colspan="4"><b>Total</b></td>
				  <td class="text-right">$ <?php echo $amt;?></td>
				</tr>
					  </tbody>
			</table>
		  </div>
		  </div>
	</body>
</html>