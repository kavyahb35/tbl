<!DOCTYPE html>
<html lang="en">
   <head>
      <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('assets/favicon/');?>favicon.ico">
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <!-- Meta, title, CSS, favicons, etc. -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="icon" href="images/favicon.ico" type="image/ico" />
      <title>Tablefast | Admin Dashboard 
      </title>
      <!-- Bootstrap -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
      <!-- Font Awesome -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
      <!-- NProgress -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/nprogress/nprogress.css" rel="stylesheet">
      <!-- iCheck -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/iCheck/skins/flat/green.css" rel="stylesheet">
      <!-- bootstrap-progressbar -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
      <!-- JQVMap -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>
      <!-- bootstrap-daterangepicker -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
      <!-- Custom Theme Style -->
      <link href="<?php echo base_url('assets/admintheme');?>/build/css/custom.min.css" rel="stylesheet">
   </head>
   <body class="nav-md">
      <div class="container body">
         <div class="main_container">
            <div class="col-md-3 left_col">
               <?php  $this->load->view('admin/include/sidebar');?>
            </div>
            <!-- top navigation -->
            <?php  $this->load->view('admin/include/header');?>
            <!-- /top navigation -->
            <!-- page content -->
            <div class="onel" role="main">
               <!-- top tiles -->
               <!-- /top tiles -->
               <div class="r" role="main">
                  <div class="mycls">
                     <div class="">
                        <div class="row top_tiles">
                           <div class="animated flipInY col-lg-2 col-md-2 col-sm-6 col-xs-12">
                              <div class="tile-stats a1">
                                 <div class="icon">
                                    <i class="fa fa-user">
                                    </i>
                                 </div>
                                 <div class="count">
                                    <?php echo $totalApproved;?>
                                 </div>
                                 <h3>Total Approved 
                                 </h3>
                              </div>
                           </div>
                           <div class="animated flipInY col-lg-2 col-md-2 col-sm-6 col-xs-12">
                              <div class="tile-stats a2">
                                 <div class="icon">
                                    <i class="fa fa-user">
                                    </i>
                                 </div>
                                 <div class="count">
                                    <?php echo $totalrejected;?>
                                 </div>
                                 <h3>Total Rejected 
                                 </h3>
                              </div>
                           </div>
                           <div class="animated flipInY col-lg-2 col-md-2 col-sm-6 col-xs-12">
                              <div class="tile-stats a3">
                                 <div class="icon">
                                    <i class="fa fa-user">
                                    </i>
                                 </div>
                                 <div class="count">
                                    <?php echo $totaltrash;?>
                                 </div>
                                 <h3>Total Trash 
                                 </h3>
                              </div>
                           </div>
                           <div class="animated flipInY col-lg-2 col-md-2 col-sm-6 col-xs-12">
                              <div class="tile-stats a4">
                                 <div class="icon">
                                    <i class="fa fa-user">
                                    </i>
                                 </div>
                                 <div class="count">
                                    <?php echo $totaldraft;?>
                                 </div>
                                 <h3>Total  Draft
                                 </h3>
                              </div>
                           </div>
                           <div class="animated flipInY col-lg-2 col-md-2 col-sm-6 col-xs-12">
                              <div class="tile-stats a5">
                                 <div class="icon">
                                    <i class="fa fa-user">
                                    </i>
                                 </div>
                                 <div class="count">
                                    <?php echo $totalPending;?>
                                 </div>
                                 <h3>Total Panding 
                                 </h3>
                              </div>
                           </div>
                           <div class="animated flipInY col-lg-2 col-md-2 col-sm-6 col-xs-12">
                              <div class="tile-stats a6">
                                 <div class="icon">
                                    <i class="fa fa-user">
                                    </i>
                                 </div>
                                 <div class="count">
                                    <?php echo $totalclub;?>
                                 </div>
                                 <h3>Total Club
                                 </h3>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- /page content -->
            <!-- footer content -->
            <footer>
               <div class="pull-right">
                  Tablefast.com
               </div>
               <div class="clearfix">
               </div>
            </footer>
            <!-- /footer content -->
         </div>
      </div>
      <!-- jQuery -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/jquery/dist/jquery.min.js"></script>
      <!-- Bootstrap -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
      <!-- FastClick -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/fastclick/lib/fastclick.js"></script>
      <!-- NProgress -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/nprogress/nprogress.js"></script>
      <!-- Chart.js -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/Chart.js/dist/Chart.min.js"></script>
      <!-- gauge.js -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/gauge.js/dist/gauge.min.js"></script>
      <!-- bootstrap-progressbar -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
      <!-- iCheck -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/iCheck/icheck.min.js"></script>
      <!-- Skycons -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/skycons/skycons.js"></script>
      <!-- Flot -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/Flot/jquery.flot.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/Flot/jquery.flot.pie.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/Flot/jquery.flot.time.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/Flot/jquery.flot.stack.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/Flot/jquery.flot.resize.js"></script>
      <!-- Flot plugins -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/flot.curvedlines/curvedLines.js"></script>
      <!-- DateJS -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/DateJS/build/date.js"></script>
      <!-- JQVMap -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/jqvmap/dist/jquery.vmap.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
      <!-- bootstrap-daterangepicker -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/moment/min/moment.min.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
      <!-- Custom Theme Scripts -->
      <script src="<?php echo base_url('assets/admintheme');?>/build/js/custom.min.js"></script>
      <style>
          .tile-stats {
              height: 121px;
          }
         .mycls {
         height: 550px;
         }
         .r {
         padding: 10px 30px 10px 16px;
         margin-left: 230px;
         background: #F7F7F7;
         min-height: auto;
         }
         .tile-stats h3 {
         color: #fff;
         font-size: 21px;
     padding: 6px 0px 1px 0px;

         }
         .row.top_tiles {
         min-height:600px;
         }
         .tile-stats .icon i {
         padding: 16px 7px ;
         }
         .tile-stats.a4 {
         background: midnightblue;
         color: #fff;
         }
         .tile-stats .icon {
         width: 20px;
         height: 20px;
         color: #fff;
         }
         .tile-stats.a1 {
         background: maroon;
         color: #fff;
         }
         .tile-stats.a2 {
         background: tomato;
         color: #fff;
         }.tile-stats.a3 {
         background: teal;
         color: #fff;
         }.tile-stats.a4 {
         background: midnightblue;
         color: #fff;
         }.tile-stats.a5 {
         background: purple;
         color: #fff;
         }.tile-stats.a6 {
         background: hotpink;
         color: #fff;
         }
      </style>
   </body>
</html>