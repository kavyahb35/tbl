<!DOCTYPE html>
<html lang="en">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <!-- Meta, title, CSS, favicons, etc. -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('assets/favicon/');?>favicon.ico">
      <title>Tablefast.com | Admin | Dashboard</title>
      <!-- Bootstrap -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
      <!-- Font Awesome -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
      <!-- NProgress -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/nprogress/nprogress.css" rel="stylesheet">
      <!-- iCheck -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/iCheck/skins/flat/green.css" rel="stylesheet">
      <!-- bootstrap-wysiwyg -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
      <!-- Select2 -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/select2/dist/css/select2.min.css" rel="stylesheet">
      <!-- Switchery -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/switchery/dist/switchery.min.css" rel="stylesheet">
      <!-- starrr -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/starrr/dist/starrr.css" rel="stylesheet">
      <!-- bootstrap-daterangepicker -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
      <!-- Custom Theme Style -->
      <link href="<?php echo base_url('assets/admintheme');?>/build/css/custom.min.css" rel="stylesheet">
   </head>
   <body class="nav-md">
      <div class="container body">
         <div class="main_container">
            <div class="col-md-3 left_col">
               <?php $this->load->view('admin/include/sidebar');?>
            </div>
            <!-- top navigation -->
            <?php $this->load->view('admin/include/header');?>
            <!-- /top navigation -->
            <!-- page content -->
            <div class="right_col" role="main">
               <div class="">
                  <div class="clearfix"></div>
                  <div class="row">
                     <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                           <div class="x_title">
                              <h3>Dashboard</h3>
                           </div>
                           <div class="x_content">
                               <div class="row">
                                   <div class="col-md-12">
                                       <div class="row top_tiles">
                                        <div class="animated flipInY col-lg-2 col-md-2 col-sm-6 col-xs-6">
                                           <div class="tile-stats a6">
                                              <div class="icon">
                                                 <i class="fa fa-user i6f">
                                                 </i>
                                              </div>
                                              <div class="count f8">
                                                 <?php echo $totalclub;?>
                                              </div>
                                              <h3>Total Club
                                              </h3>
                                           </div>
                                        </div>
                                        <div class="animated flipInY col-lg-2 col-md-2 col-sm-6 col-xs-6">
                                           <div class="tile-stats a1">
                                              <div class="icon">
                                                 <i class="fa fa-user i6f">
                                                 </i>
                                              </div>
                                              <div class="count f8">
                                                 <?php echo $totalcustomer;?>
                                              </div>
                                              <h3>Total Customers 
                                              </h3>
                                           </div>
                                        </div>
                                        <div class="animated flipInY col-lg-2 col-md-2 col-sm-6 col-xs-6">
                                           <div class="tile-stats a2">
                                              <div class="icon">
                                                 <i class="fa fa-user i6f">
                                                 </i>
                                              </div>
                                              <div class="count f8">
                                                 <?php echo $totalbooking;?>
                                              </div>
                                              <h3>Total Booking 
                                              </h3>
                                           </div>
                                        </div>
                                        <div class="animated flipInY col-lg-2 col-md-2 col-sm-6 col-xs-6">
                                           <div class="tile-stats a5">
                                              <div class="icon">
                                                 <i class="fa fa-user i6f">
                                                 </i>
                                              </div>
                                              <div class="count f8">
                                                 <?php echo $totalreviews;?>
                                              </div>
                                              <h3>Total Reviews 
                                              </h3>
                                           </div>
                                        </div>
                                        <div class="animated flipInY col-lg-2 col-md-2 col-sm-6 col-xs-6">
                                           <div class="tile-stats a4">
                                              <div class="icon">
                                                 <i class="fa fa-user i6f">
                                                 </i>
                                              </div>
                                              <div class="count f8">
                                                 <?php echo $totalcontact;?>
                                              </div>
                                              <h3>Total Contacts
                                              </h3>
                                           </div>
                                        </div>
                                        
                                           <div class="animated flipInY col-lg-2 col-md-2 col-sm-6 col-xs-6">
                                           <div class="tile-stats a3">
                                              <div class="icon">
                                                 <i class="fa fa-user i6f">
                                                 </i>
                                              </div>
                                              <div class="count f8">
                                                 <?php echo $totalnewsletter;?>
                                              </div>
                                              <h3>Total Newsletter 
                                              </h3>
                                           </div>
                                        </div>
                                        
                                     </div>
                                   </div>
                               </div>
                           
                           
                                </div>
                        </div>
                     </div>
                  </div>
               </div>
                
                <!---------------------------------------------------------------------------->
                <div class="row">
                     <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                           
                           <div class="x_content">
                              <div class="row">
                                   <div class="col-md-6 col-lg-6 col-xs-12 col-sm-6">
                                        <div class="x_title">
                                            <h2>Approved Club List</h2>
                                            <div class="clearfix"></div>
                                        </div>
                                         <ul class="list-unstyled top_profiles scroll-view">
                                             <?php if(!empty($approvedclub)){
                                                 foreach($approvedclub as $vendor){
                                                    $vid=$vendor['Id'];
                                                    $layout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$vid);
                                                    $img=$layout[0]['MainImage'];
                                                    if($img!=''){
                                                     $i=base_url('assets/clubimage/210X150/'.$img);
                                                    }else{
                                                        $i=base_url('assets/fronttheme/customcss/Dummyimage.jpg');
                                                    }
                                                     ?>
                                            <li class="media event">
                                              <a class="pull-left border-aero profile_thumb">
                                                  <img src="<?php echo $i;?>" class="cop">
                                              </a>
                                              <div class="media-body">
                                                <?php echo $vendor['ClubName'];?>
                                              </div>
                                            </li>
                                            <?php }
                                            }?>
                                          </ul>

                                   </div>
                                   <div class="col-md-6 col-lg-6 col-xs-12 col-sm-6">
                                       <div class="x_title">
                                            <h2> Rejected / Pending club List</h2>                                            
                                            <div class="clearfix"></div>
                                        </div>
                                         <ul class="list-unstyled top_profiles scroll-view">
                                             <?php if(!empty($Pendingclub)){
                                                 foreach($Pendingclub as $vendor){
                                                    $vid=$vendor['Id'];
                                                    $layout=$this->App->getPerticularRecord('tbl_clublayout','VendorId',$vid);
                                                    $img=$layout[0]['MainImage'];
                                                    if($img!=''){
                                                     $i=base_url('assets/clubimage/210X150/'.$img);
                                                    }else{
                                                        $i=base_url('assets/fronttheme/customcss/Dummyimage.jpg');
                                                    }
                                                     ?>
                                            <li class="media event">
                                              <a class="pull-left border-aero profile_thumb">
                                                  <img src="<?php echo $i;?>" class="cop">
                                              </a>
                                              <div class="media-body">
                                                <?php echo $vendor['ClubName'];?>
                                              </div>
                                            </li>
                                            <?php }
                                            }?>
                                          </ul>

                                   </div>
                               </div>
                          
                           
                                </div>
                        </div>
                     </div>
                  </div>
                
                <!---------------------------------------------------------------------------->
                <div class="row">
                     <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                           
                           <div class="x_content">
                              <div class="row">
                                   <div class="col-md-12">
                                       <div class="row top_tiles">
                                        <div class="animated flipInY col-lg-2 col-md-2 col-sm-6 col-xs-6">
                                           <div class="tile-stats a1">
                                              <div class="icon">
                                                 <i class="fa fa-user i6f">
                                                 </i>
                                              </div>
                                              <div class="count f8">
                                                 <?php echo $totalApproved;?>
                                              </div>
                                              <h3>Total Approved 
                                              </h3>
                                           </div>
                                        </div>
                                        <div class="animated flipInY col-lg-2 col-md-2 col-sm-6 col-xs-6">
                                           <div class="tile-stats a2">
                                              <div class="icon">
                                                 <i class="fa fa-user i6f">
                                                 </i>
                                              </div>
                                              <div class="count f8">
                                                 <?php echo $totalrejected;?>
                                              </div>
                                              <h3>Total Rejected 
                                              </h3>
                                           </div>
                                        </div>
                                        <div class="animated flipInY col-lg-2 col-md-2 col-sm-6 col-xs-6">
                                           <div class="tile-stats a3">
                                              <div class="icon">
                                                 <i class="fa fa-user i6f">
                                                 </i>
                                              </div>
                                              <div class="count f8">
                                                 <?php echo $totaltrash;?>
                                              </div>
                                              <h3>Total Trash 
                                              </h3>
                                           </div>
                                        </div>
                                        <div class="animated flipInY col-lg-2 col-md-2 col-sm-6 col-xs-6">
                                           <div class="tile-stats a4">
                                              <div class="icon">
                                                 <i class="fa fa-user i6f">
                                                 </i>
                                              </div>
                                              <div class="count f8">
                                                 <?php echo $totaldraft;?>
                                              </div>
                                              <h3>Total  Draft
                                              </h3>
                                           </div>
                                        </div>
                                        <div class="animated flipInY col-lg-2 col-md-2 col-sm-6 col-xs-6">
                                           <div class="tile-stats a5">
                                              <div class="icon">
                                                 <i class="fa fa-user i6f">
                                                 </i>
                                              </div>
                                              <div class="count f8">
                                                 <?php echo $totalPending;?>
                                              </div>
                                              <h3>Total Panding 
                                              </h3>
                                           </div>
                                        </div>
                                        <div class="animated flipInY col-lg-2 col-md-2 col-sm-6 col-xs-6">
                                           <div class="tile-stats a6">
                                              <div class="icon">
                                                 <i class="fa fa-user i6f">
                                                 </i>
                                              </div>
                                              <div class="count f8">
                                                 <?php echo $totalclub;?>
                                              </div>
                                              <h3>Total Club
                                              </h3>
                                           </div>
                                        </div>
                                     </div>
                                   </div>
                               </div>
                          
                           
                                </div>
                        </div>
                     </div>
                  </div>
                <!------------------------------------------------------>
                
                
                
                
                
                
                
                
                
                
            </div>
            <!-- /page content -->
            <!-- footer content -->
            <footer>
               <div class="pull-right">
                  tablefast.com
               </div>
               <div class="clearfix"></div>
            </footer>
            <!-- /footer content -->
         </div>
      </div>
      <!-- jQuery -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/jquery/dist/jquery.min.js"></script>
      <!-- Bootstrap -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
      <!-- FastClick -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/fastclick/lib/fastclick.js"></script>
      <!-- NProgress -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/nprogress/nprogress.js"></script>
      <!-- bootstrap-progressbar -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
      <!-- iCheck -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/iCheck/icheck.min.js"></script>
      <!-- bootstrap-daterangepicker -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/moment/min/moment.min.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
      <!-- bootstrap-wysiwyg -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/google-code-prettify/src/prettify.js"></script>
      <!-- jQuery Tags Input -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
      <!-- Switchery -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/switchery/dist/switchery.min.js"></script>
      <!-- Select2 -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/select2/dist/js/select2.full.min.js"></script>
      <!-- Parsley -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/parsleyjs/dist/parsley.min.js"></script>
      <!-- Autosize -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/autosize/dist/autosize.min.js"></script>
      <!-- jQuery autocomplete -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
      <!-- starrr -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/starrr/dist/starrr.js"></script>
      <!-- Custom Theme Scripts -->
      <script src="<?php echo base_url('assets/admintheme');?>/build/js/custom.min.js"></script>
      <style>
          img.cop {
    border-radius: 119px;
    width: 49px;
    height: 50px;
    margin-top: -39%;
    margin-right: -40%;
    margin-left: -49%;
}
          .tile-stats {
              height: 121px;
          }
         .mycls {
         height: 550px;
         }
         .r {
         padding: 10px 30px 10px 16px;
         margin-left: 230px;
         background: #F7F7F7;
         min-height: auto;
         }
         .f8 {
    font-size: 22px !important;
}
         .tile-stats h3 {
         color: #fff;
     font-size: 20px;
    padding: 31px 0px 1px 0px;

         }
         
         .tile-stats .icon i {
         padding: 16px 7px ;
         }
         .tile-stats.a4 {
         background: midnightblue;
         color: #fff;
         }
         .tile-stats .icon {
         width: 20px;
         height: 20px;
         color: #fff;
         }
         .tile-stats.a1 {
         background: maroon;
         color: #fff;
         }
         .tile-stats.a2 {
         background: tomato;
         color: #fff;
         }.tile-stats.a3 {
         background: teal;
         color: #fff;
         }.tile-stats.a4 {
         background: midnightblue;
         color: #fff;
         }.tile-stats.a5 {
         background: purple;
         color: #fff;
         }.tile-stats.a6 {
         background: hotpink;
         color: #fff;
         }
      </style>
   </body>
</html>
