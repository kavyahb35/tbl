<!DOCTYPE html>
<html lang="en">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <!-- Meta, title, CSS, favicons, etc. -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('assets/favicon/');?>favicon.ico">
      <title>TrackIt | Dashboard</title>
      <!-- Bootstrap -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
      <!-- Font Awesome -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
      <!-- NProgress -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/nprogress/nprogress.css" rel="stylesheet">
      <!-- iCheck -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/iCheck/skins/flat/green.css" rel="stylesheet">
      <!-- bootstrap-wysiwyg -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
      <!-- Select2 -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/select2/dist/css/select2.min.css" rel="stylesheet">
      <!-- Switchery -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/switchery/dist/switchery.min.css" rel="stylesheet">
      <!-- starrr -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/starrr/dist/starrr.css" rel="stylesheet">
      <!-- bootstrap-daterangepicker -->
      <link href="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
      <!-- Custom Theme Style -->
      <link href="<?php echo base_url('assets/admintheme');?>/build/css/custom.min.css" rel="stylesheet">
   </head>
   <body class="nav-md">
      <div class="container body">
         <div class="main_container">
            <div class="col-md-3 left_col">
               <?php $this->load->view('admin/include/sidebar');?>
            </div>
            <!-- top navigation -->
            <?php $this->load->view('admin/include/header');?>
            <!-- /top navigation -->
            <!-- page content -->
            <div class="right_col" role="main">
               <div class="">
                  <div class="clearfix"></div>
                  <div class="row">
                     <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                           <div class="x_title">
                              <h3>Paypal Setting</h3>
                           </div>
                           <div class="x_content">
                             <?php if(!empty($error)){?>
                <div class="alert alert-danger  alert-dismissible">
                  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                  </a>
                  <?php  echo $error;?>
                </div>
                <?php } ?>
                               
                                   <form class="form-horizontal form-label-left" method="post" action="<?php echo base_url('admin/paypalsetting');?>" enctype="multipart/form-data">
    
                                     <div class="form-group">
                                    <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Username *</label>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                           <input id="middle-name" class="form-control col-md-7 col-xs-12" required="required" type="text" name="username" value="<?php echo $listsetting[0]['UserName']; ?>">
                                     </div>
                                    </div>
                                        
                                     <div class="form-group">
                                    <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Password *</label>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                           <input id="middle-name" class="form-control col-md-7 col-xs-12" required="required" type="text" name="password" value="<?php echo $listsetting[0]['Password']; ?>">
                                     </div>
                                    </div>
                                        
                                     <div class="form-group">
                                    <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Signature *</label>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                           <input id="middle-name" class="form-control col-md-7 col-xs-12" required="required" type="text" name="signature" value="<?php echo $listsetting[0]['Signature']; ?>">
                                     </div>
                                    </div>
                                        
                                     <div class="form-group">
                                    <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Currency Code *</label>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                           <input id="middle-name" class="form-control col-md-7 col-xs-12" required="required" type="text" name="CurrencyCode" value="<?php echo $listsetting[0]['CurrencyCode']; ?>">
                                     </div>
                                    </div>
                                        
                                     <div class="form-group">
                                    <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Billing Period *</label>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                           <input id="middle-name" class="form-control col-md-7 col-xs-12" required="required" type="text" name="BillingPeriod" value="<?php echo $listsetting[0]['BillingPeriod']; ?>">
                                     </div>
                                    </div>
                                        
                                     <div class="form-group">
                                    <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Billing Frequency *</label>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                           <input id="middle-name" class="form-control col-md-7 col-xs-12" required="required" type="text" name="BillingFrequency" value="<?php echo $listsetting[0]['BillingFrequency']; ?>">
                                     </div>
                                    </div>
                                        
                                     <div class="form-group">
                                    <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Total Billing Cycle *</label>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                           <input id="middle-name" class="form-control col-md-7 col-xs-12" required="required" type="text" name="TotalBillingCycle" value="<?php echo $listsetting[0]['TotalBillingCycle']; ?>">
                                     </div>
                                    </div>
                                        
                                     <div class="form-group">
                                    <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Amount *</label>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                           <input id="middle-name" class="form-control col-md-7 col-xs-12" required="required" type="text" name="Amt" value="<?php echo $listsetting[0]['Amt']; ?>">
                                     </div>
                                    </div>
                                    
                                    <div class="form-group" style="text-align:center"> Note * : <br />
										If the billingperiod is Month you can set the billingfrequency to e.g. 1, 4, 9 and 12 but not to 13.<br />
										If the billingperiod is Year you can set the billingfrequencyonly to 1.<br />
										If the billingperiod is Day you can set the billingfrequencyonly to no. of Days.
                                    
                                    </div>
                                     <div class="form-group">
                                    <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Paypal Express Period *</label>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select class="form-control col-md-7 col-xs-12" required="required" name="ExpressPeriod">
                                          <option value="Day" <?php  if($listsetting[0]['ExpressPeriod']=='Day'){ echo 'selected=selected';} ?>>Day</option>
                                           <option value="Week" <?php  if($listsetting[0]['ExpressPeriod']=='Week'){ echo 'selected=selected';} ?>>Week</option>
                                            <option value="SemiMonth" <?php  if($listsetting[0]['ExpressPeriod']=='SemiMonth'){ echo 'selected=selected';} ?>>SemiMonth</option>
                                             <option value="Month" <?php  if($listsetting[0]['ExpressPeriod']=='Month'){ echo 'selected=selected';} ?>>Month</option>
                                             <option value="Year" <?php  if($listsetting[0]['ExpressPeriod']=='Year'){ echo 'selected=selected';} ?>>Year</option>
                                        </select>
                                            </div>
                                    </div>
                                    
                                     <div class="form-group">
                                    <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Paypal Express Frequency(No. of days after recurring payment) *</label>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                           <input id="middle-name" class="form-control col-md-7 col-xs-12" required="required" type="text" name="ExpressFrequency" value="<?php echo $listsetting[0]['ExpressFrequency']; ?>">
                                     </div>
                                    </div>
                                        
                                    
                                       
                                 
                                 
                                 <div class="ln_solid"></div>
                                 <div class="form-group">
                                    <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                       <!--  <button class="btn btn-primary" type="button">Cancel</button>
                                          <button class="btn btn-primary" type="reset">Reset</button>-->
                                       <button type="submit" class="btn btn-success">Submit</button>
                                        <a class="btn btn-primary" href="<?php echo base_url('admin/paypallistsetting');?>">Cancel</a>
                                   
                                    </div>
                                 </div>
                              </form>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- /page content -->
            <!-- footer content -->
            <footer>
               <div class="pull-right">
                  TrackIt
               </div>
               <div class="clearfix"></div>
            </footer>
            <!-- /footer content -->
         </div>
      </div>
      <!-- jQuery -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/jquery/dist/jquery.min.js"></script>
      <!-- Bootstrap -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
      <!-- FastClick -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/fastclick/lib/fastclick.js"></script>
      <!-- NProgress -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/nprogress/nprogress.js"></script>
      <!-- bootstrap-progressbar -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
      <!-- iCheck -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/iCheck/icheck.min.js"></script>
      <!-- bootstrap-daterangepicker -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/moment/min/moment.min.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
      <!-- bootstrap-wysiwyg -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/google-code-prettify/src/prettify.js"></script>
      <!-- jQuery Tags Input -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
      <!-- Switchery -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/switchery/dist/switchery.min.js"></script>
      <!-- Select2 -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/select2/dist/js/select2.full.min.js"></script>
      <!-- Parsley -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/parsleyjs/dist/parsley.min.js"></script>
      <!-- Autosize -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/autosize/dist/autosize.min.js"></script>
      <!-- jQuery autocomplete -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
      <!-- starrr -->
      <script src="<?php echo base_url('assets/admintheme');?>/vendors/starrr/dist/starrr.js"></script>
      <!-- Custom Theme Scripts -->
      <script src="<?php echo base_url('assets/admintheme');?>/build/js/custom.min.js"></script>
   </body>
</html>
