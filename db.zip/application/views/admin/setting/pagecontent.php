<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Tablefast | Admin </title>

    <!-- Bootstrap -->
    <link href="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo base_url('assets/admintheme');?>/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo base_url('assets/admintheme');?>/vendors/nprogress/nprogress.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="<?php echo base_url('assets/admintheme');?>/build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
            <?php $this->load->view('admin/include/sidebar');?>
        </div>

          <?php $this->load->view('admin/include/header');?>
             

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
           
            <div class="clearfix"></div>

            <div class="row">

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2><?php echo $listpage[0]['Title'];?> </h2>
                   
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">


                    <!-- Smart Wizard -->
                     <div id="wizard" class="form_wizard wizard_horizontal">
                      
                      <div  style="display:block">
                          <?php if(!empty($error)){?>
                <div class="alert alert-danger  alert-dismissible">
                  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                  </a>
                  <?php  echo $error;?>
                </div>
                <?php } ?>
                          <form novalidate class="form-horizontal form-label-left" method="post" action="<?php echo base_url('admin/infocontent/'.$iid)?>" >


<div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Title <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            <input type="text" class="form-control" name="title" value="<?php echo $listpage[0]['Subtitle'];?>" >
                          
                          
                         </div>
                          </div> 
                         
                          


                          <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Details <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                             <script src="https://cdn.ckeditor.com/4.9.2/standard/ckeditor.js">
                          </script>
                          <textarea class="form-control" required name="description" placeholder="Enter Description" >
                            <?php echo $listpage[0]['Description'];?>
                          </textarea>    
                          <script>
                            CKEDITOR.replace( 'description' );
                          </script>   </div>
                          </div> 
                         
<div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Status <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            <select class="form-control" name="status">
                            <option value='1' <?php if($listpage[0]['Status']=='1'){ echo 'selected=selected';}?>>Active</option>
                             <option value='0' <?php if($listpage[0]['Status']=='0'){ echo 'selected=selected';}?>>Inactive</option>
                            </select >
                           
                          
                         </div>
                          </div> 
                               
                             
                            
                             
                            
                          <input type="submit" name="submit" value="submit" class="btn btn-success">
                       <a class="btn btn-info" href="<?php echo base_url('admin/listcontent');?>">Cancel</a>   
                    
                  </div>
                    
                 

                        </form>

                      </div>
                      
                      
                      

                        
                         
                    </div>
                    <!-- End SmartWizard Content -->





                    
                   
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
         <?php $this->load->view('admin/include/footer');?>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/nprogress/nprogress.js"></script>
    <!-- jQuery Smart Wizard -->
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url('assets/admintheme');?>/build/js/custom.min.js"></script>
    <style>
        .actionBar {
            display: none;
        }
        .wizard_horizontal ul.wizard_steps li a.disabled .actmy {
            background:#34495E;
        }        
       .wizard_horizontal ul.wizard_steps li .aced a:before {
         background: #34495E !important;
             content: "";
    position: absolute;
    height: 4px;
    top: 20px;
    width: 100%;
    z-index: 4;
    left: 0;
       }
    </style>
	
  </body>
</html>
