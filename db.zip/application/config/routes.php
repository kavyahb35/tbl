<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'front';
$route['terms-and-conditions'] = 'terms';
$route['privacy-policy'] = 'privacy';
$route['about-us'] = 'about';
$route['contact-us'] = 'contact';

/* Club URL*/
$route['club-list'] = 'front/allclub';
$route['search'] = 'front/search';
$route['detail/(:any)'] = 'front/clubdetails/$1';
$route['detail/(:any)'] = 'front/detail/$1';
$route['booking-success/(:any)'] = 'booking/bookingsuccess/$1';
$route['event-detail/(:any)'] = 'front/eventdetail/$1';

/* Customer URL */
$route['sign-up'] = 'customer/register';
$route['sign-in'] = 'customer/index';
$route['sign-in'] = 'customer';

$route['dashboard'] = 'customer/dashboard';
$route['profile'] = 'customer/profile';


$route['request-booking'] = 'customer/requestBooking';
$route['confirm-booking'] = 'customer/confirmBooking';
$route['cancelled'] = 'customer/cancelBooking';
$route['complete-booking'] = 'customer/completeBooking';
$route['reject-booking'] = 'customer/rejectBooking';


$route['update-booking/(:any)'] = 'customer/modify_booking/$1';
$route['success-booking/(:any)'] = 'customer/bookingsuccess/$1';
$route['cancel-booking/(:any)'] = 'customer/cancel/$1';
$route['customer-verification/(:any)/(:any)'] = 'customer/verification/$1/$2';
$route['change-password'] = 'customer/changepassword';
$route['logout'] = 'customer/logout';

/* Vendor URL */
$route['vendor-signup'] = 'vendor/register';
$route['vendor-signin'] = 'vendor/index';
$route['vendor-signin'] = 'vendor';
$route['vendor-forgot-password'] = 'vendor/forgotpassword';
$route['payment-cancelled'] = 'vendor/payment_cancelled';

$route['vendor-dashboard'] = 'vendor/dashboard';
$route['step2'] = 'vendor/step2';
$route['update-step1'] = 'vendor/updatestep1';
$route['step1'] = 'vendor/step1';
$route['step6'] = 'vendor/step6';
$route['step4'] = 'vendor/step4';
$route['step3'] = 'vendor/step3';
$route['step5'] = 'vendor/step5';
$route['completed'] = 'vendor/complete';
$route['preview-club'] = 'vendor/previewclub';
$route['create-step1'] = 'vendor/createstep1';


$route['step5'] = 'vendor/step5';
$route['step5'] = 'vendor/step5';
$route['step5'] = 'vendor/step5';
$route['vendor-change-password'] = 'vendor/changepassword';
$route['vendor-logout'] = 'vendor/logout';



$route['booking-request'] = 'booking/requestBooking';
$route['booking-confirm'] = 'booking/confirmBooking';
$route['booking-reject'] = 'booking/rejectBooking';
$route['booking-cancel'] = 'booking/cancelBooking';
$route['booking-complete'] = 'booking/completeBooking';
$route['booking/approvedrequest'] = 'booking/approvedrequest';
$route['404_override'] = 'page404';

$route['booking-club/(:any)'] = 'booking/index/$1';






$route['translate_uri_dashes'] = FALSE;
