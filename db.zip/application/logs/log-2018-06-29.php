<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ADMIN - 2018-06-29 10:21:39 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-06-29 10:21 AM","IP Address":"203.88.158.139"}
ADMIN - 2018-06-29 10:25:55 --> Admin Logout : {"Email":"admin@gmail.com","Time":"2018-06-29 10:25 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-06-29 10:26:08 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-06-29 10:26 AM","IP Address":"203.88.158.139"}
ADMIN - 2018-06-29 10:40:32 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-06-29 10:40 AM","IP Address":"178.152.81.142"}
