<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ADMIN - 2018-06-30 14:35:39 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-06-30 14:35 PM","IP Address":"37.210.115.147"}
VENDOR - 2018-06-30 14:53:39 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-06-30 14:53 PM","IP Address":"37.210.115.147"}
ADMIN - 2018-06-30 15:26:50 --> Admin Logout : {"Email":"admin@gmail.com","Time":"2018-06-30 15:26 PM","IP Address":"37.210.115.147"}
ADMIN - 2018-06-30 15:27:54 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-06-30 15:27 PM","IP Address":"37.210.115.147"}
ADMIN - 2018-06-30 15:29:23 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-06-30 15:29 PM","IP Address":"37.210.115.147"}
ADMIN - 2018-06-30 15:33:32 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-06-30 15:33 PM","IP Address":"37.210.115.147"}
VENDOR - 2018-06-30 15:36:37 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-06-30 15:36 PM","IP Address":"37.210.115.147"}
VENDOR - 2018-06-30 15:44:09 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-06-30 15:44 PM","IP Address":"37.210.115.147"}
VENDOR - 2018-06-30 15:45:10 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-06-30 15:45 PM","IP Address":"37.210.115.147"}
VENDOR - 2018-06-30 15:46:13 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-06-30 15:46 PM","IP Address":"37.210.115.147"}
VENDOR - 2018-06-30 15:47:52 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-06-30 15:47 PM","IP Address":"37.210.115.147"}
