<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

CUSTOMER - 2018-06-15 04:25:34 --> Customer login : {"Email":"rahulcueserve6@gmail.com","Time":"2018-06-15 04:25 AM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-06-15 04:26:31 --> Customer Louout : {"Email":"rahulcueserve6@gmail.com","Time":"2018-06-15 04:26 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-06-15 04:26:50 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-06-15 04:26 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-06-15 04:27:51 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-06-15 04:27 AM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-06-15 04:32:10 --> Customer login : {"Email":"rahulcueserve6@gmail.com","Time":"2018-06-15 04:32 AM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-06-15 04:33:05 --> Customer Louout : {"Email":"rahulcueserve6@gmail.com","Time":"2018-06-15 04:33 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-06-15 04:33:23 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-06-15 04:33 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-06-15 04:33:28 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-06-15 04:33 AM","IP Address":"203.88.158.139"}
ADMIN - 2018-06-15 04:47:19 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-06-15 04:47 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-06-15 05:02:36 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-06-15 05:02 AM","IP Address":"203.88.158.139"}
ADMIN - 2018-06-15 07:06:23 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-06-15 07:06 AM","IP Address":"203.88.158.139"}
