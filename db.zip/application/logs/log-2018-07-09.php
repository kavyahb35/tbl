<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

VENDOR - 2018-07-09 07:56:52 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-09 07:56 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-09 07:57:19 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-07-09 07:57 AM","IP Address":"203.88.158.139"}
ADMIN - 2018-07-09 07:57:32 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-09 07:57 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-09 08:39:08 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-09 08:39 AM","IP Address":"37.210.115.147"}
CUSTOMER - 2018-07-09 08:54:28 --> Customer Louout : {"Email":null,"Time":"2018-07-09 08:54 AM","IP Address":"37.210.115.147"}
ADMIN - 2018-07-09 09:30:40 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-09 09:30 AM","IP Address":"37.210.115.147"}
VENDOR - 2018-07-09 10:39:43 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-09 10:39 AM","IP Address":"37.210.115.147"}
CUSTOMER - 2018-07-09 10:40:08 --> Customer login : {"Email":"joy.vidal16@gmail.com","Time":"2018-07-09 10:40 AM","IP Address":"37.210.115.147"}
CUSTOMER - 2018-07-09 10:41:17 --> Customer login : {"Email":"joy.vidal16@gmail.com","Time":"2018-07-09 10:41 AM","IP Address":"37.210.115.147"}
VENDOR - 2018-07-09 10:59:19 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-09 10:59 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-09 11:01:03 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-09 11:01 AM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-07-09 13:14:04 --> Customer login : {"Email":"joy.vidal16@gmail.com","Time":"2018-07-09 13:14 PM","IP Address":"37.210.115.147"}
ADMIN - 2018-07-09 13:21:31 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-09 13:21 PM","IP Address":"37.210.115.147"}
VENDOR - 2018-07-09 15:10:34 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-07-09 15:10 PM","IP Address":"37.210.115.147"}
CUSTOMER - 2018-07-09 15:10:58 --> Customer Louout : {"Email":"joy.vidal16@gmail.com","Time":"2018-07-09 15:10 PM","IP Address":"37.210.115.147"}
