<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

VENDOR - 2018-07-29 08:50:23 --> vendor login : {"Email":"joy.vidal16@gmail.com","Time":"2018-07-29 08:50 AM","IP Address":"37.210.246.210"}
VENDOR - 2018-07-29 09:58:23 --> vendor login : {"Email":"joy.vidal16@gmail.com","Time":"2018-07-29 09:58 AM","IP Address":"37.210.246.210"}
ADMIN - 2018-07-29 10:11:26 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-29 10:11 AM","IP Address":"37.210.246.210"}
VENDOR - 2018-07-29 11:12:53 --> Vendor Louout : {"Email":"joy.vidal16@gmail.com","Time":"2018-07-29 11:12 AM","IP Address":"37.210.246.210"}
VENDOR - 2018-07-29 11:23:20 --> vendor login : {"Email":"joy.vidal16@gmail.com","Time":"2018-07-29 11:23 AM","IP Address":"37.210.246.210"}
VENDOR - 2018-07-29 11:24:18 --> Vendor Louout : {"Email":"joy.vidal16@gmail.com","Time":"2018-07-29 11:24 AM","IP Address":"37.210.246.210"}
VENDOR - 2018-07-29 13:23:07 --> vendor login : {"Email":"joy.vidal16@gmail.com","Time":"2018-07-29 13:23 PM","IP Address":"37.210.246.210"}
ADMIN - 2018-07-29 14:03:17 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-29 14:03 PM","IP Address":"37.210.246.210"}
ADMIN - 2018-07-29 15:00:56 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-29 15:00 PM","IP Address":"37.210.246.210"}
ADMIN - 2018-07-29 17:45:25 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-29 17:45 PM","IP Address":"37.210.136.87"}
