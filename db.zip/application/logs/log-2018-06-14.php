<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

CUSTOMER - 2018-06-14 07:34:04 --> Customer login : {"Email":"rahulcueserve6@gmail.com","Time":"2018-06-14 07:34 AM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-06-14 07:34:13 --> Customer Louout : {"Email":null,"Time":"2018-06-14 07:34 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-06-14 07:34:37 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-06-14 07:34 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-06-14 07:34:46 --> Vendor Louout : {"Email":null,"Time":"2018-06-14 07:34 AM","IP Address":"203.88.158.139"}
ADMIN - 2018-06-14 07:34:59 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-06-14 07:34 AM","IP Address":"203.88.158.139"}
ADMIN - 2018-06-14 07:35:03 --> Admin Logout : {"Email":"admin@gmail.com","Time":"2018-06-14 07:35 AM","IP Address":"203.88.158.139"}
ADMIN - 2018-06-14 07:59:00 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-06-14 07:59 AM","IP Address":"203.88.158.139"}
ADMIN - 2018-06-14 08:01:03 --> Admin Logout : {"Email":"admin@gmail.com","Time":"2018-06-14 08:01 AM","IP Address":"203.88.158.139"}
