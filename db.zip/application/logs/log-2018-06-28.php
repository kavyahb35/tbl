<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ADMIN - 2018-06-28 11:09:32 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-06-28 11:09 AM","IP Address":"37.211.153.151"}
