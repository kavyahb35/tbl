<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

CUSTOMER - 2018-07-15 07:25:40 --> Customer login : {"Email":"joy.vidal16@gmail.com","Time":"2018-07-15 07:25 AM","IP Address":"178.153.244.244"}
ADMIN - 2018-07-15 09:13:27 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-15 09:13 AM","IP Address":"178.153.244.244"}
VENDOR - 2018-07-15 09:17:06 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-15 09:17 AM","IP Address":"178.153.244.244"}
CUSTOMER - 2018-07-15 13:47:56 --> Customer login : {"Email":"joy.vidal16@gmail.com","Time":"2018-07-15 13:47 PM","IP Address":"178.153.244.244"}
