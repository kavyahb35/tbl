<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ADMIN - 2018-07-31 06:29:08 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-31 06:29 AM","IP Address":"37.210.246.210"}
ADMIN - 2018-07-31 08:59:31 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-31 08:59 AM","IP Address":"37.210.246.210"}
ADMIN - 2018-07-31 09:33:27 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-31 09:33 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-31 10:22:52 --> vendor login : {"Email":"jazzjavier07@gmail.com","Time":"2018-07-31 10:22 AM","IP Address":"37.210.246.210"}
ADMIN - 2018-07-31 12:02:24 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-31 12:02 PM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-31 12:05:04 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-31 12:05 PM","IP Address":"203.88.158.139"}
ADMIN - 2018-07-31 12:30:12 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-31 12:30 PM","IP Address":"37.210.246.210"}
VENDOR - 2018-07-31 13:12:37 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-31 13:12 PM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-31 13:13:38 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-07-31 13:13 PM","IP Address":"203.88.158.139"}
ADMIN - 2018-07-31 13:13:52 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-31 13:13 PM","IP Address":"203.88.158.139"}
ADMIN - 2018-07-31 13:17:35 --> Admin Logout : {"Email":"admin@gmail.com","Time":"2018-07-31 13:17 PM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-31 13:17:50 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-31 13:17 PM","IP Address":"203.88.158.139"}
ADMIN - 2018-07-31 14:03:53 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-31 14:03 PM","IP Address":"37.210.246.210"}
