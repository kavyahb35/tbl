<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ADMIN - 2018-07-16 09:25:08 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-16 09:25 AM","IP Address":"178.153.244.244"}
