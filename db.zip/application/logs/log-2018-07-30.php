<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ADMIN - 2018-07-30 06:12:18 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-30 06:12 AM","IP Address":"37.210.246.210"}
VENDOR - 2018-07-30 07:46:30 --> vendor login : {"Email":"joy.vidal16@gmail.com","Time":"2018-07-30 07:46 AM","IP Address":"37.210.246.210"}
ADMIN - 2018-07-30 07:48:17 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-30 07:48 AM","IP Address":"37.210.246.210"}
ADMIN - 2018-07-30 11:09:09 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-30 11:09 AM","IP Address":"203.88.158.139"}
