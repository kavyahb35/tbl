<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

CUSTOMER - 2018-07-10 04:26:15 --> Customer login : {"Email":"rahulcueserve6@gmail.com","Time":"2018-07-10 04:26 AM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-07-10 04:26:24 --> Customer Louout : {"Email":"rahulcueserve6@gmail.com","Time":"2018-07-10 04:26 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-10 04:28:26 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-10 04:28 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-10 04:28:30 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-07-10 04:28 AM","IP Address":"203.88.158.139"}
ADMIN - 2018-07-10 04:28:49 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-10 04:28 AM","IP Address":"203.88.158.139"}
ADMIN - 2018-07-10 04:28:54 --> Admin Logout : {"Email":"admin@gmail.com","Time":"2018-07-10 04:28 AM","IP Address":"203.88.158.139"}
ADMIN - 2018-07-10 04:44:17 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-10 04:44 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-10 05:08:01 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-10 05:08 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-10 05:37:30 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-07-10 05:37 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-10 05:37:56 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-10 05:37 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-10 06:08:13 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-10 06:08 AM","IP Address":"37.210.115.147"}
VENDOR - 2018-07-10 06:13:02 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-07-10 06:13 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-10 07:16:31 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-10 07:16 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-10 07:22:51 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-07-10 07:22 AM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-07-10 07:23:03 --> Customer login : {"Email":"rahulcueserve6@gmail.com","Time":"2018-07-10 07:23 AM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-07-10 07:30:12 --> Customer login : {"Email":"rahulcueserve6@gmail.com","Time":"2018-07-10 07:30 AM","IP Address":"37.210.115.147"}
ADMIN - 2018-07-10 07:30:34 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-10 07:30 AM","IP Address":"37.210.115.147"}
ADMIN - 2018-07-10 10:30:46 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-10 10:30 AM","IP Address":"37.210.115.147"}
ADMIN - 2018-07-10 11:10:10 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-10 11:10 AM","IP Address":"37.210.115.147"}
ADMIN - 2018-07-10 13:22:18 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-10 13:22 PM","IP Address":"37.210.115.147"}
ADMIN - 2018-07-10 13:24:13 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-10 13:24 PM","IP Address":"37.210.115.147"}
VENDOR - 2018-07-10 13:51:47 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-10 13:51 PM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-10 14:11:01 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-10 14:11 PM","IP Address":"37.210.115.147"}
