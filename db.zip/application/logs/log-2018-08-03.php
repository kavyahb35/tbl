<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ADMIN - 2018-08-03 07:32:35 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-08-03 07:32 AM","IP Address":"::1"}
