<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

VENDOR - 2018-06-19 07:59:08 --> vendor login : {"Email":"baria.hardik@gmail.com","Time":"2018-06-19 07:59 AM","IP Address":"203.88.158.139"}
