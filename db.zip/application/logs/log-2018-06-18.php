<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

VENDOR - 2018-06-18 08:17:22 --> vendor login : {"Email":"rahulcueserve16@gmail.com","Time":"2018-06-18 08:17 AM","IP Address":"203.88.158.139"}
