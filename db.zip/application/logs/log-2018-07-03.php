<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

VENDOR - 2018-07-03 10:13:43 --> Vendor Louout : {"Email":"nirmal@cueserve.com","Time":"2018-07-03 10:13 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-03 13:55:14 --> vendor login : {"Email":"laurencegarcia304@gmail.com","Time":"2018-07-03 13:55 PM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-03 13:55:19 --> Vendor Louout : {"Email":"laurencegarcia304@gmail.com","Time":"2018-07-03 13:55 PM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-03 13:55:56 --> vendor login : {"Email":"laurencegarcia304@gmail.com","Time":"2018-07-03 13:55 PM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-03 13:56:06 --> Vendor Louout : {"Email":"laurencegarcia304@gmail.com","Time":"2018-07-03 13:56 PM","IP Address":"203.88.158.139"}
