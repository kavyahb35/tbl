<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ADMIN - 2018-08-01 07:11:32 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-08-01 07:11 AM","IP Address":"37.210.246.210"}
ADMIN - 2018-08-01 10:03:11 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-08-01 10:03 AM","IP Address":"37.210.246.210"}
VENDOR - 2018-08-01 10:11:21 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-08-01 10:11 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-08-01 10:14:22 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-08-01 10:14 AM","IP Address":"203.88.158.139"}
ADMIN - 2018-08-01 10:14:35 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-08-01 10:14 AM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-08-01 10:41:15 --> Customer login : {"Email":"joy.vidal16@gmail.com","Time":"2018-08-01 10:41 AM","IP Address":"37.210.246.210"}
ADMIN - 2018-08-01 12:45:06 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-08-01 12:45 PM","IP Address":"37.210.246.210"}
ADMIN - 2018-08-01 13:26:13 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-08-01 13:26 PM","IP Address":"203.88.158.139"}
VENDOR - 2018-08-01 13:27:15 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-08-01 13:27 PM","IP Address":"203.88.158.139"}
ADMIN - 2018-08-01 13:31:53 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-08-01 13:31 PM","IP Address":"37.210.246.210"}
VENDOR - 2018-08-01 13:39:26 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-08-01 13:39 PM","IP Address":"203.88.158.139"}
