<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ADMIN - 2018-07-07 08:19:20 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-07 08:19 AM","IP Address":"37.210.115.147"}
VENDOR - 2018-07-07 08:25:28 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-07 08:25 AM","IP Address":"37.210.115.147"}
VENDOR - 2018-07-07 08:50:49 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-07-07 08:50 AM","IP Address":"37.210.115.147"}
VENDOR - 2018-07-07 08:55:40 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-07 08:55 AM","IP Address":"37.210.115.147"}
VENDOR - 2018-07-07 08:59:29 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-07-07 08:59 AM","IP Address":"37.210.115.147"}
VENDOR - 2018-07-07 09:00:22 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-07 09:00 AM","IP Address":"37.210.115.147"}
VENDOR - 2018-07-07 09:25:32 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-07-07 09:25 AM","IP Address":"37.210.115.147"}
ADMIN - 2018-07-07 09:26:21 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-07 09:26 AM","IP Address":"37.210.115.147"}
ADMIN - 2018-07-07 09:43:50 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-07 09:43 AM","IP Address":"37.210.115.147"}
VENDOR - 2018-07-07 09:55:00 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-07 09:55 AM","IP Address":"37.210.115.147"}
