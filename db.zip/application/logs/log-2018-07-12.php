<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

VENDOR - 2018-07-12 07:56:46 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-12 07:56 AM","IP Address":"37.211.148.134"}
CUSTOMER - 2018-07-12 08:09:55 --> Customer login : {"Email":"joy.vidal16@gmail.com","Time":"2018-07-12 08:09 AM","IP Address":"37.211.148.134"}
ADMIN - 2018-07-12 09:10:27 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-12 09:10 AM","IP Address":"37.211.148.134"}
VENDOR - 2018-07-12 11:40:58 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-12 11:40 AM","IP Address":"178.153.244.244"}
CUSTOMER - 2018-07-12 11:45:57 --> Customer login : {"Email":"joy.vidal16@gmail.com","Time":"2018-07-12 11:45 AM","IP Address":"178.153.244.244"}
