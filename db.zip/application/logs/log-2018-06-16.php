<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ADMIN - 2018-06-16 04:21:44 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-06-16 04:21 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-06-16 07:01:46 --> vendor login : {"Email":"rahulcueserve16@gmail.com","Time":"2018-06-16 07:01 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-06-16 10:18:50 --> vendor login : {"Email":"rahulcueserve16@gmail.com","Time":"2018-06-16 10:18 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-06-16 11:36:24 --> vendor login : {"Email":"rahulcueserve16@gmail.com","Time":"2018-06-16 11:36 AM","IP Address":"203.88.158.139"}
ADMIN - 2018-06-16 13:07:56 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-06-16 13:07 PM","IP Address":"203.88.158.139"}
ADMIN - 2018-06-16 13:21:47 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-06-16 13:21 PM","IP Address":"203.88.158.139"}
VENDOR - 2018-06-16 13:23:37 --> Vendor Louout : {"Email":"rahulcueserve16@gmail.com","Time":"2018-06-16 13:23 PM","IP Address":"203.88.158.139"}
VENDOR - 2018-06-16 13:23:53 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-06-16 13:23 PM","IP Address":"203.88.158.139"}
