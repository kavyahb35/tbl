<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ADMIN - 2018-07-26 07:02:30 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-26 07:02 AM","IP Address":"37.210.246.210"}
ADMIN - 2018-07-26 07:54:21 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-26 07:54 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-26 10:53:48 --> vendor login : {"Email":"joy.vidal16@gmail.com","Time":"2018-07-26 10:53 AM","IP Address":"37.210.246.210"}
VENDOR - 2018-07-26 10:56:45 --> vendor login : {"Email":"joy.vidal16@gmail.com","Time":"2018-07-26 10:56 AM","IP Address":"37.210.246.210"}
ADMIN - 2018-07-26 13:25:02 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-26 13:25 PM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-26 13:31:46 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-26 13:31 PM","IP Address":"203.88.158.139"}
