<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

VENDOR - 2018-07-02 08:14:31 --> Vendor Louout : {"Email":"sumit@cueserve.com","Time":"2018-07-02 08:14 AM","IP Address":"203.88.158.139"}
ADMIN - 2018-07-02 10:20:39 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-02 10:20 AM","IP Address":"203.88.158.139"}
ADMIN - 2018-07-02 10:22:42 --> Admin Logout : {"Email":"admin@gmail.com","Time":"2018-07-02 10:22 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-02 10:23:44 --> vendor login : {"Email":"laurencegarcia304@gmail.com","Time":"2018-07-02 10:23 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-02 10:26:28 --> Vendor Louout : {"Email":"laurencegarcia304@gmail.com","Time":"2018-07-02 10:26 AM","IP Address":"203.88.158.139"}
ADMIN - 2018-07-02 10:58:47 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-02 10:58 AM","IP Address":"37.210.115.147"}
ADMIN - 2018-07-02 11:47:30 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-02 11:47 AM","IP Address":"37.210.115.147"}
