<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

VENDOR - 2018-07-11 04:47:56 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-11 04:47 AM","IP Address":"203.88.158.139"}
ADMIN - 2018-07-11 05:03:08 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-11 05:03 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-11 06:24:28 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-07-11 06:24 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-11 06:41:18 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-11 06:41 AM","IP Address":"37.210.115.147"}
VENDOR - 2018-07-11 08:50:42 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-11 08:50 AM","IP Address":"37.210.115.147"}
VENDOR - 2018-07-11 08:50:54 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-07-11 08:50 AM","IP Address":"37.210.115.147"}
VENDOR - 2018-07-11 08:54:21 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-11 08:54 AM","IP Address":"37.210.115.147"}
ADMIN - 2018-07-11 09:06:40 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-11 09:06 AM","IP Address":"37.210.115.147"}
VENDOR - 2018-07-11 12:45:58 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-11 12:45 PM","IP Address":"89.211.251.141"}
