<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

CUSTOMER - 2018-07-20 10:01:40 --> Customer login : {"Email":"rahulcueserve6@gmail.com","Time":"2018-07-20 10:01 AM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-07-20 10:02:08 --> Customer Louout : {"Email":"rahulcueserve6@gmail.com","Time":"2018-07-20 10:02 AM","IP Address":"203.88.158.139"}
