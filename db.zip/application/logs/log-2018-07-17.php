<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ADMIN - 2018-07-17 10:11:42 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-17 10:11 AM","IP Address":"178.153.244.244"}
VENDOR - 2018-07-17 11:00:50 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-17 11:00 AM","IP Address":"178.153.244.244"}
CUSTOMER - 2018-07-17 13:55:49 --> Customer login : {"Email":"rahulcueserve6@gmail.com","Time":"2018-07-17 13:55 PM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-07-17 13:56:41 --> Customer Louout : {"Email":"rahulcueserve6@gmail.com","Time":"2018-07-17 13:56 PM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-17 13:56:55 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-17 13:56 PM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-17 13:58:31 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-07-17 13:58 PM","IP Address":"203.88.158.139"}
ADMIN - 2018-07-17 13:58:48 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-17 13:58 PM","IP Address":"203.88.158.139"}
ADMIN - 2018-07-17 14:05:16 --> Admin Logout : {"Email":"admin@gmail.com","Time":"2018-07-17 14:05 PM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-17 14:05:31 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-17 14:05 PM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-17 14:08:06 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-07-17 14:08 PM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-07-17 14:09:24 --> Customer login : {"Email":"laurencegarcia304@gmail.com","Time":"2018-07-17 14:09 PM","IP Address":"203.88.158.139"}
