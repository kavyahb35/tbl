<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ADMIN - 2018-06-26 11:10:43 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-06-26 11:10 AM","IP Address":"203.88.158.139"}
ADMIN - 2018-06-26 11:12:04 --> Admin Logout : {"Email":"admin@gmail.com","Time":"2018-06-26 11:12 AM","IP Address":"203.88.158.139"}
ADMIN - 2018-06-26 11:12:09 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-06-26 11:12 AM","IP Address":"203.88.158.139"}
ADMIN - 2018-06-26 11:13:02 --> Admin Logout : {"Email":"admin@gmail.com","Time":"2018-06-26 11:13 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-06-26 11:14:00 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-06-26 11:14 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-06-26 11:21:54 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-06-26 11:21 AM","IP Address":"37.211.153.151"}
ADMIN - 2018-06-26 11:23:47 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-06-26 11:23 AM","IP Address":"37.211.153.151"}
VENDOR - 2018-06-26 11:25:01 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-06-26 11:25 AM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-06-26 12:00:00 --> Customer Louout : {"Email":"nirmalchauhan125@gmail.com","Time":"2018-06-26 12:00 PM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-06-26 12:00:23 --> Customer Louout : {"Email":"nirmalchauhan125@gmail.com","Time":"2018-06-26 12:00 PM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-06-26 12:03:51 --> Customer Louout : {"Email":"nirmalchauhan125@gmail.com","Time":"2018-06-26 12:03 PM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-06-26 12:08:07 --> Customer Louout : {"Email":"rahulcueserve6@gmail.com","Time":"2018-06-26 12:08 PM","IP Address":"203.88.158.139"}
ADMIN - 2018-06-26 12:17:15 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-06-26 12:17 PM","IP Address":"203.88.158.139"}
VENDOR - 2018-06-26 12:19:45 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-06-26 12:19 PM","IP Address":"203.88.158.139"}
VENDOR - 2018-06-26 12:37:06 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-06-26 12:37 PM","IP Address":"203.88.158.139"}
ADMIN - 2018-06-26 13:09:01 --> Admin Logout : {"Email":"admin@gmail.com","Time":"2018-06-26 13:09 PM","IP Address":"37.211.153.151"}
CUSTOMER - 2018-06-26 13:29:13 --> Customer Louout : {"Email":null,"Time":"2018-06-26 13:29 PM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-06-26 13:30:02 --> Customer Louout : {"Email":null,"Time":"2018-06-26 13:30 PM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-06-26 13:35:27 --> Customer Louout : {"Email":null,"Time":"2018-06-26 13:35 PM","IP Address":"203.88.158.139"}
