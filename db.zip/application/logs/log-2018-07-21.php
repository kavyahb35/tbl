<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ADMIN - 2018-07-21 06:22:37 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-21 06:22 AM","IP Address":"178.153.244.244"}
VENDOR - 2018-07-21 06:44:39 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-21 06:44 AM","IP Address":"178.153.244.244"}
