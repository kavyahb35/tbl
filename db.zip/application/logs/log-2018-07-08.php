<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ADMIN - 2018-07-08 11:13:58 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-08 11:13 AM","IP Address":"37.210.115.147"}
VENDOR - 2018-07-08 13:54:10 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-08 13:54 PM","IP Address":"37.210.115.147"}
ADMIN - 2018-07-08 18:43:49 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-08 18:43 PM","IP Address":"37.210.136.87"}
VENDOR - 2018-07-08 20:00:43 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-08 20:00 PM","IP Address":"37.210.136.87"}
