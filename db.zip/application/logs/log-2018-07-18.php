<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ADMIN - 2018-07-18 04:28:17 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-18 04:28 AM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-07-18 04:30:44 --> Customer login : {"Email":"rahulcueserve6@gmail.com","Time":"2018-07-18 04:30 AM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-07-18 04:33:57 --> Customer Louout : {"Email":"rahulcueserve6@gmail.com","Time":"2018-07-18 04:33 AM","IP Address":"203.88.158.139"}
ADMIN - 2018-07-18 04:34:28 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-18 04:34 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-18 04:36:07 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-18 04:36 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-18 04:38:00 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-18 04:38 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-18 07:18:38 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-07-18 07:18 AM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-07-18 07:18:52 --> Customer login : {"Email":"rahulcueserve6@gmail.com","Time":"2018-07-18 07:18 AM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-07-18 07:24:41 --> Customer Louout : {"Email":"rahulcueserve6@gmail.com","Time":"2018-07-18 07:24 AM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-07-18 07:25:00 --> Customer login : {"Email":"rahulcueserve6@gmail.com","Time":"2018-07-18 07:25 AM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-07-18 07:28:16 --> Customer Louout : {"Email":"rahulcueserve6@gmail.com","Time":"2018-07-18 07:28 AM","IP Address":"203.88.158.139"}
VENDOR - 2018-07-18 07:28:26 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-18 07:28 AM","IP Address":"203.88.158.139"}
CUSTOMER - 2018-07-18 07:31:48 --> Customer login : {"Email":"joy.vidal16@gmail.com","Time":"2018-07-18 07:31 AM","IP Address":"178.153.244.244"}
ADMIN - 2018-07-18 08:19:02 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-18 08:19 AM","IP Address":"178.153.244.244"}
VENDOR - 2018-07-18 08:31:30 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-18 08:31 AM","IP Address":"178.153.244.244"}
VENDOR - 2018-07-18 08:33:44 --> vendor login : {"Email":"bhavna@cueserve.com","Time":"2018-07-18 08:33 AM","IP Address":"178.153.244.244"}
VENDOR - 2018-07-18 10:51:02 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-07-18 10:51 AM","IP Address":"178.153.244.244"}
CUSTOMER - 2018-07-18 10:52:06 --> Customer login : {"Email":"joy.vidal16@gmail.com","Time":"2018-07-18 10:52 AM","IP Address":"178.153.244.244"}
CUSTOMER - 2018-07-18 12:41:48 --> Customer Louout : {"Email":"joy.vidal16@gmail.com","Time":"2018-07-18 12:41 PM","IP Address":"178.153.244.244"}
VENDOR - 2018-07-18 13:39:59 --> Vendor Louout : {"Email":"bhavna@cueserve.com","Time":"2018-07-18 13:39 PM","IP Address":"178.153.244.244"}
