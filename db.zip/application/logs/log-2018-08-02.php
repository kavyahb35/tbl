<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ADMIN - 2018-08-02 04:24:36 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-08-02 04:24 AM","IP Address":"203.88.158.139"}
ADMIN - 2018-08-02 11:43:17 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-08-02 11:43 AM","IP Address":"37.210.246.210"}
