<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ADMIN - 2018-07-14 10:40:07 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-14 10:40 AM","IP Address":"178.153.244.244"}
ADMIN - 2018-07-14 13:35:15 --> Admin login : {"Email":"admin@gmail.com","Time":"2018-07-14 13:35 PM","IP Address":"178.153.244.244"}
